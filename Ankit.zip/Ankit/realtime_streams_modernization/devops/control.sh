#!/bin/bash

#Appending '/' at the end
config_location="$1/"
env="$2"
module="$3"
operation="$4"
time_in_seconds=250
#For parsing yaml helper files

###########YAML PARSING LOGIC#############################
function yaml() {
python3 -c "import yaml;print(yaml.safe_load(open('$1'))$2)"
}
##########################################################


#Checking for existence of pipeline.yaml config file
######File Checks#########################################
files=$(find "$config_location" -name "pipeline.yaml")
if [[ $files == "" ]]; then
  echo "Configuration file pipeline.yaml missing ! Exiting "
  exit 1
fi
echo "File found: $files"
#num_files=$(echo "$files" | wc -l)

if [ -e "$files" ]; then
  echo "Configuration file exists"
fi




#if [ "$num_files" -eq 1 ]; then
#  if [[ "$files" =~ "pipeline" ]]; then
#    mv "$files" pipeline.yaml
#    echo "Files renamed !"
#  fi
#else
#  echo "Multiple matches found exiting !"
#  exit 1
#fi

#if [ -n "$files" ]; then
# echo "Hello"
# mv "$files" "$(dirname "$files")/pipeline.yaml"
# echo "Files renamed"
#fi

######File Checks#########################################


########VALIDATING pipeline.yaml##########################
#VALUE1=$(yaml $config_location/job.yaml "['details']['projectID']")
jobDeclared=$(yaml $config_location/pipeline.yaml "['jobList']")
totalJobs=$(yaml $config_location/pipeline.yaml "['totalJobs']")
templateType=$(yaml $config_location/pipeline.yaml "['templateType']")
IFS=',' read -ra jobList <<< "$jobDeclared"
job_declared_count=${#jobList[@]}

echo "Job list declared: $jobDeclared"
echo "Total job number of job declared: $totalJobs"
echo "Total no of jobs found: $job_declared_count"
if [[ $totalJobs != "$job_declared_count" ]]; then
  echo " Incorrect declaration in pipeline.yaml config. Please check and correct it. Exiting"
  exit 1
fi

function check_classic_config_files() {
  for filename in "${jobList[@]}"; do
    filename_with_extension="${config_location}${filename%.yaml}.yaml"
    echo "File: $filename_with_extension"
    if [ ! -e "$filename_with_extension" ]; then
      echo "Config files dont exist!"
      return 1
    fi
  done
  return 0
}

#function check_flex_config_files(){
#  local env="$1"
#  local config_location="$2"
#  local index="$3"
#  yaml_file="runner_${env}.yaml"
#  found=$(find "$config_location" -iname "${yaml_file}")
#
#  if [[ $found == "" ]]; then
#    echo "Configuration file ${yaml_file} missing ! Exiting "
#    exit 1
#  fi
#
#
#  local counter=1
#
#  while [ $counter -le $index ]; do
#    elements_to_search+=("job_$counter:")
#    ((counter++))
#  done
#
#  elements_to_search+=("build:")
#  ((counter++))
#
#  yaml_file="${config_location}${yaml_file}"
#  echo "$yaml_file"
#
#  for i in "${elements_to_search[@]}"; do
#    # echo "$i"
#    if grep -q "${i}" "$yaml_file"; then
#     echo "${i} found"
#    else
#      echo "Format of runner_dev.yaml incorrect. Exiting !"
#      exit 1
#    fi
#  done
##  return 0
#}

function check_flex_config_files(){
  local env="$1"
  local config_location="$2"
  local index="$3"
  yaml_file="runner_${env}.yaml"
  found=$(find "$config_location" -iname "${yaml_file}")

  if [[ $found == "" ]]; then
    echo "Configuration file ${yaml_file} missing ! Exiting "
    exit 1
  fi

  for dfjobs in "${jobList[@]}"; do
    job1=$(yaml $config_location/runner_dev.yaml "['${dfjobs}']")
    echo "$job1"
  done
#  local counter=1
#
#  while [ $counter -le $index ]; do
#    elements_to_search+=("job_$counter:")
#    ((counter++))
#  done
#
#  elements_to_search+=("build:")
#  ((counter++))
#
#  yaml_file="${config_location}${yaml_file}"
#  echo "$yaml_file"
#
#  for i in "${elements_to_search[@]}"; do
#    # echo "$i"
#    if grep -q "${i}" "$yaml_file"; then
#     echo "${i} found"
#    else
#      echo "Format of runner_dev.yaml incorrect. Exiting !"
#      exit 1
#    fi
#  done
#  return 0
}

function check_batch_config_files(){
  local env="$1"
  local config_location="$2"
  local index="$3"
  yaml_file="runner_${env}.yaml"
  found=$(find "$config_location" -iname "${yaml_file}")

  if [[ $found == "" ]]; then
    echo "Configuration file ${yaml_file} missing ! Exiting "
    exit 1
  fi


  local counter=1

  while [ $counter -le $index ]; do
    elements_to_search+=("job_$counter:")
    ((counter++))
  done

  elements_to_search+=("build:")
  ((counter++))

  yaml_file="${config_location}${yaml_file}"
  echo "$yaml_file"

  for i in "${elements_to_search[@]}"; do
    # echo "$i"
    if grep -q "${i}" "$yaml_file"; then
     echo "${i} found"
    else
      echo "Format of ${yaml_file} incorrect. Exiting !"
      exit 1
    fi
  done
#  return 0
}





if [[ "$templateType" == "classic" ]]; then
  if check_classic_config_files; then
    echo "Resource files are valid !"
  else
    echo "Resource files are not valid !"
    exit 1
  fi
else
  if [[ "$templateType" == "flex" ]]; then
    check_flex_config_files "dev" "${config_location}" "${totalJobs}"
    echo "Validations passed !"
    echo "Template is flex !"
  fi

  if [[ "$templateType" == "batch" ]]; then
      check_batch_config_files "dev" "${config_location}" "${totalJobs}"
      echo "Validations passed !"
      echo "Template is flex !"
    fi
fi

########VALIDATING pipeline.yaml##########################



function check_job_status() {
    gcloud dataflow jobs describe ${job_id} --format='value(currentState)' --region us-east4
}
function drain_dataflow_job() {
    gcloud dataflow jobs drain ${job_id} --region us-east4
}
index=0

echo "Operation to perform on Module: $module is $operation"

while [ $index -lt ${#jobList[@]} ];do
    job_id=$(gcloud dataflow jobs list --region us-east4 | grep "${jobList[index]}" | awk '{print $1 }' | awk 'NR==1 {print}')
    echo "${job_id}"
    job_status=$(check_job_status)
    if [[ "${job_status}" == "JOB_STATE_RUNNING" ]]; then
        echo "Found earlier version of ${jobList[index]} Dataflow job running. Attempting to drain."
        # Drain the Dataflow job
        drain_dataflow_job
    fi
    ((index++))

done
index=0


while [ $index -lt ${#jobList[@]} ] && [ $time_in_seconds -gt 0 ];do
    echo "${jobList[index]}"
    job_id=$(gcloud dataflow jobs list --region us-east4 | grep "${jobList[index]}" | awk '{print $1 }' | awk 'NR==1 {print}')

    job_status=$(check_job_status)

    if [[ "${job_status}" == "JOB_STATE_DRAINING" ]]; then
        if [[ $((time_in_seconds % 5 )) -eq 0 ]]; then
            echo "Previous version of Dataflow job ${job_id} is still Draining. Waiting for it to drain completely."
        fi
        ((time_in_seconds--))
        sleep 1
    else
        echo "Dataflow job ${jobList[index]} is not running! Checking if we have other instance running."
        ((index++))
    fi
        # Drain the Dataflow job
        #drain_dataflow_job



done

if [ $index -eq ${#jobList[@]} ]; then
    echo "Previous version scan is completed. Ok to launch new job now"
fi


if [[ time_in_seconds -eq 0 ]]; then
        echo "Wait limit exceeded."
        echo "Debug this situation manually. Pipeline is exiting"
        exit 1
fi



