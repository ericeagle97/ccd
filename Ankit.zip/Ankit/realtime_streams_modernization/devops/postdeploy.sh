#!/bin/bash

#csv_file="/vzwhome/mishav9/artifact_dwnld/a.csv"

config_location=$1
echo $config_location
cd $config_location
ls -lrt
job_list=()
time_in_seconds=60



 parsed_job_list=$(awk -F ',' 'NR > 1 {print $1}' jobSubmission.csv)

 readarray -t job_list <<< "$parsed_job_list"
 echo "Parsed value in the array"
 echo "${job_list[@]}"



 function check_job_status() {
     gcloud dataflow jobs describe ${job_id} --format='value(currentState)' --region us-east4
 }

 index=0



 while [ $index -lt ${#job_list[@]} ] && [ $time_in_seconds -gt 0 ];do
     job_id=$(gcloud dataflow jobs list --region us-east4 | grep "${job_list[index]}" | awk '{print $1 }' | awk 'NR==1 {print}')
     #echo "$job_id"
     job_status=$(check_job_status)

     if [[ "${job_status}" == "JOB_STATE_RUNNING" ]]; then
#         if [[ $((time_in_seconds % 5 )) -eq 0 ]]; then
#             echo "Dataflow job ${job_list[index]} is Running. Ok!"
#         fi
         echo "Dataflow job ${job_list[index]} with $job_id is Running. Ok!"
         ((index++))
     fi
     if [[ "${job_status}" != "JOB_STATE_RUNNING" ]]; then
         echo "Dataflow job ${job_list[index]} with $job_id is Not Running. Waiting for it to kick off !"
         echo $time_in_seconds
         ((time_in_seconds--))
         sleep 1
     fi
         # Drain the Dataflow job
         #drain_dataflow_job



 done

 if [ $index -eq ${#job_list[@]} ]; then
     echo "End of job submission list."
     echo "All the listed jobs in jobSubmission.csv has been started !"
 fi

 #echo $time_in_seconds

 if [[ time_in_seconds -eq 0 ]]; then
         echo "Wait limit exceeded."
         echo "Job ${job_list[index]} is not able to run. Inspect it through gcp web console. Exiting the pipeline !"
         exit 1
 fi


# echo "Bye"