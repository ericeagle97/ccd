#!/bin/bash

#csv_file="/vzwhome/mishav9/artifact_dwnld/a.csv"
config_location=$1
cd $config_location
ls -lrt
job_list=()
time_in_seconds=250

#searching for jobsubmission csv file
file_pattern="*.csv"
match_files=($file_pattern)
matching_files=()

#Checking if jobSubmission.csv exists
files=$(find "$config_location" -iname "jobSubmission.csv")
echo "$files"
num_files=$(echo "$files" | wc -l)
if [ "$num_files" -eq 1 ]; then
  if [[ "$files" =~ "jobsubmission" ]]; then
    mv "$files" jobSubmission.csv
    echo "Files renamed !"
  fi
else
  echo "Multiple matches found exiting !"
  exit 1
fi


#file_pattern="*.csv"
#match_files=($file_pattern)
#if [ ${#match_files[@]} -eq 1 ]; then
#    echo "One file match found"
#    echo "The file is ${match_files[0]}"
#    if [[ ${match_files[0]} != "jobSubmission.csv" ]]; then
#      mv ${match_files[0]} jobSubmission.csv
#    fi
#elif [ ${#match_files[@]} -eq 0 ]; then
#    echo "No file match"
#else
#    echo "Multiple matches found! Exiting"
#    echo "${match_files[@]}"
#fi


parsed_job_list=$(awk -F ',' 'NR > 1 {print $1}' jobSubmission.csv)

readarray -t job_list <<< "$parsed_job_list"
echo "Parsed value in the array"
echo "${job_list[@]}"



function check_job_status() {
    gcloud dataflow jobs describe ${job_id} --format='value(currentState)' --region us-east4
}
function drain_dataflow_job() {
    gcloud dataflow jobs drain ${job_id} --region us-east4
}
index=0

echo "Checking if Previous version of dataflow job is running "

while [ $index -lt ${#job_list[@]} ];do
    job_id=$(gcloud dataflow jobs list --region us-east4 | grep "${job_list[index]}" | awk '{print $1 }' | awk 'NR==1 {print}')
    echo "${job_id}"
    job_status=$(check_job_status)
    if [[ "${job_status}" == "JOB_STATE_RUNNING" ]]; then
        echo "Found earlier version of ${job_list[index]} Dataflow job running. Attempting to drain."
        # Drain the Dataflow job
        drain_dataflow_job
    fi
    ((index++))

done
index=0


while [ $index -lt ${#job_list[@]} ] && [ $time_in_seconds -gt 0 ];do
    echo "${job_list[index]}"
    job_id=$(gcloud dataflow jobs list --region us-east4 | grep "${job_list[index]}" | awk '{print $1 }' | awk 'NR==1 {print}')

    job_status=$(check_job_status)

    if [[ "${job_status}" == "JOB_STATE_DRAINING" ]]; then
        if [[ $((time_in_seconds % 5 )) -eq 0 ]]; then
            echo "Previous version of Dataflow job ${job_id} is still Draining. Waiting for it to drain completely."
        fi
        ((time_in_seconds--))
        sleep 1
    else
        echo "Dataflow job ${job_list[index]} is not running! Checking if we have other instance running."
        ((index++))
    fi
        # Drain the Dataflow job
        #drain_dataflow_job



done

if [ $index -eq ${#job_list[@]} ]; then
    echo "Previous version scan is completed. Ok to launch new job now"
fi


if [[ time_in_seconds -eq 0 ]]; then
        echo "Wait limit exceeded."
        echo "Debug this situation manually. Pipeline is exiting"
        exit 1
fi
