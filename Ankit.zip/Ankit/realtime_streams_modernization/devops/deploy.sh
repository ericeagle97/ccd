#!/bin/bash
config_location="$1/config/"
JAR_VALUE="$1"
ENV="$2"
FLEX_CONFIG_FILE="runner_$ENV.yaml"
chmod +x $JAR_VALUE/rt*
###########YAML PARSING LOGIC#############################
function yaml() {
python3 -c "import yaml;print(yaml.safe_load(open('$1'))$2)"
}
##########################################################

jobDeclared=$(yaml "$config_location"/pipeline.yaml "['jobList']")
module=$(yaml "$config_location"/pipeline.yaml "['module']")
templateType=$(yaml "$config_location"/pipeline.yaml "['templateType']")
totalJobs=$(yaml $config_location/pipeline.yaml "['totalJobs']")
IFS=',' read -ra jobList <<< "$jobDeclared"
job_declared_count=${#jobList[@]}


function trim_string() {
    input="$1"
    trimmed=$(echo "$input" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
    trimmed_no_space=$(echo "$trimmed"| tr -s ' ')
    echo "$trimmed_no_space"
}


if [[ "$templateType" == "classic" ]]; then
 echo "Classic ?"
 for jobName in "${jobList[@]}"; do
     yaml_config="./${config_location}${jobName%.yaml}.yaml"
     echo "File: $yaml_config"
     if [ ! -e "$yaml_config" ]; then
       echo "Config files doesn't exist!"
       return 1
     fi
     echo "$jobName"
     gcs_template_loc_1=$(grep -o 'templateLocation:.*' "$yaml_config" | awk '{print $2}')
     gcs_staging_loc_1=$(grep -o 'stagingLocation:.*' "$yaml_config" | awk '{print $2}')
     gcs_template_loc=$(trim_string "$gcs_template_loc_1")
     gcs_staging_loc=$(trim_string "$gcs_staging_loc_1")
     pwd
#     chmod +x "${}config_location*.yaml"
     echo "$gcs_staging_loc"
     echo "$gcs_template_loc"
     echo "$1"
     echo "$module"
#     cd -;ls -ltr
      echo "The location is:"
      pwd; ls -lrt

     java -DconfigPath="$1/config/" -DjobName="$jobName" -DerrorFlag=true -Denvironment=GCP -jar "$1/$1.jar"

     gcloud dataflow jobs run "$jobName" --gcs-location="$gcs_template_loc" --dataflow-kms-key=projects/vz-it-np-d0sv-vsadkms-0/locations/us-east4/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v --disable-public-ips --region=us-east4 --network=shared-np-east --subnetwork=https://www.googleapis.com/compute/v1/projects/vz-it-np-exhv-sharedvpc-228116/regions/us-east4/subnetworks/shared-np-east-green-subnet-2 --service-account-email=sa-dev-gh2v-app-rtstdo-0@vz-it-np-gh2v-dev-rtstdo-0.iam.gserviceaccount.com --staging-location="$gcs_staging_loc" --enable-streaming-engine --worker-machine-type=c2d-standard-2
   done
 fi

#if [[ "$templateType" == "flex" ]]; then
#  echo "flex ?"
#  build_cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['build']")
#  JAR_VALUE="$JAR_VALUE/$JAR_VALUE.jar"
#  echo "JAR_VALUE"
#  JAR_VALUE_ESCAPED=$(printf '%s\n' "$JAR_VALUE" | sed -e 's/[]\/$*.^[]/\\&/g')
#  echo "$build_cmd"
#
#  if [[ $build_cmd == *"\${JAR}"* ]]; then
#    echo "Match found !"
#    build_cmd=$( echo "$build_cmd" | sed "s/\${JAR}/${JAR_VALUE_ESCAPED}/g")
#    # build="${build//\${JAR}/${JAR_VALUE}}"
#  fi
#  echo "$build_cmd"
#
#  if [ -n "$build_cmd" ]; then
#   eval "$build_cmd"
#  fi
#  counter=1
#  while [ "$counter" -le $totalJobs ]; do
#    cmd_string="job_${counter}"
#    cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['${cmd_string}']")
#    eval "$cmd"
#    ((counter++))
#  done
#fi

if [[ "$templateType" == "flex" ]]; then
  echo "flex ?"
  build_cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['build']")
  JAR_VALUE="$JAR_VALUE/$JAR_VALUE.jar"
  echo "JAR_VALUE"
  JAR_VALUE_ESCAPED=$(printf '%s\n' "$JAR_VALUE" | sed -e 's/[]\/$*.^[]/\\&/g')
  echo "$build_cmd"

  if [[ $build_cmd == *"\${JAR}"* ]]; then
    echo "Match found !"
    build_cmd=$( echo "$build_cmd" | sed "s/\${JAR}/${JAR_VALUE_ESCAPED}/g")
    # build="${build//\${JAR}/${JAR_VALUE}}"
  fi
  echo "$build_cmd"

  if [ -n "$build_cmd" ]; then
   eval "$build_cmd"
  fi
  counter=1
  for dfjobs in "${jobList[@]}"; do
      job1=$(yaml $config_location/$FLEX_CONFIG_FILE "['${dfjobs}']")
      eval "$job1"
      done
#  while [ "$counter" -le $totalJobs ]; do
#    cmd_string="job_${counter}"
#    cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['${cmd_string}']")
#    eval "$cmd"
#    ((counter++))
#  done
fi

if [[ "$templateType" == "batch" ]]; then
  echo "Batch ?"
  build_cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['build']")
  echo "$build_cmd"
  if [ -n "$build_cmd" ]; then
   eval "$build_cmd"
  fi
#  counter=1
#  while [ "$counter" -le $totalJobs ]; do
#    cmd_string="job_${counter}"
#    cmd=$(yaml $config_location/$FLEX_CONFIG_FILE "['${cmd_string}']")
#    eval "$cmd"
#    ((counter++))
#  done
fi

