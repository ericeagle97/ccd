# RTSTREAMS
Realtime streaming workflow based on GCP dataflow platform.


Jenkins Pipeline => [https://jenkins-vcg3.vpc.verizon.com/vcg3/job/WLS.GH2V.JENKINS.JOBS/job/WLS.GH2V.GCP.RT_DATAFLOW/](https://jenkins-vcg3.vpc.verizon.com/vcg3/job/WLS.GH2V.JENKINS.JOBS/job/WLS.GH2V.GCP.RT_DATAFLOW/)





