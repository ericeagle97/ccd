package com.verizon.dataindus.rtstreams.core.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
* LoggingUtils class logs the data to GCP logger when enabled by user at Template create using command line
*/


public class LoggingUtils 
{
	public  void loggingUtils(String strClassName,String strLog) 
	{
		/*Creating Object for logging*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(strClassName+".class");
		
		if(ExceptionsUtils.errorLog==true) 
		{
			GCPLOGGEROBJECT.info(strLog);
		}
		
	}


}