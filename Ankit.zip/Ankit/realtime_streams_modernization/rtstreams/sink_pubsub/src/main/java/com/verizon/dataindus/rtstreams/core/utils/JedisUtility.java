package com.verizon.dataindus.rtstreams.core.utils;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import redis.clients.jedis.Jedis;

public class JedisUtility {


	public static long jedisSADD(Jedis clientObj, String Key, String members) {
		long result = clientObj.sadd(Key,members);
		return result;
	}

	public static long jedisZADD(Jedis clientObj, String Key, Double score, String member) {
		long result = clientObj.zadd(Key, score, member);
		return result;
	}

	public static long jedisZADD(Jedis clientObj, String Key, Map<String,Double> scoreMembers) {
		long result = clientObj.zadd(Key, scoreMembers);
		return result;
	}

	public static long jedisHSet(Jedis clientObj, String Key, Map<String,String> value) {
		long result = clientObj.hset(Key, value);
		return result;
	}

	public static long jedisHSet(Jedis clientObj, String Key, String field, String value) {
		long result = clientObj.hset(Key, field, value);
		return result;
	}

	// HMset
	public static String jedisHMSet(Jedis clientObj, String Key, Map<String,String> value) {
		String result = clientObj.hmset(Key, value);
		return result;
	}
	
	public static String jedisHGet(Jedis clientObj, String Key, String field) {
		String result = clientObj.hget(Key, field);
		return result;		
	}

	public static String jedisSet(Jedis clientObj, String Key, String value) {
		String result = clientObj.set(Key, value);
		return result;
	}

	public static String jedisGet(Jedis clientObj, String Key) {
		String result = null;
		if (clientObj.exists(Key)) {	
			result = clientObj.get(Key);
		}
		return result;		
	}

	public static Boolean jedisHExists(Jedis clientObj, String Key, String field) {
		Boolean result = clientObj.hexists(Key,field);
		return result;		
	}


	public static Map<String, String> jedisHGetAll(Jedis clientObj, String Key) {
		Map<String, String> result = new HashMap<String,String> ();
		if (clientObj.exists(Key)) {
			result = clientObj.hgetAll(Key);
		}
		return result;	
	}


	public static Long jedisExpire(Jedis clientObj, String Key, Long TTL) {
		Long result = clientObj.expire(Key,TTL);
		return result;			
	}


	public static List<String> jedisZRangeByScore(Jedis clientObj, String Key, Double Min, Double Max) {
		List<String> result = clientObj.zrangeByScore(Key,Min,Max);
		return result;	
	}

	public static List<String> jedisZRangeByScore(Jedis clientObj, String Key, String Min, String Max) {
		List<String> result = clientObj.zrangeByScore(Key,Min,Max);
		return result;	
	}


}
