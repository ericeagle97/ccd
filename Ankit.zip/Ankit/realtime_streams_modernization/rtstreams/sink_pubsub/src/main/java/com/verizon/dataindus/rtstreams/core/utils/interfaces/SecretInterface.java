package com.verizon.dataindus.rtstreams.core.utils.interfaces;


/*
 * SecretInterface is a interface which has all methods defined in SecretInterfaceClass
 */

public interface SecretInterface 
{
	/*Interface to get ProjectId, SecretId, Verison as input to fetch secrets from GCP Secret Manager*/
	Object SecretGCP(String projectId, String secretId, String versionId) ;
}
