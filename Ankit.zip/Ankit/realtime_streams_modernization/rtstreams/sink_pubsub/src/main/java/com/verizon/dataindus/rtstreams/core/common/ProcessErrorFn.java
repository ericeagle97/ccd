package com.verizon.dataindus.rtstreams.core.common;

import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

public class ProcessErrorFn extends DoFn<KV<String, Map<String, String>>,String>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory.getLogger(ProcessErrorFn.class);
	final Counter failureParsingCounter = Metrics.counter(Constants.METRICS_JSON_PARSING, Constants.METRICS_COUNTER_FAILURE);

	@ProcessElement
	public void processElement(ProcessContext processContext){
		failureParsingCounter.inc();

		processContext.output(String.valueOf(processContext.element().getValue().toString()).toString());
		
	}

}
