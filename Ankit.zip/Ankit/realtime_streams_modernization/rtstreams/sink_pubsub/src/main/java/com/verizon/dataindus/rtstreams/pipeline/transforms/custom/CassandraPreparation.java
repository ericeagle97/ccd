package com.verizon.dataindus.rtstreams.pipeline.transforms.custom;

import java.io.EOFException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.beans.CassandraKeyBean;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.utils.impls.PreProcessingClass;


import redis.clients.jedis.Jedis;

public class CassandraPreparation extends DoFn<String, String> {

	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraPreparation.class);

	public static final TupleTag<String> cassValidTag = new TupleTag<String>() {};

	public static final TupleTag<String> cassInValidTag = new TupleTag<String>() {};

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {};

	private Jedis redisClientDoFnObject;

	/**
	 * Type - String, use - holds keystore password for redis connection
	 **/
	private String keystorePassword;

	/**
	 * Type - byte array, use - holds jks bytes for redis connection
	 **/
	private byte[] jksBytes;

	/**
	 * Type - byte string, use - holds secret payload for redis connection
	 **/
	private ByteString secretPayload;

	private final Counter edwFoundKeyCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, "edw_key_identifier_"+Constants.METRICS_COUNTER_FOUND);
	private final Counter edwUnFoundKeyCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, "edw_key_identifier_"+Constants.METRICS_COUNTER_UNFOUND);

	private final Counter validExistingKeyCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, "existing_key_identifier_"+Constants.METRICS_COUNTER_FOUND);

	private final Counter errorCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, "parsing_"+Constants.METRICS_COUNTER_FAILURE);

	private final Counter validCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_COUNTER_VALID);
	private final Counter inValidCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_COUNTER_INVALID);


	public CassandraPreparation(String keystorePassword, byte[] jksBytes,
			ByteString secretPayload) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;
	}

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility**/
		//redisClientDoFnObject = redis.redisConnector(projectId);
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword);
	}

	@ProcessElement
	public void processElement(ProcessContext c){
		// create object mapper instance
		ObjectMapper om = new ObjectMapper();
		// configure ignore unknown properties
		om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);

		//Calculate Load delay Metrics
		
		try {
			String inputData = c.element();

			CalculateDelayMetrics.CalculateMetrics(c.element());
			
			boolean cassCustWrite = false;
			boolean cassMTNOnlyWrite = false;
			boolean cassAggrProdWrite = false;
			boolean cassSessionWrite = false;
			boolean cassEventsCustWrite = false;
			boolean cassEventsSessionWrite = false;

			/*
			 * List<TimeDetails> timeDtlList = outputData.getTupleTimestamp(); TimeDetails
			 * timeDtlsObj = new TimeDetails() ;
			 * 
			 * timeDtlsObj.setJobName("AEPFeaturePipeline"); timeDtlsObj =
			 * CommonUtility.addJobTimestamp("IN", timeDtlsObj);
			 */

			String mtn = null;
			String custId = null;
			String acctNo = null;

			JsonNode requestBody = om.readTree(inputData);

			// Customer Table Writes with key - mtn,custid & accNo
			if (requestBody.has("mtn") && ! (requestBody.hasNonNull("keyValue") || requestBody.hasNonNull("keyName"))) 
			{
				mtn = requestBody.get("mtn").asText();
			}
			if (requestBody.has("custId")) 
			{
				custId = requestBody.get("custId").asText();
			} 
			else 
			{
				// MTN Table Writes with key - mtn and no custId or acctNo in the payload
				if (requestBody.hasNonNull("mtn") && ! (requestBody.hasNonNull("keyValue") || requestBody.hasNonNull("keyName"))
						&& mtn.matches(Constants.REGEX_MTN) && mtn.length() == 10
						)
				{
					cassMTNOnlyWrite = true;
				}
			}
			if (requestBody.has("acctNo")) 
			{
				acctNo = requestBody.get("acctNo").asText();
			}

			// Session Table Writes with key - sessionId
			if (requestBody.hasNonNull("sessionId")) 
			{
				cassSessionWrite = true;
			}

			// AggrProd Table Writes with key - aggrProdId (i.e. mtn) -- Fix 14/6/2024 -- aggrProdId can be any Identifier
			if (requestBody.hasNonNull("aggrProdId")) 
				//	&& (requestBody.get("aggrProdId").asText().matches(Constants.REGEX_MTN) 
					//		&& requestBody.get("aggrProdId").asText().length() == 10))
			{
				cassAggrProdWrite = true;
			}

			// Events Table Write with key - custid-acctno-mtn
			if (requestBody.hasNonNull("keyName") 
					&& requestBody.hasNonNull("keyValue") 
					&& requestBody.get("keyValue").asText().contains("-") ) 
			{
				String[] keys = requestBody.get("keyValue").asText().split("-");
				if (keys.length == 3) 
				{
					custId = keys[0];
					acctNo = keys[1];
					mtn = keys[2];
				}
			} 
			else if (requestBody.hasNonNull("keyName") 
					&& requestBody.hasNonNull("keyValue")) 
			{
				cassEventsSessionWrite = true;
			}


			// Key Lookup only for Customer Tables with key - mtn, custid & accNo
			if (! CommonUtility.isNullEmptyOrBlank(mtn) && !cassMTNOnlyWrite)
			{
				if (CommonUtility.isNullEmptyOrBlank(custId) 
						|| CommonUtility.isNullEmptyOrBlank(acctNo)) 
				{
					CassandraKeyBean kBean = new CassandraKeyBean(mtn,null,null);

					//EDW Redis Lookup check for Account and CustomerId if its MTN is available
					// e.g. key : EDW_1234567890 , value : 123456789-1
					kBean =  new PreProcessingClass().getCassandraKeyIdentifierFromRedis(kBean, redisClientDoFnObject);

					mtn = kBean.getMtn();
					custId = kBean.getCustomerId();
					acctNo = kBean.getAccountNo();

					if (acctNo != null && custId != null 
							&& mtn != null
							&& acctNo.matches(Constants.REGEX_MTN) 
							&& custId.matches(Constants.REGEX_MTN) 
							&& mtn.matches(Constants.REGEX_MTN) && mtn.length() == 10)
					{
						edwFoundKeyCounter.inc();
						cassCustWrite = true;
						cassEventsCustWrite = true;
					}
				} 
				else 
				{ // Existing valid Key Identifiers
					if (acctNo != null && custId != null 
							&& mtn != null
							&& acctNo.matches(Constants.REGEX_MTN) 
							&& custId.matches(Constants.REGEX_MTN) 
							&& mtn.matches(Constants.REGEX_MTN) && mtn.length() == 10)
					{
						validExistingKeyCounter.inc();
						cassCustWrite = true;
						cassEventsCustWrite = true;
					} else {
						edwUnFoundKeyCounter.inc();
					}
				}
			}

			/**All invalid scenarios for Cassandra insertion**/
			if(!cassCustWrite && !cassEventsCustWrite && !cassEventsSessionWrite && !cassMTNOnlyWrite && !cassSessionWrite && !cassAggrProdWrite) 
			{
				// Invalid Records for Cassandra Tables
				inValidCounter.inc();
				c.output(cassInValidTag, inputData);	
			} else {
				validCounter.inc();

				ObjectNode objectNode = (ObjectNode) requestBody;

				/** All Cassandra Customer Tables Writes with keys : mtn, custId and acctNo ***/
				if (cassCustWrite && ! requestBody.hasNonNull("keyName") 
						&& ! requestBody.hasNonNull("keyValue")) {
					objectNode.put("acctNo", acctNo);
					objectNode.put("custId", custId);
				} 
				/** Events Tables Writes with key : keyName, keyValue ***/
				else if (cassEventsCustWrite && requestBody.hasNonNull("keyName") 
						&& requestBody.hasNonNull("keyValue")) {
					//key - custid-acctno-mtn
					String keyVal = custId+"-"+acctNo+"-"+mtn;
					objectNode.put("keyValue", keyVal);
					objectNode.put("mtn", keyVal);
				}
				c.output(cassValidTag, requestBody.toString());
			}

		} 
		catch (Exception e) {
			errorCounter.inc();
			e.printStackTrace();
			c.output(deadLetter, c.element().toString());
		}
	}
	@Teardown
	public void teardown()
	{
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis =new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redisClientDoFnObject.close();
		redisClientDoFnObject.shutdown();
		redis.tearDown();
	}

}
