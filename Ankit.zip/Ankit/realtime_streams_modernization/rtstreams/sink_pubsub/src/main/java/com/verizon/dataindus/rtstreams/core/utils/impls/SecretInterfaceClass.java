package com.verizon.dataindus.rtstreams.core.utils.impls;

import java.io.IOException;
import com.google.cloud.secretmanager.v1.AccessSecretVersionResponse;
import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.cloud.secretmanager.v1.SecretVersionName;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.common.LoggingUtils;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;

public class SecretInterfaceClass implements SecretInterface
{
	public static Object objPayLoad;

	@Override
	public Object SecretGCP(String projectId, String secretId, String versionId)
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();

		/*Creating object form custom LoggingUtils class*/
		LoggingUtils loggingUtils = new LoggingUtils();

		/*
		 * Initialize client that will be used to send requests. 
		 * This client only needs to be created once, and can be reused for multiple requests. After completing all of your requests
		 *
		 */
		try (SecretManagerServiceClient client = SecretManagerServiceClient.create()) 
		{
			/*Fetches the secret object based on projectId and secretId and version number and store in payload object*/
			SecretVersionName secretVersionName = SecretVersionName.of(projectId, secretId, versionId);
			AccessSecretVersionResponse response = client.accessSecretVersion(secretVersionName);
			objPayLoad = response.getPayload().getData();
					//.toStringUtf8();

			loggingUtils.loggingUtils("SecretInterfaceClass", "Returning Secret Object "+secretId);

		}
		catch(IOException e) 
		{
			/*Throws an exception if unable to access secret or wrong secret name is passed */
			e.printStackTrace();
			objCustomExceptions.ioException("SecretInterfaceClass",e);
		}
		catch(Exception e) 
		{
			/* Throws an generic exception*/
			e.printStackTrace();
			objCustomExceptions.genericException("SecretInterfaceClass",e);
		}
		return objPayLoad;
	}

}
