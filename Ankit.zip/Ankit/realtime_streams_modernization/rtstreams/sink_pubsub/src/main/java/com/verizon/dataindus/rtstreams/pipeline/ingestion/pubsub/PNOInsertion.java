package com.verizon.dataindus.rtstreams.pipeline.ingestion.pubsub;

import java.util.Map;

import org.apache.beam.repackaged.core.org.apache.commons.lang3.StringUtils;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.values.PCollection;
import org.json.JSONObject;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.common.LoggingUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.PubsubIngestionOptions;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getPubsubReadConfigurations;

public class PNOInsertion {

	public void pnoInsertion(PubsubIngestionOptions options) {

		// Creates pipeline with custom pipeline options
		Pipeline pipeline = Pipeline.create(options);

		// Creating object for custom exception class
		ExceptionsUtils objCustomExceptions = new ExceptionsUtils();
		/* Creating object form custom LoggingUtils class */
		LoggingUtils loggingUtils = new LoggingUtils();

		// Create a map of Pubsub Attributes as keys and their respective configurations
		Map<String, JSONObject> pubsubAttrConfigMap = getPubsubReadConfigurations(options.getProjectId(),
				options.getPubsubIOReadConfigBucket(), options.getPubsubIOReadConfigFile(),
				options.getPubsubSubscription(), objCustomExceptions);
		try {

			/* Reading from PNO Cassandra Data Pubsub*/
			String sub = StringUtils.substringAfterLast(options.getPubsubSubscription(), "/");

			PCollection<PubsubMessage> pubsubData = pipeline.apply(
					String.format("Pubsub read from subscription - %s", sub),
					PubsubIO.readMessagesWithAttributes().fromSubscription(options.getPubsubSubscription()));

			/*
			 * PCollection<String> pubsubData =
			 * pipeline.apply(String.format("Pubsub read from subscription - %1$s",
			 * sub),PubsubIO.readStrings()
			 * .fromSubscription(options.getPubSubSubscription()));
			 */
			
			PCollection<String> retrySingleData = pipeline.apply("Pubsub read from retry Single subscription", PubsubIO
					.readStrings()
					.fromSubscription(options.getRetryPubSubSubscription()));
			
			PCollection<String> retryBulkData = pipeline.apply("Pubsub read from retry Bulk subscription", PubsubIO
					.readStrings()
					.fromSubscription(options.getRetryBulkPubSubSubscription()));

			/* Invoking Transformations required */
			//			new PNOInsertionTransform().downstreamProcess(pubsubData,options);
			SourceTransformLauncher processLauncher =new SourceTransformLauncher();

			/*Calling SourceProcessLauncher for transformations if any class*/ 
			processLauncher.sourceProcessLauncher(pubsubData, retrySingleData,retryBulkData, options,pubsubAttrConfigMap);
			pipeline.run();


			//.waitUntilFinish();
		}catch (Exception e) {
			e.printStackTrace();
			objCustomExceptions.errorPipeline("PubsubIngestion", e);
		}
	}
}
