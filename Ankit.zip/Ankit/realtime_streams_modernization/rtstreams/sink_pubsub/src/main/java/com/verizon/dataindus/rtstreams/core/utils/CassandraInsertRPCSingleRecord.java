package com.verizon.dataindus.rtstreams.core.utils;


import com.verizon.dataindus.rtstreams.core.constants.Constants;


import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.text.ParseException;
import java.util.HashMap;

import static com.verizon.dataindus.rtstreams.core.utils.IOUtility.insertData;

public class CassandraInsertRPCSingleRecord extends DoFn<String, String> implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertRPCSingleRecord.class);
	private String httpRequest;
	private String requestType;

	static HttpClient client;

	public static final TupleTag<String> deadLetterQueue = new TupleTag<String>() {
	};
	public static final TupleTag<String> responseSuccess = new TupleTag<String>() {
	};
	public static final TupleTag<String> retryRecords = new TupleTag<>() {
	};

	final Counter statusCode500 = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + "status500"+ "_" + Constants.METRICS_COUNTER_FAILURE);
	final Counter statusCode400 = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + "status400"+ "_" + Constants.METRICS_COUNTER_FAILURE);
	final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_RESPONSE + "_" + Constants.METRICS_COUNTER_SUCCESS);
	final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_RESPONSE + "_" + Constants.METRICS_COUNTER_FAILURE);

	final Counter failureApiCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + Constants.METRICS_COUNTER_FAILURE);


	public CassandraInsertRPCSingleRecord(String httpRequest, String requestType) {
		// TODO Auto-generated constructor stub
		this.httpRequest = httpRequest;
		this.requestType = requestType;
	}

	@Setup
	public void setup() {
		client = HttpClient.newHttpClient();
	}

	@Teardown
	public void teardown() {
		if (client != null) {
			client = null;
		}
	}


	@ProcessElement
	public void processElement(ProcessContext c) throws ParseException, IOException, InterruptedException {
		flush(c.element().toString(), c);
	}


	private void flush(String record, ProcessContext c) {
		HashMap<String, Object> batchDataReq = new HashMap<String, Object>();
		String request = "";
		//        CassandraInsertion insertData = new CassandraInsertion(client);
		try {
			batchDataReq.put("requestType", requestType);
			batchDataReq.put("keyAttributes", new JSONObject(record));
			request = new JSONObject(batchDataReq).toString();
			/** object of cassandra insertion library */

		} catch (Exception ex) {
			failureCounter.inc();
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			c.output(deadLetterQueue, c.element());
			return;
		}

		try {

			long StartTime = System.currentTimeMillis();
			/** send metadata and data of http request to  cassandra insertion library and stores the response to 'response' variable */
			HttpResponse<String> response = insertData(client, httpRequest, request);
			long EndTime = System.currentTimeMillis();
			long TimeTaken = EndTime - StartTime;

			if (response != null && response.statusCode() == 200 && response.body().toString().matches(Constants.REGEX_PNO_SUCCESS)) {
				successCounter.inc();
				c.output(request + "," + response.toString() + "," + TimeTaken);
			} else if (response != null) {
				if (response.statusCode() == 500
						|| response.statusCode() == 501 ||
						response.statusCode() == 502
						|| response.statusCode() == 503) {
					statusCode500.inc();
					c.output(retryRecords, request);
				} else {
					if (response.statusCode() == 400
							|| response.statusCode() == 401 ||
							response.statusCode() == 402
							|| response.statusCode() == 403) {
						statusCode400.inc();
					} else {
						failureCounter.inc();
					}
					c.output(deadLetterQueue, request + "," + response + "," + TimeTaken);
				}
			} else {
				failureCounter.inc();
				c.output(deadLetterQueue, request + "," + response.toString() + "," + TimeTaken);
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			failureApiCounter.inc();
			c.output(retryRecords, request);
			LOG.error(sw.toString());
		}

	}
}
