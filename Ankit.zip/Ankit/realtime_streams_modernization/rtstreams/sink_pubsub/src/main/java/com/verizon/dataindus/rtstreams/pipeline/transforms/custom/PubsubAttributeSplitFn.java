package com.verizon.dataindus.rtstreams.pipeline.transforms.custom;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.constants.Constants;

public class PubsubAttributeSplitFn extends DoFn<PubsubMessage, String> {

	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(PubsubAttributeSplitFn.class);

	public static final TupleTag<String> validTag = new TupleTag<String>() {};
	public static final TupleTag<String> inValidTag = new TupleTag<String>() {};

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {};

	/**
	 * Type - String, use - holds attribute names to read the Pubsub data for Cassandra Insertion
	 **/
	private String attributeName;

	public PubsubAttributeSplitFn(String attributeName) {
		this.attributeName = attributeName;
	}

	private final Counter errorCounter = Metrics.counter(Constants.METRICS_PREPROCESSING, "ParsingFailure");

	private final Counter validCounter = Metrics.counter(Constants.METRICS_PREPROCESSING, Constants.METRICS_COUNTER_VALID);
	//private final Counter inValidCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_COUNTER_INVALID);


	@ProcessElement
	public void processElement(ProcessContext c) throws IOException, InterruptedException 
	{
		PubsubMessage inputData = c.element();
		try {

			String inputString = new String(inputData.getPayload(), StandardCharsets.UTF_8);

			/** LOG.info("attribute : "+attributeName +  ",  inputData-Attri : "+ inputData.getAttribute(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE) 
			* + ", message : "+ inputString + ", attributeMaps : "+ inputData.getAttributeMap().toString());
			*/

			if (attributeName.equalsIgnoreCase(inputData.getAttribute(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE))) 
			{
				validCounter.inc();					
				c.output(inputString);
			} 
			/*
			 * else { inValidCounter.inc(); c.output(inValidTag,inputString); }
			 */
		}
		catch (Exception e) {
			errorCounter.inc();
			e.printStackTrace();
			c.output(deadLetter, new String(inputData.getPayload(), StandardCharsets.UTF_8));
		}

	}



}
