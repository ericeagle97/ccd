//package com.verizon.dataindus.rtstreams.core.lib;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.io.StringWriter;
//import java.net.URI;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//import java.util.UUID;
//
//import org.apache.kafka.common.resource.ResourceType;
//import org.slf4j.LoggerFactory;
//
//import com.verizon.dataindus.rtstreams.core.constants.Constants;
//
//public class CassandraInsertion
//{
//	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertion.class);
//
//	HttpClient client;
//
//	public CassandraInsertion(HttpClient client) {
//		this.client = client;
//	}
//
//	public HttpResponse<String> cassandraInsertion(String httpURL, String strRequestBody)
//	{
//		HttpResponse<String> response = null;
//		try
//		{
////		HttpClient client = HttpClient.newHttpClient();
//		HttpRequest request = null;
//
//		UUID uuid = UUID.randomUUID();
//		Long lLsb = Math.abs(uuid.getLeastSignificantBits());
//		//String val = ""+lLsb;
//		String val = "LT-" + lLsb;
//		request = HttpRequest.newBuilder()
//				.uri(URI.create(httpURL))
//				.headers(Constants.HTTP_REQUEST_PROP_CONTENT_TYPE,Constants.HTTP_REQUEST_CONTENT_JSON,
//						Constants.HTTP_REQUEST_PROP_CORRELATION_ID,val,
//						Constants.HTTP_REQUEST_PROP_ORIGINAL_SERVICE,Constants.HTTP_REQUEST_SERVICE_WW,
//						Constants.HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE,Constants.HTTP_REQUEST_SERVICE_WW)
//				.POST(HttpRequest.BodyPublishers.ofString(strRequestBody))
//				.build();
//			response = client.send(request,HttpResponse.BodyHandlers.ofString());
//		}
//		catch (InterruptedException e)
//		{
//				StringWriter sw = new StringWriter();
//				PrintWriter pw = new PrintWriter(sw);
//				e.printStackTrace(pw);
//				LOG.error(sw.toString());
//				return null;
//		}
//		catch (IOException e)
//		{
//				StringWriter sw = new StringWriter();
//				PrintWriter pw = new PrintWriter(sw);
//				e.printStackTrace(pw);
//				LOG.error(sw.toString());
//				return null;
//		}
//		catch (Exception e)
//		{
//				StringWriter sw = new StringWriter();
//				PrintWriter pw = new PrintWriter(sw);
//				e.printStackTrace(pw);
//				LOG.error(sw.toString());
//				return null;
//		}
//		return response;
//	}
//}


package com.verizon.dataindus.rtstreams.core.lib;

import com.verizon.dataindus.rtstreams.core.utils.CassandraInsertRPC;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import static com.verizon.dataindus.rtstreams.core.utils.IOUtility.insertData;

public class CassandraInsertion
{
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertion.class);

	HttpClient client;

	public CassandraInsertion(HttpClient client) {
		this.client = client;
	}

	public HttpResponse<String> cassandraInsertion(String httpURL, String strRequestBody, DoFn.ProcessContext c)
	{
		HttpResponse<String> response;
		try {
			response = insertData(client, httpURL, strRequestBody);

		} catch (Exception e) {
			c.output(CassandraInsertRPC.retryRecords, strRequestBody);

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			LOG.error(sw.toString());
			return null;
		}

		return response;
	}

	private HttpResponse<String> handleError(Throwable ex) {

		ex.printStackTrace();
		return null;
	}
}
