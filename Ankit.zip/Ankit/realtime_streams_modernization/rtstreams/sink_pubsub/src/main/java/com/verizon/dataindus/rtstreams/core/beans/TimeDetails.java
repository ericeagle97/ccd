package com.verizon.dataindus.rtstreams.core.beans;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable  
public class TimeDetails implements Serializable {

   @SerializedName("inTime")
   @Nullable
   String inTime;

   @SerializedName("outTime")
   @Nullable
   String outTime;

   @SerializedName("jobName")
   @Nullable
   String jobName;


    public void setInTime(String inTime) {
        this.inTime = inTime;
    }
    public String getInTime() {
        return inTime;
    }
    
    public void setOutTime(String outTime) {
        this.outTime = outTime;
    }
    public String getOutTime() {
        return outTime;
    }
    
    public void setJobName(String jobName) {
        this.jobName = jobName;
    }
    public String getJobName() {
        return jobName;
    }
    
}
