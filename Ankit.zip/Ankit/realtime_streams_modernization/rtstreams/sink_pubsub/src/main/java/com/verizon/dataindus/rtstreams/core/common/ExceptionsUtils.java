package com.verizon.dataindus.rtstreams.core.common;

import java.io.*;
import java.lang.reflect.InvocationTargetException;

import org.apache.kafka.common.KafkaException;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.storage.StorageException;

public class ExceptionsUtils  implements Serializable
{
	/*Custom error messages for Custom Exception logging*/
	private static final long serialVersionUID = 1L;
	public static final String fileNotfound="File not found in specified path  ";
	public static final String parsingText="Error in parsing text: ";
	public static final String JobName="JobName";
	public static final String error="Error";
	public static final String status="PipelineStatus";
	public static final String running="running";
	public static final String timestamp="TimeStamp";
	public static final String IOexception="IO Exception at: ";
	public static final String exception= "Exception in creating http request";
	public static final String noMethod="No such method found or error in initiating with given Job Name: ";
	public static final String noClass="Provided JobName is not matching with existing class name: ";
	public static final String noObject="Error in Instantiation of class object for given jobName: ";
	public static final String illegalObjectAccess="Unable to access object";
	public static final String errorPipeline="Error in initilizing pipeline: ";
	public static final String interruptedException="Execution interupted:  ";
	public static final String arrayOutofBounds="Given argument is not valid";
	public static final String storageException = "StorageException: Exception while reading configuration file from GCS bucket.";
	public static final String jsonException = "JSONException: Exception while parsing JSON configuration file.";
	public static final String kafkaException = "Error while reading from Kafka";
	
	public static boolean errorLog=false;

	/*Generic exception is called where generic exception might occur*/
	public void genericException(String className, Exception e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//Exception e = new Exception();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(sw.toString());
	}

	/*NoClass exception is called where there might be wrong class name specified*/
	public void noClass(String className, ClassNotFoundException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//ClassNotFoundException classNotFoundException = new ClassNotFoundException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.noClass+className+"  "+sw.toString());
	}

	/*NoMethod exception is called where there might be wrong method name specified*/
	public void noMethod(String className, NoSuchMethodException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//NoSuchMethodException e =new NoSuchMethodException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.noMethod+sw.toString());
	}
	
	/*Creates a SecurityException with the specified cause and a detail message of (cause==null ? null : cause.toString()) (which typically contains the class and detail message of cause).*/
	public void securityException(String className, SecurityException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//NoSuchMethodException e =new NoSuchMethodException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(sw.toString());
	}
	
	/*InvocationTargetException is a checked exception that wraps an exception thrown by an invoked method or constructor. */
	public void invocationTargetException(String className, InvocationTargetException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//NoSuchMethodException e =new NoSuchMethodException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(sw.toString());
	}

	/*Illegal method exception is called where there might be wrong method name or mismatch in method name specified*/
	public void illegalMethod(String className, IllegalArgumentException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//IllegalArgumentException e =new IllegalArgumentException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.noMethod+sw.toString()); 
	}

	/*NoObject exception is called class object is not created */
	public void noObject(String className, InstantiationException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//InstantiationException e =new InstantiationException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.noObject+sw.toString()); 
	}

	/*ArrayIndexOutofBound exception is called when you pass incorrect number or null arguments*/
	public void ArrayIndexOutOfBounds(String className, ArrayIndexOutOfBoundsException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//ArrayIndexOutOfBoundsException e =new ArrayIndexOutOfBoundsException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.arrayOutofBounds+className+" "+sw.toString());
	}

	/*IllegaObjectAccess is called when trying to access class object with wrong scope or name*/
	public void illegalObjectAccess(String className, IllegalAccessException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//IllegalAccessException e =new IllegalAccessException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.illegalObjectAccess+sw.toString()); 
	}

	/*File not found is called when wrong file name or give file name is not matching*/
	public void fileNotFound(String className, FileNotFoundException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//FileNotFoundException e =new FileNotFoundException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.fileNotfound+sw.toString());
	}

	/*An IllegalAccessException is thrown when an application tries to reflectively create an instance */
	public void ioException(String className,IOException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//IOException e =new IOException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.IOexception+className+" "+sw.toString());
	}

	/*Thrown when a thread is waiting, sleeping, or otherwise occupied, and the thread is interrupted, either before or during the activity.*/
	public void interruptedException(String className, InterruptedException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//InterruptedException e =new InterruptedException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.interruptedException+className+" "+sw.toString());
	}

	/*Constructs a ParseException with the specified detail message and offset*/
	public void parseException(String className,java.text.ParseException e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			//java.text.ParseException e =new java.text.ParseException();
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.parsingText+className+" "+sw.toString());
	}

	/*Error Pipeline is called when there is an error in running pipeline*/
	public void errorPipeline(String className, Exception e) 
	{
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true) 
		{
			e.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.errorPipeline+className+" "+sw.toString());
	}
	
	public void storageException(String className, StorageException storageException) {
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true)
		{
			storageException.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.errorPipeline+className+" "+sw.toString());
	}

	public void jsonException(String className, JSONException jsonException) {
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true)
		{
			jsonException.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.errorPipeline+className+" "+sw.toString());
	}

	public void kafkaException(String className, KafkaException kafkaException) {
		/*For GCP logging LOG object can be used to write custom logs or metrics in GCP logger*/
		Logger GCPLOGGEROBJECT = LoggerFactory.getLogger(className+".class");
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		if(errorLog==true)
		{
			kafkaException.printStackTrace(pw);
		}
		GCPLOGGEROBJECT.error(ExceptionsUtils.errorPipeline+className+" "+sw.toString());
	}

}
