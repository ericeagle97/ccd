
package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import java.util.Map;
import java.util.Random;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.utils.*;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.GroupIntoBatches;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.transforms.WithKeys;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.json.JSONObject;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.PubsubIngestionOptions;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.CassandraPreparation;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.PubsubAttributeSplitFn;

public class PNOInsertionTransform {

	public void downstreamProcess(PCollection<PubsubMessage> validData, 
			PCollection<String> retrySingleData,PCollection<String> retryBulkData, PubsubIngestionOptions options, 
			Map<String,JSONObject> pubsubAttrConfigObjMap) 
	{

		boolean errorLog = false;
		SecretInterface objSecret = new SecretInterfaceClass();
		/*Creating object for custom exception class*/
		ExceptionsUtils exceptions=new ExceptionsUtils();


		try {
			/**
			 * Type - String, use - holds keystore password for redis connection
			 **/
			String keystorePassword = ((ByteString) objSecret.SecretGCP(options.getProjectId(),
					options.getKeystorePassword(), "latest")).toStringUtf8();

			/**
			 * Type - byte array, use - holds jks bytes for redis connection
			 **/
			byte[] jksBytes = ((ByteString) objSecret.SecretGCP(options.getProjectId()
					, options.getKeystoreFile(), "latest")).toByteArray();

			/**
			 * Type - byte string, use - holds secret payload for redis connection
			 **/
			ByteString secretPayload = (ByteString) objSecret.SecretGCP(options.getProjectId(),
					options.getSecretCredentials(), "latest");

			/**
			 * Process multiple Cassandra RequestType Insertions based on the configuration
			 * and the runtime parameter provided
			 **/
			for (String attribute : options.getPubsubAttributeNames().split(",")) 
			{
				
				JSONObject pubsubAttrConfigObj = pubsubAttrConfigObjMap.get(attribute);

				String outputTopic = pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_OUTPUTTOPIC);
				int windowDuration = pubsubAttrConfigObj.getInt(Constants.CONFIG_KEYWORD_WINDURATION);
				String filePath = pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_PATH);
				String fileName = pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_FILENAME);
				int numShards = pubsubAttrConfigObj.getInt(Constants.CONFIG_KEYWORD_NUMSHARDS);	
				// 22-02-2024
				String gcsOrPubSub = pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_GCSORPUBSUB);

				// Applying Filters for each attribute
				PCollectionTuple pubsubData = validData
						.apply(String.format("Splitting per Attribute - %s",attribute), 
								ParDo.of(new PubsubAttributeSplitFn(attribute))
								.withOutputTags(PubsubAttributeSplitFn.validTag, 
										TupleTagList.of(PubsubAttributeSplitFn.inValidTag)
										.and(PubsubAttributeSplitFn.deadLetter)));

				// Dead letters Sink for Invalid Records - GCS/PubSub 	
				IOUtility.deadLetterOptionalSink(gcsOrPubSub,
						pubsubData.get(PubsubAttributeSplitFn.inValidTag),
						outputTopic+"-invalid",windowDuration,filePath+"/invalid/",fileName,numShards);

				// Applying Cassandra Preprocessing by performing EDW Lookups
				PCollectionTuple cassProcessData = pubsubData.get(PubsubAttributeSplitFn.validTag)
						.apply(String.format("Cassandra Preparation - %s",attribute), 
								ParDo.of(new CassandraPreparation(
										keystorePassword, jksBytes, secretPayload))
								.withOutputTags(CassandraPreparation.cassValidTag, 
										TupleTagList.of(CassandraPreparation.cassInValidTag)
										.and(CassandraPreparation.deadLetter)));

				// Dead letters Sink for Invalid Records - GCS/PubSub 	
				IOUtility.deadLetterOptionalSink(gcsOrPubSub, 
						cassProcessData.get(CassandraPreparation.cassInValidTag),
						outputTopic+"-invalid",windowDuration,filePath+"/invalid/",fileName,numShards);

				PCollection<String> cassandraPNOSuccess = null;
				PCollection<String> cassandraPNOFailure = null;
				PCollection<String> cassandraRetryRecords = null;
				PCollection<String> cassandraInsertionTimeMetrics = null;

				int keySize = 0;
				int batchSize = 0;
				String retryTopicVar = "";

				if (pubsubAttrConfigObj.has(Constants.CONFIG_KEYWORD_KEYSIZE)) {
					keySize = pubsubAttrConfigObj.getInt(Constants.CONFIG_KEYWORD_KEYSIZE);
				}
				if (pubsubAttrConfigObj.has(Constants.CONFIG_KEYWORD_BATCHSIZE))
					batchSize = pubsubAttrConfigObj.getInt(Constants.CONFIG_KEYWORD_BATCHSIZE);

				// Cassandra Insertions
				if ((CommonUtility.isNullEmptyOrBlank(String.valueOf(keySize)) || keySize == 0 
						&& CommonUtility.isNullEmptyOrBlank(String.valueOf(batchSize)) || batchSize == 0 )
						&& ! pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_HTTPURL).contains("List")) 
				{
					// Single Cassandra Insertions
					PCollectionTuple cassandraTuple = cassProcessData.get(CassandraPreparation.cassValidTag)
							.apply(String.format("Cassandra Single Insertion - %s",attribute), 
									ParDo.of(new CassandraInsertRPCSingleRecord(
											pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_HTTPURL),
											pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_REQUESTTYPE)
											))
									.withOutputTags(CassandraInsertRPCSingleRecord.responseSuccess, 
											TupleTagList.of(CassandraInsertRPCSingleRecord.deadLetterQueue)
											.and(CassandraInsertRPCSingleRecord.retryRecords)
											));

					cassandraPNOSuccess = cassandraTuple.get(CassandraInsertRPCSingleRecord.responseSuccess);
					cassandraPNOFailure = cassandraTuple.get(CassandraInsertRPCSingleRecord.deadLetterQueue);
					cassandraRetryRecords = cassandraTuple.get(CassandraInsertRPCSingleRecord.retryRecords);
					retryTopicVar = "retry-single";

				} else {

					// Bulk Insertions
					int pnoKeySize = keySize;

					PCollectionTuple cassandraTuple = cassProcessData.get(CassandraPreparation.cassValidTag)
							.apply(String.format("Assign Random key - %s",attribute), WithKeys.of((SerializableFunction<String, Integer>) ignored -> new Random()
									.nextInt(pnoKeySize)).withKeyType(TypeDescriptors.integers()))
							.apply(String.format("Group into Batches - %s(%s)",String.valueOf(batchSize),attribute),GroupIntoBatches.ofSize(batchSize))
							.apply(String.format("Cassandra Bulk Insertion - %s",attribute), 
									ParDo.of(new CassandraInsertRPC(
											pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_HTTPURL),
											pubsubAttrConfigObj.getString(Constants.CONFIG_KEYWORD_REQUESTTYPE)
											))
									.withOutputTags(CassandraInsertRPC.responseSuccess, 
											TupleTagList.of(CassandraInsertRPC.deadLetterQueue)
											.and(CassandraInsertRPC.retryRecords).and(CassandraInsertRPC.timeMetrics)
											));

					cassandraPNOSuccess = cassandraTuple.get(CassandraInsertRPC.responseSuccess);
					cassandraPNOFailure = cassandraTuple.get(CassandraInsertRPC.deadLetterQueue);
					cassandraRetryRecords = cassandraTuple.get(CassandraInsertRPC.retryRecords);
					cassandraInsertionTimeMetrics = cassandraTuple.get(CassandraInsertRPC.timeMetrics);
					retryTopicVar = "retry-bulk";
					
					//TimeMetrics
					cassandraInsertionTimeMetrics.apply(new ParallelWriteGCS(options));
				}

				// Sink for Cassandra Retry Records - PubSub
				IOUtility.deadLetterOptionalSink(Constants.PUBSUB, cassandraRetryRecords,
						options.getPubSubTopic() +"-"+ retryTopicVar, options.getWindowDuration(),
						options.getPath()+"/pnoretry/",options.getFileName(),options.getNumShards());

				// PNO Status Sink for Valid Records - GCS/PubSub 	
				IOUtility.deadLetterOptionalSink(gcsOrPubSub,cassandraPNOSuccess,
						outputTopic+"-success",windowDuration,filePath+"/pnosuccess/",fileName,numShards);

				// Dead letters Sink for Invalid Records - GCS/PubSub 	
				IOUtility.deadLetterOptionalSink(gcsOrPubSub, cassandraPNOFailure,
						outputTopic+"-error",windowDuration,filePath+"/pnofailure/",fileName,numShards);
			}
			

			// Write retry data to Single Cassandra Insertions
			PCollectionTuple cassandraSingleRetryTuple = retrySingleData
					.apply("Cassandra Retry Single Insertion",
							ParDo.of(new CassandraInsertRPCRetry(
									options.getHttpUrl()
									))
							.withOutputTags(CassandraInsertRPCRetry.responseSuccess,
									TupleTagList.of(CassandraInsertRPCRetry.deadLetterQueue)
									.and(CassandraInsertRPCRetry.retryRecords).and(CassandraInsertRPCRetry.timeMetrics)));

			//Dead letter Sink for Retry failures - GCS/PubSub
			IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(),
					cassandraSingleRetryTuple.get(CassandraInsertRPCRetry.retryRecords),
					options.getPubSubTopic()+"-retry-singlefailure",options.getWindowDuration(),
					options.getPath()+"/retrysinglefailure/",options.getFileName(),options.getNumShards());

			// Write retry data to Bulk Cassandra Insertions
			PCollectionTuple cassandraBulkRetryTuple = retryBulkData
					.apply("Cassandra Retry Bulk Insertion",
							ParDo.of(new CassandraInsertRPCRetry(
									options.getBulkHttpUrl()
									))
							.withOutputTags(CassandraInsertRPCRetry.responseSuccess,
									TupleTagList.of(CassandraInsertRPCRetry.deadLetterQueue)
									.and(CassandraInsertRPCRetry.retryRecords).and(CassandraInsertRPCRetry.timeMetrics)));

			//Dead letter Sink for Retry failures - GCS/PubSub
			IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(),
					cassandraBulkRetryTuple.get(CassandraInsertRPCRetry.retryRecords),
					options.getPubSubTopic()+"-retry-bulkfailure",options.getWindowDuration(),
					options.getPath()+"/retrybulkfailure/",options.getFileName(),options.getNumShards());
			
			//TimeMetrics
			PCollection<String> retryInsertionTimeMetrics = cassandraBulkRetryTuple.get(CassandraInsertRPCRetry.timeMetrics);
			retryInsertionTimeMetrics.apply(new ParallelWriteGCS(options));
		

		}
		catch(Exception e) {
			e.printStackTrace();
			exceptions.errorPipeline("PNOInsertionTransform", e);
		}
	}
}
