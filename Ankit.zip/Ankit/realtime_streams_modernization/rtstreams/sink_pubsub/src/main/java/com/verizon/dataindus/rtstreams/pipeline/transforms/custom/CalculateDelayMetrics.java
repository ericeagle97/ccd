package com.verizon.dataindus.rtstreams.pipeline.transforms.custom;

import java.text.ParseException;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.common.CommonUtility;

public class CalculateDelayMetrics {
	private static final Logger LOG = LoggerFactory.getLogger(CalculateDelayMetrics.class);
	
	static Counter totalEvents = Metrics.counter("Load Delay", "Total Events");
    // Load Delay counters
    static Counter lessThanZeroSecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay <= 0 second");
    static Counter zeroToOneSecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 0-1 second");
    static Counter oneToFiveSecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 1-5 seconds");
    static Counter fiveToTenSecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 5-10 seconds");
    static Counter tenToTwentySecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 10-20 seconds");
    static Counter twentyToThirtySecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 20-30 seconds");
    static Counter thirtyToFortySecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 30-40 seconds");
    static Counter fortyToFiftySecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 40-50 seconds");
    static Counter fiftyToSixtySecondsLoadDelay = Metrics.counter("Load Delay", "Load Delay 50-60 seconds");
    static Counter oneToTwoMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 1-2 minutes");
    static Counter twoToThreeMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 2-3 minutes");
    static Counter threeToFiveMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 3-5 minutes");
    static Counter fiveToTenMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 5-10 minutes");
    static Counter tenToThirtyMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 10-30 minutes");
    static Counter thirtyToSixtyMinutesLoadDelay = Metrics.counter("Load Delay", "Load Delay 30-60 minutes");
    static Counter greaterThanOneHourLoadDelay = Metrics.counter("Load Delay", "Load Delay >1 hour");
    static Counter timeMetricsMissing = Metrics.counter("Load Delay", "TimeMetrics Missing");
    
    
    public static void CalculateMetrics(String c) {
    	try {
    		totalEvents.inc();
    		
    		JSONObject inputJson = new JSONObject(c);
			if(inputJson.has("timeMetrics") && !CommonUtility.isNullEmptyOrBlank(inputJson.getJSONObject("timeMetrics").getString("queueTimeStamp"))) {
				long kafkaTimestampInMillis = Long.parseLong(inputJson.getJSONObject("timeMetrics").getString("queueTimeStamp"));
				long kafkaTimeStampInSeconds = kafkaTimestampInMillis / 1000; 
				
				long systemTimestampInSeconds = System.currentTimeMillis() / 1000;
				
				long diffInSeconds = systemTimestampInSeconds - kafkaTimeStampInSeconds;
			    
				if (diffInSeconds <= 0) // less than 0 second
			        lessThanZeroSecondsLoadDelay.inc();
			    else if (diffInSeconds > 0 && diffInSeconds <= 1) // 0-1 second
			        zeroToOneSecondsLoadDelay.inc();
			    else if (diffInSeconds > 1 && diffInSeconds <= 5) // 1-5 seconds
			        oneToFiveSecondsLoadDelay.inc();
			    else if (diffInSeconds > 5 && diffInSeconds <= 10) // 5-10 seconds
			        fiveToTenSecondsLoadDelay.inc();
			    else if (diffInSeconds > 10 && diffInSeconds <= 20) // 10-20 seconds
			        tenToTwentySecondsLoadDelay.inc();
			    else if (diffInSeconds > 20 && diffInSeconds <= 30) // 20-30 seconds
			        twentyToThirtySecondsLoadDelay.inc();
			    else if (diffInSeconds > 30 && diffInSeconds <= 40) // 30-40 seconds
			        thirtyToFortySecondsLoadDelay.inc();
			    else if (diffInSeconds > 40 && diffInSeconds <= 50) // 40-50 seconds
			        fortyToFiftySecondsLoadDelay.inc();
			    else if (diffInSeconds > 50 && diffInSeconds <= 60) // 50-60 seconds
			        fiftyToSixtySecondsLoadDelay.inc();
			    else if (diffInSeconds > 60 && diffInSeconds <= 120) // 1-2 minutes
			        oneToTwoMinutesLoadDelay.inc();
			    else if (diffInSeconds > 120 && diffInSeconds <= 180) // 2-3 minutes
			        twoToThreeMinutesLoadDelay.inc();
			    else if (diffInSeconds > 180 && diffInSeconds <= 300) // 3-5 minutes
			        threeToFiveMinutesLoadDelay.inc();
			    else if (diffInSeconds > 300 && diffInSeconds <= 600) // 5-10 minutes
			        fiveToTenMinutesLoadDelay.inc();
			    else if (diffInSeconds > 600 && diffInSeconds <= 1800) // 10-30 minutes
			        tenToThirtyMinutesLoadDelay.inc();
			    else if (diffInSeconds > 1800 && diffInSeconds <= 3600) // 30-60 minutes
			        thirtyToSixtyMinutesLoadDelay.inc();
			    else if (diffInSeconds > 3600) // Greater than 1 hour
			        greaterThanOneHourLoadDelay.inc();
			} else {
				timeMetricsMissing.inc();
			}
		} catch (Exception e) {
			timeMetricsMissing.inc();
			e.printStackTrace();
		}
    }
	

}
