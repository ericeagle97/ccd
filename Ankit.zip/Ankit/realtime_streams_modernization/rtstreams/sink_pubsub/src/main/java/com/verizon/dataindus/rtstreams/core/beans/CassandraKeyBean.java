package com.verizon.dataindus.rtstreams.core.beans;

public class CassandraKeyBean {

	public CassandraKeyBean(String mtn, String customerId, String accountNo) {
		super();
		this.mtn = mtn;
		this.customerId = customerId;
		this.accountNo = accountNo;
	}
	private String mtn;
	private String customerId;
	private String accountNo;

	public String getMtn() {
		return mtn;
	}
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

}
