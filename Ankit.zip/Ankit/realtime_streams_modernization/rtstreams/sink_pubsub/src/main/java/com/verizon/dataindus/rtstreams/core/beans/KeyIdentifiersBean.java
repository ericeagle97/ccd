package com.verizon.dataindus.rtstreams.core.beans;

public class KeyIdentifiersBean {
	
	public KeyIdentifiersBean(String mtn, String hashMTN, String hashAccount,String accountId,
			String customerNo,String usrAccount, String globalId, String IP) {
		super();
		this.mtn = mtn;
		this.accountId = accountId;
		this.customerNo = customerNo;
		this.usrAccount = usrAccount;
		this.hashMTN = hashMTN;
		this.hashAccount = hashAccount;
		this.globalId = globalId;
		this.IP = IP;
	}
	private String mtn;
	private String accountId;
	private String customerNo;
	private String usrAccount;
	private String hashMTN;
	private String hashAccount;
	private String globalId;
	private String IP;
	
	
	public String getMtn() {
		return mtn;
	}
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getHashMTN() {
		return hashMTN;
	}
	public void setHashMTN(String hashMTN) {
		this.hashMTN = hashMTN;
	}
	public String getHashAccount() {
		return hashAccount;
	}
	public void setHashAccount(String hashAccount) {
		this.hashAccount = hashAccount;
	}
	public String getGlobalId() {
		return globalId;
	}
	public void setGlobalId(String globalId) {
		this.globalId = globalId;
	}
	public String getUsrAccount() {
		return usrAccount;
	}
	public void setUsrAccount(String usrAccount) {
		this.usrAccount = usrAccount;
	}
	public String getIP() {
		return IP;
	}
	public void setIP(String iP) {
		IP = iP;
	}
	

}
