package com.verizon.dataindus.rtstreams.core.factory;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.StorageOptions;
import com.google.common.collect.Lists;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.Properties;


public class ConsumerFactoryFn implements SerializableFunction<Map<String, Object>, Consumer<byte[], byte[]>>
{
	private static final long serialVersionUID = 1L;
	String bucket;
	String keyFile;

	public ConsumerFactoryFn(String strBucket,String strKeyFile)
	{
		this.bucket=strBucket;
		this.keyFile=strKeyFile;
	}
	public Consumer<byte[], byte[]> apply(Map<String, Object> config) 
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils exceptions=new ExceptionsUtils();
		try 
		{
			/*Accessing the kafka credentials from GCS bucket and passing to SSLTrustStore*/
			GoogleCredentials credentialsNew = GoogleCredentials.getApplicationDefault().createScoped(Lists.newArrayList("https://www.googleapis.com/auth/cloud-platform"));
			com.google.cloud.storage.Storage storage = StorageOptions.newBuilder().setCredentials(credentialsNew).build().getService();

			/*Specifying Bucket and file name where JKS file located*/			
			Blob blob = storage.get(bucket, keyFile);
			ReadChannel readChannel = blob.reader();
			FileOutputStream fileOuputStream;

			/*Downloads file from GCS and store in temp location*/
			fileOuputStream = new FileOutputStream("/tmp/"+keyFile.toString()); //path where the jks file will be stored
			fileOuputStream.getChannel().transferFrom(readChannel, 0, Long.MAX_VALUE);
			fileOuputStream.close(); 

			/*Assigining downloaded object o TRUSTSTORE*/
			config.put("ssl.truststore.location",(Object) "/tmp/"+keyFile.toString());
		} 
		catch (FileNotFoundException e) 
		{
			/*Throws exception when scpecified file not present in GCS bucket*/
			exceptions.fileNotFound(Properties.CLASS_CONSUMERFACTORY,e);
		} 
		catch (IOException e) 
		{
			/*Throws excpetion when not able to read file*/
			exceptions.ioException(Properties.CLASS_CONSUMERFACTORY,e);
		}
		catch (Exception e) 
		{
			/*Throws generic exception*/
			exceptions.genericException(Properties.CLASS_CONSUMERFACTORY,e);
		}

		return new KafkaConsumer<byte[], byte[]>(config);
	}


}
