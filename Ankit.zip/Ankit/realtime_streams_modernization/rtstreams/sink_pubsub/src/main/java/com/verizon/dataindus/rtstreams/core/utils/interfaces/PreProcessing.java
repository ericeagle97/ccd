package com.verizon.dataindus.rtstreams.core.utils.interfaces;

import com.verizon.dataindus.rtstreams.core.beans.CassandraKeyBean;
import com.verizon.dataindus.rtstreams.core.beans.KeyIdentifiersBean;
import redis.clients.jedis.Jedis;

public interface PreProcessing {

	/* Interface to get UnHash MTNs and Accounts from Redis */
	KeyIdentifiersBean getUnHashKeyIdentifierFromRedis(KeyIdentifiersBean kIdentityBean, Jedis jedisClientObj);
	
	/* Interface to get MTNs and Accounts using GlobalID from Redis <T> */
	KeyIdentifiersBean getKeyIdentifierFromRedis(KeyIdentifiersBean kIdentityBean,Jedis jedisClientObj) ;
	  
	/* Interface to get UnHash MTNs and Accounts from DVS API <T> */
	KeyIdentifiersBean  getUnHashKeyIdentifierFromDVS(KeyIdentifiersBean kIdentityBean,String apiUrl,
			String bucket,String fileName,Boolean enableWriteResponse) ;
	   
	/* Interface to get MTNs and Accounts using GlobalID from Keyring API <T> */
	KeyIdentifiersBean  getKeyIdentifierFromKeyring(KeyIdentifiersBean kIdentityBean,String keyringUrl,
			String bucket,String fileName,Boolean enableWriteResponse) ;
	  
	/* Interface to set Hash MTNs and Accounts To Redis <T> */
	KeyIdentifiersBean  setHashKeyIdentifierToRedis(KeyIdentifiersBean kIdentityBean,Jedis jedisClientObj) ;
	  
	/* Interface to set GlobalID for MTNs and Accounts To Redis <T> */
	KeyIdentifiersBean  setKeyIdentifierToRedis(KeyIdentifiersBean kIdentityBean,Jedis jedisClientObj) ;
	
	
	/* Interface to get Accounts and CustId using MTN from Redis */
	CassandraKeyBean getCassandraKeyIdentifierFromRedis(CassandraKeyBean keyBean,Jedis jedisClientObj) ;
	 
	 

}
