package com.verizon.dataindus.rtstreams.core.utils;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.vendor.calcite.v1_28_0.org.apache.commons.lang3.StringUtils;
import org.joda.time.Duration;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static com.verizon.dataindus.rtstreams.core.utils.CassandraInsertRPC.client;

public class IOUtility {

	public static void applyWindowAndWriteToGCS(PCollection<String> data,int windowInSec, String filePath, 
			String fileName,int numShards) {
		//String fileFormat = String.format("GCS fileSink - (%s)", StringUtils.substringAfter(filePath, "/"));

		String fileFormat = String.format("GCS fileSink - %s(%s)", StringUtils.substringAfterLast(filePath.substring(0,filePath.lastIndexOf("/")),"/"), fileName);
		data.apply(Window.<String>into(FixedWindows.of(Duration
				.standardSeconds(windowInSec)))
				.withAllowedLateness(Duration.standardHours(5))
				.discardingFiredPanes())
		.apply(fileFormat, WriteToGcs.writeToGCS(filePath,
				fileName,numShards));
	}

	public static void deadLetterOptionalSink (String deadletterOption, PCollection<String> invalidData,
			String pubsubTopic, int windowInSec, String filePath, String fileName,int numShards) {
		// Dead letters for Invalid Records 
		if((Constants.GCS).equalsIgnoreCase(deadletterOption)) 
		{
			// Dead letter GCS Sink
			applyWindowAndWriteToGCS(invalidData, Integer.valueOf(windowInSec),
					filePath,fileName,Integer.valueOf(numShards));
		}
		else if ((Constants.PUBSUB).equalsIgnoreCase(deadletterOption))
		{
			// Dead letter Pub Sub Topic
			invalidData.apply(String.format("Pubsub topicSink - %1$s",StringUtils.substringAfterLast(pubsubTopic, "/")), PubsubIO.writeStrings().to(pubsubTopic));
		}
	}

	public static HttpResponse<String> insertData(HttpClient client, String httpURL,
			String strRequestBody) throws ExecutionException, InterruptedException {
		UUID uuid = UUID.randomUUID();
		Long lLsb = Math.abs(uuid.getLeastSignificantBits());
		//String val = ""+lLsb;
		String val = "LT-" + lLsb;
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create(httpURL))
				.headers(Constants.HTTP_REQUEST_PROP_CONTENT_TYPE,Constants.HTTP_REQUEST_CONTENT_JSON,
						Constants.HTTP_REQUEST_PROP_CORRELATION_ID,val,
						Constants.HTTP_REQUEST_PROP_ORIGINAL_SERVICE,Constants.HTTP_REQUEST_SERVICE_WW,
						Constants.HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE,Constants.HTTP_REQUEST_SERVICE_WW)
				.POST(HttpRequest.BodyPublishers.ofString(strRequestBody))
				.build();

		return client.sendAsync(request,HttpResponse.BodyHandlers.ofString())
				.orTimeout(500, TimeUnit.MILLISECONDS)
				.get();
	}

}
