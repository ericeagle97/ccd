package com.verizon.dataindus.rtstreams.core.constants;

import java.util.EnumMap;

public class Properties 
{
		public static final String CLASS_STREAMSJOBLAUNCHER= "JobLauncher";
		public static final String CLASS_STREAMSJOBRUNNER= "Runner";
		public static final String CLASS_ACCESSSECRETVERSION= "AccessSecretVersion";
		public static final String CLASS_KAFKAREADER= "KafkaReader";
		public static final String CLASS_CONSUMERFACTORY= "ConsumerFactoryFn";
		public static final String CLASS_COMMONUTILITY= "CommonUtility";
		public static final String CLASS_SOURCETRANSFORMATION= "SourceTransformation";
		
}
