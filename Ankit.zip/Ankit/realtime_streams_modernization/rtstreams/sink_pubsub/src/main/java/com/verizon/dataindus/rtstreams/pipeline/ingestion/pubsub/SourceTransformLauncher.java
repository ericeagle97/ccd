package com.verizon.dataindus.rtstreams.pipeline.ingestion.pubsub;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.values.PCollection;
import org.json.JSONObject;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.common.LoggingUtils;
import com.verizon.dataindus.rtstreams.core.constants.Properties;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.PubsubIngestionOptions;

public class SourceTransformLauncher {

	public void sourceProcessLauncher(PCollection<PubsubMessage> data,
									  PCollection<String> retrySingleData,
									  PCollection<String> retryBulkData,
									  PubsubIngestionOptions options,
									  Map<String,JSONObject> pubsubAttrConfigObj) {

		/*Declaring jobClass and jobMethod variables to fetch job class name from particular package & corresponding job method*/
		Class<?> classJob = null;
		Method methodJob = null;

		/*Object to initiate Properties class & calling the properties method*/

		/*Creating object for custom exception class*/
		ExceptionsUtils exceptions=new ExceptionsUtils();
		try 
		{
			/*Class name derived from Job Name & Static Keyword.
			 * appName : PNOInsertion and Concatenated with Transform forming the Class Name as PNOInsertionTransform*/
			//String classNameRef = options.getJobName()+"Transform";
			String classNameRef = "PNOInsertionTransform";
			
			/*Method Name - Same Name for all Source Jobs*/
			String methodName = "downstreamProcess";

			/*Get the transform class name using reflection design pattern*/
			classJob = Class.forName("com.verizon.dataindus.rtstreams.pipeline.transforms.invocation."+classNameRef);

			/*Getting the details of method from the jobClass*/
			methodJob = classJob.getDeclaredMethod(methodName,PCollection.class, PCollection.class, PCollection.class,
					PubsubIngestionOptions.class,Map.class);
			
			/* create an instance of your class*/
			Object objJobClass = null;
			objJobClass = classJob.getDeclaredConstructor().newInstance();

			/*Creating object form custom LoggingUtils class*/
			LoggingUtils loggingUtils = new LoggingUtils();
			loggingUtils.loggingUtils(Properties.CLASS_SOURCETRANSFORMATION, 
					"Launching pipeline: "+classNameRef);

			/* call the method in context of object*/
			methodJob.invoke(objJobClass,data,retrySingleData,retryBulkData, options,pubsubAttrConfigObj);

		}
		catch(ClassNotFoundException e)
		{
			/*Throws an exception when specified class is not found*/
			exceptions.noClass(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(NoSuchMethodException  e) 
		{
			/*Throws an exception when specified method is not found*/
			exceptions.noMethod(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(SecurityException e) 
		{
			/* Throws exception in Java that is thrown by the security manager to indicate a security violation*/
			exceptions.securityException(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(InstantiationException e) 
		{
			/*Throws an exception when an application tries to create an instance of a class using the newInstance method*/
			exceptions.noObject(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(IllegalAccessException e) 
		{
			/*IllegaObjectAccess is called when trying to access class object with wrong scope or name**/
			exceptions.illegalObjectAccess(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(IllegalArgumentException e) 
		{
			/*Illegal method exception is called where there might be wrong method name or mismatch in method name specified*/
			exceptions.illegalMethod(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch (InvocationTargetException e) 
		{
			/*Throws an exception when not able to invoke method*/
			exceptions.invocationTargetException(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
		catch(Exception e) 
		{
			/* Throws an generic exception*/
			exceptions.genericException(Properties.CLASS_SOURCETRANSFORMATION,e);
		}
	}

}
