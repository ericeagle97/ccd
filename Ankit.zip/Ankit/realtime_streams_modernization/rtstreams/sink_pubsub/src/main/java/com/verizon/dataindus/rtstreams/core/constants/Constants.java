package com.verizon.dataindus.rtstreams.core.constants;


public class Constants {

	public static final String CONFIG_KEYWORD_SOURCES = "sources";
	public static final String CONFIG_KEYWORD_TOPICS = "topics";
	public static final String CONFIG_KEYWORD_REGIONS = "regions";
	public static final String CONFIG_KEYWORD_GROUP_ID = "group.id";
	public static final String CONFIG_KEYWORD_TRUSTSTORE_BUCKET = "truststore.bucket";
	public static final String CONFIG_KEYWORD_TRUSTSTORE_FILE = "truststore.file";
	public static final String CONFIG_KEYWORD_KAFKA_PROPERTIES = "kafka.properties";
	public static final String CONFIG_KEYWORD_BOOTSTRAP_SERVER = "bootstrap.servers";
	
	public static final String SSL_TRUSTSTORE_LOCATION = "ssl.truststore.location";
	public static final String TMP_PATH = "/tmp/";
	
	public static final String MEMSTORE_SECRET_ID_KEYSTORE_PASS ="memorystore-keystore-pass";
	public static final String MEMSTORE_SECRET_ID_JKS="memorystore-cert";
	public static final String MEMSTORE_SECRET_ID="memorystore-secrets";
	public static final String MEMSTORE_SECRET_ID_VERSION = "latest";
	
	public static final String MEMSTORE_HOST ="host";
	public static final String MEMSTORE_PORT="port";
	public static final String MEMSTORE_PASSWORD="password";
	public static final String MEMSTORE_JKS_FILEPATH = "/tmp/server-ca.jks";
	public static final String MEMSTORE_SSL_SOCKET_PROTOCOL= "TLSv1.3";
	public static final String MEMSTORE_KEYSTORE_INSTANCE_TYPE= "JKS";
	

	public static final String GCP_AUTH_CRED = "https://www.googleapis.com/auth/cloud-platform";
	
	public static final String HASH_MTN_PREFIX = "HASH_";
	public static final String HASH_CUSTID_ACCT_PREFIX = "Hash_";
	public static final String REDIS_GLOBALID_PREFIX = "GlobalID_";
	
	public static final String REDIS_KEY_MTN = "MTN";
	public static final String REDIS_KEY_ACCT_NUM = "ACCT_NUM";
	public static final String REDIS_KEY_CUST_ID = "CUST_ID";
	
	public static final String REDIS_KEY_GLOBALID_MTN = "MTN";
	public static final String REDIS_KEY_GLOBALID_CUSTID = "CUSTID";
	
	public static final String REGEX_MTN = "^[0-9]+$";
	public static final String REGEX_PNO_SUCCESS = "(.*?)(200|Success)(.*?)";
	
	public static final String REDIS_SUCCESS_MSG_PREFIX = "INSERT SUCCESSFUL: Redis Inserting ";
	public static final String REDIS_FAILURE_MSG_PREFIX = "INSERT FAILED: Redis Inserting ";
	
	public static final String DVS_KEY_MTN = "MTN";
	public static final String DVS_KEY_ACCOUNT = "ACCOUNT";
	
	public static final String METRICS_COUNTER_VALID = "valid_count";
	public static final String METRICS_COUNTER_INVALID = "invalid_count";
	public static final String METRICS_COUNTER_SUCCESS = "successful_count";
	public static final String METRICS_COUNTER_FAILURE = "failure_count";
	public static final String METRICS_COUNTER_SUCCESS_RETRY = "retry_successful_count";
	public static final String METRICS_COUNTER_FAILURE_RETRY = "retry_failure_count";
	public static final String METRICS_COUNTER_FOUND = "found_count";
	public static final String METRICS_COUNTER_UNFOUND = "unfound_count";
	
	public static final String METRICS_JSON_VALIDATION = "json_validation";
	public static final String METRICS_JSON_PARSING = "json_parsing";
	public static final String METRICS_PREPROCESSING = "preprocessing";

	public static final String METRICS_GLOBALID_KEYRING = "globalId_keyring_response";
	public static final String METRICS_GLOBALID_REDIS = "globalId_redis_response";
	public static final String METRICS_UNHASH_DVS = "unhash_dvs_response";
	public static final String METRICS_UNHASH_REDIS = "unhash_redis_response";

	public static final String METRICS_DVS_API = "dvs_api_response";
	public static final String METRICS_KEYRING_API = "keyring_api_response";
	
	
	public static final String HTTP_REQUEST_POST = "POST";
	
	public static final String HTTP_REQUEST_CONTENT_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String HTTP_REQUEST_CONTENT_JSON = "application/json";
	
	public static final String HTTP_REQUEST_CHARSET_UTF = "UTF-8";
	
	public static final String HTTP_REQUEST_PROP_CHARSET = "Charset";
	public static final String HTTP_REQUEST_PROP_CONTENT_TYPE = "Content-Type";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SERVICE = "ORIGINAL_SERVICE";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE = "ORIGINAL_SUBSERVICE";
	public static final String HTTP_REQUEST_PROP_CORRELATION_ID = "CORRELATION_ID";
	
	public static final String METRICS_CASSANDRA_INSERTION = "cassandra_insertion";
	public static final String METRICS_CASSANDRA_RESPONSE = "cassandra_insertion_response";
	public static final String METRICS_CASSANDRA_API = "cassandra_insertion_api";
	public static final String HTTP_REQUEST_SERVICE_WW = "ww";
	
	public static final String PUBSUB = "PubSub";
	public static final String GCS = "GCS";
	
	public static final String REDIS_EDW_PREFIX = "EDW_";
	public static final String METRICS_MTN_EDWLOOKUP ="edw_lookup";
	
	public static final int HTTP_TIMEOUT = 600;
	
	public static final String CONFIG_KEYWORD_ATTRIBUTES = "attributes";
	public static final String CONFIG_KEYWORD_SUBSCRIPTION = "subscription";
	
	public static final String CONFIG_KEYWORD_REQUESTTYPE = "requestType";
	public static final String CONFIG_KEYWORD_HTTPURL = "httpUrl";
	
	public static final String CONFIG_KEYWORD_BATCHSIZE = "pnoBatchSize";
	public static final String CONFIG_KEYWORD_KEYSIZE = "pnoKeySize";
	
	public static final String CONFIG_KEYWORD_NUMSHARDS = "numShards";
	public static final String CONFIG_KEYWORD_WINDURATION = "windowDuration";
	
	public static final String CONFIG_KEYWORD_GCSORPUBSUB = "gcsOrPubsub";
	public static final String CONFIG_KEYWORD_PATH = "path";
	public static final String CONFIG_KEYWORD_FILENAME = "fileName";
	public static final String CONFIG_KEYWORD_OUTPUTTOPIC = "outputTopic";
	
	public static final String PUBSUB_KEYWORD_ATTRIBUTETYPE = "attributeType";
	
}
