package com.verizon.dataindus.rtstreams.core.utils.impls;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verizon.dataindus.rtstreams.core.beans.CassandraKeyBean;
import com.verizon.dataindus.rtstreams.core.beans.KeyIdentifiersBean;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.utils.JedisUtility;
import com.verizon.dataindus.rtstreams.core.utils.RestClientAPIService;
import com.verizon.dataindus.rtstreams.core.utils.WriteToGcs;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.PreProcessing;

import redis.clients.jedis.Jedis;

public class PreProcessingClass implements PreProcessing {

	private static final Logger LOG = LoggerFactory.getLogger(PreProcessingClass.class);
	
	
	@Override
	public CassandraKeyBean getCassandraKeyIdentifierFromRedis(CassandraKeyBean keyBean, Jedis jedisClientObj) 
	{
		final Counter successEDWRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_MTN_EDWLOOKUP+"_"+ Constants.METRICS_COUNTER_FOUND);
		final Counter failureEDWRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_MTN_EDWLOOKUP+"_"+ Constants.METRICS_COUNTER_UNFOUND);

		String redisKey = Constants.REDIS_EDW_PREFIX + keyBean.getMtn() ;
		
		// Jedis Utility to perform Jedis Operations with Redis Connection Object
		String custIdAccNo = JedisUtility.jedisGet(jedisClientObj, redisKey);

		if (custIdAccNo != null && custIdAccNo.contains("-")) {

			successEDWRedisCounter.inc();
			keyBean.setCustomerId(custIdAccNo.split("-")[0]);
			keyBean.setAccountNo(custIdAccNo.split("-")[1]);
		} 
		else {
			failureEDWRedisCounter.inc();
		}
		return keyBean;
	}

	@Override
	public KeyIdentifiersBean getUnHashKeyIdentifierFromRedis(KeyIdentifiersBean kIdentityBean, Jedis jedisClientObj) {
		// TODO Auto-generated method stub
		String hashMTNKey = Constants.HASH_MTN_PREFIX+kIdentityBean.getHashMTN();
		String hashAccountKey = Constants.HASH_CUSTID_ACCT_PREFIX+kIdentityBean.getHashAccount();
		final Counter successUnhashRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_UNHASH_REDIS+"_"+Constants.METRICS_COUNTER_FOUND);
		final Counter failureUnhashRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_UNHASH_REDIS+"_"+Constants.METRICS_COUNTER_UNFOUND);

		if(hashMTNKey.length() > 30)
		{
			Map<String, String> clearMap = JedisUtility.jedisHGetAll(jedisClientObj, hashMTNKey);
			if (! clearMap.isEmpty()) {
				successUnhashRedisCounter.inc();
				if (clearMap.containsKey(Constants.REDIS_KEY_MTN)) {
					kIdentityBean.setMtn(clearMap.get(Constants.REDIS_KEY_MTN));
				}				
			} else {
				failureUnhashRedisCounter.inc();
			}
		}

		if(hashAccountKey.length() > 30)
		{
			Map<String, String> clearMap = JedisUtility.jedisHGetAll(jedisClientObj, hashAccountKey);
			if (clearMap.containsKey(Constants.REDIS_KEY_ACCT_NUM)) {
				kIdentityBean.setAccountId(clearMap.get(Constants.REDIS_KEY_ACCT_NUM));
			}
			if (clearMap.containsKey(Constants.REDIS_KEY_CUST_ID)) {
				kIdentityBean.setCustomerNo(clearMap.get(Constants.REDIS_KEY_CUST_ID));
			}

			if ( ! (CommonUtility.isNullEmptyOrBlank(kIdentityBean.getAccountId())) && 
					! (CommonUtility.isNullEmptyOrBlank(kIdentityBean.getCustomerNo())) 
					&& kIdentityBean.getAccountId().length() < 30 && kIdentityBean.getCustomerNo().length() < 30 ) {

				kIdentityBean.setUsrAccount(kIdentityBean.getCustomerNo() +"-"+ kIdentityBean.getAccountId());		
			} 
		}
		return kIdentityBean;

	}

	@Override
	public KeyIdentifiersBean getKeyIdentifierFromRedis(KeyIdentifiersBean kIdentityBean, Jedis jedisClientObj) {
		// TODO Auto-generated method stub
		final Counter successKeyringRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_GLOBALID_REDIS+"_"+ Constants.METRICS_COUNTER_FOUND);
		final Counter failureKeyringRedisCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_GLOBALID_REDIS+"_"+ Constants.METRICS_COUNTER_UNFOUND);
		String redisKey = Constants.REDIS_GLOBALID_PREFIX + kIdentityBean.getGlobalId() ;
		Map<String, String> clearMap = JedisUtility.jedisHGetAll(jedisClientObj, redisKey);
		if (clearMap.size() > 0) 
		{

			if (clearMap.containsKey(Constants.REDIS_KEY_GLOBALID_MTN)) 
			{
				successKeyringRedisCounter.inc();
				kIdentityBean.setMtn(clearMap.get(Constants.REDIS_KEY_GLOBALID_MTN));
			}

			if(clearMap.containsKey(Constants.REDIS_KEY_GLOBALID_CUSTID))
			{
				kIdentityBean.setUsrAccount(clearMap.get(Constants.REDIS_KEY_GLOBALID_CUSTID));
			}

			if (kIdentityBean.getUsrAccount().contains("-")) {
				kIdentityBean.setCustomerNo(kIdentityBean.getUsrAccount().split("-")[0]);
				kIdentityBean.setAccountId(kIdentityBean.getUsrAccount().split("-")[1]);
			} 
		} else {
			failureKeyringRedisCounter.inc();
		}


		return kIdentityBean;

	}

	@Override
	public KeyIdentifiersBean getUnHashKeyIdentifierFromDVS(KeyIdentifiersBean kIdentityBean, String apiUrl,String bucket, 
			String fileName,Boolean enableWriteResponse) {
		// TODO Auto-generated method stub
		String hashMTN = kIdentityBean.getHashMTN();
		String hashAccount = kIdentityBean.getHashAccount();
		final Counter successDVSKeyCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_UNHASH_DVS+"_"+ Constants.METRICS_COUNTER_FOUND);
		final Counter failureDVSKeyCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_UNHASH_DVS+"_"+ Constants.METRICS_COUNTER_UNFOUND);
		String xmlString = "xmlreqdoc=<service><serviceHeader><billingSys>VISION_NORTH</billingSys><clientId>VNV-VMG</clientId><userId>VMGPROD</userId><password>Grp94136</password><serviceName>retrieveClearTextValues</serviceName></serviceHeader><serviceBody><serviceRequest><subServiceName/><hashedValueList><hashedValue><value>"+hashAccount+"</value><type>ACCOUNT</type></hashedValue><hashedValue><value>"+hashMTN+"</value><type>MTN</type></hashedValue></hashedValueList></serviceRequest></serviceBody></service>";

		String initiationTime = CommonUtility.getMilliTime();
		String[] responseList = RestClientAPIService.getRestServiceClientDVSAPIResponse(xmlString, initiationTime, apiUrl);
		if (enableWriteResponse) {
			// WIP WriteToGcs.writeStringToGCS(responseList.toString(), bucket, fileName+"/DVSResponse");
		}
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			if(responseList.length > 0)
			{
				if (responseList[1] != "" )
				{
					Document doc;
					try {
						doc = dBuilder.parse(new InputSource(new StringReader(responseList[1])));
						doc.getDocumentElement().normalize();
						String hashed_item1_name = "";
						String clear_item1 = "";
						String hashed_item2_name = "";
						String clear_item2 = "";

						if (responseList[1].contains("hashedValue")) {
							successDVSKeyCounter.inc();
							NodeList nList = doc.getElementsByTagName("hashedValue");
							if (nList.getLength() > 0) {
								hashed_item1_name = doc.getElementsByTagName("type").item(0).getTextContent();
								clear_item1 = doc.getElementsByTagName("clearText").item(0).getTextContent();
								hashed_item2_name = doc.getElementsByTagName("type").item(1).getTextContent();
								clear_item2 = doc.getElementsByTagName("clearText").item(1).getTextContent();
							}

							if(hashed_item1_name.length() > 0 && clear_item1.length() > 0)
							{
								if(hashed_item1_name.equalsIgnoreCase(Constants.DVS_KEY_MTN) && kIdentityBean.getMtn().length() != 10)
								{
									kIdentityBean.setMtn(clear_item1);
								}
								else if(hashed_item1_name.equalsIgnoreCase(Constants.DVS_KEY_ACCOUNT) &&  !(kIdentityBean.getUsrAccount().contains("-")))
								{
									if(clear_item1.contains("-") && clear_item1.split("-").length == 2)
									{
										kIdentityBean.setUsrAccount(clear_item1);
										kIdentityBean.setCustomerNo(clear_item1.split("-")[0]);
										kIdentityBean.setAccountId(clear_item1.split("-")[1]);
									}
								}
							}

							if(hashed_item2_name.length() > 0 && clear_item2.length() > 0)
							{
						
								if(hashed_item2_name.equalsIgnoreCase(Constants.DVS_KEY_MTN) && kIdentityBean.getMtn().length() != 10)
								{
									kIdentityBean.setMtn(clear_item2);
								}
								else if(hashed_item2_name.equalsIgnoreCase(Constants.DVS_KEY_ACCOUNT) && (kIdentityBean.getUsrAccount().contains("-") != true))
								{
									if(clear_item2.contains("-") && clear_item2.split("-").length == 2)
									{
										kIdentityBean.setUsrAccount(clear_item2);
										kIdentityBean.setCustomerNo(clear_item2.split("-")[0]);
										kIdentityBean.setAccountId(clear_item2.split("-")[1]);
									}
								}
							}
						}
						else {
							failureDVSKeyCounter.inc();
							LOG.error("Response : "+ responseList[1]);
						}

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						failureDVSKeyCounter.inc();
					}
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			failureDVSKeyCounter.inc();
		}

		return kIdentityBean;

	}

	@Override
	public KeyIdentifiersBean getKeyIdentifierFromKeyring(KeyIdentifiersBean kIdentityBean, String keyringUrl,String bucket, String fileName,Boolean enableWriteResponse) {
		// TODO Auto-generated method stub
		Map<String,Object>mapKeyAttributes = new HashMap<String,Object> ();
		//KeyAttributes map to store KeyAttributes which need to be passed in requestBody
		Map<String,Object>mapCassandraMainMap = new HashMap<String,Object> ();

		mapKeyAttributes.put("insightCategory","customer");
		mapKeyAttributes.put("insightName","keyring");
		mapKeyAttributes.put("sessionId",kIdentityBean.getGlobalId());
		mapCassandraMainMap.put("requestType", "SOI_SessionInsights_by_session");
		mapCassandraMainMap.put("keyAttributes",new JSONObject(mapKeyAttributes));

		String initiationTime = CommonUtility.getMilliTime();

		final Counter successKeyringCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_GLOBALID_KEYRING+"_"+ Constants.METRICS_COUNTER_FOUND);
		final Counter failureKeyringCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_GLOBALID_KEYRING+"_"+ Constants.METRICS_COUNTER_UNFOUND);

		// Calling a Java function that will return responseList from Cassandra.
		String[] responseStrList = RestClientAPIService.getRestServiceClientAPIKeyringResponse(new JSONObject(mapCassandraMainMap).toString(),initiationTime,keyringUrl);
		if (enableWriteResponse) {
			// WIP WriteToGcs.writeStringToGCS(responseStrList.toString(), bucket, fileName+"/KeyringResponse");
		}
		if(responseStrList.length > 0)
		{
			JsonObject objJson =  JsonParser.parseString(responseStrList[1]).getAsJsonObject();
			JsonObject detailObject = (JsonObject) objJson.get("results");

			JsonArray sessionInsightsObj = detailObject.getAsJsonArray("SessionInsights");

			if(sessionInsightsObj.size() > 0)
			{

				JsonObject insightObj = (JsonObject) sessionInsightsObj.get(0).getAsJsonObject().get("insightValues");
				successKeyringCounter.inc();
				String strMdn = insightObj.get("mtn").toString().replace("\"", "");
				String strCustId = insightObj.get("cust_id").toString().replace("\"", "");
				String strAccNo = insightObj.get("acct_no").toString().replace("\"", "");

				if(strMdn != "")
				{
					kIdentityBean.setMtn(strMdn);
				}
				if(strCustId != "" && strAccNo != "")
				{
					kIdentityBean.setAccountId(strAccNo);
					kIdentityBean.setCustomerNo(strCustId);
					kIdentityBean.setUsrAccount(strCustId+"-"+strAccNo);
				}
			}
			else if( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getIP()) )
			{
				mapKeyAttributes.put("sessionId",kIdentityBean.getIP());
				mapCassandraMainMap.put("requestType", "SOI_SessionInsights_by_session");
				mapCassandraMainMap.put("keyAttributes",new JSONObject(mapKeyAttributes));

				// Calling a Java function that will return responseList from Cassandra.
				String[] responseStrListUpt = RestClientAPIService.getRestServiceClientAPIKeyringResponse(new JSONObject(mapCassandraMainMap).toString(),initiationTime,keyringUrl);

				if(responseStrListUpt.length > 0)
				{
					JsonObject objJson1 =  JsonParser.parseString(responseStrListUpt[1]).getAsJsonObject();
					JsonObject detailObject1 = (JsonObject) objJson1.get("results");
					JsonArray sessionInsightsObj1 = detailObject1.getAsJsonArray("SessionInsights");

					if(sessionInsightsObj1.size() > 0)
					{
						JsonObject insightObj1 = (JsonObject) sessionInsightsObj1.get(0).getAsJsonObject().get("insightValues");

						successKeyringCounter.inc();
						String strMdn = insightObj1.get("mtn").toString().replace("\"", "");
						String strCustId = insightObj1.get("cust_id").toString().replace("\"", "");
						String strAccNo = insightObj1.get("acct_no").toString().replace("\"", "");

						if(strMdn != "")
						{
							kIdentityBean.setMtn(strMdn);
						}
						if(strCustId != "" && strAccNo != "")
						{
							kIdentityBean.setAccountId(strAccNo);
							kIdentityBean.setCustomerNo(strCustId);
							kIdentityBean.setUsrAccount(strCustId+"-"+strAccNo);

						}

					}
				}	
			}
		} else {
			failureKeyringCounter.inc();
		}


		return kIdentityBean;
	}

	@Override
	public KeyIdentifiersBean setHashKeyIdentifierToRedis(KeyIdentifiersBean kIdentityBean, Jedis jedisClientObj) {
		// TODO Auto-generated method stub

		//this is for the HASH redis insert for the clear mtn lookup
		if((( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getMtn())) && 
				(kIdentityBean.getMtn().matches(Constants.REGEX_MTN)) && 
				kIdentityBean.getMtn().length()==10) && ((kIdentityBean.getHashMTN() != null) 
						&& (kIdentityBean.getHashMTN().length() > 30)))
		{
			//hset logic
			Long res = JedisUtility.jedisHSet(jedisClientObj, Constants.HASH_MTN_PREFIX + kIdentityBean.getHashMTN(), Constants.REDIS_KEY_MTN, kIdentityBean.getMtn());

			if(res == 0 || res == 1)
			{
			}
			else
			{
				LOG.error(Constants.REDIS_FAILURE_MSG_PREFIX + Constants.HASH_MTN_PREFIX + kIdentityBean.getHashMTN()
				+" : "+kIdentityBean.getMtn()+" :  - Error Code : " + res);
			}

		}
		//this is for the Hash redis insert for the clear account lookup
		if(( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getCustomerNo()))
				&& ( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getAccountId())) 
				&& (kIdentityBean.getHashAccount().length() > 30) 
				&& kIdentityBean.getUsrAccount().contains("-"))
		{
			//hset logic
			Long res = JedisUtility.jedisHSet(jedisClientObj, Constants.HASH_CUSTID_ACCT_PREFIX + kIdentityBean.getHashAccount()
			, Constants.REDIS_KEY_CUST_ID, kIdentityBean.getCustomerNo());
			Long res1 = JedisUtility.jedisHSet(jedisClientObj, Constants.HASH_CUSTID_ACCT_PREFIX + kIdentityBean.getHashAccount()
			, Constants.REDIS_KEY_ACCT_NUM, kIdentityBean.getAccountId());

			if(res == 0 || res == 1 || res1 == 0 || res1 == 1)
			{

			}
			else
			{
				LOG.error(Constants.REDIS_FAILURE_MSG_PREFIX + Constants.HASH_CUSTID_ACCT_PREFIX + kIdentityBean.getHashAccount()+" : "+kIdentityBean.getCustomerNo()
				+" :  - Error Code : " + res + "for CUST_ID and ACCT_NUM with : " + res1);
			}
		}
		//this is for the GlobalID redis insert for the keyring lookup
		setKeyIdentifierToRedis(kIdentityBean, jedisClientObj);

		return kIdentityBean;

	}

	@Override
	public KeyIdentifiersBean setKeyIdentifierToRedis(KeyIdentifiersBean kIdentityBean, Jedis jedisClientObj) {
		// TODO Auto-generated method stub
		//this is for the GlobalID redis insert for the keyring lookup
		if( (!CommonUtility.isNullEmptyOrBlank(kIdentityBean.getMtn())) && 
				(kIdentityBean.getMtn().matches(Constants.REGEX_MTN)) && kIdentityBean.getMtn().length()==10)
		{
			//hset logic
			String redisKey = Constants.REDIS_GLOBALID_PREFIX + kIdentityBean.getGlobalId() ;
			//inserting field and values against the key
			Long res = JedisUtility.jedisHSet(jedisClientObj, redisKey, Constants.REDIS_KEY_GLOBALID_MTN, kIdentityBean.getMtn());

			if(( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getCustomerNo()))
					&& ( ! CommonUtility.isNullEmptyOrBlank(kIdentityBean.getAccountId())) 
					&& kIdentityBean.getUsrAccount().contains("-"))
			{
				Long res1 = JedisUtility.jedisHSet(jedisClientObj, redisKey, Constants.REDIS_KEY_GLOBALID_CUSTID, kIdentityBean.getUsrAccount());
			}
			//setting the time to live for the key in redis.
			Long res1 = JedisUtility.jedisExpire(jedisClientObj, redisKey, (long) 7776000); //90 days
			if(!(res == 0 || res == 1 || res1 == 0 || res1 == 1))
			{
				LOG.error(Constants.REDIS_FAILURE_MSG_PREFIX + redisKey+" :  - Error Code : " + res + "for CUSTID with : " + res1);
			}
		}
		return kIdentityBean;
	}

}
