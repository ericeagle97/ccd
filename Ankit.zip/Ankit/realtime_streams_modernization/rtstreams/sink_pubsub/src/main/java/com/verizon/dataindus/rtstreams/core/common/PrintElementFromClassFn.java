package com.verizon.dataindus.rtstreams.core.common;

import org.apache.beam.sdk.transforms.DoFn;

public class PrintElementFromClassFn extends DoFn<Object,String>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext processContext){
		processContext.output(String.valueOf(processContext.element().toString()).toString());

	}
}

