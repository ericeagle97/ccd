package com.verizon.dataindus.rtstreams.core.lib;

import com.verizon.dataindus.rtstreams.core.utils.CassandraInsertRPCRetry;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;

import static com.verizon.dataindus.rtstreams.core.utils.IOUtility.insertData;

public class CassandraInsertionRetry
{
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertion.class);

    public HttpClient client;

    public CassandraInsertionRetry(HttpClient client) {
        this.client = client;
    }

    public HttpResponse<String> cassandraInsertion(String httpURL, String strRequestBody, DoFn.ProcessContext c)
    {
        HttpResponse<String> response;
        try {
            response = insertData(client, httpURL, strRequestBody);

        } catch (Exception e) {
            c.output(CassandraInsertRPCRetry.retryRecords, strRequestBody);

            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            LOG.error(sw.toString());
            return null;
        }

        return response;
    }

    private HttpResponse<String> handleError(Throwable ex) {

        ex.printStackTrace();
        return null;
    }
}
