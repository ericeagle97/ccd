package com.verizon.dataindus.rtstreams.core.common;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import com.google.cloud.storage.*;
import com.google.common.hash.Hashing;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.verizon.dataindus.rtstreams.core.constants.Properties;
import com.verizon.dataindus.rtstreams.core.constants.Constants;

import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;

public class CommonUtility {

	public static String getFileContent(
			String project,
			String gcsBucket,
			String sqlQueryFile,
			ExceptionsUtils objCustomExceptions) {

		String fileContent = "";
		try{
			Storage storage = StorageOptions.newBuilder()
					.setProjectId(project)
					.build()
					.getService();

			Blob blob = storage.get(BlobId.of(gcsBucket, sqlQueryFile));
			fileContent = new String(blob.getContent());
		}
		catch(StorageException storageException){
			objCustomExceptions.storageException(Properties.CLASS_COMMONUTILITY,
					storageException);
			return null;
		}
		return fileContent;
	}

	public static String getGMTDateTime(String pattern) {
		// Format the date and time as a string
		Instant instantTime = Instant.now();
		ZoneId zone = ZoneId.of("GMT");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		String dateTime = instantTime.atZone(zone).format(formatter);
		return dateTime;

	}
	public static String getMilliTime() {
		Clock clock = Clock.systemDefaultZone();
		Instant instant = clock.instant();
		String milliTs = String.valueOf(instant.toEpochMilli());				
		return milliTs;
	}

	public static String getNanoGMTTime () {
		Instant instantTime = Instant.now();
		ZoneId zone = ZoneId.of("GMT");
		long nano = instantTime.atZone(zone).getNano();
		String dateTime = getGMTDateTime("yyyy-MM-dd HH:mm:ss");
		String nanotime = dateTime+":"+nano +" GMT";
		return nanotime;	
	}

	public static TimeDetails addJobTimestamp(String inout, TimeDetails obj) {

		if("IN".equals(inout)) {
			obj.setInTime(getGMTDateTime("yyyy-MM-dd HH:mm:ss:SSS 'GMT'"));
		}
		else if ("OUT".equals(inout)) {
			obj.setOutTime(getGMTDateTime("yyyy-MM-dd HH:mm:ss:SSS 'GMT'"));
		}
		return obj;

	}

	public static String genLinkageID(String mtn, String channel) {

		Integer uniqueId = 1;
		String indexNo = "0";
		String dateTime = getGMTDateTime("yyyy-MM-dd HHmmss.SSSSSS");
		String currentDay = dateTime.split(" ")[0];
		String currentTime = dateTime.split(" ")[1].split("\\.")[0];

		String currentTimeMs = dateTime.split("\\.")[1];

		String linkageID = "";
		//+getChannel()
		uniqueId = 1;
		//linkageID = mtn+"_"+channel+"_"+currentDay+"_"+currentTime+indexNo+String.valueOf(uniqueId);
		linkageID = mtn + "_" + channel + "_" + currentDay + "_" + currentTime + currentTimeMs + indexNo + String.valueOf(uniqueId);
		return linkageID;
	}
	
	public static Boolean isNullEmptyOrBlank (String field) {
		if (field == null || field.isBlank() || field.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static Object getEmptyIfNull (Object obj) {
		if (obj != null) {
			return obj;
		}else {
			return "";
		}	
	}

	public static String toBase64String(String inputString) {

		StringBuilder sb = new StringBuilder();
		String myresult = new String();
		try
		{
			BigInteger bigint = new BigInteger(inputString, 16);	
			byte[] ba = Base64.encodeInteger(bigint);
			for (byte b : ba) 
			{
				sb.append((char)b);
			}
			myresult = sb.toString();
		}
		catch (Exception ex)
		{

			ex.printStackTrace();
		}
		return(myresult);
	}

	public static String left5(String inputString) {

		String myresult = new String();
		try
		{
			myresult= inputString.substring(0, Math.min(5, inputString.length()));
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return(myresult);
	}

	public static String hash512String(String inputString) {
		String generatedHash = null;

		generatedHash = Hashing.sha512().hashString(inputString, StandardCharsets.UTF_8).toString();
		/*
		 * try { MessageDigest md = MessageDigest.getInstance("SHA-512"); byte[] sha =
		 * md.digest(inputString.getBytes(StandardCharsets.UTF_8)); StringBuilder sb =
		 * new StringBuilder(); for(int i=0; i< sha.length ;i++){
		 * sb.append(Integer.toString((sha[i] & 0xff) + 0x100, 16).substring(1)); }
		 * generatedHash = sb.toString(); } catch (NoSuchAlgorithmException e) {
		 * System.out.
		 * println("Exception occured in invocation of hash512String Method : " +
		 * e.getMessage() ); }
		 */	
		return generatedHash;
	}

	public static String leftAppendString(String inputString,String filler, int index) {
		int diff = index - inputString.length();
		String temp = inputString;
		int i = 0;
		while (i < diff)
		{
			temp = filler + temp;
			++i;
		}
		return temp;
	}
	
	public static Map<String,JSONObject> getPubsubReadConfigurations(
			String project,
			String pubsubIOReadConfigBucket,
			String pubsubIOReadConfigFile,
			String pubsubIOSubscription,
			ExceptionsUtils objCustomExceptions) {

		String fileContent = "";
		try{
			Storage storage = StorageOptions.newBuilder()
					.setProjectId(project)
					.build()
					.getService();

			Blob blob = storage.get(BlobId.of(pubsubIOReadConfigBucket, pubsubIOReadConfigFile));
			fileContent = new String(blob.getContent());
		}
		catch(StorageException storageException){
			objCustomExceptions.storageException(Properties.CLASS_COMMONUTILITY,
					storageException);
			return null;
		}
		try
		{
			String subscription = new JSONObject(fileContent).getString(Constants.CONFIG_KEYWORD_SUBSCRIPTION);

			JSONArray jsonConfig = new JSONObject(fileContent)
					.getJSONArray(Constants.CONFIG_KEYWORD_ATTRIBUTES);

			Map<String,JSONObject> pubsubIOReadTopicConfigMap = new HashMap<>();

			if (subscription.equalsIgnoreCase(pubsubIOSubscription)) 
			{
				populateConfigMap(jsonConfig, pubsubIOReadTopicConfigMap);
			}
			return pubsubIOReadTopicConfigMap;
		}
		catch(JSONException jsonException){
			objCustomExceptions.jsonException(Properties.CLASS_COMMONUTILITY,jsonException);
			return null;
		}
	}

	public static void populateConfigMap(JSONArray jsonArray, Map<String,JSONObject> map){
		for(int i = 0; i < jsonArray.length(); i++) {
			JSONObject innerObj = jsonArray.getJSONObject(i);
			Iterator<String> keys = innerObj.keys();

			while(keys.hasNext()) {
				String key = keys.next();
				map.put(key, innerObj.getJSONObject(key));
			}
		}
	}
}
