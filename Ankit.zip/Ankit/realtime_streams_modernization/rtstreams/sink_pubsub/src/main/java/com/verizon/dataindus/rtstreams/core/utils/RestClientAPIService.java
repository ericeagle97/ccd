/**
 * 
 */
package com.verizon.dataindus.rtstreams.core.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

import java.lang.Math;
import java.util.Random;
import java.util.UUID;

public class RestClientAPIService {

	private static final Logger LOG = LoggerFactory.getLogger(RestClientAPIService.class);

	public static String[] getRestServiceClientDVSAPIResponse(String xmlRequest, String initiationTime, String apiUrl) {
		URL url = null;
		long timeTaken=0L;
		long startTime=0L;
		long EndTime =0L;
		String responseStr = "";
		String responseCode = "";
		HttpURLConnection httpConnection = null;
		OutputStream outputStream = null;
		startTime = System.currentTimeMillis();
		String[] response = new String[7];
		final Counter successDVSApiCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_DVS_API+"_"+Constants.METRICS_COUNTER_SUCCESS);
		final Counter failureDVSApiCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_DVS_API+"_"+Constants.METRICS_COUNTER_FAILURE);
		try 
		{
			url = new URL(apiUrl);
			httpConnection = (HttpURLConnection) url.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod(Constants.HTTP_REQUEST_POST);
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_CONTENT_TYPE,Constants.HTTP_REQUEST_CONTENT_X_WWW_FORM_URLENCODED);
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_CHARSET,Constants.HTTP_REQUEST_CHARSET_UTF);

			httpConnection.setConnectTimeout(200);
			httpConnection.setReadTimeout(200);
			outputStream = httpConnection.getOutputStream();
			outputStream.write(xmlRequest.getBytes());
			outputStream.flush();

			responseCode = String.valueOf(httpConnection.getResponseCode());
			if (httpConnection.getResponseCode() != 200) 
			{
				failureDVSApiCounter.inc();
				throw new RuntimeException("invokeRestApi Method. Failed : HTTP error code : "+ httpConnection.getResponseCode());
			}
			String output;
			BufferedReader responseBuffer = new BufferedReader(new InputStreamReader((httpConnection.getInputStream())));

			while ((output = responseBuffer.readLine()) != null) 
			{
				responseStr += output;
			}
			successDVSApiCounter.inc();
		} 
		catch (Exception ex) 
		{
			response[0] = ex.getMessage();
			failureDVSApiCounter.inc();
			ex.printStackTrace();
			LOG.error(ex.getMessage());
		} 
		finally 
		{
			EndTime = System.currentTimeMillis();
			timeTaken = EndTime - startTime;
			try 
			{
				if (outputStream != null)
					outputStream.close();

				outputStream = null;
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				LOG.error(e.getMessage());
			}

			try 
			{
				if (httpConnection != null)
					httpConnection.disconnect();
				httpConnection = null;
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e.getMessage());
			}
		}

		response[1] = responseStr;
		response[2] = xmlRequest;
		response[3] = String.valueOf(timeTaken);
		response[4] = String.valueOf(startTime);
		response[5] = String.valueOf(EndTime);
		response[6] = String.valueOf(initiationTime);

		
		return response;	

	}


	public static String[] getRestServiceClientAPIKeyringResponse(String jsonRequest, String initiationTime,String pnoUrl) {
		URL url = null;
		long timeTaken=0L;
		long startTime=0L;
		long EndTime =0L;
		String responseStr = "";
		HttpURLConnection httpConnection = null;
		OutputStream outputStream = null;
		startTime = System.currentTimeMillis();
		String[] response = new String[7];
		final Counter successKeyringApiCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_KEYRING_API+"_"+Constants.METRICS_COUNTER_SUCCESS);
		final Counter failureKeyringApiCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,Constants.METRICS_KEYRING_API+"_"+Constants.METRICS_COUNTER_FAILURE);
		try 
		{
			url = new URL(pnoUrl);
			httpConnection = (HttpURLConnection) url.openConnection();
			httpConnection.setDoOutput(true);
			httpConnection.setRequestMethod(Constants.HTTP_REQUEST_POST);
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_CONTENT_TYPE,Constants.HTTP_REQUEST_CONTENT_JSON);
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_ORIGINAL_SERVICE,"");
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE,"");
			UUID uuid = UUID.randomUUID();
			Long lLsb = Math.abs(uuid.getLeastSignificantBits());
			String val = ""+lLsb;
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_CORRELATION_ID,val);
			httpConnection.setRequestProperty(Constants.HTTP_REQUEST_PROP_CHARSET, Constants.HTTP_REQUEST_CHARSET_UTF);
			httpConnection.setConnectTimeout(200);
			httpConnection.setReadTimeout(200);
			outputStream = httpConnection.getOutputStream();
			outputStream.write(jsonRequest.getBytes());
			outputStream.flush();

			if (httpConnection.getResponseCode() != 200) 
			{
				failureKeyringApiCounter.inc();
				throw new RuntimeException("invokeRestApi Method. Failed : HTTP error code : "+ httpConnection.getResponseCode());
			}
			String output;
			BufferedReader responseBuffer = new BufferedReader(new InputStreamReader((httpConnection.getInputStream())));

			while ((output = responseBuffer.readLine()) != null) 
			{
				responseStr += output;
			}
			successKeyringApiCounter.inc();
		} 
		catch (Exception ex) 
		{
			response[0] = ex.getMessage();
			failureKeyringApiCounter.inc();
			ex.printStackTrace();
			LOG.error(ex.getMessage());
		} 
		finally 
		{
			EndTime = System.currentTimeMillis();
			timeTaken = EndTime - startTime;
			try 
			{
				if (outputStream != null)
					outputStream.close();

				outputStream = null;
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				LOG.error(e.getMessage());
			}

			try 
			{
				if (httpConnection != null)
					httpConnection.disconnect();
				httpConnection = null;
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e.getMessage());
			}
		}	


		response[1] = responseStr;
		response[2] = jsonRequest;
		response[3] = String.valueOf(timeTaken);
		response[4] = String.valueOf(startTime);
		response[5] = String.valueOf(EndTime);
		response[6] = String.valueOf(initiationTime);

		return response;  

	}


}