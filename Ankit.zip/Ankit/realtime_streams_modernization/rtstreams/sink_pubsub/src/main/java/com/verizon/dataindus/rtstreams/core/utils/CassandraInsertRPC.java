package com.verizon.dataindus.rtstreams.core.utils;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getNanoGMTTime;
import static com.verizon.dataindus.rtstreams.core.utils.IOUtility.insertData;

public class CassandraInsertRPC extends DoFn<KV<Integer, Iterable<String>>, String> implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertRPC.class);
	private String httpRequest;
	private String requestType;

	static HttpClient client;

	final Counter statusCode500 = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + "status500"+ "_" + Constants.METRICS_COUNTER_FAILURE);
	final Counter statusCode400 = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + "status400"+ "_" + Constants.METRICS_COUNTER_FAILURE);

	public static final TupleTag<String> deadLetterQueue = new TupleTag<>() {
	};
	public static final TupleTag<String> responseSuccess = new TupleTag<>() {
	};
	public static final TupleTag<String> retryRecords = new TupleTag<>() {
	};
	public static final TupleTag<String> timeMetrics = new TupleTag<>() {
	};

	public static final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_RESPONSE + "_" + Constants.METRICS_COUNTER_SUCCESS);
	public static final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_RESPONSE + "_" + Constants.METRICS_COUNTER_FAILURE);
	final Counter failureApiCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION, Constants.METRICS_CASSANDRA_API + "_" + Constants.METRICS_COUNTER_FAILURE);

	public CassandraInsertRPC(String httpRequest, String requestType) {

		this.httpRequest = httpRequest;
		this.requestType = requestType;
	}

	@Setup
	public void setup() {
		client = HttpClient.newHttpClient();
	}


	@ProcessElement
	public void processElement(ProcessContext c) throws IOException {
		Iterable<String> str_val_for_key = c.element().getValue();
		flush(str_val_for_key, c);
	}

	@Teardown
	public void teardown() {
		if (client != null) {
			client = null;
		}
	}


	private void flush(Iterable<String> buffered, DoFn.ProcessContext c) {
		String request = "";
		ArrayList<Object> mylist = new ArrayList<Object>();
		ArrayList<JSONObject> timeMetricsList = new ArrayList<JSONObject>();
		//        CassandraInsertion insertData = new CassandraInsertion(client);
		//        HashMap<String, Object> batchDataReq = new HashMap<String, Object>();
		JSONObject batchDataReq =  new JSONObject();
		try {
			for (String s : buffered) {
				JSONObject inputJson = new JSONObject(s);
				if(inputJson.has("timeMetrics")) {
					timeMetricsList.add(inputJson.getJSONObject("timeMetrics"));
					inputJson.remove("timeMetrics");
				}

				//mylist.add(new JSONObject(s)); // Fix- 09/05/2024 - Parse JSON without time metrics
				mylist.add(inputJson);

			}
			batchDataReq.put("requestType", requestType);
			batchDataReq.put("listKeyAttributes", mylist);

			request = batchDataReq.toString();
		} catch (Exception ex) {
			failureCounter.inc();
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			c.output(deadLetterQueue, c.element());
			return;
		}
		/** object of cassandra insertion library */
		try {
			long StartTime = System.currentTimeMillis();


			/** send metadata and data of http request to cassandra insertion library and stores the response to 'response' variable */
			HttpResponse<String> response = insertData(client, httpRequest, request);;

			long EndTime = System.currentTimeMillis();
			long TimeTaken = EndTime - StartTime;

			if (response != null && response.statusCode() == 200 && response.body().matches(Constants.REGEX_PNO_SUCCESS)) {
				successCounter.inc();
				c.output(request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
				if(timeMetricsList.size() > 0) {
					for (JSONObject tmObj : timeMetricsList) {
						try {
							tmObj.put("cassandraInsertionTime", getNanoGMTTime());

							SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");
							long sourceLatency = (sdf.parse(tmObj.getString("sourceDFOutTime").substring(0,23)).getTime() -
									sdf.parse(tmObj.getString("sourceDFInTime").substring(0,23)).getTime());
							long transLatency = (sdf.parse(tmObj.getString("transDFOutTime").substring(0,23)).getTime() -
									sdf.parse(tmObj.getString("transDFInTime").substring(0,23)).getTime());
							long totalLatency = (sdf.parse(tmObj.getString("cassandraInsertionTime").substring(0,23)).getTime() -
									sdf.parse(tmObj.getString("sourceDFInTime").substring(0,23)).getTime());

							tmObj.put("sourceDFJobLatency", String.valueOf(sourceLatency) + " ms");
							tmObj.put("transDFJobLatency", String.valueOf(transLatency) + " ms");
							tmObj.put("totalDFJobLatency", String.valueOf(totalLatency) + " ms");

							c.output(timeMetrics, tmObj.toString());
						}catch (Exception e) {
							StringWriter sw = new StringWriter();
							PrintWriter pw = new PrintWriter(sw);
							e.printStackTrace(pw);
							LOG.error(sw.toString());
						}
					}
				}
			} else if (response != null) {
				if (response.statusCode() == 500
						|| response.statusCode() == 501 ||
						response.statusCode() == 502
						|| response.statusCode() == 503) {
					statusCode500.inc();
					if(timeMetricsList.size() > 0) {
						batchDataReq.put("timeMetrics", timeMetricsList);
					}
					c.output(retryRecords, batchDataReq.toString());
				} else {
					if (response.statusCode() == 400
							|| response.statusCode() == 401 ||
							response.statusCode() == 402
							|| response.statusCode() == 403) {
						statusCode400.inc();
					} else {
						failureCounter.inc();
					}
					c.output(deadLetterQueue, request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
				}
			} else {
				failureCounter.inc();
				c.output(deadLetterQueue, request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
			}

		} catch (Exception e) {
			//c.output(retryRecords, request);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			failureApiCounter.inc();
			if(timeMetricsList.size() > 0) {
				batchDataReq.put("timeMetrics", timeMetricsList);
			}
			c.output(retryRecords, batchDataReq.toString());
			LOG.error(sw.toString());
		}

	}
}
