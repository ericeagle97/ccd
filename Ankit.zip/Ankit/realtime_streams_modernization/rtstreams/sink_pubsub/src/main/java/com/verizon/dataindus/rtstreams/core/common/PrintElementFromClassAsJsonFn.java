package com.verizon.dataindus.rtstreams.core.common;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class PrintElementFromClassAsJsonFn extends DoFn<Object,String>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(PrintElementFromClassAsJsonFn.class);

	@ProcessElement
	public void processElement(ProcessContext processContext){

		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		try {
			String json = ow.writeValueAsString(processContext.element());
			processContext.output(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			processContext.output(String.valueOf(processContext.element().toString()).toString());
			e.printStackTrace();
		}		
	}
}

