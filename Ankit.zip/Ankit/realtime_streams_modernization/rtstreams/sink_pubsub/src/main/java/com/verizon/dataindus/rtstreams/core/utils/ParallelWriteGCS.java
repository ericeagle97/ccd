package com.verizon.dataindus.rtstreams.core.utils;

/** A Java class extending Ptransform, expects string input pcollection and yields string output pcollection,
 * Class calls the RedisFlagUtility to do a lookup.
 * Example usage:
 PCollection<String> lines = ... ;
 PCollection<String>  tableRowCollection  = lines.apply(new ParallelWriteGCS(keystorePassword, jksBytes,secretPayload, minuteInterval,timeSeconds, redisFlagValue, redisFlagKey))

 Type parameters:
 <InputT> –  String - Main data
 <OutputT> – String - input data as it is **/

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.lib.RedisFlagLookup;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

public class ParallelWriteGCS extends PTransform<PCollection<String>, PCollection<String>> {

    StreamsJobRunner.PubsubIngestionOptions options;
    public ParallelWriteGCS(StreamsJobRunner.PubsubIngestionOptions options){
        this.options = options;
    }

    @Override
    public PCollection<String> expand(PCollection<String> input) {
        SecretInterface objSecret = new SecretInterfaceClass();

        /**
         * Type - String, use - holds keystore password for redis connection
         **/
        String keystorePassword = ((ByteString) objSecret.SecretGCP(options.getProjectId(),
                options.getKeystorePassword(), "latest")).toStringUtf8();

        /**
         * Type - byte array, use - holds jks bytes for redis connection
         **/
        byte[] jksBytes = ((ByteString) objSecret.SecretGCP(options.getProjectId()
                , options.getKeystoreFile(), "latest")).toByteArray();

        /**
         * Type - byte string, use - holds secret payload for redis connection
         **/
        ByteString secretPayload = (ByteString) objSecret.SecretGCP(options.getProjectId(),
                options.getSecretCredentials(), "latest");

        int minuteInterval = options.getMinuteInterval();

        /**
         * Type -  string, use - holds config data, seconds for redis flag check **/
        int timeSeconds = options.getTimeSeconds();

        /**
         * Type -  string, use - holds config data, value for redis lookup **/
        String redisFlagValue = options.getRedisFlagValue();

        /**
         * Type -  string, use - holds config data, key for redis lookup **/
        String redisFlagKey = options.getRedisFlagKey();

        int gcsWindowDuration = options.getWindowDuration();
        String gcsFilePath = options.getTimeMetricsGCSLoc();
        String gcsFileName = options.getTimeMetricsGCSFileName();
        int gcsNoShards = options.getNumShards();

        String gcsOrPubsubTM = options.getGcsOrPubsubTM(); ;
        String pubsubOutputTopicTM = options.getPubsubOutputTopicTM();

        /**
         * call a pardo function, to check for redis flag **/
        PCollection<String> gcsRowCollection = input
        		.apply("Redis flag check", ParDo.of(new RedisFlagLookup(keystorePassword,
                        jksBytes, secretPayload, minuteInterval,
        				timeSeconds, redisFlagValue, redisFlagKey)));
        /**
         * Utility call to write data to gcs (change the code as Write utility is prepared) **/
         IOUtility.deadLetterOptionalSink(gcsOrPubsubTM,
                gcsRowCollection, pubsubOutputTopicTM,
                gcsWindowDuration, // changed
                gcsFilePath,
                gcsFileName,
                gcsNoShards);
        return input;
    }
}
