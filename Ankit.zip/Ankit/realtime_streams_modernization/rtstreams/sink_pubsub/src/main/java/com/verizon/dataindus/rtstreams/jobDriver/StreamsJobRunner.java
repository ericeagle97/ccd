package com.verizon.dataindus.rtstreams.jobDriver;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.pipeline.ingestion.pubsub.PNOInsertion;


public class StreamsJobRunner 
{
	public static PubsubIngestionOptions options;
	public static boolean flagGCS = false;
	/*
	 * Interface to add custom pipeline options to  pipeline
	 */
	public static interface PubsubIngestionOptions extends PipelineOptions 
	{
		//Get GCP Project ID
		@Description("GCP Project ID")
		@Validation.Required
		//@Default.String("vz-it-np-gh2v-dev-rtstdo-0")
		String getProjectId();
		void setProjectId(String projectId);

		// Pubsub Input Subscription
		@Description("PubSub topic to subscribe messages")
		@Validation.Required
		//@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/subscriptions/sub-cee-pubsub-trans-pzai")
		String getPubsubSubscription();
		void setPubsubSubscription(String value);

		// Pubsub Retry Single Subscription
		@Description("PubSub topic to subscribe Single retry messages")
		@Validation.Required
		//@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/subscriptions/sub-cee-pubsub-pno-retry")
		String getRetryPubSubSubscription();
		void setRetryPubSubSubscription(String value);

		// Pubsub Retry Bulk Subscription
		@Description("PubSub topic to subscribe Bulk retry messages")
		@Validation.Required
		//@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/subscriptions/sub-cee-pubsub-pno-retry")
		String getRetryBulkPubSubSubscription();
		void setRetryBulkPubSubSubscription(String value);

		//Pubsub Attributes to read messages
		@Description("Pubsub Attributes Names (comma-separated)")
		@Validation.Required
		@Default.String("attr-cee-pubsub-pzai-events")
		String getPubsubAttributeNames();
		void setPubsubAttributeNames(String pubsubAttributeNames);

		//Get PubsubIO Read Config bucket
		@Description("PubsubIO read config bucket")
		@Validation.Required
		@Default.String("vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow_rts")
		String getPubsubIOReadConfigBucket();
		void setPubsubIOReadConfigBucket(String pubsubIOReadConfigBucket);

		//Get PubsubIO read config file
		@Description("PubsubIO read config file")
		@Validation.Required
		@Default.String("rt/cee/tar/cassandra/config/cassandra_config.json")
		String getPubsubIOReadConfigFile();
		void setPubsubIOReadConfigFile(String pubsubIOReadConfigFile);

		@Description("Enable or Disable custom Logging and exceptions")
		@Validation.Required
		@Default.Boolean(true)
		boolean getErrorLog();
		void setErrorLog(boolean errorLog);

		// Parameters below are used only for writing dead letter records

		// Pubsub Retry Output Topic
		@Description("PubSub topic to publish messages")
		@Validation.Required
		@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/topics/tp-cee-pno")
		String getPubSubTopic();
		void setPubSubTopic(String value);

		@Description("Number of shards for each windowing function ")
		//@Validation.Required
		int getNumShards();
		void setNumShards(int value);

		@Description("Dead Letter Output can be \"GCS\" or \"PubSub\" ")
		//@Validation.Required
		String getDeadLetterSink();
		void setDeadLetterSink(String value);

		@Description("Gcs path to store the data into runtime path")
		//@Validation.Required
		String getPath();
		void setPath(String value);

		@Description("WindowDuration in Seconds")
		//@Validation.Required
		int getWindowDuration();
		void setWindowDuration(int value);

		@Description("FileName")
		//@Validation.Required
		String getFileName();
		void setFileName(String value);

		// Parameters below are used only for writing dead letter records

		@Description("MemoryStore Keystore File")
		String getKeystoreFile();
		void setKeystoreFile(String value);

		@Description("MemoryStore Keystore Password")
		String getKeystorePassword();
		void setKeystorePassword(String value);

		@Description("MemoryStore GCP Secrets")
		String getSecretCredentials();
		void setSecretCredentials(String value);

		@Description("Cassandra Insertion Single URL")
		@Validation.Required
		//@Default.String("https://mcscmpt2-pnosoi.ebiz.verizon.com/PNO/request")
		String getHttpUrl();
		void setHttpUrl(String httpUrl);

		@Description("Cassandra Insertion Bulk URL")
		@Validation.Required
		//@Default.String("https://mcscmpt2-pnosoi.ebiz.verizon.com/PNO/request")
		String getBulkHttpUrl();
		void setBulkHttpUrl(String bulkHttpUrl);
		
		@Description("PNO RequestType")
		@Validation.Required
			//eg.  "SOI_InsertCustModelfeatures"
		int getMinuteInterval();
		void setMinuteInterval(int minuteInterval);

		@Description("PNO RequestType")
		@Validation.Required
			//eg.  "SOI_InsertCustModelfeatures"
		int getTimeSeconds();
		void setTimeSeconds(int timeSeconds);

		@Description("PNO RequestType")
		@Validation.Required
			//eg.  "SOI_InsertCustModelfeatures"
		String getRedisFlagValue();
		void setRedisFlagValue(String redisFlagValue);

		@Description("PNO RequestType")
		@Validation.Required
		String getTimeMetricsGCSFileName();
		void setTimeMetricsGCSFileName(String timeMetricsGCSFileName);

		@Description("PNO RequestType")
		@Validation.Required
		String getTimeMetricsGCSLoc();
		void setTimeMetricsGCSLoc(String timeMetricsGCSLoc);

		@Description("PNO RequestType")
		@Validation.Required
		String getRedisFlagKey();
		void setRedisFlagKey(String redisFlagKey);

		@Description("PNO RequestType")
		@Validation.Required
		String getGcsOrPubsubTM();
		void setGcsOrPubsubTM(String gcsOrPubsubTM);

		@Description("PNO RequestType")
		@Validation.Required
		String getPubsubOutputTopicTM();
		void setPubsubOutputTopicTM(String pubsubOutputTopicTM);
	}

	/*
	 * Main method gets arguments as custom pipeline options and triggers PubsubIngestion template
	 */
	public static void main(String args[])
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();
		try
		{
			options = PipelineOptionsFactory.fromArgs(args).withValidation().as(PubsubIngestionOptions.class);
			objCustomExceptions.errorLog = options.getErrorLog();
			PNOInsertion pubsub = new PNOInsertion();
			pubsub.pnoInsertion(options);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			objCustomExceptions.errorPipeline("StreamsJobRunner",e);
		}
	}
}
