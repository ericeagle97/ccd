package com.verizon.dataindus.rtstreams.core.utils;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.lib.CassandraInsertionRetry;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getNanoGMTTime;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;


public class CassandraInsertRPCRetry extends DoFn<String, String> {
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertRPCRetry.class);
    private String httpRequest;
  //  private String requestType;
    static HttpClient client;

	public CassandraInsertRPCRetry(String httpRequest/* , String requestType */) {
        this.httpRequest = httpRequest;
    //    this.requestType = requestType;
    }

    public static final TupleTag<String> retryRecords = new TupleTag<>() {
    };
    public static final TupleTag<String> deadLetterQueue = new TupleTag<>() {
    };
    public static final TupleTag<String> responseSuccess = new TupleTag<>() {
    };
    public static final TupleTag<String> timeMetrics = new TupleTag<>() {
    };

    public static final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_RESPONSE+"_"+ Constants.METRICS_COUNTER_SUCCESS_RETRY );
    public static final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_RESPONSE+"_"+ Constants.METRICS_COUNTER_FAILURE_RETRY );



    @Setup
    public void setup(){
        client = HttpClient.newHttpClient();
    }

    @ProcessElement
    public void processElement(ProcessContext c){
    	String request = c.element();
        JSONObject requestJsonObject = new JSONObject(c.element());
        JSONArray timeMetricsList = null;
        if(requestJsonObject.has("timeMetrics")) {
        	try {
        		timeMetricsList = (JSONArray)requestJsonObject.remove("timeMetrics");
        	}catch (Exception e) {
        		StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				LOG.error(sw.toString());
			}
        }
        request = requestJsonObject.toString(); 
        try {
            long StartTime = System.currentTimeMillis();
            CassandraInsertionRetry insertData = new CassandraInsertionRetry(client);

            /** send metadata and data of http request to cassandra insertion library and stores the response to 'response' variable */
            HttpResponse<String> response = insertData.cassandraInsertion(httpRequest, request, c);
            long EndTime = System.currentTimeMillis();
            long TimeTaken = EndTime - StartTime;
            if (response != null && response.statusCode() == 200 && response.body().matches(Constants.REGEX_PNO_SUCCESS)) {
                successCounter.inc();
                c.output(request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
                if (timeMetricsList != null) {
					for (int i = 0;i < timeMetricsList.length(); i++) {
						JSONObject tmObj = timeMetricsList.getJSONObject(i);
						try {
							tmObj.put("cassandraInsertionTime", getNanoGMTTime());

							SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");
							long sourceLatency = (sdf.parse(tmObj.getString("sourceDFOutTime").substring(0, 23))
									.getTime()
									- sdf.parse(tmObj.getString("sourceDFInTime").substring(0, 23)).getTime());
							long transLatency = (sdf.parse(tmObj.getString("transDFOutTime").substring(0, 23)).getTime()
									- sdf.parse(tmObj.getString("transDFInTime").substring(0, 23)).getTime());
							long totalLatency = (sdf.parse(tmObj.getString("cassandraInsertionTime").substring(0, 23))
									.getTime()
									- sdf.parse(tmObj.getString("sourceDFInTime").substring(0, 23)).getTime());

							tmObj.put("sourceDFJobLatency", String.valueOf(sourceLatency) + " ms");
							tmObj.put("transDFJobLatency", String.valueOf(transLatency) + " ms");
							tmObj.put("totalDFJobLatency", String.valueOf(totalLatency) + " ms");

							c.output(timeMetrics, tmObj.toString());
						} catch (Exception e) {
							StringWriter sw = new StringWriter();
							PrintWriter pw = new PrintWriter(sw);
							e.printStackTrace(pw);
							LOG.error(sw.toString());
						}
					}
				}
            } else if (response == null || !(response.body().matches(Constants.REGEX_PNO_SUCCESS))) {
                failureCounter.inc();
                c.output(deadLetterQueue, request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
            } else {
                failureCounter.inc();
                c.output(deadLetterQueue, request + "," + response + "," + TimeTaken + "," + StartTime + "," + EndTime);
            }
        }
        catch (Exception e) {
        	if(timeMetricsList != null && timeMetricsList.length() > 0) {
        		requestJsonObject.put("timeMetrics", timeMetricsList);
        	}
            c.output(CassandraInsertRPCRetry.retryRecords, requestJsonObject.toString());

            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            LOG.error(sw.toString());
            failureCounter.inc();
        }
    }

    @Teardown
    public void teardown(){
        if(client != null){
            client=null;
        }
    }
}
