package com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.KafkaIngestionOptions;
import com.verizon.dataindus.rtstreams.lib.readers.KafkaReader;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getKafkaIOReadConfigurations;

public class MultiTopicKafkaIngestion {

	public void multiTopicKafkaIngestion(KafkaIngestionOptions options) {

		// Creates pipeline with custom pipeline options
		Pipeline pipeline = Pipeline.create(options);

		// Creating object for custom exception class
		ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

		// Create a map of topics as keys and their respective configurations as values
		Map<String,JSONObject> kafkaTopicConfigMap = getKafkaIOReadConfigurations(
				options.getProjectId(),
				options.getKafkaIOReadConfigBucket(),
				options.getKafkaIOReadConfigFile(),
				options.getKafkaIOReadSource(),
				objCustomExceptions);

		// Map <TopicName , PCollections created after KafkaIO.read()>
		Map<String,PCollection<String>> mapKafkaIOReadPCollections = new HashMap<String,PCollection<String>>();

		try{
			if(!kafkaTopicConfigMap.isEmpty())
				for(String kafkaTopic: options.getKafkaTopicNames().split(",")){
					// Add all PCollections read to the list
					List<PCollection<String>> listPCollectionsByRegion = new KafkaReader()
							.readSource(pipeline,kafkaTopic,options.getKafkaIOReadRegions(),
									kafkaTopicConfigMap);

					// Flatten out all PCollections read
					PCollection<String> dataFromAllKafkaTopicRead =
							PCollectionList.of(listPCollectionsByRegion)
									.apply("Flatten PCollections",Flatten.pCollections());


					mapKafkaIOReadPCollections.put(kafkaTopic ,dataFromAllKafkaTopicRead);
				}

			//JsonParsing and Source Transformations with PubSub write for downstream consumptions
			MultiTopicSourceTransformLauncher processLauncher =new MultiTopicSourceTransformLauncher();
			/*Calling SourceProcessLauncher for source transformations if any class*/
			processLauncher.sourceProcessLauncher(mapKafkaIOReadPCollections,options);

			pipeline.run();
		} catch (Exception e) {
			e.printStackTrace();
			objCustomExceptions.errorPipeline("KafkaIngestion", e);
		}
	}

}