package com.verizon.dataindus.rtstreams.core.beans.tar.port;

import java.io.Serializable;

import javax.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

public class portInsightValues implements Serializable{
	
	
	public String getLastQualificationTime() {
		return lastQualificationTime;
	}
	public void setLastQualificationTime(String lastQualificationTime) {
		this.lastQualificationTime = lastQualificationTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Nullable
	@SerializedName("lastQualificationTime")
	private String lastQualificationTime;
	
	@Nullable
	@SerializedName("status")
	private String status;
	
	@Nullable
	@SerializedName("name")
	private String name;

}
