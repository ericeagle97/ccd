package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


@javax.annotation.Nullable
public class SubmittedPerkDetails implements Serializable {
	
	@Nullable
	@SerializedName("pxObjClass")
	String pxObjClass;
	
	@Nullable
	@SerializedName("posOrderNumber")
	String posOrderNumber;
	
	@Nullable
	@SerializedName("addDeleteInd")
	String addDeleteInd;
	
	@Nullable
	@SerializedName("mtn")
	String mtn;
	
	@Nullable
	@SerializedName("posLocationCode")
	String posLocationCode;
	
	@Nullable
	@SerializedName("visFeatureCode")
	String visFeatureCode;
	
	@Nullable
	@SerializedName("effectiveDate")
	String effectiveDate;
	
	@Nullable
	@SerializedName("isProrated")
	String isProrated;
	
	@Nullable
	@SerializedName("pxUpdateDateTime")
	String pxUpdateDateTime;

	public String getPxObjClass() {
		return pxObjClass;
	}

	public void setPxObjClass(String pxObjClass) {
		this.pxObjClass = pxObjClass;
	}

	public String getPosOrderNumber() {
		return posOrderNumber;
	}

	public void setPosOrderNumber(String posOrderNumber) {
		this.posOrderNumber = posOrderNumber;
	}

	public String getAddDeleteInd() {
		return addDeleteInd;
	}

	public void setAddDeleteInd(String addDeleteInd) {
		this.addDeleteInd = addDeleteInd;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getPosLocationCode() {
		return posLocationCode;
	}

	public void setPosLocationCode(String posLocationCode) {
		this.posLocationCode = posLocationCode;
	}

	public String getVisFeatureCode() {
		return visFeatureCode;
	}

	public void setVisFeatureCode(String visFeatureCode) {
		this.visFeatureCode = visFeatureCode;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getIsProrated() {
		return isProrated;
	}

	public void setIsProrated(String isProrated) {
		this.isProrated = isProrated;
	}

	public String getPxUpdateDateTime() {
		return pxUpdateDateTime;
	}

	public void setPxUpdateDateTime(String pxUpdateDateTime) {
		this.pxUpdateDateTime = pxUpdateDateTime;
	}
	
}
