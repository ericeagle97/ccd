package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class RtModelRes implements Serializable {

   @SerializedName("insightCategory")
   String insightCategory;

   @SerializedName("insightName")
   String insightName;

   @SerializedName("modelName")
   String modelName;

   @SerializedName("timeTaken")
   int timeTaken;

   @SerializedName("result")
   Result result;


    public void setInsightCategory(String insightCategory) {
        this.insightCategory = insightCategory;
    }
    public String getInsightCategory() {
        return insightCategory;
    }
    
    public void setInsightName(String insightName) {
        this.insightName = insightName;
    }
    public String getInsightName() {
        return insightName;
    }
    
    public void setModelName(String modelName) {
        this.modelName = modelName;
    }
    public String getModelName() {
        return modelName;
    }
    
    public void setTimeTaken(int timeTaken) {
        this.timeTaken = timeTaken;
    }
    public int getTimeTaken() {
        return timeTaken;
    }
    
    public void setResult(Result result) {
        this.result = result;
    }
    public Result getResult() {
        return result;
    }
    
}