package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Features implements Serializable {

   @SerializedName("refNumber")
   String refNumber;

   @SerializedName("source")
   String source;

   @SerializedName("comments")
   String comments;


    public void setRefNumber(String refNumber) {
        this.refNumber = refNumber;
    }
    public String getRefNumber() {
        return refNumber;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    public String getSource() {
        return source;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
    public String getComments() {
        return comments;
    }
    
}