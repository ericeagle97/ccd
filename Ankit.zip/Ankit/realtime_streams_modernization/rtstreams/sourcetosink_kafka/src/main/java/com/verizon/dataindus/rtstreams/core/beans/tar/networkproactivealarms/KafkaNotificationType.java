package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class KafkaNotificationType implements Serializable {
    @SerializedName("MDN_5G")
    @Nullable
    String MDN_5G;

    @SerializedName("SERIALNUMBER")
    @Nullable
    String SERIALNUMBER;

    @SerializedName("REPORT_TIME")
    @Nullable
    String REPORT_TIME;

    @SerializedName("TRANS_DT")
    @Nullable
    String TRANS_DT;

    @SerializedName("ALARM_TYPE")
    @Nullable
    String ALARM_TYPE;

    @SerializedName("ALARM_CATEGORY")
    @Nullable
    String ALARM_CATEGORY;

    @SerializedName("ALERT_ID")
    @Nullable
    String ALERT_ID;

    @SerializedName("ID")
    @Nullable
    String ID;

    @SerializedName("SOIPROCESSTIME")
    @Nullable
    String SOIPROCESSTIME;

    @SerializedName("CATEGORY_ID")
    @Nullable
    String CATEGORY_ID;

    @SerializedName("description")
    @Nullable
    String description;

    @Nullable
    public String getMDN_5G() {
        return MDN_5G;
    }

    public void setMDN_5G(@Nullable String MDN_5G) {
        this.MDN_5G = MDN_5G;
    }

    @Nullable
    public String getSERIALNUMBER() {
        return SERIALNUMBER;
    }

    public void setSERIALNUMBER(@Nullable String SERIALNUMBER) {
        this.SERIALNUMBER = SERIALNUMBER;
    }

    @Nullable
    public String getREPORT_TIME() {
        return REPORT_TIME;
    }

    public void setREPORT_TIME(@Nullable String REPORT_TIME) {
        this.REPORT_TIME = REPORT_TIME;
    }

    @Nullable
    public String getTRANS_DT() {
        return TRANS_DT;
    }

    public void setTRANS_DT(@Nullable String TRANS_DT) {
        this.TRANS_DT = TRANS_DT;
    }

    @Nullable
    public String getALARM_TYPE() {
        return ALARM_TYPE;
    }

    public void setALARM_TYPE(@Nullable String ALARM_TYPE) {
        this.ALARM_TYPE = ALARM_TYPE;
    }

    @Nullable
    public String getALARM_CATEGORY() {
        return ALARM_CATEGORY;
    }

    public void setALARM_CATEGORY(@Nullable String ALARM_CATEGORY) {
        this.ALARM_CATEGORY = ALARM_CATEGORY;
    }

    @Nullable
    public String getALERT_ID() {
        return ALERT_ID;
    }

    public void setALERT_ID(@Nullable String ALERT_ID) {
        this.ALERT_ID = ALERT_ID;
    }

    @Nullable
    public String getID() {
        return ID;
    }

    public void setID(@Nullable String ID) {
        this.ID = ID;
    }

    @Nullable
    public String getSOIPROCESSTIME() {
        return SOIPROCESSTIME;
    }

    public void setSOIPROCESSTIME(@Nullable String SOIPROCESSTIME) {
        this.SOIPROCESSTIME = SOIPROCESSTIME;
    }

    @Nullable
    public String getCATEGORY_ID() {
        return CATEGORY_ID;
    }

    public void setCATEGORY_ID(@Nullable String CATEGORY_ID) {
        this.CATEGORY_ID = CATEGORY_ID;
    }


    public void setSOIPROCESSTIME(){
        this.SOIPROCESSTIME = null;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "KafkaNotificationType{" +
                "MDN_5G='" + MDN_5G + '\'' +
                ", SERIALNUMBER='" + SERIALNUMBER + '\'' +
                ", REPORT_TIME='" + REPORT_TIME + '\'' +
                ", TRANS_DT='" + TRANS_DT + '\'' +
                ", ALARM_TYPE='" + ALARM_TYPE + '\'' +
                ", ALARM_CATEGORY='" + ALARM_CATEGORY + '\'' +
                ", ALERT_ID='" + ALERT_ID + '\'' +
                ", ID='" + ID + '\'' +
                ", SOIPROCESSTIME='" + SOIPROCESSTIME + '\'' +
                ", CATEGORY_ID='" + CATEGORY_ID + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
