package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class OrderDetailsType implements Serializable {

	@Nullable
	@SerializedName("pxObjClass")
	String pxObjClass;

	@Nullable
	@SerializedName("digitalOrderType")
	String digitalOrderType;
	
	@Nullable
	@SerializedName("pxUpdateDateTime")
	String pxUpdateDateTime;
	
	@Nullable
	@SerializedName("ServiceAppointment")
	ServiceAppointment ServiceAppointment;

	@Nullable
	@SerializedName("homeInstallType")
	String homeInstallType;

	public String getPxObjClass() {
		return pxObjClass;
	}

	public void setPxObjClass(String pxObjClass) {
		this.pxObjClass = pxObjClass;
	}

	public String getDigitalOrderType() {
		return digitalOrderType;
	}

	public void setDigitalOrderType(String digitalOrderType) {
		this.digitalOrderType = digitalOrderType;
	}

	public String getPxUpdateDateTime() {
		return pxUpdateDateTime;
	}

	public void setPxUpdateDateTime(String pxUpdateDateTime) {
		this.pxUpdateDateTime = pxUpdateDateTime;
	}

	public ServiceAppointment getServiceAppointment() {
		return ServiceAppointment;
	}

	public void setServiceAppointment(ServiceAppointment serviceAppointment) {
		ServiceAppointment = serviceAppointment;
	}

	public String getHomeInstallType() {
		return homeInstallType;
	}

	public void setHomeInstallType(String homeInstallType) {
		this.homeInstallType = homeInstallType;
	}

	

}