package com.verizon.dataindus.rtstreams.core.beans.src.ivrintent;

import autovalue.shaded.org.jetbrains.annotations.Nullable;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class cassandratobq implements Serializable{
	
	
	@Nullable
	@SerializedName("DfStarttime")
	private String DfStarttime;
	
	@Nullable
	@SerializedName("IVRSentTime")
	private String IVRSentTime;
	
	@Nullable
	@SerializedName("KafkaInputRaw")
	private String KafkaInputRaw;
	
	@Nullable
	@SerializedName("DFEndTime")
	private String DFEndTime;
	
	
	@Nullable
	@SerializedName("mtn")
	private String mtn;

	
	@Nullable
	@SerializedName("statusCode")
	private int statusCode;
	
	@Nullable
	@SerializedName("cassandraReq")
	private String cassandraReq;

	public String getDfStarttime() {
		return DfStarttime;
	}

	public void setDfStarttime(String DfStarttime) {
		DfStarttime = DfStarttime;
	}

	public String getIVRSentTime() {
		return IVRSentTime;
	}

	public void setIVRSentTime(String IVRSentTime) {
		IVRSentTime = IVRSentTime;
	}

	public String getKafkaInputRaw() {
		return KafkaInputRaw;
	}

	public void setKafkaInputRaw(String KafkaInputRaw) {
		KafkaInputRaw = KafkaInputRaw;
	}

	public String getDFEndTime() {
		return DFEndTime;
	}

	public void setDFEndTime(String dFEndTime) {
		DFEndTime = dFEndTime;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getCassandraReq() {
		return cassandraReq;
	}

	public void setCassandraReq(String cassandraReq) {
		this.cassandraReq = cassandraReq;
	}

	@Override
	public String toString() {
		return "cassandratobq {" + (DfStarttime != null ? "DfStarttime:" + DfStarttime + ", " : "")
				+ (IVRSentTime != null ? "IVRSentTime:" + IVRSentTime + ", " : "")
				+ (KafkaInputRaw != null ? "KafkaInputRaw:" + KafkaInputRaw + ", " : "")
				+ (DFEndTime != null ? "DFEndTime:" + DFEndTime + ", " : "") + (mtn != null ? "mtn:" + mtn + ", " : "")
				+ "statusCode:" + statusCode + ", " + (cassandraReq != null ? "cassandraReq:" + cassandraReq : "")
				+ "}";
	}

	
	


	
	
	
	

}
