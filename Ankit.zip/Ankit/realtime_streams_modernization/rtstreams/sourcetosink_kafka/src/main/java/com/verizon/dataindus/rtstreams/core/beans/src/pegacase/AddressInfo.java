package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class AddressInfo implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("zipCode")
   String zipCode;

   @Nullable
	@SerializedName("city")
   String city;

   @Nullable
	@SerializedName("addressType")
   String addressType;

   @Nullable
	@SerializedName("addressLine1")
   String addressLine1;

   @Nullable
	@SerializedName("addressIdClient")
   String addressIdClient;

   @Nullable
	@SerializedName("state")
   String state;

   @Nullable
	@SerializedName("vertexGeocode")
   String vertexGeocode;

   @Nullable
	@SerializedName("addressId")
   String addressId;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    public String getZipCode() {
        return zipCode;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    public String getCity() {
        return city;
    }
    
    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }
    public String getAddressType() {
        return addressType;
    }
    
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    
    public void setAddressIdClient(String addressIdClient) {
        this.addressIdClient = addressIdClient;
    }
    public String getAddressIdClient() {
        return addressIdClient;
    }
    
    public void setState(String state) {
        this.state = state;
    }
    public String getState() {
        return state;
    }
    
    public void setVertexGeocode(String vertexGeocode) {
        this.vertexGeocode = vertexGeocode;
    }
    public String getVertexGeocode() {
        return vertexGeocode;
    }
    
    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
    public String getAddressId() {
        return addressId;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
}