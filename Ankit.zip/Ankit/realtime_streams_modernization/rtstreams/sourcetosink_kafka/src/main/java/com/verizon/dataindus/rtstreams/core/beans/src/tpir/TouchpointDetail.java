package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@XmlRootElement(name = "touchpointDetail")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class TouchpointDetail implements Serializable{
	
	@SerializedName("channelId")
	@Nullable 
	@XmlElement(name = "channelId")
	public String channelId; 

	@SerializedName("activityDate")
	@Nullable 
	@XmlElement(name = "activityDate")
	public String activityDate; 

	@SerializedName("activitySummary")
	@Nullable 
	@XmlElement(name = "activitySummary")
	public String activitySummary; 

	@SerializedName("activityDetail")
	@Nullable 
	@XmlElement(name = "activityDetail")
	public String activityDetail; 

	@SerializedName("status")
	@Nullable 
	@XmlElement(name = "status")
	public String status; 

	@SerializedName("selfServe")
	@Nullable 
	@XmlElement(name = "selfServe")
	public String selfServe; 

	@SerializedName("mtn")
	@Nullable 
	@XmlElement(name = "mtn")
	public String mtn; 

	@SerializedName("outageID")
	@Nullable 
	@XmlElement(name = "outageID")
	public String outageID; 

	@SerializedName("outageState")
	@Nullable 
	@XmlElement(name = "outageState")
	public String outageState; 

	@SerializedName("requestID")
	@Nullable 
	@XmlElement(name = "requestID")
	public String requestID; 

	@SerializedName("timestamp")
	@Nullable 
	@XmlElement(name = "timestamp")
	public String timestamp; 

	@SerializedName("congestedHours")
	@Nullable 
	@XmlElement(name = "congestedHours")
	public String congestedHours; 

	@SerializedName("accountNumber")
	@Nullable 
	@XmlElement(name = "accountNumber")
	public String accountNumber; 

	@SerializedName("subChannel")
	@Nullable 
	@XmlElement(name = "subChannel")
	public String subChannel; 
	
	@SerializedName("statusMessage")
	@Nullable 
	@XmlElement(name = "statusMessage")
	public String statusMessage; 
	
	@SerializedName("statusCode")
	@Nullable 
	@XmlElement(name = "statusCode")
	public String statusCode; 

	@SerializedName("additionalInfo")
	@Nullable 
	@XmlElement(name = "additionalInfo")
	public String additionalInfo; 

	@SerializedName("agentUserName")
	@Nullable 
	@XmlElement(name = "agentUserName")
	public String agentUserName; 

	@SerializedName("accountTenure")
	@Nullable 
	@XmlElement(name = "accountTenure")
	public String accountTenure; 

	@SerializedName("callCenterDesc")
	@Nullable 
	@XmlElement(name = "callCenterDesc")
	public String callCenterDesc; 

	@SerializedName("callDisputeInd")
	@Nullable 
	@XmlElement(name = "callDisputeInd")
	public String callDisputeInd; 

	@SerializedName("callReason")
	@Nullable 
	@XmlElement(name = "callReason")
	public String callReason; 

	@SerializedName("cartID")
	@Nullable 
	@XmlElement(name = "cartID")
	public String cartID; 

	@SerializedName("cbr")
	@Nullable 
	@XmlElement(name = "cbr")
	public String cbr; 

	@SerializedName("departmentDesc")
	@Nullable 
	@XmlElement(name = "departmentDesc")
	public String departmentDesc; 

	@SerializedName("destinationDept")
	@Nullable 
	@XmlElement(name = "destinationDept")
	public String destinationDept; 

	@SerializedName("repName")
	@Nullable 
	@XmlElement(name = "repName")
	public String repName; 

	@SerializedName("errorMsg")
	@Nullable 
	@XmlElement(name = "errorMsg")
	public String errorMsg; 

	@SerializedName("failReason")
	@Nullable 
	@XmlElement(name = "failReason")
	public String failReason; 

	@SerializedName("finalStatus")
	@Nullable 
	@XmlElement(name = "finalStatus")
	public String finalStatus; 

	@SerializedName("lastName")
	@Nullable 
	@XmlElement(name = "lastName")
	public String lastName; 

	@SerializedName("lob")
	@Nullable 
	@XmlElement(name = "lob")
	public String lob; 

	@SerializedName("pageName")
	@Nullable 
	@XmlElement(name = "pageName")
	public String pageName; 

	@SerializedName("purchaseFlow")
	@Nullable 
	@XmlElement(name = "purchaseFlow")
	public String purchaseFlow; 

	@SerializedName("remedyFlag")
	@Nullable 
	@XmlElement(name = "remedyFlag")
	public String remedyFlag; 

	@SerializedName("revenue")
	@Nullable 
	@XmlElement(name = "revenue")
	public String revenue; 

	@SerializedName("toolkit")
	@Nullable 
	@XmlElement(name = "toolkit")
	public String toolkit; 

	@SerializedName("transferPoint")
	@Nullable 
	@XmlElement(name = "transferPoint")
	public String transferPoint; 

	@SerializedName("treatmentFlag")
	@Nullable 
	@XmlElement(name = "treatmentFlag")
	public String treatmentFlag; 

	@SerializedName("tsrNextStep")
	@Nullable 
	@XmlElement(name = "tsrNextStep")
	public String tsrNextStep; 

	@SerializedName("tsrSymptom")
	@Nullable 
	@XmlElement(name = "tsrSymptom")
	public String tsrSymptom; 

	@SerializedName("typeOfBilling")
	@Nullable 
	@XmlElement(name = "typeOfBilling")
	public String typeOfBilling; 

	@SerializedName("userRole")
	@Nullable 
	@XmlElement(name = "userRole")
	public String userRole; 

	@SerializedName("workState")
	@Nullable 
	@XmlElement(name = "workState")
	public String workState; 

	@SerializedName("speechTag")
	@Nullable 
	@XmlElement(name = "speechTag")
	public String speechTag; 

	@SerializedName("intent")
	@Nullable 
	@XmlElement(name = "intent")
	public String intent;

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getActivitySummary() {
		return activitySummary;
	}

	public void setActivitySummary(String activitySummary) {
		this.activitySummary = activitySummary;
	}

	public String getActivityDetail() {
		return activityDetail;
	}

	public void setActivityDetail(String activityDetail) {
		this.activityDetail = activityDetail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSelfServe() {
		return selfServe;
	}

	public void setSelfServe(String selfServe) {
		this.selfServe = selfServe;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getOutageID() {
		return outageID;
	}

	public void setOutageID(String outageID) {
		this.outageID = outageID;
	}

	public String getOutageState() {
		return outageState;
	}

	public void setOutageState(String outageState) {
		this.outageState = outageState;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getCongestedHours() {
		return congestedHours;
	}

	public void setCongestedHours(String congestedHours) {
		this.congestedHours = congestedHours;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getSubChannel() {
		return subChannel;
	}

	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getAgentUserName() {
		return agentUserName;
	}

	public void setAgentUserName(String agentUserName) {
		this.agentUserName = agentUserName;
	}

	public String getAccountTenure() {
		return accountTenure;
	}

	public void setAccountTenure(String accountTenure) {
		this.accountTenure = accountTenure;
	}

	public String getCallCenterDesc() {
		return callCenterDesc;
	}

	public void setCallCenterDesc(String callCenterDesc) {
		this.callCenterDesc = callCenterDesc;
	}

	public String getCallDisputeInd() {
		return callDisputeInd;
	}

	public void setCallDisputeInd(String callDisputeInd) {
		this.callDisputeInd = callDisputeInd;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCartID() {
		return cartID;
	}

	public void setCartID(String cartID) {
		this.cartID = cartID;
	}

	public String getCbr() {
		return cbr;
	}

	public void setCbr(String cbr) {
		this.cbr = cbr;
	}

	public String getDepartmentDesc() {
		return departmentDesc;
	}

	public void setDepartmentDesc(String departmentDesc) {
		this.departmentDesc = departmentDesc;
	}

	public String getDestinationDept() {
		return destinationDept;
	}

	public void setDestinationDept(String destinationDept) {
		this.destinationDept = destinationDept;
	}

	public String getRepName() {
		return repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getFinalStatus() {
		return finalStatus;
	}

	public void setFinalStatus(String finalStatus) {
		this.finalStatus = finalStatus;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPurchaseFlow() {
		return purchaseFlow;
	}

	public void setPurchaseFlow(String purchaseFlow) {
		this.purchaseFlow = purchaseFlow;
	}

	public String getRemedyFlag() {
		return remedyFlag;
	}

	public void setRemedyFlag(String remedyFlag) {
		this.remedyFlag = remedyFlag;
	}

	public String getRevenue() {
		return revenue;
	}

	public void setRevenue(String revenue) {
		this.revenue = revenue;
	}

	public String getToolkit() {
		return toolkit;
	}

	public void setToolkit(String toolkit) {
		this.toolkit = toolkit;
	}

	public String getTransferPoint() {
		return transferPoint;
	}

	public void setTransferPoint(String transferPoint) {
		this.transferPoint = transferPoint;
	}

	public String getTreatmentFlag() {
		return treatmentFlag;
	}

	public void setTreatmentFlag(String treatmentFlag) {
		this.treatmentFlag = treatmentFlag;
	}

	public String getTsrNextStep() {
		return tsrNextStep;
	}

	public void setTsrNextStep(String tsrNextStep) {
		this.tsrNextStep = tsrNextStep;
	}

	public String getTsrSymptom() {
		return tsrSymptom;
	}

	public void setTsrSymptom(String tsrSymptom) {
		this.tsrSymptom = tsrSymptom;
	}

	public String getTypeOfBilling() {
		return typeOfBilling;
	}

	public void setTypeOfBilling(String typeOfBilling) {
		this.typeOfBilling = typeOfBilling;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getWorkState() {
		return workState;
	}

	public void setWorkState(String workState) {
		this.workState = workState;
	}

	public String getSpeechTag() {
		return speechTag;
	}

	public void setSpeechTag(String speechTag) {
		this.speechTag = speechTag;
	}

	public String getIntent() {
		return intent;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}

	@Override
	public String toString() {
		return "TouchpointDetail [channelId=" + channelId + ", activityDate=" + activityDate + ", activitySummary="
				+ activitySummary + ", activityDetail=" + activityDetail + ", status=" + status + ", selfServe="
				+ selfServe + ", mtn=" + mtn + ", outageID=" + outageID + ", outageState=" + outageState
				+ ", requestID=" + requestID + ", timestamp=" + timestamp + ", congestedHours=" + congestedHours
				+ ", accountNumber=" + accountNumber + ", subChannel=" + subChannel + ", statusMessage=" + statusMessage
				+ ", statusCode=" + statusCode + ", additionalInfo=" + additionalInfo + ", agentUserName="
				+ agentUserName + ", accountTenure=" + accountTenure + ", callCenterDesc=" + callCenterDesc
				+ ", callDisputeInd=" + callDisputeInd + ", callReason=" + callReason + ", cartID=" + cartID + ", cbr="
				+ cbr + ", departmentDesc=" + departmentDesc + ", destinationDept=" + destinationDept + ", repName="
				+ repName + ", errorMsg=" + errorMsg + ", failReason=" + failReason + ", finalStatus=" + finalStatus
				+ ", lastName=" + lastName + ", lob=" + lob + ", pageName=" + pageName + ", purchaseFlow="
				+ purchaseFlow + ", remedyFlag=" + remedyFlag + ", revenue=" + revenue + ", toolkit=" + toolkit
				+ ", transferPoint=" + transferPoint + ", treatmentFlag=" + treatmentFlag + ", tsrNextStep="
				+ tsrNextStep + ", tsrSymptom=" + tsrSymptom + ", typeOfBilling=" + typeOfBilling + ", userRole="
				+ userRole + ", workState=" + workState + ", speechTag=" + speechTag + ", intent=" + intent + "]";
	} 

}
