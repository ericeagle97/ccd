package com.verizon.dataindus.rtstreams.core.constants.pegacase;

public class Constants {
    public static final String PEGACASE_NAMESPACE = "PegaCase";
    public static final String TOTAL_VOL_COUNTER = "Source_PegaCase_Count";
    public static final String VIRA_COUNTER = "Source_PegaCase_FilteredVIRA_Count";
    public static final String ERROR_COUNTER = "Source_PegaCase_Error_Count";
    public static final String OST_COUNTER = "Source_PegaCase_FilteredOST_Count";
}

