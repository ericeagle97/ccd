package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.am;

import com.verizon.dataindus.rtstreams.core.beans.src.am.SourceAMPojo;
import com.verizon.dataindus.rtstreams.core.beans.tar.am.CassandraStreamType;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.am.AmConstants;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.joda.time.Instant;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.verizon.dataindus.rtstreams.core.constants.am.AmConstants.*;

public class InsightGeneration extends DoFn <SourceAMPojo,CassandraStreamType> {
    private final Counter AMINSIGHTS_vol = Metrics.counter(AMINSIGHTS, AmConstants.aminsights_counter_success);
    private final Counter AMINSIGHTS_error = Metrics.counter(AMINSIGHTS, AmConstants.aminsights_counter_failure);
    public static final TupleTag<CassandraStreamType> AmInsights_Tag = new TupleTag<CassandraStreamType>() {};
    public static final TupleTag<String> deadLetter = new TupleTag<String>() {};

    @ProcessElement
    public void processElement(ProcessContext c) throws NullPointerException, IOException,IndexOutOfBoundsException {
        CassandraStreamType cassandraObject = new CassandraStreamType();
        SourceAMPojo sourceAMPojo = c.element();
        Map<String, Object> insight_values = new HashMap<>();
        try {
            String cust_id=new String("");
            String acct_no=new String("");

            if ((!CommonUtility.isNullEmptyOrBlank(sourceAMPojo.getMobileNumber()) &&
            		sourceAMPojo.getMobileNumber().matches(Constants.REGEX_MTN) 
    				&& sourceAMPojo.getMobileNumber().length() == 10) &&
            		!CommonUtility.isNullEmptyOrBlank(sourceAMPojo.getAccountNumber())) {
                String CustidAcctno=sourceAMPojo.getAccountNumber();
                cust_id=CustidAcctno.substring(0,10);
                acct_no=CustidAcctno.substring(10,CustidAcctno.length());
            }

            if (!cust_id.isEmpty()&&!acct_no.isEmpty()){
               // DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd'T'HH:mm:ss.SSS 'GMT'"); // format update per BAU - 6/6/2024
                DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd'T'HHmmss.SSS 'GMT'");
                Instant instant = Instant.now();
                String eventTime = formatter.print(instant);
                HashMap<String, Object> InsightValueJson = new HashMap<>();
                String alreadyLocked = sourceAMPojo.isAlreadyLocked();
                cassandraObject.setCust_id_no(cust_id.replaceAll("-", ""));
                cassandraObject.setAcct_no(acct_no.replaceAll("-", ""));
                cassandraObject.setMtn(CommonUtility.getEmptyStrIfNull(sourceAMPojo.getMobileNumber()));
                cassandraObject.setInsight_category("interactions");
                cassandraObject.setInsight_name("accessmanager");
                if(alreadyLocked.equals("true")) {
                    insight_values.put("alreadyLocked", "true");
                }
                else{
                    insight_values.put("alreadyLocked", "false");
                }
                insight_values.put("eventTime", eventTime);
                cassandraObject.setInsight_values(new JSONObject(insight_values));
            }
            AMINSIGHTS_vol.inc();
            c.output(AmInsights_Tag, cassandraObject);
        } catch (Exception e) {
            AMINSIGHTS_error.inc();
            c.output(deadLetter, c.element().toString());
            e.printStackTrace(System.out);
        }
    }
}