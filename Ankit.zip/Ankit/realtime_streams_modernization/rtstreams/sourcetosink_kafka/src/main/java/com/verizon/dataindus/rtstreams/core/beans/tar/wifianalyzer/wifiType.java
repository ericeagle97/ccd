package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

@javax.annotation.Nullable
public class wifiType implements Serializable {

	@SerializedName("bandwidthChannel")
	@Nullable
	private String bandwidthChannel;
	
	@SerializedName("bssid")
	@Nullable
	private String bssid;

	@SerializedName("channelNumber")
	@Nullable
	private long channelNumber;

	@SerializedName("wifiRSSI")
	@Nullable
	private long wifiRSSI;

	@SerializedName("frequency")
	@Nullable
	private long frequency;

	public String getBandwidthChannel() {
		return bandwidthChannel;
	}

	public void setBandwidthChannel(String bandwidthChannel) {
		this.bandwidthChannel = bandwidthChannel;
	}

	public String getBssid() {
		return bssid;
	}

	public void setBssid(String bssid) {
		this.bssid = bssid;
	}

	public long getChannelNumber() {
		return channelNumber;
	}

	public void setChannelNumber(long channelNumber) {
		this.channelNumber = channelNumber;
	}

	public long getWifiRSSI() {
		return wifiRSSI;
	}

	public void setWifiRSSI(long wifiRSSI) {
		this.wifiRSSI = wifiRSSI;
	}

	public long getFrequency() {
		return frequency;
	}

	public void setFrequency(long frequency) {
		this.frequency = frequency;
	}

	@Override
	public String toString() {
		return "wifiType [bandwidthChannel=" + bandwidthChannel + ", bssid=" + bssid + ", channelNumber="
				+ channelNumber + ", wifiRSSI=" + wifiRSSI + ", frequency=" + frequency + "]";
	}

	
	
	

}