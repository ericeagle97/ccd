package com.verizon.dataindus.rtstreams.core.constants.spanremarks;

public class SpanRemarksConstant {
	
	public static final String SPANREMARK_CUSTTYPE = "custType";
	public static final String SPANREMARK_CUSTID = "custId";
	public static final String SPANREMARK_ISSUEID = "issueId";
	public static final String SPANREMARK_TIME = "time";
	public static final String SPANREMARK_clientApp = "clientApp";
	public static final String SPANREMARK_EVENTTIME = "eventTime";
	public static final String SPANREMARK_DATE = "date";
	public static final String SPANREMARK_EVENTDATE = "eventDate";
	public static final String SPANREMARK_INSIGHTVALUES = "insightValues";
	public static final String SPANREMARK_UPDATEBY = "updateBy";
	public static final String SPANREMARK_CREATEDBY = "createdBy";
	public static final String SPANREMARK_UPDATETS = "updateTs";
	public static final String SPANREMARK_KEYATTRIBUTES = "keyAttributes";
	public static final String SPANREMARK_INTERACTIONS = "interactions";
	public static final String SPANREMARK_INSIGHTCATEGORY = "insightCategory";
	public static final String SPANREMARK_INSIGHTNAME = "insightName";
	public static final String SPANREMARK_TTL = "ttl";
	public static final String SPANREMARK_MTN = "mtn";
	public static final String SPANREMARK_ACCTNO = "acctNo";
	public static final String SPANREMARK_ACCTNUM = "acctNum";
	public static final String SPANREMARK_REQUESTTYPE = "requestType";
	public static final String SPANREMARK_STREAMS = "streams";
	public static final String CHANNEL = "SourceSPANREMARK";

}
