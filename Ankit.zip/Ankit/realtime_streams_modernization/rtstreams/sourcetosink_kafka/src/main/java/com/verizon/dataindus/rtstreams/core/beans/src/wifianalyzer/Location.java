package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;

import com.google.gson.annotations.SerializedName;

   
public class Location {

   @SerializedName("latitude")
   double latitude;

   @SerializedName("longitude")
   double longitude;

   @SerializedName("altitude")
   int altitude;

   @SerializedName("accuracy")
   double accuracy;


    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLatitude() {
        return latitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    public double getLongitude() {
        return longitude;
    }
    
    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }
    public int getAltitude() {
        return altitude;
    }
    
    public void setAccuracy(double accuracy) {
        this.accuracy = accuracy;
    }
    public double getAccuracy() {
        return accuracy;
    }
    
}