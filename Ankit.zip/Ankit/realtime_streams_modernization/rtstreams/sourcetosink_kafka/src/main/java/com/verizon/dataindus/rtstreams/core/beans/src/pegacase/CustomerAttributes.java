package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class CustomerAttributes implements Serializable{
	
	@Nullable
	@SerializedName("active")
	String active;
	
	@Nullable
	@SerializedName("associationIdNo")
	String associationIdNo;
	
	@Nullable
	@SerializedName("statusCode")
	String statusCode;

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getAssociationIdNo() {
		return associationIdNo;
	}

	public void setAssociationIdNo(String associationIdNo) {
		this.associationIdNo = associationIdNo;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	
}