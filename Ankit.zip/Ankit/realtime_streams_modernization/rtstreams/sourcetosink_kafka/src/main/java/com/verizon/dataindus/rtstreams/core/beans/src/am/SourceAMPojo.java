package com.verizon.dataindus.rtstreams.core.beans.src.am;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class SourceAMPojo implements Serializable {

    @SerializedName("accountNumber")
    @Nullable
    String accountNumber;

    @SerializedName("userName")
    @Nullable
    String userName;

    @SerializedName("mobileNumber")
    @Nullable
    String mobileNumber;

    @SerializedName("ipAddress")
    @Nullable
    String ipAddress;

    @SerializedName("date")
    @Nullable
    String date;

    @SerializedName("uuid")
    @Nullable
    String uuid;

    @SerializedName("openAmSource")
    @Nullable
    String openAmSource;

    @SerializedName("transactionType")
    @Nullable
    String transactionType;

    @SerializedName("linkageId")
    @Nullable
    String linkageId;

    @SerializedName("source")
    @Nullable
    String source;


    @SerializedName("alreadyLocked")
    @Nullable
    String alreadyLocked;

    @SerializedName("queue")
    @Nullable
    String queue;


    @SerializedName("stopSacHistory")
    @Nullable
    String stopSacHistory;

    @SerializedName("resend")
    @Nullable
    String resend;

    @SerializedName("publishToJV")
    @Nullable
    String publishToJV;

    @SerializedName("disconnectedProfile")
    @Nullable
    String disconnectedProfile;

    @SerializedName("invalidLoginTransactionType")
    @Nullable
    String invalidLoginTransactionType;

    @SerializedName("invalidForgotPasswordTransactionType")
    @Nullable
    String invalidForgotPasswordTransactionType;
    @SerializedName("invalidForgotUserNameTransactionType")
    @Nullable
    String invalidForgotUserNameTransactionType;
    @SerializedName("invalidModifyRoleTransactionType")
    @Nullable
    String invalidModifyRoleTransactionType;
    @SerializedName("invalidAccountHolderAuthenticationTransactionType")
    @Nullable
    String invalidAccountHolderAuthenticationTransactionType;

    @SerializedName("modifyPasswordTransactionType")
    @Nullable
    String modifyPasswordTransactionType;

    @SerializedName("modifyUserNameTransactionType")
    @Nullable
    String modifyUserNameTransactionType;

    @SerializedName("modifyChallengeQuestionTransactionType")
    @Nullable
    String modifyChallengeQuestionTransactionType;

    @SerializedName("modifyNameTransactionType")
    @Nullable
    String modifyNameTransactionType;
    @SerializedName("registrationTransactionType")
    @Nullable
    String registrationTransactionType;

    @SerializedName("successUpgradeAuthenticationTransactionType")
    @Nullable
    String successUpgradeAuthenticationTransactionType;

    @SerializedName("failedUpgradeAuthenticationCheckTransactionType")
    @Nullable
    String failedUpgradeAuthenticationCheckTransactionType;

    @SerializedName("invalidRegistrationTransactionType")
    @Nullable
    String invalidRegistrationTransactionType;

    @SerializedName("modifyEmailAddressTransactionType")
    @Nullable
    String modifyEmailAddressTransactionType;

    @SerializedName("modifyAccountHolderTransactionType")
    @Nullable
    String modifyAccountHolderTransactionType;

    @SerializedName("modifyRoleTransactionType")
    @Nullable
    String modifyRoleTransactionType;

    @SerializedName("asploginTransactionType")
    @Nullable
    String asploginTransactionType;

    @SerializedName("aspinvalidLoginTransactionType")
    @Nullable
    String aspinvalidLoginTransactionType;

    @SerializedName("deletePermanentlyDeenrollMobileLevelTransactionType")
    @Nullable
    String deletePermanentlyDeenrollMobileLevelTransactionType;

    @SerializedName("removeEmailAddressTransactionType")
    @Nullable
    String removeEmailAddressTransactionType;

    @SerializedName("mqprocessed")
    @Nullable
    String mqprocessed;

    @SerializedName("epochTransactionTime")
    @Nullable
    String epochTransactionTime;

    @SerializedName("loginTransactionType")
    @Nullable
    String loginTransactionType;

    @SerializedName("handsetLoginTransactionType")
    @Nullable
    String handsetLoginTransactionType;

    @SerializedName("clientId")
    @Nullable
    String clientId;

    @SerializedName("changedBy")
    @Nullable
    String changedBy;

    @SerializedName("deviceType")
    @Nullable
    String deviceType;

    @SerializedName("operatingSystem")
    @Nullable
    String operatingSystem;
    @SerializedName("browserType")
    @Nullable
    String browserType;

    @SerializedName("role")
    @Nullable
    String role;

    @SerializedName("reason")
    @Nullable
    String reason;

    @SerializedName("lob")
    @Nullable
    String lob;

    @SerializedName("passwordChangeType")
    @Nullable
    String passwordChangeType;

    @SerializedName("newValue")
    @Nullable
    String newValue;

    @SerializedName("channelID")
    @Nullable
    String channelID;

    @SerializedName("amSessionID")
    @Nullable
    String amSessionID;

    @SerializedName("checkpoint")
    @Nullable
    String checkpoint;

    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(String changedBy) {
        this.changedBy = changedBy;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getBrowserType() {
        return browserType;
    }

    public void setBrowserType(String browserType) {
        this.browserType = browserType;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOpenAmSource() {
        return openAmSource;
    }

    public void setOpenAmSource(String openAmSource) {
        this.openAmSource = openAmSource;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String isAlreadyLocked() {
        return alreadyLocked;
    }

    public void setAlreadyLocked(String alreadyLocked) {
        this.alreadyLocked = alreadyLocked;
    }

    public String getQueue() {
        return queue;
    }

    public void setQueue(String queue) {
        this.queue = queue;
    }

    public String isStopSacHistory() {
        return stopSacHistory;
    }

    public void setStopSacHistory(String stopSacHistory) {
        this.stopSacHistory = stopSacHistory;
    }

    public String isResend() {
        return resend;
    }

    public void setResend(String resend) {
        this.resend = resend;
    }

    public String isPublishToJV() {
        return publishToJV;
    }

    public void setPublishToJV(String publishToJV) {
        this.publishToJV = publishToJV;
    }

    public String isDisconnectedProfile() {
        return disconnectedProfile;
    }

    public void setDisconnectedProfile(String disconnectedProfile) {
        this.disconnectedProfile = disconnectedProfile;
    }

    public String isInvalidLoginTransactionType() {
        return invalidLoginTransactionType;
    }

    public void setInvalidLoginTransactionType(String invalidLoginTransactionType) {
        this.invalidLoginTransactionType = invalidLoginTransactionType;
    }

    public String isInvalidForgotPasswordTransactionType() {
        return invalidForgotPasswordTransactionType;
    }

    public void setInvalidForgotPasswordTransactionType(String invalidForgotPasswordTransactionType) {
        this.invalidForgotPasswordTransactionType = invalidForgotPasswordTransactionType;
    }

    public String isInvalidForgotUserNameTransactionType() {
        return invalidForgotUserNameTransactionType;
    }

    public void setInvalidForgotUserNameTransactionType(String invalidForgotUserNameTransactionType) {
        this.invalidForgotUserNameTransactionType = invalidForgotUserNameTransactionType;
    }

    public String isInvalidModifyRoleTransactionType() {
        return invalidModifyRoleTransactionType;
    }

    public void setInvalidModifyRoleTransactionType(String invalidModifyRoleTransactionType) {
        this.invalidModifyRoleTransactionType = invalidModifyRoleTransactionType;
    }

    public String isInvalidAccountHolderAuthenticationTransactionType() {
        return invalidAccountHolderAuthenticationTransactionType;
    }

    public void setInvalidAccountHolderAuthenticationTransactionType(String invalidAccountHolderAuthenticationTransactionType) {
        this.invalidAccountHolderAuthenticationTransactionType = invalidAccountHolderAuthenticationTransactionType;
    }

    public String isModifyPasswordTransactionType() {
        return modifyPasswordTransactionType;
    }

    public void setModifyPasswordTransactionType(String modifyPasswordTransactionType) {
        this.modifyPasswordTransactionType = modifyPasswordTransactionType;
    }

    public String isModifyUserNameTransactionType() {
        return modifyUserNameTransactionType;
    }

    public void setModifyUserNameTransactionType(String modifyUserNameTransactionType) {
        this.modifyUserNameTransactionType = modifyUserNameTransactionType;
    }

    public String isModifyChallengeQuestionTransactionType() {
        return modifyChallengeQuestionTransactionType;
    }

    public void setModifyChallengeQuestionTransactionType(String modifyChallengeQuestionTransactionType) {
        this.modifyChallengeQuestionTransactionType = modifyChallengeQuestionTransactionType;
    }

    public String isModifyNameTransactionType() {
        return modifyNameTransactionType;
    }

    public void setModifyNameTransactionType(String modifyNameTransactionType) {
        this.modifyNameTransactionType = modifyNameTransactionType;
    }

    public String isRegistrationTransactionType() {
        return registrationTransactionType;
    }

    public void setRegistrationTransactionType(String registrationTransactionType) {
        this.registrationTransactionType = registrationTransactionType;
    }

    public String isSuccessUpgradeAuthenticationTransactionType() {
        return successUpgradeAuthenticationTransactionType;
    }

    public void setSuccessUpgradeAuthenticationTransactionType(String successUpgradeAuthenticationTransactionType) {
        this.successUpgradeAuthenticationTransactionType = successUpgradeAuthenticationTransactionType;
    }

    public String isFailedUpgradeAuthenticationCheckTransactionType() {
        return failedUpgradeAuthenticationCheckTransactionType;
    }

    public void setFailedUpgradeAuthenticationCheckTransactionType(String failedUpgradeAuthenticationCheckTransactionType) {
        this.failedUpgradeAuthenticationCheckTransactionType = failedUpgradeAuthenticationCheckTransactionType;
    }

    public String isInvalidRegistrationTransactionType() {
        return invalidRegistrationTransactionType;
    }

    public void setInvalidRegistrationTransactionType(String invalidRegistrationTransactionType) {
        this.invalidRegistrationTransactionType = invalidRegistrationTransactionType;
    }

    public String isModifyEmailAddressTransactionType() {
        return modifyEmailAddressTransactionType;
    }

    public void setModifyEmailAddressTransactionType(String modifyEmailAddressTransactionType) {
        this.modifyEmailAddressTransactionType = modifyEmailAddressTransactionType;
    }

    public String isModifyAccountHolderTransactionType() {
        return modifyAccountHolderTransactionType;
    }

    public void setModifyAccountHolderTransactionType(String modifyAccountHolderTransactionType) {
        this.modifyAccountHolderTransactionType = modifyAccountHolderTransactionType;
    }

    public String isModifyRoleTransactionType() {
        return modifyRoleTransactionType;
    }

    public void setModifyRoleTransactionType(String modifyRoleTransactionType) {
        this.modifyRoleTransactionType = modifyRoleTransactionType;
    }

    public String isAsploginTransactionType() {
        return asploginTransactionType;
    }

    public void setAsploginTransactionType(String asploginTransactionType) {
        this.asploginTransactionType = asploginTransactionType;
    }

    public String isAspinvalidLoginTransactionType() {
        return aspinvalidLoginTransactionType;
    }

    public void setAspinvalidLoginTransactionType(String aspinvalidLoginTransactionType) {
        this.aspinvalidLoginTransactionType = aspinvalidLoginTransactionType;
    }

    public String isDeletePermanentlyDeenrollMobileLevelTransactionType() {
        return deletePermanentlyDeenrollMobileLevelTransactionType;
    }

    public void setDeletePermanentlyDeenrollMobileLevelTransactionType(String deletePermanentlyDeenrollMobileLevelTransactionType) {
        this.deletePermanentlyDeenrollMobileLevelTransactionType = deletePermanentlyDeenrollMobileLevelTransactionType;
    }

    public String isRemoveEmailAddressTransactionType() {
        return removeEmailAddressTransactionType;
    }

    public void setRemoveEmailAddressTransactionType(String removeEmailAddressTransactionType) {
        this.removeEmailAddressTransactionType = removeEmailAddressTransactionType;
    }

    public String isMqprocessed() {
        return mqprocessed;
    }

    public void setMqprocessed(String mqprocessed) {
        this.mqprocessed = mqprocessed;
    }

    public String getEpochTransactionTime() {
        return epochTransactionTime;
    }

    public void setEpochTransactionTime(String epochTransactionTime) {
        this.epochTransactionTime = epochTransactionTime;
    }

    public String isLoginTransactionType() {
        return loginTransactionType;
    }

    public void setLoginTransactionType(String loginTransactionType) {
        this.loginTransactionType = loginTransactionType;
    }

    public String isHandsetLoginTransactionType() {
        return handsetLoginTransactionType;
    }

    public void setHandsetLoginTransactionType(String handsetLoginTransactionType) {
        this.handsetLoginTransactionType = handsetLoginTransactionType;
    }

    public String getPasswordChangeType() {
        return passwordChangeType;
    }

    public void setPasswordChangeType(String passwordChangeType) {
        this.passwordChangeType = passwordChangeType;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    public String getChannelID() {
        return channelID;
    }

    public void setChannelID(String channelID) {
        this.channelID = channelID;
    }

    public String getAmSessionID() {
        return amSessionID;
    }

    public void setAmSessionID(String amSessionID) {
        this.amSessionID = amSessionID;
    }

    public String getCheckpoint() {
        return checkpoint;
    }

    public void setCheckpoint(String checkpoint) {
        this.checkpoint = checkpoint;
    }

    @Override
    public String toString() {
        return "SourceAMPojo{" +
                "accountNumber='" + accountNumber + '\'' +
                ", userName='" + userName + '\'' +
                ", mobileNumber='" + mobileNumber + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                ", date='" + date + '\'' +
                ", uuid='" + uuid + '\'' +
                ", openAmSource='" + openAmSource + '\'' +
                ", transactionType='" + transactionType + '\'' +
                ", linkageId='" + linkageId + '\'' +
                ", source='" + source + '\'' +
                ", alreadyLocked=" + alreadyLocked +
                ", queue='" + queue + '\'' +
                ", stopSacHistory=" + stopSacHistory +
                ", resend=" + resend +
                ", publishToJV=" + publishToJV +
                ", disconnectedProfile=" + disconnectedProfile +
                ", invalidLoginTransactionType=" + invalidLoginTransactionType +
                ", invalidForgotPasswordTransactionType=" + invalidForgotPasswordTransactionType +
                ", invalidForgotUserNameTransactionType=" + invalidForgotUserNameTransactionType +
                ", invalidModifyRoleTransactionType=" + invalidModifyRoleTransactionType +
                ", invalidAccountHolderAuthenticationTransactionType=" + invalidAccountHolderAuthenticationTransactionType +
                ", modifyPasswordTransactionType=" + modifyPasswordTransactionType +
                ", modifyUserNameTransactionType=" + modifyUserNameTransactionType +
                ", modifyChallengeQuestionTransactionType=" + modifyChallengeQuestionTransactionType +
                ", modifyNameTransactionType=" + modifyNameTransactionType +
                ", registrationTransactionType=" + registrationTransactionType +
                ", successUpgradeAuthenticationTransactionType=" + successUpgradeAuthenticationTransactionType +
                ", failedUpgradeAuthenticationCheckTransactionType=" + failedUpgradeAuthenticationCheckTransactionType +
                ", invalidRegistrationTransactionType=" + invalidRegistrationTransactionType +
                ", modifyEmailAddressTransactionType=" + modifyEmailAddressTransactionType +
                ", modifyAccountHolderTransactionType=" + modifyAccountHolderTransactionType +
                ", modifyRoleTransactionType=" + modifyRoleTransactionType +
                ", asploginTransactionType=" + asploginTransactionType +
                ", aspinvalidLoginTransactionType=" + aspinvalidLoginTransactionType +
                ", deletePermanentlyDeenrollMobileLevelTransactionType=" + deletePermanentlyDeenrollMobileLevelTransactionType +
                ", removeEmailAddressTransactionType=" + removeEmailAddressTransactionType +
                ", mqprocessed=" + mqprocessed +
                ", epochTransactionTime=" + epochTransactionTime +
                ", loginTransactionType=" + loginTransactionType +
                ", handsetLoginTransactionType=" + handsetLoginTransactionType +
                ", clientId='" + clientId + '\'' +
                ", changedBy='" + changedBy + '\'' +
                ", deviceType='" + deviceType + '\'' +
                ", operatingSystem='" + operatingSystem + '\'' +
                ", browserType='" + browserType + '\'' +
                ", role='" + role + '\'' +
                ", reason='" + reason + '\'' +
                ", lob='" + lob + '\'' +
                ", passwordChangeType='" + passwordChangeType + '\'' +
                ", newValue='" + newValue + '\'' +
                ", channelID='" + channelID + '\'' +
                ", amSessionID='" + amSessionID + '\'' +
                ", checkpoint='" + checkpoint + '\'' +
                '}';
    }
}