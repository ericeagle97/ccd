package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class SegmentUnlockMtn {
	
	@SerializedName("createdAt")
	int createdAt;

	@SerializedName("lastQualificationTime")
	Date lastQualificationTime;

	@SerializedName("mappingCreatedAt")
	int mappingCreatedAt;

	@SerializedName("mappingUpdatedAt")
	int mappingUpdatedAt;

	@SerializedName("name")
	String name;

	@SerializedName("status")
	String status;

	@SerializedName("updatedAt")
	int updatedAt;

	public void setCreatedAt(int createdAt) {
		this.createdAt = createdAt;
	}

	public int getCreatedAt() {
		return createdAt;
	}

	public void setLastQualificationTime(Date lastQualificationTime) {
		this.lastQualificationTime = lastQualificationTime;
	}

	public Date getLastQualificationTime() {
		return lastQualificationTime;
	}

	public void setMappingCreatedAt(int mappingCreatedAt) {
		this.mappingCreatedAt = mappingCreatedAt;
	}

	public int getMappingCreatedAt() {
		return mappingCreatedAt;
	}

	public void setMappingUpdatedAt(int mappingUpdatedAt) {
		this.mappingUpdatedAt = mappingUpdatedAt;
	}

	public int getMappingUpdatedAt() {
		return mappingUpdatedAt;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setUpdatedAt(int updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getUpdatedAt() {
		return updatedAt;
	}

}
