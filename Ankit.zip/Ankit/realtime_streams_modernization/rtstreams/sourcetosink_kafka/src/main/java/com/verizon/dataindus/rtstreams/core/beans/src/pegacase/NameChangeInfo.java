package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import java.io.Serializable;
import org.apache.avro.reflect.Nullable;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class NameChangeInfo implements Serializable
{
	@Nullable
	@SerializedName("lastName")
	String lastName;

	@Nullable
	@SerializedName("firstName")
	String firstName;

	@Nullable
	@SerializedName("phoneNumber")
	String phoneNumber;

	@Nullable
	@SerializedName("levelType")
	String levelType;

	@Nullable
	@SerializedName("middleName")
	String middleName;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getLevelType() {
		return levelType;
	}

	public void setLevelType(String levelType) {
		this.levelType = levelType;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
	
}
