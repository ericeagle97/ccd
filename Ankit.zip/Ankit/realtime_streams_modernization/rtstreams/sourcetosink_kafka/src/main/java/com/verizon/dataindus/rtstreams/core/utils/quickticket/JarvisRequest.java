package com.verizon.dataindus.rtstreams.core.utils.quickticket;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.concurrent.TimeUnit;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.beans.src.quickticket.TempResponseType;
import com.verizon.dataindus.rtstreams.core.constants.Constants;


public class JarvisRequest {
	
	
	private static final Logger LOG = LoggerFactory.getLogger(JarvisRequest.class);
	
	public static TempResponseType sendPostRequest(HttpClient client, String jsonBody, String apiUrl, String apiKey) {
		
		final Counter requestCounter = Metrics.counter("JARVIS_FEATURES",Constants.JARVIS_FEATURES_REQUEST);
		final Counter responseCounter = Metrics.counter("JARVIS_FEATURES",Constants.JARVIS_FEATURES_RESPONSE);


		TempResponseType responseData = new TempResponseType();

		long startTime = System.currentTimeMillis();

		HttpResponse<String> response = null;
		try {

			System.setProperty("java.net.useSystemProxies", "false"); 
			
			HttpRequest request = HttpRequest
					.newBuilder(URI.create(apiUrl))
					.header("content-type", "application/json").header("X-apikey", apiKey)
					.POST(HttpRequest.BodyPublishers.ofString(jsonBody))
					.build();
			
			requestCounter.inc();
			
			// Removing timeout per BAU. - 31/05/2024
			//HttpResponse<String> response = client.sendAsync(request,HttpResponse.BodyHandlers.ofString()).get(Constants.HTTP_TIMEOUT, TimeUnit.MILLISECONDS);
			response = client.send(request,HttpResponse.BodyHandlers.ofString());
			
			responseCounter.inc();

			responseData.setREQUEST(jsonBody);
			responseData.setScore(String.valueOf(response.statusCode()));
			responseData.setTemp(response.body());

		} catch (Exception e) {
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;

		responseData.setSTARTTIME(String.valueOf(startTime));
		responseData.setENDTIME(String.valueOf(endTime));
		responseData.setTimeTaken(String.valueOf(totalTime));
		
		
		return responseData;
	}

}
