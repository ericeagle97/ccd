package com.verizon.dataindus.rtstreams.core.constants.vlm;

public class StoreVisitFeedCardConstants {

	public static final String yyyyMMddTHHmmss = "yyyyMMdd HHmmss";
	public static final String GMT = " GMT";
	public static final String REGISTRANTID = "registrantId";
	public static final String MDN = "mdn";
	public static final String ACCOUNTNO = "accountNo";
	public static final String REASONCODE = "reasonCode";
	public static final String VLMCODE = "vlmCode";
	public static final String POSLOCCODE = "posLocCode";
	public static final String LOCATIONNAME = "locationName";
	public static final String TIMEZONE = "timeZone";
	public static final String APPOINTMENTDATE = "appointmentDate";
	public static final String STARTTIME = "startTime";
	public static final String STATUS = "status";
	public static final String ENDTIME = "endTime";
	public static final String STRSTREAMSTIMESTAMP = "strStreamsTimestamp";
	public static final String registrantId = "registrantId";
	public static final String SCHEDULED = "Scheduled";
	public static final String APPOINTMENT_ID = "appointment_id";
	public static final String STOREID = "storeId";
	public static final String STORENAME = "storeName";
	public static final String RELATION = "relation";
	public static final String REASON = "reason";
	public static final String CHANNEL = "channel";
	public static final String VLM = "VLM";
	public static final String NA = "NA";
	public static final String CONFIRMED = "Confirmed";
	public static final String ACTIVITYDATE = "activityDate";
	public static final String TIMEFORMAT12HRS = "hh:mm a";
	public static final String TIMEFORMAT24HRS = "HH:mm";
	public static final String YYYY = "YYYYMMdd hh:mm:ss";
	public static final String PST = "PST";
	public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String AKST = "AKST";
	public static final String APPOINTMENTSTARTTIME = "appointment_startTime";
	public static final String APPOINTMENTENDTIME = "appointment_endTime";
	public static final String MTN = "mtn";
	// Updating per BAU - 11/6/2024
	//public static final String INSIGHTCATEGORY = "insight_category";
	public static final String INSIGHTCATEGORY = "insightCategory";
	public static final String INTERACTIONS = "interactions";
	//public static final String INSIGHTNAME = "insight_name";
	public static final String INSIGHTNAME = "insightName";
	public static final String MVASCHEDSTOREVISIT = "mvaschedstorevisit";
	//public static final String INSIGHTVALUES = "insight_values";
	public static final String INSIGHTVALUES = "insightValues";
	public static final String CANCELLED = "Cancelled";
	public static final String CUSTID = "custId";
	public static final String ACCTNO = "acctNo";
	public static final String SCHEDULED_TIME = "scheduled_time";
	public static final String UPDATETS = "updateTs";
	public static final String UPDATEBY = "updateBy";
	public static final String UPDATEBY_VALUE = "streams";
	public static final String NUMERICREGEX = "[0-9]+";
	public static final String CANCELEDREGEX = "Canceled";

}
