package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


@javax.annotation.Nullable
public class MtnPlanDetails implements Serializable {

	   @Nullable
	   @SerializedName("deviceType")
	   String deviceType;

	   @Nullable
	   @SerializedName("Description")
	   @JsonProperty("Description")
	   String Description;

	   @Nullable
	   @SerializedName("DeviceSkuId")
	   @JsonProperty("DeviceSkuId")
	   String DeviceSkuId;

	   @Nullable
	   @SerializedName("DeviceId")
	   @JsonProperty("DeviceId")
	   String DeviceId;

	   @Nullable
	   @SerializedName("mtn")
	   String mtn;

	   @Nullable
	   @SerializedName("lineActivityType")
	   String lineActivityType;

	   @Nullable
	   @SerializedName("planDescription")
	   String planDescription;

	   @Nullable
	   @SerializedName("planId")
	   String planId;
	   
	   @Nullable
	   @SerializedName("portinMtnAssignment")
	   String portinMtnAssignment;
	   
	   @Nullable
	   @SerializedName("sharePlan")
	   String sharePlan;
	   
	   @Nullable
	   @SerializedName("ItemsInfo")
	   @JsonProperty("ItemsInfo") 
	   List<ItemsInfo> itemsInfo;
	   
	   @Nullable
	   @SerializedName("serviceInfo")
	   ServiceInfo serviceInfo;
	   
	   @Nullable
	   @SerializedName("installmentContractDetail")
	   InstallmentContractDetail installmentContractDetail;


	    public void setDeviceType(String deviceType) {
	        this.deviceType = deviceType;
	    }
	    public String getDeviceType() {
	        return deviceType;
	    }
	    
	    public void setDescription(String Description) {
	        this.Description = Description;
	    }
	    public String getDescription() {
	        return Description;
	    }
	    
	    public void setDeviceSkuId(String DeviceSkuId) {
	        this.DeviceSkuId = DeviceSkuId;
	    }
	    public String getDeviceSkuId() {
	        return DeviceSkuId;
	    }
	    
	    public void setDeviceId(String DeviceId) {
	        this.DeviceId = DeviceId;
	    }
	    public String getDeviceId() {
	        return DeviceId;
	    }
	    
	    public void setMtn(String mtn) {
	        this.mtn = mtn;
	    }
	    public String getMtn() {
	        return mtn;
	    }
	    
	    public void setLineActivityType(String lineActivityType) {
	        this.lineActivityType = lineActivityType;
	    }
	    public String getLineActivityType() {
	        return lineActivityType;
	    }
	    
	    public void setPlanDescription(String planDescription) {
	        this.planDescription = planDescription;
	    }
	    public String getPlanDescription() {
	        return planDescription;
	    }
	    
	    public void setPlanId(String planId) {
	        this.planId = planId;
	    }	
	    public String getPlanId() {
	        return planId;
	    }
		public String getPortinMtnAssignment() {
			return portinMtnAssignment;
		}
		public void setPortinMtnAssignment(String portinMtnAssignment) {
			this.portinMtnAssignment = portinMtnAssignment;
		}
		public String getSharePlan() {
			return sharePlan;
		}
		public void setSharePlan(String sharePlan) {
			this.sharePlan = sharePlan;
		}
		public List<ItemsInfo> getItemsInfo() {
			return itemsInfo;
		}
		public void setItemsInfo(List<ItemsInfo> itemsInfo) {
			this.itemsInfo = itemsInfo;
		}
		public ServiceInfo getServiceInfo() {
			return serviceInfo;
		}
		public void setServiceInfo(ServiceInfo serviceInfo) {
			this.serviceInfo = serviceInfo;
		}
		public InstallmentContractDetail getInstallmentContractDetail() {
			return installmentContractDetail;
		}
		public void setInstallmentContractDetail(InstallmentContractDetail installmentContractDetail) {
			this.installmentContractDetail = installmentContractDetail;
		}
	    
		
	    
}