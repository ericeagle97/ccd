package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class DisconnectOrderListItem implements Serializable{
	
	@Nullable
	@SerializedName("universalAccountFlag")
	String universalAccountFlag;
	
	@Nullable
	@SerializedName("recommendationExists")
	String recommendationExists;
	
	@Nullable
	@SerializedName("mtn")
	String mtn;
	
	@Nullable
	@SerializedName("competitorCode")
	String competitorCode;
	
	@Nullable
	@SerializedName("reasonCode")
	String reasonCode;
	
	@Nullable
	@SerializedName("billThroughDate")
	String billThroughDate;
	
	@Nullable
	@SerializedName("effectiveDate")
	String effectiveDate;
	
	@Nullable
	@SerializedName("activationFeeAmount")
	String activationFeeAmount;
	
	@Nullable
	@SerializedName("activationFeeCreditIndicator")
	String activationFeeCreditIndicator;
	
	@Nullable
	@SerializedName("networkBandInd")
	String networkBandInd;
	
	@Nullable
	@SerializedName("installLoanInd")
	String installLoanInd;
	
	@Nullable
	@SerializedName("creditEscalationQueueRemarks")
	String creditEscalationQueueRemarks;
	
	@Nullable
	@SerializedName("waiveETFIndicator")
	String waiveETFIndicator;
	
	@Nullable
	@SerializedName("dbTimestamp")
	String dbTimestamp;
	
	@Nullable
	@SerializedName("imei")
	String imei;
	
	@Nullable
	@SerializedName("skipPostTrialInd")
	String skipPostTrialInd;
	
	public String getUniversalAccountFlag() {
		return universalAccountFlag;
	}

	public void setUniversalAccountFlag(String universalAccountFlag) {
		this.universalAccountFlag = universalAccountFlag;
	}

	public String getRecommendationExists() {
		return recommendationExists;
	}

	public void setRecommendationExists(String recommendationExists) {
		this.recommendationExists = recommendationExists;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getCompetitorCode() {
		return competitorCode;
	}

	public void setCompetitorCode(String competitorCode) {
		this.competitorCode = competitorCode;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getBillThroughDate() {
		return billThroughDate;
	}

	public void setBillThroughDate(String billThroughDate) {
		this.billThroughDate = billThroughDate;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getActivationFeeAmount() {
		return activationFeeAmount;
	}

	public void setActivationFeeAmount(String activationFeeAmount) {
		this.activationFeeAmount = activationFeeAmount;
	}

	public String getActivationFeeCreditIndicator() {
		return activationFeeCreditIndicator;
	}

	public void setActivationFeeCreditIndicator(String activationFeeCreditIndicator) {
		this.activationFeeCreditIndicator = activationFeeCreditIndicator;
	}

	public String getNetworkBandInd() {
		return networkBandInd;
	}

	public void setNetworkBandInd(String networkBandInd) {
		this.networkBandInd = networkBandInd;
	}

	public String getInstallLoanInd() {
		return installLoanInd;
	}

	public void setInstallLoanInd(String installLoanInd) {
		this.installLoanInd = installLoanInd;
	}

	public String getCreditEscalationQueueRemarks() {
		return creditEscalationQueueRemarks;
	}

	public void setCreditEscalationQueueRemarks(String creditEscalationQueueRemarks) {
		this.creditEscalationQueueRemarks = creditEscalationQueueRemarks;
	}

	public String getWaiveETFIndicator() {
		return waiveETFIndicator;
	}

	public void setWaiveETFIndicator(String waiveETFIndicator) {
		this.waiveETFIndicator = waiveETFIndicator;
	}

	public String getDbTimestamp() {
		return dbTimestamp;
	}

	public void setDbTimestamp(String dbTimestamp) {
		this.dbTimestamp = dbTimestamp;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getSkipPostTrialInd() {
		return skipPostTrialInd;
	}

	public void setSkipPostTrialInd(String skipPostTrialInd) {
		this.skipPostTrialInd = skipPostTrialInd;
	}
	
	
}