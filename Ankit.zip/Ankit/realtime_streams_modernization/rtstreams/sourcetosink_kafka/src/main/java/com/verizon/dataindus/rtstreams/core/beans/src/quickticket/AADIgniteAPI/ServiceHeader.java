package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.AADIgniteAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class ServiceHeader implements Serializable {
	
	@SerializedName("clientId")
	   String clientId;

	   @SerializedName("clientTransactionId")
	   String clientTransactionId;

	   @SerializedName("transactionId")
	   String transactionId;

	   @SerializedName("channelName")
	   String channelName;


	    public void setClientId(String clientId) {
	        this.clientId = clientId;
	    }
	    public String getClientId() {
	        return clientId;
	    }
	    
	    public void setClientTransactionId(String clientTransactionId) {
	        this.clientTransactionId = clientTransactionId;
	    }
	    public String getClientTransactionId() {
	        return clientTransactionId;
	    }
	    
	    public void setTransactionId(String transactionId) {
	        this.transactionId = transactionId;
	    }
	    public String getTransactionId() {
	        return transactionId;
	    }
	    
	    public void setChannelName(String channelName) {
	        this.channelName = channelName;
	    }
	    public String getChannelName() {
	        return channelName;
	    }
	    
	}