package com.verizon.dataindus.rtstreams.core.constants.networkoutagemap;

public class NetworkoutagemapConstants {

	public static final String RAWOUTAGEMAPCOUNTS = "RawOutageMapCount";
	public static final String OUTAGEMAPKAFKACOUNT = "OutageMapKafkaCount";
	public static final String KAFKAREAD = "kafkaRead";
	public static final String KAFKAPUBLISH = "KafkaPublish";
}
