package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class KeyAttributesTypeRemoveAlarm implements Serializable {
    @SerializedName("custId")
    @Nullable
    String custId;

    @SerializedName("acctNo")
    @Nullable
    String acctNo;

    @SerializedName("mtn")
    @Nullable
    String mtn;

    @SerializedName("insightValues")
    @Nullable
    String insightValues;

    @SerializedName("insightName")
    @Nullable
    String insightName;

    @SerializedName("updateBy")
    @Nullable
    String updateBy;

    @SerializedName("insightCategory")
    @Nullable
    String insightCategory;

    @SerializedName("updateTs")
    @Nullable
    String updateTs;

    @SerializedName("ttl")
    @Nullable
    String ttl;

    @Nullable
    public String getCustId() {
        return custId;
    }

    public void setCustId(@Nullable String custId) {
        this.custId = custId;
    }

    @Nullable
    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(@Nullable String acctNo) {
        this.acctNo = acctNo;
    }

    @Nullable
    public String getMtn() {
        return mtn;
    }

    public void setMtn(@Nullable String mtn) {
        this.mtn = mtn;
    }

    @Nullable
    public String getInsightValues() {
        return insightValues;
    }

    public void setInsightValues(@Nullable String insightValues) {
        this.insightValues = insightValues;
    }

    @Nullable
    public String getInsightName() {
        return insightName;
    }

    public void setInsightName(@Nullable String insightName) {
        this.insightName = insightName;
    }

    @Nullable
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(@Nullable String updateBy) {
        this.updateBy = updateBy;
    }

    @Nullable
    public String getInsightCategory() {
        return insightCategory;
    }

    public void setInsightCategory(@Nullable String insightCategory) {
        this.insightCategory = insightCategory;
    }

    @Nullable
    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(@Nullable String updateTs) {
        this.updateTs = updateTs;
    }

    @Nullable
    public String getTtl() {
        return ttl;
    }

    public void setTtl(@Nullable String ttl) {
        this.ttl = ttl;
    }

    @Override
    public String toString() {
        return "KeyAttributesType{" +
                "custId='" + custId + '\'' +
                ", acctNo='" + acctNo + '\'' +
                ", mtn='" + mtn + '\'' +
                ", insightValues='" + insightValues + '\'' +
                ", insightName='" + insightName + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", insightCategory='" + insightCategory + '\'' +
                ", updateTs='" + updateTs + '\'' +
                ", ttl='" + ttl + '\'' +
                '}';
    }
}
