package com.verizon.dataindus.rtstreams.core.beans.src.port;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

public class Ups {

	@Override
	public String toString() {
		return "Ups [segmentPortOut=" + segmentPortOut + ", segmentUnlockMtn=" + segmentUnlockMtn
				+ ", segment_port_out_others=" + segment_port_out_others + "]";
	}

	
	@SerializedName("segment_port_out")
	segment_idType  segmentPortOut;
	
	@SerializedName("segment_unlock_mtn") 
	segment_idType  segmentUnlockMtn;
	
	@SerializedName("segment_port_out_others") 
	segment_idType  segment_port_out_others;
	
	public segment_idType getSegmentPortOut() {
		return segmentPortOut;
	}

	public void setSegmentPortOut(segment_idType segmentPortOut) {
		this.segmentPortOut = segmentPortOut;
	}

	public segment_idType getSegmentUnlockMtn() {
		return segmentUnlockMtn;
	}

	public void setSegmentUnlockMtn(segment_idType segmentUnlockMtn) {
		this.segmentUnlockMtn = segmentUnlockMtn;
	}

	public segment_idType getSegment_port_out_others() {
		return segment_port_out_others;
	}

	public void setSegment_port_out_others(segment_idType segment_port_out_others) {
		this.segment_port_out_others = segment_port_out_others;
	}


	


	  
	  
	 

}
