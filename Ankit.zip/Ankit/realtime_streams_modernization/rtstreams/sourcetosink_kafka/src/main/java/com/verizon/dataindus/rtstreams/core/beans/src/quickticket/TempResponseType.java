package com.verizon.dataindus.rtstreams.core.beans.src.quickticket;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class TempResponseType implements Serializable {


	   @SerializedName("REQUEST")
	   String REQUEST;

	   @SerializedName("START_TIME")
	   String STARTTIME;

	   @SerializedName("END_TIME")
	   String ENDTIME;

	   @SerializedName("timeTaken")
	   String timeTaken;

	   @SerializedName("score")
	   String score;

	   @SerializedName("temp")
	   String temp;

	    public void setREQUEST(String REQUEST) {
	        this.REQUEST = REQUEST;
	    }
	    public String getREQUEST() {
	        return REQUEST;
	    }
	    
	    public void setSTARTTIME(String STARTTIME) {
	        this.STARTTIME = STARTTIME;
	    }
	    public String getSTARTTIME() {
	        return STARTTIME;
	    }
	    
	    public void setENDTIME(String ENDTIME) {
	        this.ENDTIME = ENDTIME;
	    }
	    public String getENDTIME() {
	        return ENDTIME;
	    }
	    
	    public void setTimeTaken(String timeTaken) {
	        this.timeTaken = timeTaken;
	    }
	    public String getTimeTaken() {
	        return timeTaken;
	    }
	    
	    public void setScore(String score) {
	        this.score = score;
	    }
	    public String getScore() {
	        return score;
	    }
	    
	    public void setTemp(String temp) {
	        this.temp = temp;
	    }
	    public String getTemp() {
	        return temp;
	    }
	    
	}