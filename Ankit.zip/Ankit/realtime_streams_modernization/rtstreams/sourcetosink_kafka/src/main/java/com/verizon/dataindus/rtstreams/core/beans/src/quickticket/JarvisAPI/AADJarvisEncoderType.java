package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class AADJarvisEncoderType implements Serializable {

	
	   @SerializedName("ID")
	   String ID;

	   @SerializedName("SEARCH_TERM")
	   String SEARCHTERM;

	   @SerializedName("BOT_STATUS")
	   String BOTSTATUS;

	   @SerializedName("RATINGCOUNT")
	   String RATINGCOUNT;

	   @SerializedName("ARTICLE_TYPE")
	   String ARTICLETYPE;

	   @SerializedName("SOURCE")
	   String SOURCE;

	   @SerializedName("CALLING_SYSTEM")
	   String CALLINGSYSTEM;

	   @SerializedName("COMMENT")
	   String COMMENT;

	   @SerializedName("TICKET")
	   String TICKET;

	   @SerializedName("REQUEST")
	   String REQUEST;

	   @SerializedName("START_TIME")
	   String STARTTIME;

	   @SerializedName("END_TIME")
	   String ENDTIME;

	   @SerializedName("timeTaken")
	   String timeTaken;

	   @SerializedName("score")
	   String score;

	   @SerializedName("temp")
	   String temp;


	    public void setID(String ID) {
	        this.ID = ID;
	    }
	    public String getID() {
	        return ID;
	    }
	    
	    public void setSEARCHTERM(String SEARCHTERM) {
	        this.SEARCHTERM = SEARCHTERM;
	    }
	    public String getSEARCHTERM() {
	        return SEARCHTERM;
	    }
	    
	    public void setBOTSTATUS(String BOTSTATUS) {
	        this.BOTSTATUS = BOTSTATUS;
	    }
	    public String getBOTSTATUS() {
	        return BOTSTATUS;
	    }
	    
	    public void setRATINGCOUNT(String RATINGCOUNT) {
	        this.RATINGCOUNT = RATINGCOUNT;
	    }
	    public String getRATINGCOUNT() {
	        return RATINGCOUNT;
	    }
	    
	    public void setARTICLETYPE(String ARTICLETYPE) {
	        this.ARTICLETYPE = ARTICLETYPE;
	    }
	    public String getARTICLETYPE() {
	        return ARTICLETYPE;
	    }
	    
	    public void setSOURCE(String SOURCE) {
	        this.SOURCE = SOURCE;
	    }
	    public String getSOURCE() {
	        return SOURCE;
	    }
	    
	    public void setCALLINGSYSTEM(String CALLINGSYSTEM) {
	        this.CALLINGSYSTEM = CALLINGSYSTEM;
	    }
	    public String getCALLINGSYSTEM() {
	        return CALLINGSYSTEM;
	    }
	    
	    public void setCOMMENT(String COMMENT) {
	        this.COMMENT = COMMENT;
	    }
	    public String getCOMMENT() {
	        return COMMENT;
	    }
	    
	    public void setTICKET(String TICKET) {
	        this.TICKET = TICKET;
	    }
	    public String getTICKET() {
	        return TICKET;
	    }
	    	    
	    public void setREQUEST(String REQUEST) {
	        this.REQUEST = REQUEST;
	    }
	    public String getREQUEST() {
	        return REQUEST;
	    }
	    
	    public void setSTARTTIME(String STARTTIME) {
	        this.STARTTIME = STARTTIME;
	    }
	    public String getSTARTTIME() {
	        return STARTTIME;
	    }
	    
	    public void setENDTIME(String ENDTIME) {
	        this.ENDTIME = ENDTIME;
	    }
	    public String getENDTIME() {
	        return ENDTIME;
	    }
	    
	    public void setTimeTaken(String timeTaken) {
	        this.timeTaken = timeTaken;
	    }
	    public String getTimeTaken() {
	        return timeTaken;
	    }
	    
	    public void setScore(String score) {
	        this.score = score;
	    }
	    public String getScore() {
	        return score;
	    }
	    
	    public void setTemp(String temp) {
	        this.temp = temp;
	    }
	    public String getTemp() {
	        return temp;
	    }
	    
	}