package com.verizon.dataindus.rtstreams.core.beans.src.ivrcallpredictives;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class FeedbackResponse implements Serializable {

   @SerializedName("context")
   @Nullable
   Context context;


    public void setContext(Context context) {
        this.context = context;
    }
    public Context getContext() {
        return context;
    }

    @Override
    public String toString() {
        return "FeedbackResponse{" +
                "context=" + context +
                '}';
    }
}