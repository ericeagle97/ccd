package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class wifiTestHistoryType implements Serializable{
	
	
	
	@SerializedName("mdn")
	@Nullable
	private String  mdn;
	
	@SerializedName("timezone")
	@Nullable
	private String  timezone;
	
	@SerializedName("time")
	@Nullable
	private Integer  time;
	
	@SerializedName("floor")
	@Nullable
	private String  floor;

	@SerializedName("testName")
	@Nullable
	private String  testName;
	
	@SerializedName("testDevice")
	@Nullable
	private String  testDevice;
	
	
	@SerializedName("result")
	@Nullable
	private String  result;


	public String getMdn() {
		return mdn;
	}


	public void setMdn(String mdn) {
		this.mdn = mdn;
	}


	public String getTimezone() {
		return timezone;
	}


	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}


	public Integer getTime() {
		return time;
	}


	public void setTime(Integer time) {
		this.time = time;
	}


	public String getFloor() {
		return floor;
	}


	public void setFloor(String floor) {
		this.floor = floor;
	}


	public String getTestName() {
		return testName;
	}


	public void setTestName(String testName) {
		this.testName = testName;
	}


	public String getTestDevice() {
		return testDevice;
	}


	public void setTestDevice(String testDevice) {
		this.testDevice = testDevice;
	}


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}


	@Override
	public String toString() {
		return "wifiTestHistoryType [mdn=" + mdn + ", timezone=" + timezone + ", time=" + time + ", floor=" + floor
				+ ", testName=" + testName + ", testDevice=" + testDevice + ", result=" + result + "]";
	}
	
	
	
	
	
	
	


}
