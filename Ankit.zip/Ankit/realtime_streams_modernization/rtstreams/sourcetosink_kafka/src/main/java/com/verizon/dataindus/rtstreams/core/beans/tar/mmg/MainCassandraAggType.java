package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class MainCassandraAggType implements Serializable {

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public keyAttributesType getKeyAttributes() {
		return keyAttributes;
	}

	public void setKeyAttributes(keyAttributesType keyAttributes) {
		this.keyAttributes = keyAttributes;
	}

	@SerializedName("requestType")
	@Nullable
	private String requestType;

	@SerializedName("keyAttributes")
	@Nullable
	private keyAttributesType keyAttributes;

}
