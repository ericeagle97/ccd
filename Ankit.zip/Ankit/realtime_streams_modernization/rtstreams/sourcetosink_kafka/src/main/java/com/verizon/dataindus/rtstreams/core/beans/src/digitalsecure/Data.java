package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class Data implements Serializable {
	private static final long serialVersionUID = 1L;
	@SerializedName("isRunning")
	@Nullable
	public String isRunning;
	@SerializedName("mmsVersion")
	@Nullable
	public String mmsVersion;
	@SerializedName("signatureVersion")
	@Nullable
	public String signatureVersion;
	@SerializedName("lastUpdateTime")
	@Nullable
	public String lastUpdateTime;
	@SerializedName("lastScanTime")
	@Nullable
	public String lastScanTime;
	@SerializedName("lastSignatureCheckTime")
	@Nullable
	public String lastSignatureCheckTime;
	@SerializedName("threats")
	@Nullable
	public List<Threat> threats;
	@SerializedName("isRooted")
	@Nullable
	public String isRooted;
	@SerializedName("nextScanTime")
	@Nullable
	public String nextScanTime;
	@SerializedName("privacyAlertCount")
	@Nullable
	public String privacyAlertCount;
	@SerializedName("appsWithHighDataExposure")
	@Nullable
	public List<String> appsWithHighDataExposure;
	@SerializedName("isDigitalSecureActivated")
	@Nullable
	public String isDigitalSecureActivated;
	@SerializedName("isDigitalSecureAppInstalled")
	@Nullable
	public String isDigitalSecureAppInstalled;
	@SerializedName("isMdnCaptured")
	@Nullable
	public String isMdnCaptured;
	@SerializedName("subscriptionType")
	@Nullable
	public String subscriptionType;
	@SerializedName("scannedThreatLogs")
	@Nullable
	public List<ScannedThreatLog> scannedThreatLogs;
	@SerializedName("threatHistoryLogs")
	@Nullable
	public List<ThreatHistoryLog> threatHistoryLogs;
	@SerializedName("isWebSecurityEnabled")
	@Nullable
	public String isWebSecurityEnabled;
	@SerializedName("isRunning")
	@Nullable
	public String isWifiSecurityEnabled;
	@SerializedName("wifiAlertsByDay")
	@Nullable
	public List<WifiAlertsByDay> wifiAlertsByDay;
	@SerializedName("ignoredWifiAlertsByDay")
	@Nullable
	public List<IgnoredWifiAlertsByDay> ignoredWifiAlertsByDay;
	@SerializedName("isVPNConnected")
	@Nullable
	public String isVPNConnected;
	@SerializedName("isVPNAutoConnectEnabled")
	@Nullable
	public String isVPNAutoConnectEnabled;
	@SerializedName("isUserEnrolledToDwm")
	@Nullable
	public String isUserEnrolledToDwm;
	@SerializedName("isUserEnrolledToCSID")
	@Nullable
	public String isUserEnrolledToCSID;
	@SerializedName("isRealTimeScanEnabled")
	@Nullable
	public String isRealTimeScanEnabled;
	@SerializedName("isScheduledScanEnabled")
	@Nullable
	public String isScheduledScanEnabled;
	@SerializedName("mmsVersionCode")
	@Nullable
	public String mmsVersionCode;
	@SerializedName("metaData")
	@Nullable
	public MetaData metaData;
	@SerializedName("isMMSInstalled")
	@Nullable
	public String isMMSInstalled;

	public String getIsMMSInstalled() {
		return isMMSInstalled;
	}

	public void setIsMMSInstalled(String isMMSInstalled) {
		this.isMMSInstalled = isMMSInstalled;
	}

	public String getIsRunning() {
		return isRunning;
	}

	public void setIsRunning(String isRunning) {
		this.isRunning = isRunning;
	}

	public String getMmsVersion() {
		return mmsVersion;
	}

	public void setMmsVersion(String mmsVersion) {
		this.mmsVersion = mmsVersion;
	}

	public String getSignatureVersion() {
		return signatureVersion;
	}

	public void setSignatureVersion(String signatureVersion) {
		this.signatureVersion = signatureVersion;
	}

	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getLastScanTime() {
		return lastScanTime;
	}

	public void setLastScanTime(String lastScanTime) {
		this.lastScanTime = lastScanTime;
	}

	public String getLastSignatureCheckTime() {
		return lastSignatureCheckTime;
	}

	public void setLastSignatureCheckTime(String lastSignatureCheckTime) {
		this.lastSignatureCheckTime = lastSignatureCheckTime;
	}

	public List<Threat> getThreats() {
		return threats;
	}

	public void setThreats(List<Threat> threats) {
		this.threats = threats;
	}

	public String getIsRooted() {
		return isRooted;
	}

	public void setIsRooted(String isRooted) {
		this.isRooted = isRooted;
	}

	public String getNextScanTime() {
		return nextScanTime;
	}

	public void setNextScanTime(String nextScanTime) {
		this.nextScanTime = nextScanTime;
	}

	public String getPrivacyAlertCount() {
		return privacyAlertCount;
	}

	public void setPrivacyAlertCount(String privacyAlertCount) {
		this.privacyAlertCount = privacyAlertCount;
	}

	public List<String> getAppsWithHighDataExposure() {
		return appsWithHighDataExposure;
	}

	public void setAppsWithHighDataExposure(List<String> appsWithHighDataExposure) {
		this.appsWithHighDataExposure = appsWithHighDataExposure;
	}

	public String getIsDigitalSecureActivated() {
		return isDigitalSecureActivated;
	}

	public void setIsDigitalSecureActivated(String isDigitalSecureActivated) {
		this.isDigitalSecureActivated = isDigitalSecureActivated;
	}

	public String getIsDigitalSecureAppInstalled() {
		return isDigitalSecureAppInstalled;
	}

	public void setIsDigitalSecureAppInstalled(String isDigitalSecureAppInstalled) {
		this.isDigitalSecureAppInstalled = isDigitalSecureAppInstalled;
	}

	public String getIsMdnCaptured() {
		return isMdnCaptured;
	}

	public void setIsMdnCaptured(String isMdnCaptured) {
		this.isMdnCaptured = isMdnCaptured;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public List<ScannedThreatLog> getScannedThreatLogs() {
		return scannedThreatLogs;
	}

	public void setScannedThreatLogs(List<ScannedThreatLog> scannedThreatLogs) {
		this.scannedThreatLogs = scannedThreatLogs;
	}

	public List<ThreatHistoryLog> getThreatHistoryLogs() {
		return threatHistoryLogs;
	}

	public void setThreatHistoryLogs(List<ThreatHistoryLog> threatHistoryLogs) {
		this.threatHistoryLogs = threatHistoryLogs;
	}

	public String getIsWebSecurityEnabled() {
		return isWebSecurityEnabled;
	}

	public void setIsWebSecurityEnabled(String isWebSecurityEnabled) {
		this.isWebSecurityEnabled = isWebSecurityEnabled;
	}

	public String getIsWifiSecurityEnabled() {
		return isWifiSecurityEnabled;
	}

	public void setIsWifiSecurityEnabled(String isWifiSecurityEnabled) {
		this.isWifiSecurityEnabled = isWifiSecurityEnabled;
	}

	public List<WifiAlertsByDay> getWifiAlertsByDay() {
		return wifiAlertsByDay;
	}

	public void setWifiAlertsByDay(List<WifiAlertsByDay> wifiAlertsByDay) {
		this.wifiAlertsByDay = wifiAlertsByDay;
	}

	public List<IgnoredWifiAlertsByDay> getIgnoredWifiAlertsByDay() {
		return ignoredWifiAlertsByDay;
	}

	public void setIgnoredWifiAlertsByDay(List<IgnoredWifiAlertsByDay> ignoredWifiAlertsByDay) {
		this.ignoredWifiAlertsByDay = ignoredWifiAlertsByDay;
	}

	public String getIsVPNConnected() {
		return isVPNConnected;
	}

	public void setIsVPNConnected(String isVPNConnected) {
		this.isVPNConnected = isVPNConnected;
	}

	public String getIsVPNAutoConnectEnabled() {
		return isVPNAutoConnectEnabled;
	}

	public void setIsVPNAutoConnectEnabled(String isVPNAutoConnectEnabled) {
		this.isVPNAutoConnectEnabled = isVPNAutoConnectEnabled;
	}

	public String getIsUserEnrolledToDwm() {
		return isUserEnrolledToDwm;
	}

	public void setIsUserEnrolledToDwm(String isUserEnrolledToDwm) {
		this.isUserEnrolledToDwm = isUserEnrolledToDwm;
	}

	public String getIsUserEnrolledToCSID() {
		return isUserEnrolledToCSID;
	}

	public void setIsUserEnrolledToCSID(String isUserEnrolledToCSID) {
		this.isUserEnrolledToCSID = isUserEnrolledToCSID;
	}

	public String getIsRealTimeScanEnabled() {
		return isRealTimeScanEnabled;
	}

	public void setIsRealTimeScanEnabled(String isRealTimeScanEnabled) {
		this.isRealTimeScanEnabled = isRealTimeScanEnabled;
	}

	public String getIsScheduledScanEnabled() {
		return isScheduledScanEnabled;
	}

	public void setIsScheduledScanEnabled(String isScheduledScanEnabled) {
		this.isScheduledScanEnabled = isScheduledScanEnabled;
	}

	public String getMmsVersionCode() {
		return mmsVersionCode;
	}

	public void setMmsVersionCode(String mmsVersionCode) {
		this.mmsVersionCode = mmsVersionCode;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Data [isRunning=" + isRunning + ", mmsVersion=" + mmsVersion + ", signatureVersion=" + signatureVersion
				+ ", lastUpdateTime=" + lastUpdateTime + ", lastScanTime=" + lastScanTime + ", lastSignatureCheckTime="
				+ lastSignatureCheckTime + ", threats=" + threats + ", isRooted=" + isRooted + ", nextScanTime="
				+ nextScanTime + ", privacyAlertCount=" + privacyAlertCount + ", appsWithHighDataExposure="
				+ appsWithHighDataExposure + ", isDigitalSecureActivated=" + isDigitalSecureActivated
				+ ", isDigitalSecureAppInstalled=" + isDigitalSecureAppInstalled + ", isMdnCaptured=" + isMdnCaptured
				+ ", subscriptionType=" + subscriptionType + ", scannedThreatLogs=" + scannedThreatLogs
				+ ", threatHistoryLogs=" + threatHistoryLogs + ", isWebSecurityEnabled=" + isWebSecurityEnabled
				+ ", isWifiSecurityEnabled=" + isWifiSecurityEnabled + ", wifiAlertsByDay=" + wifiAlertsByDay
				+ ", ignoredWifiAlertsByDay=" + ignoredWifiAlertsByDay + ", isVPNConnected=" + isVPNConnected
				+ ", isVPNAutoConnectEnabled=" + isVPNAutoConnectEnabled + ", isUserEnrolledToDwm="
				+ isUserEnrolledToDwm + ", isUserEnrolledToCSID=" + isUserEnrolledToCSID + ", isRealTimeScanEnabled="
				+ isRealTimeScanEnabled + ", isScheduledScanEnabled=" + isScheduledScanEnabled + ", mmsVersionCode="
				+ mmsVersionCode + ", metaData=" + metaData + "]";
	}

}
