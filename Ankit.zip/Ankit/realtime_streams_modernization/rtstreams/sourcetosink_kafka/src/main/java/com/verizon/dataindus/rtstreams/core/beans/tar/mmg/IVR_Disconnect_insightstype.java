package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class IVR_Disconnect_insightstype implements Serializable {

	@SerializedName("date")
	@Nullable
	private String date;
	@SerializedName("deviceInstanceId")
	@Nullable
	private String deviceInstanceId;
	@SerializedName("smartLinkClickId")
	@Nullable
	private String smartLinkClickId;
	@SerializedName("data")
	@Nullable
	private dataType data;
	@SerializedName("smartLinkUrl")
	@Nullable
	private String smartLinkUrl;
	@SerializedName("channel")
	@Nullable
	private String channel;
	@SerializedName("message")
	@Nullable
	private String message;
	@SerializedName("userId")
	@Nullable
	private String userId;
	@SerializedName("smartLinkId")
	@Nullable
	private String smartLinkId;
	@SerializedName("transactionId")
	@Nullable
	private String transactionId;
	@SerializedName("utm")
	@Nullable
	private utmType utm;
	@SerializedName("referrer")
	@Nullable
	private String referrer;
	@SerializedName("subLaunchType")
	@Nullable
	private String subLaunchType;
	@SerializedName("application")
	@Nullable
	private String application;
	@SerializedName("externalUserId")
	@Nullable
	private String externalUserId;
	@SerializedName("client")
	@Nullable
	private String client;
	@SerializedName("campaign")
	@Nullable
	private campaignType campaign;
	@SerializedName("event")
	@Nullable
	private String event;
	@SerializedName("status")
	@Nullable
	private String status;
	@SerializedName("launchType")
	@Nullable
	private String launchType;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDeviceInstanceId() {
		return deviceInstanceId;
	}

	public void setDeviceInstanceId(String deviceInstanceId) {
		this.deviceInstanceId = deviceInstanceId;
	}

	public String getSmartLinkClickId() {
		return smartLinkClickId;
	}

	public void setSmartLinkClickId(String smartLinkClickId) {
		this.smartLinkClickId = smartLinkClickId;
	}

	public dataType getData() {
		return data;
	}

	public void setData(dataType data) {
		this.data = data;
	}

	public String getSmartLinkUrl() {
		return smartLinkUrl;
	}

	public void setSmartLinkUrl(String smartLinkUrl) {
		this.smartLinkUrl = smartLinkUrl;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSmartLinkId() {
		return smartLinkId;
	}

	public void setSmartLinkId(String smartLinkId) {
		this.smartLinkId = smartLinkId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public utmType getUtm() {
		return utm;
	}

	public void setUtm(utmType utm) {
		this.utm = utm;
	}

	public String getReferrer() {
		return referrer;
	}

	public void setReferrer(String referrer) {
		this.referrer = referrer;
	}

	public String getSubLaunchType() {
		return subLaunchType;
	}

	public void setSubLaunchType(String subLaunchType) {
		this.subLaunchType = subLaunchType;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getExternalUserId() {
		return externalUserId;
	}

	public void setExternalUserId(String externalUserId) {
		this.externalUserId = externalUserId;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public campaignType getCampaign() {
		return campaign;
	}

	public void setCampaign(campaignType campaign) {
		this.campaign = campaign;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLaunchType() {
		return launchType;
	}

	public void setLaunchType(String launchType) {
		this.launchType = launchType;
	}

	@Override
	public String toString() {
		return "IVR_Disconnect_insightstype [date=" + date + ", deviceInstanceId=" + deviceInstanceId
				+ ", smartLinkClickId=" + smartLinkClickId + ", data=" + data + ", smartLinkUrl=" + smartLinkUrl
				+ ", channel=" + channel + ", message=" + message + ", userId=" + userId + ", smartLinkId="
				+ smartLinkId + ", transactionId=" + transactionId + ", utm=" + utm + ", referrer=" + referrer
				+ ", subLaunchType=" + subLaunchType + ", application=" + application + ", externalUserId="
				+ externalUserId + ", client=" + client + ", campaign=" + campaign + ", event=" + event + ", status="
				+ status + ", launchType=" + launchType + "]";
	}

}
