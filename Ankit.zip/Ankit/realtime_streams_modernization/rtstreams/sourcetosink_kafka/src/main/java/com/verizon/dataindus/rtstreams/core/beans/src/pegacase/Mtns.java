package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class Mtns implements Serializable{
	
	@Nullable
	@SerializedName("equipmentInfos")
	List<EquipmentInfos> equipmentInfos;
	
	@Nullable
	@SerializedName("mtnStatus")
	MtnStatus mtnStatus;
	
	@Nullable
	@SerializedName("mtn")
	String mtn;
	
	@Nullable
	@SerializedName("mobileInfoAttributes")
	MobileInfoAttributes mobileInfoAttributes;

	public List<EquipmentInfos> getEquipmentInfos() {
		return equipmentInfos;
	}

	public void setEquipmentInfos(List<EquipmentInfos> equipmentInfos) {
		this.equipmentInfos = equipmentInfos;
	}

	public MtnStatus getMtnStatus() {
		return mtnStatus;
	}

	public void setMtnStatus(MtnStatus mtnStatus) {
		this.mtnStatus = mtnStatus;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public MobileInfoAttributes getMobileInfoAttributes() {
		return mobileInfoAttributes;
	}

	public void setMobileInfoAttributes(MobileInfoAttributes mobileInfoAttributes) {
		this.mobileInfoAttributes = mobileInfoAttributes;
	}
	
			
	
}