package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.mmg;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;

public class AddLinkageIdToMMGRawJson extends DoFn<String, String> {

	private static final long serialVersionUID = 1L;

	private String source;

	public AddLinkageIdToMMGRawJson(String source) {
		this.source = source;
	}

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
	};
	public static final TupleTag<String> validTag = new TupleTag<String>() {
	};


	@ProcessElement
	public void processElement(ProcessContext c) {

		try {
			String rawData = c.element();
			JSONObject rawJson = new JSONObject(rawData);

			String externalUserId = null;
			String transactionId = null;
			String event = null;

			if (rawData.contains("transactionID")) {
				rawData = rawData.replace("transactionID", "transactionId");
			}
			if (rawData.contains("externalUserId")) {
				externalUserId = rawJson.get("externalUserId").toString();
			}

			if (rawData.contains("transactionId")) {
				transactionId = rawJson.get("transactionId").toString();

			}

			if (rawData.contains("event")) {
				event = rawJson.get("event").toString();
			}
			String LinkageId = genLinkageID(externalUserId, transactionId, event);
			rawJson.put("linkageID", LinkageId);

			c.output(rawJson.toString());

		} catch (Exception e) {

			c.output(deadLetter, c.element());

		}
	}


	public static String genLinkageID (String externalUserId,  String transactionId, String event) {

		String dateTime = getGMTDateTime("yyyy-MM-dd HHmmss.SSSSSS");
		String currentDay = dateTime.split(" ")[0];
		
		String linkageID = "";
		if (event.contains("Push_Notification_Sent") 
				|| event.contains("Push_Notification_Failed")
				|| event.contains("Push_Notification_Action") 
				|| event.contains("Push_Notification_Not_Delivered"))
		{

			linkageID = externalUserId +"_"+ currentDay + "_PushNotification_MMG_" + transactionId +"_"+ event;		
		}
		else 
		{
			linkageID = externalUserId +"_"+ currentDay + "_ClickNotification_MMG_" + transactionId +"_"+ event;		
		}
		return linkageID;

	}



	public static String getGMTDateTime(String pattern) {
		// Format the date and time as a string
		Instant instantTime = Instant.now();
		ZoneId zone = ZoneId.of("GMT");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		String dateTime = instantTime.atZone(zone).format(formatter);
		return dateTime;

	}
}










