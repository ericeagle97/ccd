package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class CustInformation implements Serializable{
	
	@Nullable
	@SerializedName("accountLevelProtection")
	String accountLevelProtection;
	
	@Nullable
	@SerializedName("vzwRoles")
	String vzwRoles;	
	

	public String getAccountLevelProtection() {
		return accountLevelProtection;
	}

	public void setAccountLevelProtection(String accountLevelProtection) {
		this.accountLevelProtection = accountLevelProtection;
	}

	public String getVzwRoles() {
		return vzwRoles;
	}

	public void setVzwRoles(String vzwRoles) {
		this.vzwRoles = vzwRoles;
	}
	
	
	
}