package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class AggrValuesListType implements Serializable{
	
	@SerializedName("wifiTestHistory")
	@Nullable
	private List<wifiTestHistoryType>  wifiTestHistory;

	public List<wifiTestHistoryType> getWifiTestHistory() {
		return wifiTestHistory;
	}

	public void setWifiTestHistory(List<wifiTestHistoryType> wifiTestHistory) {
		this.wifiTestHistory = wifiTestHistory;
	}
	
	
	
	
	
	

	
	
	
	
	

}
