package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class Context implements Serializable{
	
	@Nullable
	@SerializedName("disconnectOrderListItem")
	List<DisconnectOrderListItem> disconnectOrderListItem;
	
	@Nullable
	@SerializedName("originating_client_id")
	String originating_client_id;
	
	@Nullable
	@SerializedName("orderInfo")
	OrderInfo orderInfo;
	
	@Nullable
	@SerializedName("orderDetails")
	List<OrderDetailsContext> orderDetails;

	public List<DisconnectOrderListItem> getDisconnectOrderListItem() {
		return disconnectOrderListItem;
	}

	public void setDisconnectOrderListItem(List<DisconnectOrderListItem> disconnectOrderListItem) {
		this.disconnectOrderListItem = disconnectOrderListItem;
	}

	public String getOriginating_client_id() {
		return originating_client_id;
	}

	public void setOriginating_client_id(String originating_client_id) {
		this.originating_client_id = originating_client_id;
	}

	public OrderInfo getOrderInfo() {
		return orderInfo;
	}

	public void setOrderInfo(OrderInfo orderInfo) {
		this.orderInfo = orderInfo;
	}

	public List<OrderDetailsContext> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetailsContext> orderDetails) {
		this.orderDetails = orderDetails;
	}	

	
}