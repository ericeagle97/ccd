package com.verizon.dataindus.rtstreams.core.constants.networkwificalling;

public class WifiCallingConstants {

    public static final String DEVICE = "device";
    public static final String WIFICALLING = "wificalling";
    public static final String MTN_REGEX = "^[0-9]+$";
    public static final String TTL_VALUE = "2592000";
    public static final String STREAMS = "streams";
    public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS = "attr-cee-pubsub-cust-insights";
    public static final String CUST_LINE_SEQ_ID = "CUST_LINE_SEQ_ID";
    public static final String CALLSWITHALEG_WIFI_OVERALL_FLAG = "CALLSWITHALEG_WIFI_OVERALL_FLAG";
    public static final String AVG_DEVICE_1_3 = "AVG_DEVICE_1_3";
    public static final String ACTIVITY_DT = "ACTIVITY_DT";
}
