package com.verizon.dataindus.rtstreams.core.constants.am;

public class AmConstants {
    public static final String AM_NAMESPACE = "AM";
    public static final String metrics_total_count = "total_count";
    public static final String AMINSIGHTS = "AMInsights tag";
    public static final String aminsights_counter_success = "am_insights_generation_successful_count";
    public static final String aminsights_counter_failure = "am_Insights_generation_failure_count";
    public static final String CUSTINSIGHTS = "customer_insights";
    public static final String custinsights_success = "customer_insight_successful_count";
    public static final String custinsights_failure = "customer_insight_failure_count";
    public static final String EDW = "EDW_";
}
