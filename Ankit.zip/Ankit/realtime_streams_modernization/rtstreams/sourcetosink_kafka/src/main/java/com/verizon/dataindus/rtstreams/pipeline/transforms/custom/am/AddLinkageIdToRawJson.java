package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.am;


import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import static com.verizon.dataindus.rtstreams.core.constants.Constants.*;


public class AddLinkageIdToRawJson extends DoFn<String, String> {

    private static final long serialVersionUID = 1L;

    private String source;

    public AddLinkageIdToRawJson(String source) {
        this.source = source;
    }

    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };
    public static final TupleTag<String> validTag = new TupleTag<String>() {
    };

    private final Counter invalidLinkageIDCounter = Metrics.counter(Linkage_Id, INVALID_COUNT_LINKAGE_ID);

    @ProcessElement
    public void processElement(ProcessContext c) {

        try {
            String rawData = c.element();
            JSONObject rawJson = new JSONObject(rawData);
            String linkageId = "";
            String mdn = "null";
            if (rawJson.has("mobileNumber")) {
                mdn = rawJson.get("mobileNumber").toString();
            }
            linkageId = CommonUtility.genLinkageID(mdn, this.source);
            rawJson.put("linkageId", linkageId);
            c.output(rawJson.toString());


        }
        catch (Exception e) {
            invalidLinkageIDCounter.inc();
            e.printStackTrace();
            c.output(deadLetter, c.element());

        }
    }
}