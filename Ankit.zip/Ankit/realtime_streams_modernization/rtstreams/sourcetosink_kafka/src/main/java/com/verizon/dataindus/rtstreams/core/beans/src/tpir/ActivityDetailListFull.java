package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.google.gson.annotations.SerializedName;

@XmlRootElement(name = "activityDetailList")
@XmlAccessorType(XmlAccessType.FIELD)

@javax.annotation.Nullable
public class ActivityDetailListFull implements Serializable{
	
	@JacksonXmlElementWrapper(useWrapping = false)
	@SerializedName("touchpointDetail")
    @Nullable
    @XmlElement(name = "touchpointDetail")
	private List<TouchpointDetailFull> touchpointDetail;
	
    public List<TouchpointDetailFull> gettouchpointDetail() {
        return touchpointDetail;
    }
    public void settouchpointDetail(List<TouchpointDetailFull> touchpointDetail) {
        this.touchpointDetail = touchpointDetail;
    }
    
	@Override
	public String toString() {
		
		return "activityDetailList [touchpointDetail = " + touchpointDetail  + "]";
	}

}

