package com.verizon.dataindus.rtstreams.core.common;

import java.text.ParseException;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;

/*
 * Ipardo class is interface for DoFn 
*/

public abstract class Ipardo extends DoFn<String, String> 
{
	private static final long serialVersionUID = 1L;
	@ProcessElement
	public abstract void processElement(ProcessContext c) throws ParseException ;

}
