package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class Category implements Serializable{
	
	@Nullable
	@SerializedName("smartwatch")
	String smartwatch;
	
	@Nullable
	@SerializedName("connectedDevice")
	String connectedDevice;
	
	@Nullable
	@SerializedName("tablet")
	String tablet;
	
	@Nullable
	@SerializedName("smartphone")
	String smartphone;
	
	@Nullable
	@SerializedName("WSOnly")
	String WSOnly;
	
	@Nullable
	@SerializedName("internetDevice")
	String internetDevice;
	
	@Nullable
	@SerializedName("homePC")
	String homePC;
	
	@Nullable
	@SerializedName("basicphone")
	String basicphone;
	
	@Nullable
	@SerializedName("virtualDevice")
	String virtualDevice;
	
	@Nullable
	@SerializedName("telematics")
	String telematics;
	
	@Nullable
	@SerializedName("category")
	String category;

	public String getSmartwatch() {
		return smartwatch;
	}

	public void setSmartwatch(String smartwatch) {
		this.smartwatch = smartwatch;
	}

	public String getConnectedDevice() {
		return connectedDevice;
	}

	public void setConnectedDevice(String connectedDevice) {
		this.connectedDevice = connectedDevice;
	}

	public String getTablet() {
		return tablet;
	}

	public void setTablet(String tablet) {
		this.tablet = tablet;
	}

	public String getSmartphone() {
		return smartphone;
	}

	public void setSmartphone(String smartphone) {
		this.smartphone = smartphone;
	}

	public String getWSOnly() {
		return WSOnly;
	}

	public void setWSOnly(String wSOnly) {
		WSOnly = wSOnly;
	}

	public String getInternetDevice() {
		return internetDevice;
	}

	public void setInternetDevice(String internetDevice) {
		this.internetDevice = internetDevice;
	}

	public String getHomePC() {
		return homePC;
	}

	public void setHomePC(String homePC) {
		this.homePC = homePC;
	}

	public String getBasicphone() {
		return basicphone;
	}

	public void setBasicphone(String basicphone) {
		this.basicphone = basicphone;
	}

	public String getVirtualDevice() {
		return virtualDevice;
	}

	public void setVirtualDevice(String virtualDevice) {
		this.virtualDevice = virtualDevice;
	}

	public String getTelematics() {
		return telematics;
	}

	public void setTelematics(String telematics) {
		this.telematics = telematics;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
}