package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class DeviceType implements Serializable{
	
	@Nullable
	@SerializedName("deviceType")
	String deviceType;
	
	@Nullable
	@SerializedName("home4GLte")
	String home4GLte;
	
	@Nullable
	@SerializedName("deskphone")
	String deskphone;
	
	@Nullable
	@SerializedName("device4GO")
	String device4GO;
	
	@Nullable
	@SerializedName("antenna5G")
	String antenna5G;
	
	@Nullable
	@SerializedName("description")
	String description;
	
	@Nullable
	@SerializedName("jetPack5G")
	String jetPack5G;
	
	@Nullable
	@SerializedName("jetPack4G")
	String jetPack4G;
	
	@Nullable
	@SerializedName("homeFusionDevice")
	String homeFusionDevice;
	
	@Nullable
	@SerializedName("device4G")
	String device4G;
	
	@Nullable
	@SerializedName("home5G")
	String home5G;
	
	@Nullable
	@SerializedName("device3G")
	String device3G;
	
	@Nullable
	@SerializedName("huntGroup")
	String huntGroup;
	
	@Nullable
	@SerializedName("overTheTop")
	String overTheTop;
	
	@Nullable
	@SerializedName("device5GA")
	String device5GA;
	
	@Nullable
	@SerializedName("backupRouter4G")
	String backupRouter4G;
	
	@Nullable
	@SerializedName("device5GE")
	String device5GE;
	
	@Nullable
	@SerializedName("autoAttendant")
	String autoAttendant;

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getHome4GLte() {
		return home4GLte;
	}

	public void setHome4GLte(String home4gLte) {
		home4GLte = home4gLte;
	}

	public String getDeskphone() {
		return deskphone;
	}

	public void setDeskphone(String deskphone) {
		this.deskphone = deskphone;
	}

	public String getDevice4GO() {
		return device4GO;
	}

	public void setDevice4GO(String device4go) {
		device4GO = device4go;
	}

	public String getAntenna5G() {
		return antenna5G;
	}

	public void setAntenna5G(String antenna5g) {
		antenna5G = antenna5g;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getJetPack5G() {
		return jetPack5G;
	}

	public void setJetPack5G(String jetPack5G) {
		this.jetPack5G = jetPack5G;
	}

	public String getJetPack4G() {
		return jetPack4G;
	}

	public void setJetPack4G(String jetPack4G) {
		this.jetPack4G = jetPack4G;
	}

	public String getHomeFusionDevice() {
		return homeFusionDevice;
	}

	public void setHomeFusionDevice(String homeFusionDevice) {
		this.homeFusionDevice = homeFusionDevice;
	}

	public String getDevice4G() {
		return device4G;
	}

	public void setDevice4G(String device4g) {
		device4G = device4g;
	}

	public String getHome5G() {
		return home5G;
	}

	public void setHome5G(String home5g) {
		home5G = home5g;
	}

	public String getDevice3G() {
		return device3G;
	}

	public void setDevice3G(String device3g) {
		device3G = device3g;
	}

	public String getHuntGroup() {
		return huntGroup;
	}

	public void setHuntGroup(String huntGroup) {
		this.huntGroup = huntGroup;
	}

	public String getOverTheTop() {
		return overTheTop;
	}

	public void setOverTheTop(String overTheTop) {
		this.overTheTop = overTheTop;
	}

	public String getDevice5GA() {
		return device5GA;
	}

	public void setDevice5GA(String device5ga) {
		device5GA = device5ga;
	}

	public String getBackupRouter4G() {
		return backupRouter4G;
	}

	public void setBackupRouter4G(String backupRouter4G) {
		this.backupRouter4G = backupRouter4G;
	}

	public String getDevice5GE() {
		return device5GE;
	}

	public void setDevice5GE(String device5ge) {
		device5GE = device5ge;
	}

	public String getAutoAttendant() {
		return autoAttendant;
	}

	public void setAutoAttendant(String autoAttendant) {
		this.autoAttendant = autoAttendant;
	}
	
		
}