package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;

import com.google.gson.annotations.SerializedName;

   
public class MapData {

   @SerializedName("location")
   Location location;

   @SerializedName("wifi")
   Wifi wifi;

   @SerializedName("cellularLTE")
   CellularLTE cellularLTE;

   @SerializedName("cellular5G")
   Cellular5G cellular5G;


    public void setLocation(Location location) {
        this.location = location;
    }
    public Location getLocation() {
        return location;
    }
    
    public void setWifi(Wifi wifi) {
        this.wifi = wifi;
    }
    public Wifi getWifi() {
        return wifi;
    }
    
    public void setCellularLTE(CellularLTE cellularLTE) {
        this.cellularLTE = cellularLTE;
    }
    public CellularLTE getCellularLTE() {
        return cellularLTE;
    }
    
    public void setCellular5G(Cellular5G cellular5G) {
        this.cellular5G = cellular5G;
    }
    public Cellular5G getCellular5G() {
        return cellular5G;
    }
    
}