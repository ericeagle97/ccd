package com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.utils.IOUtility;
import com.verizon.dataindus.rtstreams.core.utils.JsonValidation;
import com.verizon.dataindus.rtstreams.core.utils.WriteToGcs;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.KafkaIngestionOptions;
import com.verizon.dataindus.rtstreams.lib.readers.KafkaReader;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.networklocationviolation.SourceNetworkLocationViolationTransformLauncher;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getKafkaIOReadConfigurations;
import static com.verizon.dataindus.rtstreams.core.utils.JsonValidation.INVALID_JSON_RECORDS;
import static com.verizon.dataindus.rtstreams.core.utils.JsonValidation.VALID_JSON_RECORDS;

public class KafkaIngestion {
	public static boolean flagGCS = false;
	public void kafkaIngestion(KafkaIngestionOptions options) {

		// Creates pipeline with custom pipeline options
		Pipeline pipeline = Pipeline.create(options);

		// Creating object for custom exception class
		ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

		// Create a map of topics as keys and their respective configurations as values
		Map<String,JSONObject> kafkaTopicConfigMap = getKafkaIOReadConfigurations(
				options.getProjectId(),
				options.getKafkaIOReadConfigBucket(),
				options.getKafkaIOReadConfigFile(),
				options.getKafkaIOReadSource(),
				objCustomExceptions);

		// List of PCollections created after KafkaIO.read()
		List<PCollection<String>> listKafkaIOReadPCollections = new ArrayList<>();

		try{
			if(options.getKafkaIOReadSource().equals("source-NetworkLocationViolation")) {

				if(!kafkaTopicConfigMap.isEmpty())
					for(String kafkaTopic: options.getKafkaTopicNames().split(",")){
						// Add all PCollections read to the list
						List<PCollection<String>> listPCollectionsByRegion = new KafkaReader()
								.readSource(pipeline,kafkaTopic,options.getKafkaIOReadRegions(),
										kafkaTopicConfigMap);

						listKafkaIOReadPCollections.addAll(listPCollectionsByRegion);
					}
				//JsonParsing and Source Transformations with PubSub write for downstream consumptions	
				SourceNetworkLocationViolationTransformLauncher nwlvProcessLauncher =new SourceNetworkLocationViolationTransformLauncher(); 
				/*Calling SourceProcessLauncher for source transformations if any class*/ 
				nwlvProcessLauncher.sourceProcessLauncher(listKafkaIOReadPCollections.get(0), listKafkaIOReadPCollections.get(1), options);
				pipeline.run();

			}
			else {
				if(!kafkaTopicConfigMap.isEmpty())
					for(String kafkaTopic: options.getKafkaTopicNames().split(",")){
						// Add all PCollections read to the list
						List<PCollection<String>> listPCollectionsByRegion = new KafkaReader()
								.readSource(pipeline,kafkaTopic,options.getKafkaIOReadRegions(),
										kafkaTopicConfigMap);

						listKafkaIOReadPCollections.addAll(listPCollectionsByRegion);
					}

				// Flatten out all PCollections read
				PCollection<String> dataFromAllKafkaTopicRead =
						PCollectionList.of(listKafkaIOReadPCollections)
						.apply("Flatten multiple PCollections",Flatten.pCollections());

				//JsonParsing and Source Transformations with PubSub write for downstream consumptions	
				SourceTransformLauncher processLauncher =new SourceTransformLauncher(); 
				/*Calling SourceProcessLauncher for source transformations if any class*/ 
				processLauncher.sourceProcessLauncher(dataFromAllKafkaTopicRead,options);

				pipeline.run();
			}
		} catch (Exception e) {
			e.printStackTrace();
			objCustomExceptions.errorPipeline("KafkaIngestion", e);
		}
	}

}

