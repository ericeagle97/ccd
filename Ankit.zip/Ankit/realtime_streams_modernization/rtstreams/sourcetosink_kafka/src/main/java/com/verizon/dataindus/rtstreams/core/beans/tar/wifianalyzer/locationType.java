package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

@javax.annotation.Nullable
public class locationType implements Serializable {

	@SerializedName("altitude")
	@Nullable
	private long altitude;

	@SerializedName("latitude")
	@Nullable
	private double latitude;

	@SerializedName("accuracy")
	@Nullable
	private double accuracy;
	
	@SerializedName("longitude")
	@Nullable
	private double longitude;

	@SerializedName("axialColumn")
	@Nullable
	private long axialColumn;

	@SerializedName("axialRow")
	@Nullable
	private long axialRow;

	public long getAltitude() {
		return altitude;
	}

	public void setAltitude(long altitude) {
		this.altitude = altitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(double accuracy) {
		this.accuracy = accuracy;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public long getAxialColumn() {
		return axialColumn;
	}

	public void setAxialColumn(long axialColumn) {
		this.axialColumn = axialColumn;
	}

	public long getAxialRow() {
		return axialRow;
	}

	public void setAxialRow(long axialRow) {
		this.axialRow = axialRow;
	}

	@Override
	public String toString() {
		return "locationType [altitude=" + altitude + ", latitude=" + latitude + ", accuracy=" + accuracy
				+ ", longitude=" + longitude + ", axialColumn=" + axialColumn + ", axialRow=" + axialRow + "]";
	}

	

}