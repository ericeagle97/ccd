package com.verizon.dataindus.rtstreams.core.constants.ivrcallpredictives;

public class IvrCallPredictivesConstants {

    public static final String CHANNEL = "IVRCallPredictives";

    public static final String PREDICTIVE_TO_CASSANDRA_CUST_INSIGHTS = "SOI_InsertCustomerInsights";
    public static final String PREDICTIVE_TO_CASSANDRA_CUST_MTN_INSIGHTS= "SOI_InsertCustomerMtnInsights";
    public static final String CASSANDRA_ENDPOINT = "https://mcscmpt3-pnosoi.ebiz.verizon.com/PNO/request";

    public static final String CUSTOMER_ID = "customerId";
    public static final String ACCOUNT_NO = "accountNo";
    public static final String MTN = "mtn";
    public static final String CALL = "call";
    public static final String PREDICTIVE = "predictive";
    public static final String FEEDBACK_RESPONSE = "feedbackResponse";
    public static final String INSIGHT_VALUES = "insightValues";
    public static final String CUST_ID_NO = "cust_id_no";

    public static final String CUST_ID = "custId";
    public static final String ACCT_NO = "acctNo";
    public static final String INSIGHT_CATEGORY = "insightCategory";
    public static final String INSIGHT_NAME = "insightName";
    public static final String UPDATE_BY = "updateBy";

    public static final String UPDATE_TS = "updateTs";
    public static final Object STREAMS = "streams";
    public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String TIME_ZONE = " GMT";
    public static final String LINKAGE_ID = "linkageID";
    
    public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS = "attr-cee-pubsub-cust-insights-no-ttl";
    public static final String PUBSUB_ATTRIBUTE_CUST_MTN_INSIGHTS= "attr-cee-pubsub-cust-mtn-insights-no-ttl";
}
