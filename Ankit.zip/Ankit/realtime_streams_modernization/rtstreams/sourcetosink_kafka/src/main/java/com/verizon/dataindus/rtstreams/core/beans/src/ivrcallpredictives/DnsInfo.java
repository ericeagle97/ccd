package com.verizon.dataindus.rtstreams.core.beans.src.ivrcallpredictives;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class DnsInfo implements Serializable {

   @SerializedName("dnsNumber")
   @Nullable
   String dnsNumber;


    public void setDnsNumber(String dnsNumber) {
        this.dnsNumber = dnsNumber;
    }
    public String getDnsNumber() {
        return dnsNumber;
    }

    
}