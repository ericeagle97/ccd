package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class CPEAlertTupleDelayStreamOut implements Serializable {

    @SerializedName("Delay")
    @Nullable
    String Delay;

    @SerializedName("Records")
    @Nullable
    long Records;

    @SerializedName("totalNoOfRecords")
    @Nullable
    long totalNoOfRecords;

    @SerializedName("Ratio")
    @Nullable
    double Ratio;

    @Nullable
    public String getDelay() {
        return Delay;
    }

    public void setDelay(@Nullable String delay) {
        Delay = delay;
    }

    public long getRecords() {
        return Records;
    }

    public void setRecords(long records) {
        Records = records;
    }

    public long getTotalNoOfRecords() {
        return totalNoOfRecords;
    }

    public void setTotalNoOfRecords(long totalNoOfRecords) {
        this.totalNoOfRecords = totalNoOfRecords;
    }

    public double getRatio() {
        return Ratio;
    }

    public void setRatio(double ratio) {
        Ratio = ratio;
    }

    @Override
    public String toString() {
        return "CPEAlertTupleDelayStreamOut{" +
                "Delay='" + Delay + '\'' +
                ", Records=" + Records +
                ", totalNoOfRecords=" + totalNoOfRecords +
                ", Ratio=" + Ratio +
                '}';
    }
}
