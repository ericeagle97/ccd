package com.verizon.dataindus.rtstreams.core.beans.src.networkwificalling;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class WificallingRawType implements Serializable {

   @SerializedName("MTN")
   @JsonProperty("MTN")
   @Nullable
   String MTN;

   @SerializedName("ACCT_NUM")
   @JsonProperty("ACCT_NUM")
   @Nullable
   String ACCT_NUM;

   @SerializedName("CUST_ID")
   @JsonProperty("CUST_ID")
   @Nullable
   String CUST_ID;

   @SerializedName("ACTIVITY_DT")
   @JsonProperty("ACTIVITY_DT")
   @Nullable
   String ACTIVITY_DT;

   @SerializedName("AVG_DEVICE_1_3")
   @JsonProperty("AVG_DEVICE_1_3")
   @Nullable
   Long AVG_DEVICE_1_3;

   @SerializedName("CALLSWITHALEG_WIFI_OVERALL_FLAG")
   @JsonProperty("CALLSWITHALEG_WIFI_OVERALL_FLAG")
   @Nullable
   Long CALLSWITHALEG_WIFI_OVERALL_FLAG;

   @SerializedName("CUST_LINE_SEQ_ID")
   @JsonProperty("CUST_LINE_SEQ_ID")
   @Nullable
   String CUST_LINE_SEQ_ID;

    public String getMTN() {
        return MTN;
    }

    public void setMTN(String MTN) {
        this.MTN = MTN;
    }

    public String getACCT_NUM() {
        return ACCT_NUM;
    }

    public void setACCT_NUM(String ACCT_NUM) {
        this.ACCT_NUM = ACCT_NUM;
    }

    public String getCUST_ID() {
        return CUST_ID;
    }

    public void setCUST_ID(String CUST_ID) {
        this.CUST_ID = CUST_ID;
    }

    public String getACTIVITY_DT() {
        return ACTIVITY_DT;
    }

    public void setACTIVITY_DT(String ACTIVITY_DT) {
        this.ACTIVITY_DT = ACTIVITY_DT;
    }

    public Long getAVG_DEVICE_1_3() {
        return AVG_DEVICE_1_3;
    }

    public void setAVG_DEVICE_1_3(Long AVG_DEVICE_1_3) {
        this.AVG_DEVICE_1_3 = AVG_DEVICE_1_3;
    }

    public Long getCALLSWITHALEG_WIFI_OVERALL_FLAG() {
        return CALLSWITHALEG_WIFI_OVERALL_FLAG;
    }

    public void setCALLSWITHALEG_WIFI_OVERALL_FLAG(Long CALLSWITHALEG_WIFI_OVERALL_FLAG) {
        this.CALLSWITHALEG_WIFI_OVERALL_FLAG = CALLSWITHALEG_WIFI_OVERALL_FLAG;
    }

    public String getCUST_LINE_SEQ_ID() {
        return CUST_LINE_SEQ_ID;
    }

    public void setCUST_LINE_SEQ_ID(String CUST_LINE_SEQ_ID) {
        this.CUST_LINE_SEQ_ID = CUST_LINE_SEQ_ID;
    }


    @Override
    public String toString() {
        return "WificallingRawType{" +
                "MTN='" + MTN + '\'' +
                ", ACCT_NUM='" + ACCT_NUM + '\'' +
                ", CUST_ID='" + CUST_ID + '\'' +
                ", ACTIVITY_DT='" + ACTIVITY_DT + '\'' +
                ", AVG_DEVICE_1_3=" + AVG_DEVICE_1_3 +
                ", CALLSWITHALEG_WIFI_OVERALL_FLAG=" + CALLSWITHALEG_WIFI_OVERALL_FLAG +
                ", CUST_LINE_SEQ_ID='" + CUST_LINE_SEQ_ID + '\'' +
                '}';
    }
}