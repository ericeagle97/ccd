package com.verizon.dataindus.rtstreams.core.beans.tar.port;

import java.io.Serializable;

public class CassandraMainType implements Serializable{
	
	private String requestType;
	 public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public keyAttributesType getKeyAttributes() {
		return keyAttributes;
	}
	public void setKeyAttributes(keyAttributesType keyAttributes) {
		this.keyAttributes = keyAttributes;
	}
	public String getCurrentvalues() {
		return currentvalues;
	}
	public void setCurrentvalues(String currentvalues) {
		this.currentvalues = currentvalues;
	}
	private keyAttributesType keyAttributes;
	 private String currentvalues;

}
