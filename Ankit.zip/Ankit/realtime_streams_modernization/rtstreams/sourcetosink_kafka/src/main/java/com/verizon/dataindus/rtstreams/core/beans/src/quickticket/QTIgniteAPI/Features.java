package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.QTIgniteAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class Features implements Serializable {

	   @SerializedName("operation")
	   String operation;

	   @SerializedName("comments")
	   String comments;

	   @SerializedName("jiraId")
	   String jiraId;

	   @SerializedName("issueDesc")
	   String issueDesc;

	   @SerializedName("symptoms")
	   String symptoms;

	   @SerializedName("ordLocCode")
	   String ordLocCode;

	   @SerializedName("childCount")
	   String childCount;


	    public void setOperation(String operation) {
	        this.operation = operation;
	    }
	    public String getOperation() {
	        return operation;
	    }
	    
	    public void setComments(String comments) {
	        this.comments = comments;
	    }
	    public String getComments() {
	        return comments;
	    }
	    
	    public void setJiraId(String jiraId) {
	        this.jiraId = jiraId;
	    }
	    public String getJiraId() {
	        return jiraId;
	    }
	    
	    public void setIssueDesc(String issueDesc) {
	        this.issueDesc = issueDesc;
	    }
	    public String getIssueDesc() {
	        return issueDesc;
	    }
	    
	    public void setSymptoms(String symptoms) {
	        this.symptoms = symptoms;
	    }
	    public String getSymptoms() {
	        return symptoms;
	    }
	    
	    public void setOrdLocCode(String ordLocCode) {
	        this.ordLocCode = ordLocCode;
	    }
	    public String getOrdLocCode() {
	        return ordLocCode;
	    }
	    
	    public void setChildCount(String childCount) {
	        this.childCount = childCount;
	    }
	    public String getChildCount() {
	        return childCount;
	    }
	    
	}