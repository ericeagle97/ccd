package com.verizon.dataindus.rtstreams.core.constants.cat;

public class SourceCustomerAccountType {

	public static final String ACCOUNTNO = "acctNo";
	public static final String CUSTID = "custId";
	public static final String MTN = "mtn";
	public static final String INSIGHTCATEGORY = "insightCategory";
	public static final String INSIGHTNAME = "insightName";
	public static final String UPDATEBY = "updateBy";
	public static final String UPDATETS = "updateTs";
	public static final String STARTTIME = "start_time";
	public static final String ENDTIME = "end_time";
	public static final String CUSTOMERACCOUNTTYPE = "customer_account_type";
	public static final String INSIGHTVALUES = "insightValues";
	
	
	//Values
	public static final String INSIGHTCATEGORYVALUE = "CCPA";
	public static final String INSIGHTNAMEVALUE = "customer_account_type";
	public static final String UPDATEBYVALUE = "streams";
	public static final String ENDTIMEVALUE = "NA";	
		
}
