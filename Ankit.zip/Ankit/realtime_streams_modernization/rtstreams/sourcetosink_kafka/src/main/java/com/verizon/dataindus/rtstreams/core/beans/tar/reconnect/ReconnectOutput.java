package com.verizon.dataindus.rtstreams.core.beans.tar.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class ReconnectOutput implements Serializable {
//    type reconnecttype=tuple<
//            rstring acss_call_id,
//    rstring acss_dept_id,
//    rstring Cust_ID,
//    rstring Acct_Num,
//    rstring Mtn,
//    rstring ani,
//    rstring agent_uswin,
//    rstring cti_dept_nm,
//    rstring router_callkey_callid,
//    rstring router_callkey_day,
//    rstring ivr_call_id,
//    rstring activity_id,
//    rstring ivr_call_startdt,
//    rstring ivr_call_enddt,
//    rstring speech_tag,
//    rstring solutions_team_ind,
//    rstring predictive_id,
//    rstring predictive_optin_ind>;
    @SerializedName("acss_call_id")
    @Nullable
    String acss_call_id;
    @SerializedName("acss_dept_id")
    @Nullable
    String acss_dept_id;
    @SerializedName("Cust_ID")
    @Nullable
    String Cust_ID;
    @SerializedName("Acct_Num")
    @Nullable
    String Acct_Num;
    @SerializedName("Mtn")
    @Nullable
    String Mtn;
    @SerializedName("ani")
    @Nullable
    String ani;
    @SerializedName("agent_uswin")
    @Nullable
    String agent_uswin;
    @SerializedName("cti_dept_nm")
    @Nullable
    String cti_dept_nm;
    @SerializedName("router_callkey_callid")
    @Nullable
    String router_callkey_callid;
    @SerializedName("router_callkey_day")
    @Nullable
    String router_callkey_day;
    @SerializedName("ivr_call_id")
    @Nullable
    String ivr_call_id;
    @SerializedName("activity_id")
    @Nullable
    String activity_id;
    @SerializedName("ivr_call_startdt")
    @Nullable
    String ivr_call_startdt;
    @SerializedName("ivr_call_enddt")
    @Nullable
    String ivr_call_enddt;
    @SerializedName("speech_tag")
    @Nullable
    String speech_tag;
    @SerializedName("solutions_team_ind")
    @Nullable
    String solutions_team_ind;
    @SerializedName("predictive_id")
    @Nullable
    String predictive_id;
    @SerializedName("predictive_optin_ind")
    @Nullable
    String predictive_optin_ind;

    public String getAcss_call_id() {
        return acss_call_id;
    }

    public void setAcss_call_id(String acss_call_id) {
        this.acss_call_id = acss_call_id;
    }

    public String getAcss_dept_id() {
        return acss_dept_id;
    }

    public void setAcss_dept_id(String acss_dept_id) {
        this.acss_dept_id = acss_dept_id;
    }

    public String getCust_ID() {
        return Cust_ID;
    }

    public void setCust_ID(String cust_ID) {
        Cust_ID = cust_ID;
    }

    public String getAcct_Num() {
        return Acct_Num;
    }

    public void setAcct_Num(String acct_Num) {
        Acct_Num = acct_Num;
    }

    public String getMtn() {
        return Mtn;
    }

    public void setMtn(String mtn) {
        Mtn = mtn;
    }

    public String getAni() {
        return ani;
    }

    public void setAni(String ani) {
        this.ani = ani;
    }

    public String getAgent_uswin() {
        return agent_uswin;
    }

    public void setAgent_uswin(String agent_uswin) {
        this.agent_uswin = agent_uswin;
    }

    public String getCti_dept_nm() {
        return cti_dept_nm;
    }

    public void setCti_dept_nm(String cti_dept_nm) {
        this.cti_dept_nm = cti_dept_nm;
    }

    public String getRouter_callkey_callid() {
        return router_callkey_callid;
    }

    public void setRouter_callkey_callid(String router_callkey_callid) {
        this.router_callkey_callid = router_callkey_callid;
    }

    public String getRouter_callkey_day() {
        return router_callkey_day;
    }

    public void setRouter_callkey_day(String router_callkey_day) {
        this.router_callkey_day = router_callkey_day;
    }

    public String getIvr_call_id() {
        return ivr_call_id;
    }

    public void setIvr_call_id(String ivr_call_id) {
        this.ivr_call_id = ivr_call_id;
    }

    public String getActivity_id() {
        return activity_id;
    }

    public void setActivity_id(String activity_id) {
        this.activity_id = activity_id;
    }

    public String getIvr_call_startdt() {
        return ivr_call_startdt;
    }

    public void setIvr_call_startdt(String ivr_call_startdt) {
        this.ivr_call_startdt = ivr_call_startdt;
    }

    public String getIvr_call_enddt() {
        return ivr_call_enddt;
    }

    public void setIvr_call_enddt(String ivr_call_enddt) {
        this.ivr_call_enddt = ivr_call_enddt;
    }

    public String getSpeech_tag() {
        return speech_tag;
    }

    public void setSpeech_tag(String speech_tag) {
        this.speech_tag = speech_tag;
    }

    public String getSolutions_team_ind() {
        return solutions_team_ind;
    }

    public void setSolutions_team_ind(String solutions_team_ind) {
        this.solutions_team_ind = solutions_team_ind;
    }

    public String getPredictive_id() {
        return predictive_id;
    }

    public void setPredictive_id(String predictive_id) {
        this.predictive_id = predictive_id;
    }

    public String getPredictive_optin_ind() {
        return predictive_optin_ind;
    }

    public void setPredictive_optin_ind(String predictive_optin_ind) {
        this.predictive_optin_ind = predictive_optin_ind;
    }

    @Override
    public String toString() {
        return "reconnectOutput{" +
                "acss_call_id='" + acss_call_id + '\'' +
                ", acss_dept_id='" + acss_dept_id + '\'' +
                ", Cust_ID='" + Cust_ID + '\'' +
                ", Acct_Num='" + Acct_Num + '\'' +
                ", Mtn='" + Mtn + '\'' +
                ", ani='" + ani + '\'' +
                ", agent_uswin='" + agent_uswin + '\'' +
                ", cti_dept_nm='" + cti_dept_nm + '\'' +
                ", router_callkey_callid='" + router_callkey_callid + '\'' +
                ", router_callkey_day='" + router_callkey_day + '\'' +
                ", ivr_call_id='" + ivr_call_id + '\'' +
                ", activity_id='" + activity_id + '\'' +
                ", ivr_call_startdt='" + ivr_call_startdt + '\'' +
                ", ivr_call_enddt='" + ivr_call_enddt + '\'' +
                ", speech_tag='" + speech_tag + '\'' +
                ", solutions_team_ind='" + solutions_team_ind + '\'' +
                ", predictive_id='" + predictive_id + '\'' +
                ", predictive_optin_ind='" + predictive_optin_ind + '\'' +
                '}';
    }
}
