package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;
import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class segment_idType  implements Serializable {

	@SerializedName("createdAt")
	long createdAt;

	@SerializedName("lastQualificationTime")
	String lastQualificationTime;

	@SerializedName("mappingCreatedAt")
	long mappingCreatedAt;

	@SerializedName("mappingUpdatedAt")
	long mappingUpdatedAt;

	@SerializedName("name")
	String name;

	@SerializedName("status")
	String status;

	@SerializedName("updatedAt")
	long updatedAt;

	public long getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(long createdAt) {
		this.createdAt = createdAt;
	}

	public String getLastQualificationTime() {
		return lastQualificationTime;
	}

	public void setLastQualificationTime(String lastQualificationTime) {
		this.lastQualificationTime = lastQualificationTime;
	}

	public long getMappingCreatedAt() {
		return mappingCreatedAt;
	}

	public void setMappingCreatedAt(long mappingCreatedAt) {
		this.mappingCreatedAt = mappingCreatedAt;
	}

	public long getMappingUpdatedAt() {
		return mappingUpdatedAt;
	}

	public void setMappingUpdatedAt(long mappingUpdatedAt) {
		this.mappingUpdatedAt = mappingUpdatedAt;
	}

	@Override
	public String toString() {
		return "segment_idType [createdAt=" + createdAt + ", lastQualificationTime=" + lastQualificationTime
				+ ", mappingCreatedAt=" + mappingCreatedAt + ", mappingUpdatedAt=" + mappingUpdatedAt + ", name=" + name
				+ ", status=" + status + ", updatedAt=" + updatedAt + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(long updatedAt) {
		this.updatedAt = updatedAt;
	}

	
}
