package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;
import java.util.List;

  
@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class PegaCase implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @SerializedName("Service")
   @JsonProperty("Service")
   Service service;

   @Nullable
	@SerializedName("e2eRequestId")
   String e2eRequestId;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;
   
	@SerializedName("tupleTimestamp")
	@Nullable
	List<TimeDetails> timeDetails;
	
	@SerializedName("linkageID")
	@Nullable
	String linkageID;



    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setService(Service service) {
        this.service = service;
    }
    public Service getService() {
        return service;
    }
    
    public void setE2eRequestId(String e2eRequestId) {
        this.e2eRequestId = e2eRequestId;
    }
    public String getE2eRequestId() {
        return e2eRequestId;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
    public void setTimeDetails(List<TimeDetails> timeDetails) {
		this.timeDetails = timeDetails;
	}
	public List<TimeDetails> getTimeDetails() {
		return timeDetails;
	}
	
	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	}
	public String getLinkageID() {
		return linkageID;
	}
    
    @Override
    public String toString() {
        return "PegaCase [pxObjClass=" + pxObjClass + ", Service=" + service + ", e2eRequestId=" + e2eRequestId +
                ", pxUpdateDateTime=" + pxUpdateDateTime + ", tupleTimestamp=" + timeDetails + ", linkageID=" + linkageID  + "]";
    }
    
}