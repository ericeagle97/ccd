package com.verizon.dataindus.rtstreams.core.constants;

public class Constants {

	public static final String CONFIG_KEYWORD_SOURCES = "sources";
	public static final String CONFIG_KEYWORD_TOPICS = "topics";
	public static final String CONFIG_KEYWORD_REGIONS = "regions";
	public static final String CONFIG_KEYWORD_GROUP_ID = "group.id";
	public static final String CONFIG_KEYWORD_SASL_JAAS = "sasl.jaas.config";
	public static final String CONFIG_KEYWORD_TRUSTSTORE_BUCKET = "truststore.bucket";
	public static final String CONFIG_KEYWORD_TRUSTSTORE_FILE = "truststore.file";
	public static final String CONFIG_KEYWORD_KAFKA_PROPERTIES = "kafka.properties";
	public static final String CONFIG_KEYWORD_BOOTSTRAP_SERVER = "bootstrap.servers";

	public static final String CONFIG_KEYWORD_EAST = "east";
	public static final String CONFIG_KEYWORD_WEST = "west";

	public static final String SSL_TRUSTSTORE_LOCATION = "ssl.truststore.location";
	public static final String TMP_PATH = "/tmp/";

	public static final String MEMSTORE_SECRET_ID_KEYSTORE_PASS = "memorystore-keystore-pass";
	public static final String MEMSTORE_SECRET_ID_JKS = "memorystore-cert";
	public static final String MEMSTORE_SECRET_ID = "memorystore-secrets";
	public static final String MEMSTORE_SECRET_ID_VERSION = "latest";

	public static final String MEMSTORE_HOST = "host";
	public static final String MEMSTORE_PORT = "port";
	public static final String MEMSTORE_PASSWORD = "password";
	public static final String MEMSTORE_JKS_FILEPATH = "/tmp/server-ca.jks";
	public static final String MEMSTORE_SSL_SOCKET_PROTOCOL = "TLSv1.3";
	public static final String MEMSTORE_KEYSTORE_INSTANCE_TYPE = "JKS";

	public static final String GCP_AUTH_CRED = "https://www.googleapis.com/auth/cloud-platform";

	public static final String HASH_MTN_PREFIX = "HASH_";
	public static final String HASH_CUSTID_ACCT_PREFIX = "Hash_";
	public static final String REDIS_GLOBALID_PREFIX = "GlobalID_";

	public static final String REDIS_KEY_MTN = "MTN";
	public static final String REDIS_KEY_ACCT_NUM = "ACCT_NUM";
	public static final String REDIS_KEY_CUST_ID = "CUST_ID";

	public static final String REDIS_KEY_GLOBALID_MTN = "MTN";
	public static final String REDIS_KEY_GLOBALID_CUSTID = "CUSTID";

	public static final String REGEX_MTN = "^[0-9]+$";
	public static final String REGEX_PNO_SUCCESS = "(.*?)(200|Success)(.*?)";

	public static final String REDIS_SUCCESS_MSG_PREFIX = "INSERT SUCCESSFUL: Redis Inserting ";
	public static final String REDIS_FAILURE_MSG_PREFIX = "INSERT FAILED: Redis Inserting ";

	public static final String DVS_KEY_MTN = "MTN";
	public static final String DVS_KEY_ACCOUNT = "ACCOUNT";

	public static final String METRICS_COUNTER_VALID = "valid_count";
	public static final String METRICS_COUNTER_INVALID = "invalid_count";
	public static final String METRICS_COUNTER_SUCCESS = "successful_count";
	public static final String METRICS_COUNTER_FAILURE = "failure_count";
	public static final String METRICS_COUNTER_FOUND = "found_count";
	public static final String METRICS_COUNTER_UNFOUND = "unfound_count";

	public static final String METRICS_JSON_VALIDATION = "JsonValidation";
	public static final String METRICS_JSON_PARSING = "JsonParsing";
	public static final String METRICS_PREPROCESSING = "Preprocessing";

	public static final String METRICS_GLOBALID_KEYRING = "GlobalIdKeyringResponse";
	public static final String METRICS_GLOBALID_REDIS = "GlobalIdRedisResponse";
	public static final String METRICS_UNHASH_DVS = "UnhashDVSResponse";
	public static final String METRICS_UNHASH_REDIS = "UnhashRedisResponse";

	public static final String METRICS_DVS_API = "DVSApiResponse";
	public static final String METRICS_KEYRING_API = "KeyringApiResponse";

	public static final String HTTP_REQUEST_POST = "POST";
	public static final int HTTP_TIMEOUT = 2000;

	public static final String HTTP_REQUEST_CONTENT_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String HTTP_REQUEST_CONTENT_JSON = "application/json";

	public static final String HTTP_REQUEST_CHARSET_UTF = "UTF-8";

	public static final String HTTP_REQUEST_PROP_CHARSET = "Charset";
	public static final String HTTP_REQUEST_PROP_CONTENT_TYPE = "Content-Type";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SERVICE = "ORIGINAL_SERVICE";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE = "ORIGINAL_SUBSERVICE";
	public static final String HTTP_REQUEST_PROP_CORRELATION_ID = "CORRELATION_ID";

	public static final String METRICS_CASSANDRA_INSERTION = "CassandraInsertion";
	public static final String METRICS_CASSANDRA_FEATURES = "FeatureInsertionResponse";
	public static final String METRICS_CASSANDRA_API = "CassandraInsertionApi";
	public static final String HTTP_REQUEST_SERVICE_WW = "ww";

	public static final String PUBSUB_DEADLETTER_TOPIC = "tp-cee-kafka-maineconsent-error";

	public static final String PUBSUB = "PubSub";
	public static final String GCS = "GCS";
	public static final String HTTP_REQUEST_CORRELATION_ID = "12345";

	public static final String REDIS_EDW_PREFIX = "EDW_";
	public static final String METRICS_MTN_EDWLOOKUP = "MTN EDW look UP";

	public static final String CLASSNAME_VLM_COMPOSITE = "VLM_StoreFeedVisit_Composite";
	public static final String CLASSNAME_PEGACASE = "PegaCreateCase";
	public static final String SOURCE_MMG = "source_mmg";
	public static final String CLASSNAME_AM = "AM";
	public static final String Linkage_Id = "linkage_id";
	public static final String INVALID_COUNT_LINKAGE_ID = "invalid_count_linkage_id";
	public static final String CUSTOMER_ACCOUNT_TYPE = "customer_account_type";

	public static final String JARVIS_FEATURES_REQUEST = "jarvis_features_request";
	public static final String JARVIS_FEATURES_RESPONSE = "jarvis_features_response";
	public static final String METRICS_CASSANDRA_LOOKUP = "CassandraLookUp";
	public static final String PUBSUB_KEYWORD_ATTRIBUTETYPE = "attributeType";
	public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS = "attr-cee-pubsub-cust-insights-no-ttl";// SOI_InsertCustomerInsights
	//public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS_NOTTL = "attr-cee-pubsub-cust-insights-no-ttl";
	public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL = "attr-cee-pubsub-cust-insights";// SOI_InsertCustomerInsights_ttl
	public static final String PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS = "attr-cee-pubsub-aggr-prod-insights";// SOI_InsertAggrProductInsights
	public static final String PUBSUB_ATTRIBUTE_CUST_MTN_INSIGHTS = "attr-cee-pubsub-cust-mtn-insights-no-ttl";// SOI_InsertCustomerMtnInsights
	public static final String PUBSUB_ATTRIBUTE_SESSION_INSIGHTS = "attr-cee-pubsub-session-insights";// SOI_InsertSessionInsights_ttl
	public static final String PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS_TTL = "attr-cee-pubsub-aggr-prod-insights-ttl";// SOI_InsertAggrProductInsights_ttl
	public static final String PUBSUB_ATTRIBUTE_CUST_EVENT_TIMELINE = "attr-cee-pubsub-cust-event-timeline";
	public static final String PUBSUB_ATTRIBUTE_CUST_MTN_INSIGHTS_TTL = "attr-cee-pubsub-cust-mtn-insights";// SOI_InsertCustomerMtnInsights_ttl

	public static final String ANOMALY_DATA = "anomalyData";
	public static final String ANOMALY_VOICE = "anomalyVoice";
	public static final String ANOMALY_MT = "anomalyMt";
	public static final String CHANGE_3_DAY = "change_3_day";
	
	public static final String HTTP_REQUEST_CASSANDRA = "https://mcscmpt1-pnosoi.ebiz.verizon.com/PNO/request";
	public static final String REQUEST_TYPE_CASSANDRA = "SOI_InsertCustomerMtnInsights";
	public static final String INSIGHT_CATEGORY = "insightCategory";
	public static final String INSIGHT_NAME = "insightName";
	public static final String INSIGHT_VALUES = "insightValues";
	public static final String UPDATE_BY = "updateBy";
	public static final String UPDATE_TS = "updateTs";

	public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS_NO_TTL = "attr-cee-pubsub-cust-insights-no-ttl"; // SOI_InsertCustomerInsights
	public static final String PUBSUB_ATTRIBUTE_INSERT_EVENT = "attr-cee-pubsub-pzai-events";// SOI_InsertSessionInsights_ttl
	public static final String CLASSNAME_VISION_REMARKS_REWIRED = "AgentRemarks";
}
