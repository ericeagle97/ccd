package com.verizon.dataindus.rtstreams.core.constants.RemarksRewired;

public class RemarksRewiredConstants {

    public static final String MTN = "mtn";
    public static final String CONTACT_TYPE_CODE = "contactTypeCode";
    public static final String BILL_SYS_ID = "billSysId";
    public static final String CONTACT_DT = "contact_dt";
    public static final String REMAKR_TYPE = "remarkType";
    public static final String REGION = "region";
    public static final String REMARKS_DATE = "remarks_date";
    public static final String CHANNEL = "channelId";
    public static final String CUST_ID_NO = "cust_id_no";
    public static final String REMARKS = "remarks";
    public static final String REMAKRS_LIST = "remarks_list";
    public static final String L1 = "L1";
    public static final String L2 = "L2";
    public static final String L3 = "L3";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION_JSON = "application/json";
    public static final String MSG = "msg";


}
