package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class OrderDetailsContext implements Serializable{
	
	@Nullable
	@SerializedName("lineInfo")
	List<LineInfo> lineInfo;
	
	@Nullable
	@SerializedName("orderActivityType")
	String orderActivityType;
	
	@Nullable
	@SerializedName("locationCode")
	String locationCode;
	
	@Nullable
	@SerializedName("orderNum")
	String orderNum;
	

	public List<LineInfo> getLineInfo() {
		return lineInfo;
	}

	public void setLineInfo(List<LineInfo> lineInfo) {
		this.lineInfo = lineInfo;
	}

	public String getOrderActivityType() {
		return orderActivityType;
	}

	public void setOrderActivityType(String orderActivityType) {
		this.orderActivityType = orderActivityType;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	
	
}