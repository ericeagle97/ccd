package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class heatmapPointsType implements Serializable{
		
	@SerializedName("cellular5G")
	@Nullable
	private cellular5GType  cellular5G;
	
	@SerializedName("wifi")
	@Nullable
	private wifiType  wifi;
	
	@SerializedName("location")
	@Nullable
	private locationType  location;
	
	@SerializedName("cellularLTE")
	@Nullable
	private cellularLTEType  cellularLTE;

	public cellular5GType getCellular5G() {
		return cellular5G;
	}

	public void setCellular5G(cellular5GType cellular5g) {
		cellular5G = cellular5g;
	}

	public wifiType getWifi() {
		return wifi;
	}

	public void setWifi(wifiType wifi) {
		this.wifi = wifi;
	}

	public locationType getLocation() {
		return location;
	}

	public void setLocation(locationType location) {
		this.location = location;
	}

	public cellularLTEType getCellularLTE() {
		return cellularLTE;
	}

	public void setCellularLTE(cellularLTEType cellularLTE) {
		this.cellularLTE = cellularLTE;
	}

	@Override
	public String toString() {
		return "heatmapPointsType [cellular5G=" + cellular5G + ", wifi=" + wifi + ", location=" + location
				+ ", cellularLTE=" + cellularLTE + "]";
	}
	
	public heatmapPointsType() {
		super();
		// TODO Auto-generated constructor stub
	}

	public heatmapPointsType(cellular5GType cellular5G, wifiType wifi, locationType location, cellularLTEType cellularLTE) {
		super();
		this.cellular5G = cellular5G;
		this.wifi = wifi;
		this.location = location;
		this.cellularLTE = cellularLTE;
	}
}
