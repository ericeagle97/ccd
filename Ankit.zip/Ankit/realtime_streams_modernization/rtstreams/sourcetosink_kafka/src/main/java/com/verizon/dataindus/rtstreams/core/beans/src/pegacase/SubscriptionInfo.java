package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;
import java.util.List;

   

@javax.annotation.Nullable
public class SubscriptionInfo implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("orderNumber")
   String orderNumber;

   @Nullable
	@SerializedName("Category")
   @JsonProperty("Category")
   String Category;

   @Nullable
	@SerializedName("recurFrequency")
   String recurFrequency;

   @Nullable
	@SerializedName("entitlementId")
   String entitlementId;

   @Nullable
	@SerializedName("planName")
   String planName;

   @Nullable
	@SerializedName("ehubService")
   String ehubService;

   @Nullable
	@SerializedName("productKey")
   String productKey;

   @Nullable
	@SerializedName("promotionId")
   String promotionId;

   @Nullable
	@SerializedName("productName")
   String productName;

   @Nullable
	@SerializedName("priceList")
   String priceList;

   @Nullable
	@SerializedName("merchantAccountKey")
   String merchantAccountKey;

   @Nullable
	@SerializedName("addressId")
   String addressId;

   @Nullable
	@SerializedName("DutyFreeAmountValue")
   @JsonProperty("DutyFreeAmountValue")
   String DutyFreeAmountValue;

   @Nullable
	@SerializedName("productOfferingId")
   String productOfferingId;

   @Nullable
	@SerializedName("SubscriptionType")
   @JsonProperty("SubscriptionType")
   String SubscriptionType;

   @Nullable
	@SerializedName("PromotionName")
   @JsonProperty("PromotionName")
   String PromotionName;

   @Nullable
	@SerializedName("offerKey")
   String offerKey;

   @Nullable
	@SerializedName("price")
   String price;

   @Nullable
	@SerializedName("DisplayName")
   @JsonProperty("DisplayName")
   String DisplayName;

   @Nullable
	@SerializedName("action")
   String action;

   @Nullable
	@SerializedName("serialNumber")
   String serialNumber;

   @Nullable
	@SerializedName("Productoffertype")
   @JsonProperty("Productoffertype")
   String Productoffertype;

   @Nullable
	@SerializedName("acceptIndicator")
   String acceptIndicator;

   @Nullable
	@SerializedName("recurrChrdPeriodLen")
   String recurrChrdPeriodLen;

   @Nullable
	@SerializedName("PaymentFrequency")
   @JsonProperty("PaymentFrequency")
   String PaymentFrequency;

   @Nullable
	@SerializedName("bundleIndicator")
   String bundleIndicator;

   @Nullable
	@SerializedName("EPCPromoEndDate")
   @JsonProperty("EPCPromoEndDate")
   String EPCPromoEndDate;

   @Nullable
	@SerializedName("aggregatorId")
   String aggregatorId;

   @Nullable
	@SerializedName("accountLevel")
   String accountLevel;

   @Nullable
	@SerializedName("PaymentMethodRefId")
   @JsonProperty("PaymentMethodRefId")
   String PaymentMethodRefId;

   @Nullable
	@SerializedName("finalPriceValue")
   String finalPriceValue;

   @Nullable
	@SerializedName("sellerOfRecord")
   String sellerOfRecord;

   @Nullable
	@SerializedName("acceptBy")
   String acceptBy;

   @Nullable
	@SerializedName("OfferName")
   @JsonProperty("OfferName")
   String OfferName;

   @Nullable
	@SerializedName("taxLocation")
   String taxLocation;

   @Nullable
	@SerializedName("productOfferingPricingID")
   String productOfferingPricingID;

   @Nullable
	@SerializedName("recurrChrgPeriodType")
   String recurrChrgPeriodType;

   @Nullable
	@SerializedName("taxAmount")
   String taxAmount;

   @Nullable
	@SerializedName("paymentTransactionId")
   String paymentTransactionId;

   @Nullable
	@SerializedName("paymentMethodType")
   String paymentMethodType;

   @Nullable
	@SerializedName("lob")
   String lob;

   @Nullable
	@SerializedName("productOfferingGroupId")
   String productOfferingGroupId;

   @Nullable
	@SerializedName("OfferType")
   @JsonProperty("OfferType")
   String OfferType;
   
   @Nullable
	@SerializedName("ProductList")
  @JsonProperty("ProductList")
  List<ProductList> ProductList;
   

   @Nullable
	@SerializedName("agreementType")
   String agreementType;

   @Nullable
	@SerializedName("Play_Trial_Cost")
   @JsonProperty("Play_Trial_Cost")
   String PlayTrialCost;

   @Nullable
	@SerializedName("promoPurchaseType")
   String promoPurchaseType;

   @Nullable
	@SerializedName("offerSubType")
   String offerSubType;

   @Nullable
	@SerializedName("buyProductReplace")
   String buyProductReplace;

   @Nullable
	@SerializedName("entitlementExpiryLimit")
   String entitlementExpiryLimit;

   @Nullable
	@SerializedName("recurrChrgPeriodLen")
   String recurrChrgPeriodLen;

   @Nullable
	@SerializedName("maxRedeemLimit")
   String maxRedeemLimit;

   @Nullable
	@SerializedName("Play_Subscription_MTNLast4")
   @JsonProperty("Play_Subscription_MTNLast4")
   String PlaySubscriptionMTNLast4;

   @Nullable
	@SerializedName("OMPCount")
   @JsonProperty("OMPCount")
   String OMPCount;

   @Nullable
	@SerializedName("getProductReplace")
   String getProductReplace;

   @Nullable
	@SerializedName("SpecialProcessingNote")
   @JsonProperty("SpecialProcessingNote")
   String SpecialProcessingNote;

   @Nullable
	@SerializedName("Play_Redeem_By_Date")
   @JsonProperty("Play_Redeem_By_Date")
   String PlayRedeemByDate;

   @Nullable
	@SerializedName("masterOrderNumber")
   String masterOrderNumber;

   @Nullable
	@SerializedName("Type")
   @JsonProperty("Type")
   String Type;

   @Nullable
	@SerializedName("responseCode")
   String responseCode;

   @Nullable
	@SerializedName("cancelBy")
   String cancelBy;

   @Nullable
	@SerializedName("effectiveTill")
   EffectiveTill effectiveTill;

   @Nullable
	@SerializedName("responseMessage")
   String responseMessage;

   @Nullable
	@SerializedName("subscriptionId")
   String subscriptionId;

   @Nullable
	@SerializedName("Play_NewSubcription_StartDate")
   @JsonProperty("Play_NewSubcription_StartDate")
   String PlayNewSubcriptionStartDate;

   @Nullable
	@SerializedName("BangoPromoEndDate")
   @JsonProperty("BangoPromoEndDate")
   String BangoPromoEndDate;

   @Nullable
	@SerializedName("state")
   String state;

   @Nullable
	@SerializedName("billingPeriod")
   String billingPeriod;

   @Nullable
	@SerializedName("billingStartDate")
   String billingStartDate;

   @Nullable
	@SerializedName("promoDurationPriceValue")
   String promoDurationPriceValue;

   @Nullable
	@SerializedName("promoDurationPriceUnit")
   String promoDurationPriceUnit;

   @Nullable
	@SerializedName("nextPayment")
   NextPayment nextPayment;

   @Nullable
	@SerializedName("promoStartDate")
   String promoStartDate;

   @Nullable
	@SerializedName("BangoPromoEndDateOM")
   @JsonProperty("BangoPromoEndDateOM")
   String BangoPromoEndDateOM;

   @Nullable
	@SerializedName("SubscriptionChangeType")
   @JsonProperty("SubscriptionChangeType")
   String SubscriptionChangeType;

   @Nullable
	@SerializedName("phaseType")
   String  phaseType;

   @Nullable
	@SerializedName("externalKey")
   String externalKey;

   @Nullable
	@SerializedName("upgradeSubscriptionId")
   String upgradeSubscriptionId;

   @Nullable
	@SerializedName("lastPayment")
   LastPayment lastPayment;

   @Nullable
	@SerializedName("billCycleDayLocal")
   String billCycleDayLocal;

   @Nullable
	@SerializedName("upcoming")
   Upcoming upcoming;

   @Nullable
	@SerializedName("promoEndDate")
   String promoEndDate;

   @Nullable
	@SerializedName("pxUdateDateTime")
   String pxUdateDateTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
    public String getOrderNumber() {
        return orderNumber;
    }
    
    public void setCategory(String Category) {
        this.Category = Category;
    }
    public String getCategory() {
        return Category;
    }
    
    public void setRecurFrequency(String recurFrequency) {
        this.recurFrequency = recurFrequency;
    }
    public String getRecurFrequency() {
        return recurFrequency;
    }
    
    public void setEntitlementId(String entitlementId) {
        this.entitlementId = entitlementId;
    }
    public String getEntitlementId() {
        return entitlementId;
    }
    
    public void setPlanName(String planName) {
        this.planName = planName;
    }
    public String getPlanName() {
        return planName;
    }
    
    public void setEhubService(String ehubService) {
        this.ehubService = ehubService;
    }
    public String getEhubService() {
        return ehubService;
    }
    
    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }
    public String getProductKey() {
        return productKey;
    }
    
    public void setPromotionId(String promotionId) {
        this.promotionId = promotionId;
    }
    public String getPromotionId() {
        return promotionId;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public String getProductName() {
        return productName;
    }
    
    public void setPriceList(String priceList) {
        this.priceList = priceList;
    }
    public String getPriceList() {
        return priceList;
    }
    
    public void setMerchantAccountKey(String merchantAccountKey) {
        this.merchantAccountKey = merchantAccountKey;
    }
    public String getMerchantAccountKey() {
        return merchantAccountKey;
    }
    
    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
    public String getAddressId() {
        return addressId;
    }
    
    public void setDutyFreeAmountValue(String DutyFreeAmountValue) {
        this.DutyFreeAmountValue = DutyFreeAmountValue;
    }
    public String getDutyFreeAmountValue() {
        return DutyFreeAmountValue;
    }
    
    public void setProductOfferingId(String productOfferingId) {
        this.productOfferingId = productOfferingId;
    }
    public String getProductOfferingId() {
        return productOfferingId;
    }
    
    public void setSubscriptionType(String SubscriptionType) {
        this.SubscriptionType = SubscriptionType;
    }
    public String getSubscriptionType() {
        return SubscriptionType;
    }
    
    public void setPromotionName(String PromotionName) {
        this.PromotionName = PromotionName;
    }
    public String getPromotionName() {
        return PromotionName;
    }
    
    public void setOfferKey(String offerKey) {
        this.offerKey = offerKey;
    }
    public String getOfferKey() {
        return offerKey;
    }
    
    public void setPrice(String price) {
        this.price = price;
    }
    public String getPrice() {
        return price;
    }
    
    public void setDisplayName(String DisplayName) {
        this.DisplayName = DisplayName;
    }
    public String getDisplayName() {
        return DisplayName;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
    public String getAction() {
        return action;
    }
    
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }
    public String getSerialNumber() {
        return serialNumber;
    }
    
    public void setProductoffertype(String Productoffertype) {
        this.Productoffertype = Productoffertype;
    }
    public String getProductoffertype() {
        return Productoffertype;
    }
    
    public void setAcceptIndicator(String acceptIndicator) {
        this.acceptIndicator = acceptIndicator;
    }
    public String getAcceptIndicator() {
        return acceptIndicator;
    }
    
    public void setRecurrChrdPeriodLen(String recurrChrdPeriodLen) {
        this.recurrChrdPeriodLen = recurrChrdPeriodLen;
    }
    public String getRecurrChrdPeriodLen() {
        return recurrChrdPeriodLen;
    }
    
    public void setPaymentFrequency(String PaymentFrequency) {
        this.PaymentFrequency = PaymentFrequency;
    }
    public String getPaymentFrequency() {
        return PaymentFrequency;
    }
    
    public void setBundleIndicator(String bundleIndicator) {
        this.bundleIndicator = bundleIndicator;
    }
    public String getBundleIndicator() {
        return bundleIndicator;
    }
    
    public void setEPCPromoEndDate(String EPCPromoEndDate) {
        this.EPCPromoEndDate = EPCPromoEndDate;
    }
    public String getEPCPromoEndDate() {
        return EPCPromoEndDate;
    }
    
    public void setAggregatorId(String aggregatorId) {
        this.aggregatorId = aggregatorId;
    }
    public String getAggregatorId() {
        return aggregatorId;
    }
    
    public void setAccountLevel(String accountLevel) {
        this.accountLevel = accountLevel;
    }
    public String getAccountLevel() {
        return accountLevel;
    }
    
    public void setPaymentMethodRefId(String PaymentMethodRefId) {
        this.PaymentMethodRefId = PaymentMethodRefId;
    }
    public String getPaymentMethodRefId() {
        return PaymentMethodRefId;
    }
    
    public void setFinalPriceValue(String finalPriceValue) {
        this.finalPriceValue = finalPriceValue;
    }
    public String getFinalPriceValue() {
        return finalPriceValue;
    }
    
    public void setSellerOfRecord(String sellerOfRecord) {
        this.sellerOfRecord = sellerOfRecord;
    }
    public String getSellerOfRecord() {
        return sellerOfRecord;
    }
    
    public void setAcceptBy(String acceptBy) {
        this.acceptBy = acceptBy;
    }
    public String getAcceptBy() {
        return acceptBy;
    }
    
    public void setOfferName(String OfferName) {
        this.OfferName = OfferName;
    }
    public String getOfferName() {
        return OfferName;
    }
    
    public void setTaxLocation(String taxLocation) {
        this.taxLocation = taxLocation;
    }
    public String getTaxLocation() {
        return taxLocation;
    }
    
    public void setProductOfferingPricingID(String productOfferingPricingID) {
        this.productOfferingPricingID = productOfferingPricingID;
    }
    public String getProductOfferingPricingID() {
        return productOfferingPricingID;
    }
    
    public void setRecurrChrgPeriodType(String recurrChrgPeriodType) {
        this.recurrChrgPeriodType = recurrChrgPeriodType;
    }
    public String getRecurrChrgPeriodType() {
        return recurrChrgPeriodType;
    }
    
    public void setTaxAmount(String taxAmount) {
        this.taxAmount = taxAmount;
    }
    public String getTaxAmount() {
        return taxAmount;
    }
    
    public void setPaymentTransactionId(String paymentTransactionId) {
        this.paymentTransactionId = paymentTransactionId;
    }
    public String getPaymentTransactionId() {
        return paymentTransactionId;
    }
    
    public void setPaymentMethodType(String paymentMethodType) {
        this.paymentMethodType = paymentMethodType;
    }
    public String getPaymentMethodType() {
        return paymentMethodType;
    }
    
    public void setLob(String lob) {
        this.lob = lob;
    }
    public String getLob() {
        return lob;
    }
    
    public void setProductOfferingGroupId(String productOfferingGroupId) {
        this.productOfferingGroupId = productOfferingGroupId;
    }
    public String getProductOfferingGroupId() {
        return productOfferingGroupId;
    }
    
    public void setOfferType(String OfferType) {
        this.OfferType = OfferType;
    }
    public String getOfferType() {
        return OfferType;
    }
    
    public List<ProductList> getProductList() {
		return ProductList;
	}
	public void setProductList(List<ProductList> productList) {
		ProductList = productList;
	}
	public void setAgreementType(String agreementType) {
        this.agreementType = agreementType;
    }
    public String getAgreementType() {
        return agreementType;
    }
    
    public void setPlayTrialCost(String PlayTrialCost) {
        this.PlayTrialCost = PlayTrialCost;
    }
    public String getPlayTrialCost() {
        return PlayTrialCost;
    }
    
    public void setPromoPurchaseType(String promoPurchaseType) {
        this.promoPurchaseType = promoPurchaseType;
    }
    public String getPromoPurchaseType() {
        return promoPurchaseType;
    }
    
    public void setOfferSubType(String offerSubType) {
        this.offerSubType = offerSubType;
    }
    public String getOfferSubType() {
        return offerSubType;
    }
    
    public void setBuyProductReplace(String buyProductReplace) {
        this.buyProductReplace = buyProductReplace;
    }
    public String getBuyProductReplace() {
        return buyProductReplace;
    }
    
    public void setEntitlementExpiryLimit(String entitlementExpiryLimit) {
        this.entitlementExpiryLimit = entitlementExpiryLimit;
    }
    public String getEntitlementExpiryLimit() {
        return entitlementExpiryLimit;
    }
    
    public void setRecurrChrgPeriodLen(String recurrChrgPeriodLen) {
        this.recurrChrgPeriodLen = recurrChrgPeriodLen;
    }
    public String getRecurrChrgPeriodLen() {
        return recurrChrgPeriodLen;
    }
    
    public void setMaxRedeemLimit(String maxRedeemLimit) {
        this.maxRedeemLimit = maxRedeemLimit;
    }
    public String getMaxRedeemLimit() {
        return maxRedeemLimit;
    }
    
    public void setPlaySubscriptionMTNLast4(String PlaySubscriptionMTNLast4) {
        this.PlaySubscriptionMTNLast4 = PlaySubscriptionMTNLast4;
    }
    public String getPlaySubscriptionMTNLast4() {
        return PlaySubscriptionMTNLast4;
    }
    
    public void setOMPCount(String OMPCount) {
        this.OMPCount = OMPCount;
    }
    public String getOMPCount() {
        return OMPCount;
    }
    
    public void setGetProductReplace(String getProductReplace) {
        this.getProductReplace = getProductReplace;
    }
    public String getGetProductReplace() {
        return getProductReplace;
    }
    
    public void setSpecialProcessingNote(String SpecialProcessingNote) {
        this.SpecialProcessingNote = SpecialProcessingNote;
    }
    public String getSpecialProcessingNote() {
        return SpecialProcessingNote;
    }
    
    public void setPlayRedeemByDate(String PlayRedeemByDate) {
        this.PlayRedeemByDate = PlayRedeemByDate;
    }
    public String getPlayRedeemByDate() {
        return PlayRedeemByDate;
    }
    
    public void setMasterOrderNumber(String masterOrderNumber) {
        this.masterOrderNumber = masterOrderNumber;
    }
    public String getMasterOrderNumber() {
        return masterOrderNumber;
    }
    
    public void setType(String Type) {
        this.Type = Type;
    }
    public String getType() {
        return Type;
    }
    
    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }
    public String getResponseCode() {
        return responseCode;
    }
    
    public void setCancelBy(String cancelBy) {
        this.cancelBy = cancelBy;
    }
    public String getCancelBy() {
        return cancelBy;
    }
    
    public void setEffectiveTill(EffectiveTill effectiveTill) {
        this.effectiveTill = effectiveTill;
    }
    public EffectiveTill getEffectiveTill() {
        return effectiveTill;
    }
    
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
    public String getResponseMessage() {
        return responseMessage;
    }
    
    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }
    public String getSubscriptionId() {
        return subscriptionId;
    }
    
    public void setPlayNewSubcriptionStartDate(String PlayNewSubcriptionStartDate) {
        this.PlayNewSubcriptionStartDate = PlayNewSubcriptionStartDate;
    }
    public String getPlayNewSubcriptionStartDate() {
        return PlayNewSubcriptionStartDate;
    }
    
    public void setBangoPromoEndDate(String BangoPromoEndDate) {
        this.BangoPromoEndDate = BangoPromoEndDate;
    }
    public String getBangoPromoEndDate() {
        return BangoPromoEndDate;
    }
    
    public void setState(String state) {
        this.state = state;
    }
    public String getState() {
        return state;
    }
    
    public void setBillingPeriod(String billingPeriod) {
        this.billingPeriod = billingPeriod;
    }
    public String getBillingPeriod() {
        return billingPeriod;
    }
    
    public void setBillingStartDate(String billingStartDate) {
        this.billingStartDate = billingStartDate;
    }
    public String getBillingStartDate() {
        return billingStartDate;
    }
    
    public void setPromoDurationPriceValue(String promoDurationPriceValue) {
        this.promoDurationPriceValue = promoDurationPriceValue;
    }
    public String getPromoDurationPriceValue() {
        return promoDurationPriceValue;
    }
    
    public void setPromoDurationPriceUnit(String promoDurationPriceUnit) {
        this.promoDurationPriceUnit = promoDurationPriceUnit;
    }
    public String getPromoDurationPriceUnit() {
        return promoDurationPriceUnit;
    }
    
    public void setNextPayment(NextPayment nextPayment) {
        this.nextPayment = nextPayment;
    }
    public NextPayment getNextPayment() {
        return nextPayment;
    }
    
    public void setPromoStartDate(String promoStartDate) {
        this.promoStartDate = promoStartDate;
    }
    public String getPromoStartDate() {
        return promoStartDate;
    }
    
    public void setBangoPromoEndDateOM(String BangoPromoEndDateOM) {
        this.BangoPromoEndDateOM = BangoPromoEndDateOM;
    }
    public String getBangoPromoEndDateOM() {
        return BangoPromoEndDateOM;
    }
    
    public void setSubscriptionChangeType(String SubscriptionChangeType) {
        this.SubscriptionChangeType = SubscriptionChangeType;
    }
    public String getSubscriptionChangeType() {
        return SubscriptionChangeType;
    }
    
    public void setPhaseType(String phaseType) {
        this. phaseType =  phaseType;
    }
    public String getPhaseType() {
        return  phaseType;
    }
    
    public void setExternalKey(String externalKey) {
        this.externalKey = externalKey;
    }
    public String getExternalKey() {
        return externalKey;
    }
    
    public void setUpgradeSubscriptionId(String upgradeSubscriptionId) {
        this.upgradeSubscriptionId = upgradeSubscriptionId;
    }
    public String getUpgradeSubscriptionId() {
        return upgradeSubscriptionId;
    }
    
    public void setLastPayment(LastPayment lastPayment) {
        this.lastPayment = lastPayment;
    }
    public LastPayment getLastPayment() {
        return lastPayment;
    }
    
    public void setBillCycleDayLocal(String billCycleDayLocal) {
        this.billCycleDayLocal = billCycleDayLocal;
    }
    public String getBillCycleDayLocal() {
        return billCycleDayLocal;
    }
    
    public void setUpcoming(Upcoming upcoming) {
        this.upcoming = upcoming;
    }
    public Upcoming getUpcoming() {
        return upcoming;
    }
    
    public void setPromoEndDate(String promoEndDate) {
        this.promoEndDate = promoEndDate;
    }
    public String getPromoEndDate() {
        return promoEndDate;
    }
    
    public void setPxUdateDateTime(String pxUdateDateTime) {
        this.pxUdateDateTime = pxUdateDateTime;
    }
    public String getPxUdateDateTime() {
        return pxUdateDateTime;
    }
    
}