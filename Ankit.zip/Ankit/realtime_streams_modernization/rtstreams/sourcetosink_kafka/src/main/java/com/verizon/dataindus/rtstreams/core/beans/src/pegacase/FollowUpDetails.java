package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class FollowUpDetails implements Serializable {

   @Nullable
   @SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
   @SerializedName("category")
   String category;

   @Nullable
   @SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;
   
   @Nullable
   @SerializedName("associatedTicketType")
   String associatedTicketType;
   
   @Nullable
   @SerializedName("associatedTicketNumber")
   String associatedTicketNumber;
   
   @Nullable
   @SerializedName("offlineEndTime")
   String offlineEndTime;
   
   @Nullable
   @SerializedName("offlineTime")
   String offlineTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    public String getCategory() {
        return category;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
	public String getAssociatedTicketType() {
		return associatedTicketType;
	}
	public void setAssociatedTicketType(String associatedTicketType) {
		this.associatedTicketType = associatedTicketType;
	}
	public String getAssociatedTicketNumber() {
		return associatedTicketNumber;
	}
	public void setAssociatedTicketNumber(String associatedTicketNumber) {
		this.associatedTicketNumber = associatedTicketNumber;
	}
	public String getOfflineEndTime() {
		return offlineEndTime;
	}
	public void setOfflineEndTime(String offlineEndTime) {
		this.offlineEndTime = offlineEndTime;
	}
	public String getOfflineTime() {
		return offlineTime;
	}
	public void setOfflineTime(String offlineTime) {
		this.offlineTime = offlineTime;
	}
    
}