package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class InfoCFDType implements Serializable {


    // rstring epp, rstring fscore, rstring friction, rstring pagename;

   @SerializedName("epp")
   @Nullable
   String epp;

   @SerializedName("fscore")
   @Nullable
   String fscore;

   @SerializedName("friction")
   @Nullable
   String friction;

    @SerializedName("pagename")
    @Nullable
    String pagename;

    public String getEpp() {
        return epp;
    }

    public void setEpp(String epp) {
        this.epp = epp;
    }

    public String getFscore() {
        return fscore;
    }

    public void setFscore(String fscore) {
        this.fscore = fscore;
    }

    public String getFriction() {
        return friction;
    }

    public void setFriction(String friction) {
        this.friction = friction;
    }

    public String getPagename() {
        return pagename;
    }

    public void setPagename(String pagename) {
        this.pagename = pagename;
    }
}