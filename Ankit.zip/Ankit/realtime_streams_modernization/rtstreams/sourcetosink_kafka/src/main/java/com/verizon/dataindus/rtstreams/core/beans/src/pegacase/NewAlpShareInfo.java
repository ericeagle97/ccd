package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class NewAlpShareInfo implements Serializable {
	
	@Nullable
	@SerializedName("servicePlanId")
	String servicePlanId;
	
	@Nullable
	@SerializedName("servicePlanDesc")
	String servicePlanDesc;

	public String getServicePlanId() {
		return servicePlanId;
	}

	public void setServicePlanId(String servicePlanId) {
		this.servicePlanId = servicePlanId;
	}

	public String getServicePlanDesc() {
		return servicePlanDesc;
	}

	public void setServicePlanDesc(String servicePlanDesc) {
		this.servicePlanDesc = servicePlanDesc;
	}
	
}
