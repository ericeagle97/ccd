package com.verizon.dataindus.rtstreams.core.lib;

/** A Pardo Class extending DOfn, expects string input and yields string output, does a redis lookup
 * checks for the flag value in redis based on config parameters, on matching it sets the Main class static variable to true,
 * on Mis-match it sets the Main Class static variable to False. Yields output along with tuple tag.
 * input variables - keystorePassword, jksBytes,secretPayload, minuteInterval,timeSeconds, redisFlagValue, redisFlagKey
 Example usage:
 PCollection<String> lines = ... ;
 PCollection<String>  tableRowCollection  = lines.apply(new RedisFlagLookup(keystorePassword, jksBytes,secretPayload, minuteInterval,timeSeconds, redisFlagValue, redisFlagKey))

 Type parameters:
 <InputT> –  String - Main data
 <OutputT> – String - input data as it is **/

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka.KafkaIngestion;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;

import java.io.EOFException;
import java.io.IOException;
import java.io.Serializable;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.util.Calendar;

public class RedisFlagLookup extends DoFn<String, String> implements Serializable {
    /**
     * Variable declaration **/
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(RedisFlagLookup.class);

    /**
     * Type - Jedis, use - holds Redis connection **/
    private Jedis redisClientDoFnObject;

    /**
     * Type - String, projectId**/
    private String projectId;


    /**
     * Type - String, use - holds keystore password for redis connection**/
    private String keystorePassword;

    /**
     * Type - byte array, use - holds jks bytes for redis connection**/
    private byte[] jksBytes;

    /**
     * Type - byte string, use - holds secret payload for redis connection**/
    private ByteString secretPayload;


    /**
     * Type -  string, use - holds config data, minutes for redis flag check **/
    private int minuteInterval;

    /**
     * Type -  string, use - holds config data, seconds for redis flag check **/
    private int timeSeconds;

    /**
     * Type -  string, use - holds config data, key for redis lookup **/
    private String redisFlagKey;

    /**
     * Type -  string, use - holds config data, value for redis lookup **/
    private String redisFlagValue;

    /**
     * Type -  TupleTag, use - Tag value for gcs enablement **/

    
    /** Constructor -  Initializing Variables **/
    public RedisFlagLookup(String keystorePassword, byte[] jksBytes, ByteString secretPayload, int minuteInterval, int timeSeconds, String redisFlagValue, String redisFlagKey){
        this.keystorePassword = keystorePassword;
        this.jksBytes = jksBytes;
        this.secretPayload = secretPayload;
        this.minuteInterval = minuteInterval;
        this.redisFlagKey = redisFlagKey;
        this.redisFlagValue = redisFlagValue;
        this.timeSeconds = timeSeconds;

    }

    /**
     * Setup Method, use - to create redis connection once per worker node **/
    @Setup
    public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, EOFException
    {
        /** Intializing redis connection utility **/
        com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis= new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
        /** setting up redis connection, using redis connection utility**/
        //redisClientDoFnObject=	redis.redisConnector(projectId);
        redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword);

    }

    /**
     * process element Method, runs per record/row **/
    @ProcessElement
    public void processElement(ProcessContext c) throws ParseException, IOException, InterruptedException {
        try {
            /**
             * current timestamp **/
            Calendar now = Calendar.getInstance();
            /**
             * extracting minutes from current timestamp **/
            int minutes = now.get(Calendar.MINUTE);

            /**
             * extracting seconds from current timestamp **/
            int seconds = now.get(Calendar.SECOND);

            /**
             * Comparing current time window with config data, to check whether to set Main class static variable to true or false**/
            if (minutes % this.minuteInterval == 0 && seconds <= this.timeSeconds) {
                /**
                 * getting the current value of redis flag **/
                String getRedisValue = redisClientDoFnObject.get(this.redisFlagKey);
                LOG.info("redis flag value " + getRedisValue);
                if (this.redisFlagValue.equalsIgnoreCase(getRedisValue)) {
                    LOG.info("setting flag to true");
                    /**
                     * setting the Main class static variable to true **/
                    KafkaIngestion.flagGCS = true;
                } else {
                    /**
                     * setting the Main class static variable to false **/
                    LOG.info("setting flag to false");
                    KafkaIngestion.flagGCS = false;
                }
            }

            if (KafkaIngestion.flagGCS) {
                /**
                 * yield data with gcs output tag **/
                c.output(c.element().toString());
            }

            /**
             * yield data with cassandra output tag **/
        } catch (Exception e) {
            LOG.error("error message -- " +e.getMessage());
            LOG.error(e.getStackTrace().toString());
        }
    }
}
