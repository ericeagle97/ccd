package com.verizon.dataindus.rtstreams.core.beans.tar.spanremarks.passwordtumble;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

public class inisghtValues implements Serializable{
	
	

	@Override
	public String toString() {
		return " {" + (clientApp != null ? "clientApp:" + clientApp + ", " : "")
				+ (time != null ? "time:" + time + ", " : "") + (date != null ? "date:" + date : "") + "}";
	}

	public String getdate() {
		return date;
	}

	public void setdate(String date) {
		this.date = date;
	}
	

	public String gettime() {
		return time;
	}

	public void settime(String time) {
		this.time = time;
	}
	
	
	public String getclientApp() {
		return clientApp;
	}

	public void setclientApp(String clientApp) {
		this.clientApp = clientApp;
	}
	
	@SerializedName("clientApp")
	@Nullable
	private String clientApp;
	
	
	@SerializedName("time")
	@Nullable
	private String time;
	
	@SerializedName("date")
	@Nullable
	private String date;

}
