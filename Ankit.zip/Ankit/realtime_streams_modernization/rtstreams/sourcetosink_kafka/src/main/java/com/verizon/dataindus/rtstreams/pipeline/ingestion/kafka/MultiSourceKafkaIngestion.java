package com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka;

import com.verizon.dataindus.rtstreams.core.beans.src.reconnect.IvrCallPath;
import com.verizon.dataindus.rtstreams.core.beans.src.reconnect.TransIvrCallPredictivesPojo;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.KafkaIngestionOptions;
import com.verizon.dataindus.rtstreams.lib.readers.KafkaReader;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getKafkaIOReadConfigurations;

public class MultiSourceKafkaIngestion {
    public static boolean flagGCS = false;
    public void multiSourceKafkaIngestion(KafkaIngestionOptions options) {

        // Creates pipeline with custom pipeline options
        Pipeline pipeline = Pipeline.create(options);

            PCollection<IvrCallPath> ivrCallPath = pipeline.apply("Read from IvrCallPath", PubsubIO.readAvros(IvrCallPath.class)
                    .fromSubscription(StreamsJobRunner.options.getIvrCallPathSub()));

            PCollection<TransIvrCallPredictivesPojo> ivrCallPredectives = pipeline.apply("Read from IvrCallPredectives", PubsubIO.readAvros(TransIvrCallPredictivesPojo.class)
                    .fromSubscription(StreamsJobRunner.options.getIvrCallPredictivesSub()));


        // Creating object for custom exception class
        ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

        // Create a map of topics as keys and their respective configurations as values
        Map<String,JSONObject> kafkaTopicConfigMap = getKafkaIOReadConfigurations(
                options.getProjectId(),
                options.getKafkaIOReadConfigBucket(),
                options.getKafkaIOReadConfigFile(),
                options.getKafkaIOReadSource(),
                objCustomExceptions);

        // List of PCollections created after KafkaIO.read()
        List<PCollection<String>> listKafkaIOReadPCollections = new ArrayList<>();

        try{
            if(!kafkaTopicConfigMap.isEmpty())
                for(String kafkaTopic: options.getKafkaTopicNames().split(",")){
                    // Add all PCollections read to the list
                    List<PCollection<String>> listPCollectionsByRegion = new KafkaReader()
                            .readSource(pipeline,kafkaTopic,options.getKafkaIOReadRegions(),
                                    kafkaTopicConfigMap);

                    listKafkaIOReadPCollections.addAll(listPCollectionsByRegion);
                }
//			String sourceData = "{\"transactionType\" : \"123\",\"transactionData\":{\"customerId\" : \"7143421437\",\"accountNo\" : \"00009\",\"mtn\": \"9873161222\",\"ani\" : \"ani\",\"ivr_call_id\": \"99l4Xo1208\",\"acss_call_id\": \"5934077786\",\"router_callkey_day\": \"153495\",\"router_callkey_callid\": \"30245\",\"agent_uswin\": \"Manetrd\",\"acss_dept_id\": \"220\",\"cti_dept_nm\" : \"WYX\",\"solutions_team_ind\" : \"F\"}}";
//			PCollection<String> dataFromAllKafkaTopicRead = pipeline.apply(Create.of(sourceData));

//			 Flatten out all PCollections read
            PCollection<String> dataFromAllKafkaTopicRead =
                    PCollectionList.of(listKafkaIOReadPCollections)
                            .apply("Flatten multiple PCollections",Flatten.pCollections());



            //JsonParsing and Source Transformations with PubSub write for downstream consumptions
            MultiSourceSourceTransformLauncher processLauncher =new MultiSourceSourceTransformLauncher();
            /*Calling SourceProcessLauncher for source transformations if any class*/
            processLauncher.sourceProcessLauncher(dataFromAllKafkaTopicRead,ivrCallPath,ivrCallPredectives,options);

            pipeline.run();
        } catch (Exception e) {
            e.printStackTrace();
            objCustomExceptions.errorPipeline("KafkaIngestion", e);
        }
    }

}

