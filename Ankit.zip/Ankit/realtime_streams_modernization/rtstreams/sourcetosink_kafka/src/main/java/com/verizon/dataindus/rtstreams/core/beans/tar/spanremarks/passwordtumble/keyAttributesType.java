package com.verizon.dataindus.rtstreams.core.beans.tar.spanremarks.passwordtumble;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

public class keyAttributesType implements Serializable{
	
	
	@Override
	public String toString() {
		return " {" + (ttl != null ? "ttl:" + ttl + ", " : "")
				+ (updateTs != null ? "updateTs:" + updateTs + ", " : "")
				+ (insightCategory != null ? "insightCategory:" + insightCategory + ", " : "")
				+ (custId != null ? "custId:" + custId + ", " : "") + (mtn != null ? "mtn:" + mtn + ", " : "")
				+ (updateBy != null ? "updateBy:" + updateBy + ", " : "")
				+ (insightName != null ? "insightName:" + insightName + ", " : "")
				+ (insightValues != null ? "insightValues:" + insightValues + ", " : "")
				+ (acctNo != null ? "acctNo:" + acctNo : "") + "}";
	}

	public String getacctNo() {
		return acctNo;
	}

	public void setacctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	
	public String getinsightValues() {
		return insightValues;
	}

	public void setinsightValues(String insightValues) {
		this.insightValues = insightValues;
	}
	
	public String getinsightName() {
		return insightName;
	}

	public void setinsightName(String insightName) {
		this.insightName = insightName;
	}
	
	public String getupdateBy() {
		return updateBy;
	}

	public void setupdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	
	
	public String getmtn() {
		return mtn;
	}

	public void setmtn(String mtn) {
		this.mtn = mtn;
	}
	
	
	public String getcustId() {
		return custId;
	}

	public void setcustId(String custId) {
		this.custId = custId;
	}
	
	
	public String getinsightCategory() {
		return insightCategory;
	}

	public void setinsightCategory(String insightCategory) {
		this.insightCategory = insightCategory;
	}
	
	public String getupdateTs() {
		return updateTs;
	}

	public void setupdateTs(String updateTs) {
		this.updateTs = updateTs;
	}
	
	public String getttl() {
		return ttl;
	}

	public void setttl(String ttl) {
		this.ttl = ttl;
	}
	
	@SerializedName("ttl")
	@Nullable
	private String ttl;
	
	@SerializedName("updateTs")
	@Nullable
	private String updateTs;
	
	
	@SerializedName("insightCategory")
	@Nullable
	private String insightCategory;
	
	@SerializedName("custId")
	@Nullable
	private String custId;
	
	@SerializedName("mtn")
	@Nullable
	private String mtn;
	
	
	@SerializedName("updateBy")
	@Nullable
	private String updateBy;
	
	
	@SerializedName("insightName")
	@Nullable
	private String insightName;
	
	@SerializedName("insightValues")
	@Nullable
	private String insightValues;
	
	@SerializedName("acctNo")
	@Nullable
	private String acctNo;

	
	
	
	
}
