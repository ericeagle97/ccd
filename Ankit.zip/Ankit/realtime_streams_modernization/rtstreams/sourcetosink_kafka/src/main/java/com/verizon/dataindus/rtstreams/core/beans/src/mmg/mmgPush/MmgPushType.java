package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick.*;


@javax.annotation.Nullable
public class MmgPushType implements Serializable {
	@Nullable
	@SerializedName("transactionId")
	String transactionId;
	@Nullable
	@SerializedName("application")
	String application;
	@Nullable
	@SerializedName("client")
	String client;
	@Nullable
	@SerializedName("userId")
	String userId;
	@Nullable
	@SerializedName("deviceInstanceId")
	String deviceInstanceId;
	@Nullable
	@SerializedName("event")
	String event;
	@Nullable
	@SerializedName("status")
	String status;
	@Nullable
	@SerializedName("message")
	String message;
	@Nullable
	@SerializedName("externalUserId")
	String externalUserId;
	@Nullable
	@SerializedName("date")
	String date;
	@Nullable
	@SerializedName("template1")
	template_type template1;
	@Nullable
	@SerializedName("notificationPayload")
	NotificationPayload notificationPayload;
	@Nullable
	@SerializedName("campaign")
	campaign_type campaign;
	@Nullable
	@SerializedName("deviceInfo")
	deviceInfo_type deviceInfo;
	@Nullable
	@SerializedName("utm")
	Utm utm;
	@Nullable
	@SerializedName("data")
	Data data;
	@Nullable
	@SerializedName("messageId")
	String messageId;
	@SerializedName("linkageID")
	@Nullable
	String linkageID;

	public String getLinkageID() {
		return linkageID;
	}

	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	}

	public List<TimeDetails> getTupleTimestamp() {
		return tupleTimestamp;
	}

	public void setTupleTimestamp(List<TimeDetails> tupleTimestamp) {
		this.tupleTimestamp = tupleTimestamp;
	}

	@SerializedName("tupleTimestamp")

	@Nullable
	List<TimeDetails> tupleTimestamp;

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getApplication() {
		return application;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getClient() {
		return client;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setDeviceInstanceId(String deviceInstanceId) {
		this.deviceInstanceId = deviceInstanceId;
	}

	public String getDeviceInstanceId() {
		return deviceInstanceId;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getEvent() {
		return event;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setExternalUserId(String externalUserId) {
		this.externalUserId = externalUserId;
	}

	public String getExternalUserId() {
		return externalUserId;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDate() {
		return date;
	}

	public template_type getTemplate1() {
		return template1;
	}

	public void setTemplate1(template_type template1) {
		this.template1 = template1;
	}

	public void setNotificationPayload(NotificationPayload notificationPayload) {
		this.notificationPayload = notificationPayload;
	}

	public NotificationPayload getNotificationPayload() {
		return notificationPayload;
	}

	

	public campaign_type getCampaign() {
		return campaign;
	}

	public void setCampaign(campaign_type campaign) {
		this.campaign = campaign;
	}

	

	public deviceInfo_type getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(deviceInfo_type deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public void setUtm(Utm utm) {
		this.utm = utm;
	}

	public Utm getUtm() {
		return utm;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public Data getData() {
		return data;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getMessageId() {
		return messageId;
	}

	@Override
	public String toString() {
		return "MmgPushType [transactionId=" + transactionId + ", application=" + application + ", client=" + client
				+ ", userId=" + userId + ", deviceInstanceId=" + deviceInstanceId + ", event=" + event + ", status="
				+ status + ", message=" + message + ", externalUserId=" + externalUserId + ", date=" + date
				+ ", template1=" + template1 + ", notificationPayload=" + notificationPayload + ", campaign=" + campaign
				+ ", deviceInfo=" + deviceInfo + ", utm=" + utm + ", data=" + data + ", messageId=" + messageId
				+ ", linkageID=" + linkageID + ", tupleTimestamp=" + tupleTimestamp + "]";
	}

	

}
