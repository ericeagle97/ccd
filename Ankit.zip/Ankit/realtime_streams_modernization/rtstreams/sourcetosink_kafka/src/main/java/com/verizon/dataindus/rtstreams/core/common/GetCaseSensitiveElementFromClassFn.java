package com.verizon.dataindus.rtstreams.core.common;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.beam.sdk.transforms.DoFn;

public class GetCaseSensitiveElementFromClassFn extends DoFn<Object,String>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext processContext){
		Gson gson = new GsonBuilder().serializeNulls().create();
		try {
			String jsonString = gson.toJson(processContext.element());
			processContext.output(jsonString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			processContext.output(String.valueOf(processContext.element().toString()).toString());
			e.printStackTrace();
		}

	}
}

