package com.verizon.dataindus.rtstreams.core.constants.reconnect;

public class ReconnectConstants {
    public static final String DATA_FROM_ACSS_CTI = "data_from_acss_cti";
    public static final String DATA_FROM_IVR_CALL_PATH = "data_from_ivr_call_path";
    public static final String DATA_FROM_IVR_CALL_PREDECTIVES = "data_from_ivr_call_predectives";
    public static final String DATA_TO_CASSANDRA = "data_inserted_into_cassandra";
    public static final String LOOKUP_FAILED = "cassandra_lookup_failed";
    public static final String MAP_CLEAR_AT_EOD = "map_clear_at_eod";
    public static final String CALL_ID_NOT_IN_IVR_CALL_PATH_MAP = "call_id_not_in_callpath_map";
    public static final String CALL_ID_NOT_IN_IVR_CALL_PREDICTIVES_MAP = "call_id_not_in_callpredictives_map";
    public static final String ACSS_CTI_DATA_NOT_MATCHING = "source_acss_cti_data_not_matching";
    public static final String CALL_ID_NULL_ACCS_CTI = "deadletter_source_acss_cti";
    public static final String CALL_ID_NULL_IVR_CALL_PATH = "deadletter_ivrcallpath";
    public static final String CALL_ID_NULL_IVR_CALL_PREDICTIVES = "deadletter_ivrcallpredictives";
}
