package com.verizon.dataindus.rtstreams.core.constants.zineone;

public class ZineOneConstants {

    public static final String CASSANDRA_REQUEST_TYPE_SESSION_INSIGHTS = "SOI_SessionInsights_by_session";
    public static final String CASSANDRA_REQUEST_TYPE_CUSTOMER_INSIGHTS = "SOI_InsertCustomerInsights";
    public static final String CASSANDRA_REQUEST_TYPE_SESSION_INSIGHTS_TTL = "SOI_InsertSessionInsights_ttl";

    public static final String CHANNEL = "ZineoneStream";
    public static final String REQUEST_TYPE = "requestType";
    public static final String SESSION_Id = "sessionId";
    public static final String INSIGHT_VALUES = "insightValues";
    public static final String INSIGHT_CATEGORY = "insightCategory";
    public static final String UPDATE_BY = "updateBy";
    public static final String SCORES = "scores";

    public static final String STREAMS = "streams";
    public static final String TIME_ZONE = " GMT";
    public static final String UPDATE_TS = "updateTs";
    public static final String INSIGHT_NAME = "insightName";
    public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final String ONLY_DATE_FORMAT = "yyyy-MM-dd";
    public static final String EPP = "epp";
    public static final String TTL = "ttl";
    public static final String TTL_VALUE = "1296000";
    public static final String KEY_ATTRIBUTES = "keyAttributes";
    public static final String USER_ID = "userID";
    public static final String SESSION_ID = "sessionID";
    public static final String USECASE_ID = "usecaseID";
    public static final String VIS_HASHED_ACCOUNT_NO = "visHashedAccountNumber";
    public static final String VIS_HASED_MDN = "visHashedMdn";
    public static final Object CUSTOMER ="customer" ;
    public static final Object KEY_RING_TABLE = "keyring";
    public static final String GENERIC_SCORE = "GenericScore";
    public static final String MTN ="mtn" ;
    public static final String CUST_ID = "custId";
    public static final String ACCT_NO = "acctNo";
    public static final String SESSION_INSIGHTS = "SessionInsights";
    public static final String RESULTS = "results";
    public static final String OUTCOME = "outcome";
    public static final String CFD = "cfd";
    public static final String CFD_SCORE = "CFDScore";
    public static final String usecaseID = "usecaseID";
    public static final String outcomeEPP = "outcomeEPP";
    public static final String outcomeCFD = "outcomeCFD";

    public static final String CONFIG_KEYWORD_TRANSFORM = "ZINEONE_TRANSFORM";
    public static final String TIME_STAMP = "timeStamp";
    public static final String ZINEONE_SCORE_V1 = "ZineOne_Score_V1";
    public static final String _STREAMS = "Streams";
    public static final String VERSION = "v2";
    public static final String NA = "NA";
    public static final String CONFIG_KEYWORD_JSON_PARSING = "ZINEONE_JSON_PARSING";
    public static final String INFO = "info";
    public static final String CASS_RESPONSE_CUST_ID = "cust_id";
    public static final String CASS_RESPONSE_ACCT_NO = "acct_no";
    public static final String EPP_OUTCOMETYPE = "EPP" ;
    public static final String OTF = "OTF";
    public static final String OUTCOMETIMESTAMP = "outcomeTimeStamp";
    public static final String ACTIONTIER = "actionTier";
    public static final String PPSCORE = "ppscore";
    public static final String SCCOUNT = "scCount";
    public static final String FRICTION = "friction";
    public static final String PAGENAME = "pagename";
    public static final String FSCORE = "fscore";
    public static String SCORE = "score";
}
