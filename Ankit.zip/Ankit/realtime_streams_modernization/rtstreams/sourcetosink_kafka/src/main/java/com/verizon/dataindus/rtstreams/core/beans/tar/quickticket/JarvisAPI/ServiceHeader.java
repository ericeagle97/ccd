package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable 
public class ServiceHeader implements Serializable {

   @SerializedName("clientId")
   String clientId;

   @SerializedName("soiTransactionId")
   String soiTransactionId;

   @SerializedName("clientTransactionId")
   String clientTransactionId;

   @SerializedName("jarvisTransactionId")
   String jarvisTransactionId;

   @SerializedName("timeTaken")
   int timeTaken;

   @SerializedName("channelName")
   String channelName;


    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
    public String getClientId() {
        return clientId;
    }
    
    public void setSoiTransactionId(String soiTransactionId) {
        this.soiTransactionId = soiTransactionId;
    }
    public String getSoiTransactionId() {
        return soiTransactionId;
    }
    
    public void setClientTransactionId(String clientTransactionId) {
        this.clientTransactionId = clientTransactionId;
    }
    public String getClientTransactionId() {
        return clientTransactionId;
    }
    
    public void setJarvisTransactionId(String jarvisTransactionId) {
        this.jarvisTransactionId = jarvisTransactionId;
    }
    public String getJarvisTransactionId() {
        return jarvisTransactionId;
    }
    
    public void setTimeTaken(int timeTaken) {
        this.timeTaken = timeTaken;
    }
    public int getTimeTaken() {
        return timeTaken;
    }
    
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }
    public String getChannelName() {
        return channelName;
    }
    
}