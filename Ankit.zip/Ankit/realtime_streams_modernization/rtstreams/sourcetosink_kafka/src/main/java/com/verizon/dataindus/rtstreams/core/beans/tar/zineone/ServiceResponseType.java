package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class ServiceResponseType implements Serializable {


    // rstring insight_values;

    @SerializedName("insight_values")
    @Nullable
    String insight_values;

    public String getInsight_values() {
        return insight_values;
    }

    public void setInsight_values(String insight_values) {
        this.insight_values = insight_values;
    }
}