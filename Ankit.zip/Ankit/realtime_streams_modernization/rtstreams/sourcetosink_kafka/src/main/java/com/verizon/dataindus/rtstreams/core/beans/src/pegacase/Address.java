package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class Address implements Serializable{
	
	@Nullable
	@SerializedName("zipCode")
	String zipCode;
	
	@Nullable
	@SerializedName("streetType")
	String streetType;
	
	@Nullable
	@SerializedName("e911AddressSharingOptIn")
	String e911AddressSharingOptIn;
	
	@Nullable
	@SerializedName("streetNumber")
	String streetNumber;
	
	@Nullable
	@SerializedName("city")
	String city;
	
	@Nullable
	@SerializedName("county")
	String county;
	
	@Nullable
	@SerializedName("zipCode4")
	String zipCode4;
	
	@Nullable
	@SerializedName("fipsCode")
	String fipsCode;
	
	@Nullable
	@SerializedName("emailId")
	String emailId;
	
	@Nullable
	@SerializedName("streetName")
	String streetName;
	
	@Nullable
	@SerializedName("phoneNumber")
	String phoneNumber;
	
	@Nullable
	@SerializedName("addressLine1")
	String addressLine1;
	
	@Nullable
	@SerializedName("addressLine2")
	String addressLine2;
	
	@Nullable
	@SerializedName("state")
	String state;
	
	@Nullable
	@SerializedName("floor")
	String floor;
	
	@Nullable
	@SerializedName("firmName")
	String firmName;
	
	@Nullable
	@SerializedName("type")
	String type;
	
	@Nullable
	@SerializedName("secondaryAddress")
	String secondaryAddress;
	
	@Nullable
	@SerializedName("firstName")
	String firstName;
	
	@Nullable
	@SerializedName("lastName")
	String lastName;
	
	@Nullable
	@SerializedName("attention")
	String attention;
	
	@Nullable
	@SerializedName("streetDirection")
	String streetDirection;
	
	@Nullable
	@SerializedName("descriptorInfo")
	String descriptorInfo;
	
	@Nullable
	@SerializedName("shippingType")
	String shippingType;
	
	@Nullable
	@SerializedName("eventCorrelationId")
	String eventCorrelationId;
	
	@Nullable
	@SerializedName("apartmentNo")
	String apartmentNo;
	
	@Nullable
	@SerializedName("poBoxNo")
	String poBoxNo;
	
	@Nullable
	@SerializedName("ruralDelNo")
	String ruralDelNo;
	
	@Nullable
	@SerializedName("ruralRouteNo")
	String ruralRouteNo;
	
	@Nullable
	@SerializedName("countryCode")
	String countryCode;
	
	@Nullable
	@SerializedName("addressType")
	String addressType;
	
	@Nullable
	@SerializedName("addressIdNumber")
	String addressIdNumber;
	
	@Nullable
	@SerializedName("area")
	String area;
	
	@Nullable
	@SerializedName("buildingId")
	String buildingId;
	
	@Nullable
	@SerializedName("latitude")
	String latitude;
	
	@Nullable
	@SerializedName("longitude")
	String longitude;
	
	@Nullable
	@SerializedName("deviceId")
	String deviceId;
	
	@Nullable
	@SerializedName("preferFirstName")
	String preferFirstName;
	
	@Nullable
	@SerializedName("preferLastName")
	String preferLastName;
	
	@Nullable
	@SerializedName("preferPronoun")
	String preferPronoun;

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getStreetType() {
		return streetType;
	}

	public void setStreetType(String streetType) {
		this.streetType = streetType;
	}

	public String getE911AddressSharingOptIn() {
		return e911AddressSharingOptIn;
	}

	public void setE911AddressSharingOptIn(String e911AddressSharingOptIn) {
		this.e911AddressSharingOptIn = e911AddressSharingOptIn;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getZipCode4() {
		return zipCode4;
	}

	public void setZipCode4(String zipCode4) {
		this.zipCode4 = zipCode4;
	}

	public String getFipsCode() {
		return fipsCode;
	}

	public void setFipsCode(String fipsCode) {
		this.fipsCode = fipsCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSecondaryAddress() {
		return secondaryAddress;
	}

	public void setSecondaryAddress(String secondaryAddress) {
		this.secondaryAddress = secondaryAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAttention() {
		return attention;
	}

	public void setAttention(String attention) {
		this.attention = attention;
	}

	public String getStreetDirection() {
		return streetDirection;
	}

	public void setStreetDirection(String streetDirection) {
		this.streetDirection = streetDirection;
	}

	public String getDescriptorInfo() {
		return descriptorInfo;
	}

	public void setDescriptorInfo(String descriptorInfo) {
		this.descriptorInfo = descriptorInfo;
	}

	public String getShippingType() {
		return shippingType;
	}

	public void setShippingType(String shippingType) {
		this.shippingType = shippingType;
	}

	public String getEventCorrelationId() {
		return eventCorrelationId;
	}

	public void setEventCorrelationId(String eventCorrelationId) {
		this.eventCorrelationId = eventCorrelationId;
	}

	public String getApartmentNo() {
		return apartmentNo;
	}

	public void setApartmentNo(String apartmentNo) {
		this.apartmentNo = apartmentNo;
	}

	public String getPoBoxNo() {
		return poBoxNo;
	}

	public void setPoBoxNo(String poBoxNo) {
		this.poBoxNo = poBoxNo;
	}

	public String getRuralDelNo() {
		return ruralDelNo;
	}

	public void setRuralDelNo(String ruralDelNo) {
		this.ruralDelNo = ruralDelNo;
	}

	public String getRuralRouteNo() {
		return ruralRouteNo;
	}

	public void setRuralRouteNo(String ruralRouteNo) {
		this.ruralRouteNo = ruralRouteNo;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getAddressIdNumber() {
		return addressIdNumber;
	}

	public void setAddressIdNumber(String addressIdNumber) {
		this.addressIdNumber = addressIdNumber;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(String buildingId) {
		this.buildingId = buildingId;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getPreferFirstName() {
		return preferFirstName;
	}

	public void setPreferFirstName(String preferFirstName) {
		this.preferFirstName = preferFirstName;
	}

	public String getPreferLastName() {
		return preferLastName;
	}

	public void setPreferLastName(String preferLastName) {
		this.preferLastName = preferLastName;
	}

	public String getPreferPronoun() {
		return preferPronoun;
	}

	public void setPreferPronoun(String preferPronoun) {
		this.preferPronoun = preferPronoun;
	}

	

}
