package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class CartItems implements Serializable{
	
		@Nullable
	   @SerializedName("cartItem")
	   @JsonProperty("cartItem") 
	   List<CartItem> cartItem;

		public List<CartItem> getCartItem() {
			return cartItem;
		}

		public void setCartItem(List<CartItem> cartItem) {
			this.cartItem = cartItem;
		}
		
		

}
