package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class transactionData implements Serializable {
    @SerializedName("customerId")
    @Nullable
    String customerId;
    @SerializedName("accountNo")
    @Nullable
    String accountNo;
    @SerializedName("mtn")
    @Nullable
    String mtn;
    @SerializedName("ani")
    @Nullable
    String ani;
    @SerializedName("ivr_call_id")
    @Nullable
    String ivr_call_id;
    @SerializedName("acss_call_id")
    @Nullable
    String acss_call_id;
    @SerializedName("router_callkey_day")
    @Nullable
    String router_callkey_day;
    @SerializedName("router_callkey_callid")
    @Nullable
    String router_callkey_callid;
    @SerializedName("agent_uswin")
    @Nullable
    String agent_uswin;
    @SerializedName("acss_dept_id")
    @Nullable
    String acss_dept_id;
    @SerializedName("cti_dept_nm")
    @Nullable
    String cti_dept_nm;
    @SerializedName("solutions_team_ind")
    @Nullable
    String solutions_team_ind;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getAni() {
        return ani;
    }

    public void setAni(String ani) {
        this.ani = ani;
    }

    public String getIvr_call_id() {
        return ivr_call_id;
    }

    public void setIvr_call_id(String ivr_call_id) {
        this.ivr_call_id = ivr_call_id;
    }

    public String getAcss_call_id() {
        return acss_call_id;
    }

    public void setAcss_call_id(String acss_call_id) {
        this.acss_call_id = acss_call_id;
    }

    public String getRouter_callkey_day() {
        return router_callkey_day;
    }

    public void setRouter_callkey_day(String router_callkey_day) {
        this.router_callkey_day = router_callkey_day;
    }

    public String getRouter_callkey_callid() {
        return router_callkey_callid;
    }

    public void setRouter_callkey_callid(String router_callkey_callid) {
        this.router_callkey_callid = router_callkey_callid;
    }

    public String getAgent_uswin() {
        return agent_uswin;
    }

    public void setAgent_uswin(String agent_uswin) {
        this.agent_uswin = agent_uswin;
    }

    public String getAcss_dept_id() {
        return acss_dept_id;
    }

    public void setAcss_dept_id(String acss_dept_id) {
        this.acss_dept_id = acss_dept_id;
    }

    public String getCti_dept_nm() {
        return cti_dept_nm;
    }

    public void setCti_dept_nm(String cti_dept_nm) {
        this.cti_dept_nm = cti_dept_nm;
    }

    public String getSolutions_team_ind() {
        return solutions_team_ind;
    }

    public void setSolutions_team_ind(String solutions_team_ind) {
        this.solutions_team_ind = solutions_team_ind;
    }

    @Override
    public String toString() {
        return "transactionData{" +
                "customerId='" + customerId + '\'' +
                ", accountNo='" + accountNo + '\'' +
                ", mtn='" + mtn + '\'' +
                ", ani='" + ani + '\'' +
                ", ivr_call_id='" + ivr_call_id + '\'' +
                ", acss_call_id='" + acss_call_id + '\'' +
                ", router_callkey_day='" + router_callkey_day + '\'' +
                ", router_callkey_callid='" + router_callkey_callid + '\'' +
                ", agent_uswin='" + agent_uswin + '\'' +
                ", acss_dept_id='" + acss_dept_id + '\'' +
                ", cti_dept_nm='" + cti_dept_nm + '\'' +
                ", solutions_team_ind='" + solutions_team_ind + '\'' +
                '}';
    }
}
