package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable

public class MainType implements Serializable {

	@SerializedName("_5GCellId")
	@JsonProperty("_5GCellId")
	@JsonAlias({ "5GCellId" })
	@Nullable
	private long _5GCellId;

	@SerializedName("OS")
	@Nullable
	private String OS;

	@SerializedName("timezone")
	@Nullable
	private String timezone;

	@SerializedName("LTEcellId")
	@Nullable
	private long LTEcellId;

	@SerializedName("appVersionName")
	@Nullable
	private String appVersionName;

	@SerializedName("appVersionCode")
	@Nullable
	private long appVersionCode;

	@SerializedName("ssid")
	@Nullable
	private String ssid;

	@SerializedName("manufacturer")
	@Nullable
	private String manufacturer;

	@SerializedName("heatmapPoints")
	@Nullable
	private List<heatmapPointsType> heatmapPoints;

	@SerializedName("mdn")
	@Nullable
	private String mdn;

	@SerializedName("model")
	@Nullable
	private String model;

	@SerializedName("time")
	@Nullable
	private long time;

	@SerializedName("floor")
	@Nullable
	private String floor;

	@SerializedName("dataversion")
	@Nullable
	private long dataversion;

	@SerializedName("testName")
	@Nullable
	private String testName;

	@SerializedName("wifilinkSpeed")
	@Nullable
	private String wifilinkSpeed;



	public String getOS() {
		return OS;
	}

	public void setOS(String oS) {
		OS = oS;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public long getLTEcellId() {
		return LTEcellId;
	}

	public void setLTEcellId(long lTEcellId) {
		LTEcellId = lTEcellId;
	}

	public String getAppVersionName() {
		return appVersionName;
	}

	public void setAppVersionName(String appVersionName) {
		this.appVersionName = appVersionName;
	}

	public long getAppVersionCode() {
		return appVersionCode;
	}

	public void setAppVersionCode(long appVersionCode) {
		this.appVersionCode = appVersionCode;
	}

	public String getSsid() {
		return ssid;
	}

	public void setSsid(String ssid) {
		this.ssid = ssid;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public List<heatmapPointsType> getHeatmapPoints() {
		return heatmapPoints;
	}

	public void setHeatmapPoints(List<heatmapPointsType> heatmapPoints) {
		this.heatmapPoints = heatmapPoints;
	}

	public String getMdn() {
		return mdn;
	}

	public void setMdn(String mdn) {
		this.mdn = mdn;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public long getDataversion() {
		return dataversion;
	}

	public void setDataversion(long dataversion) {
		this.dataversion = dataversion;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getWifilinkSpeed() {
		return wifilinkSpeed;
	}

	public void setWifilinkSpeed(String wifilinkSpeed) {
		this.wifilinkSpeed = wifilinkSpeed;
	}

	public long get5GCellId() {
		return _5GCellId;
	}

	public void set5GCellId(long _5gCellId) {
		_5GCellId = _5gCellId;
	}

	@Override
	public String toString() {
		return "MainType [_5GCellId=" + _5GCellId + ", OS=" + OS + ", timezone=" + timezone + ", LTEcellId=" + LTEcellId
				+ ", appVersionName=" + appVersionName + ", appVersionCode=" + appVersionCode + ", ssid=" + ssid
				+ ", manufacturer=" + manufacturer + ", heatmapPoints=" + heatmapPoints + ", mdn=" + mdn + ", model="
				+ model + ", time=" + time + ", floor=" + floor + ", dataversion=" + dataversion + ", testName="
				+ testName + ", wifilinkSpeed=" + wifilinkSpeed + "]";
	}

	
	
	
	

}
