package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class Threat implements Serializable {
	private static final long serialVersionUID = 1L;

	@SerializedName("infectedItemName")
	@Nullable
	public String infectedItemName;
	@SerializedName("infectedItemType")
	@Nullable
	public String infectedItemType;
	@SerializedName("infectedItemPath")
	@Nullable
	public String infectedItemPath;
	@SerializedName("infectedItemAttachmentName")
	@Nullable
	public String infectedItemAttachmentName;
	@SerializedName("infectedItemPackageName")
	@Nullable
	public String infectedItemPackageName;
	@SerializedName("malwareName")
	@Nullable
	public String malwareName;
	@SerializedName("malwareVariant")
	@Nullable
	public String malwareVariant;
	@SerializedName("malwareType")
	@Nullable
	public String malwareType;
	@SerializedName("reputationRating")
	@Nullable
	public String reputationRating;

	public String getInfectedItemName() {
		return infectedItemName;
	}

	public void setInfectedItemName(String infectedItemName) {
		this.infectedItemName = infectedItemName;
	}

	public String getInfectedItemType() {
		return infectedItemType;
	}

	public void setInfectedItemType(String infectedItemType) {
		this.infectedItemType = infectedItemType;
	}

	public String getInfectedItemPath() {
		return infectedItemPath;
	}

	public void setInfectedItemPath(String infectedItemPath) {
		this.infectedItemPath = infectedItemPath;
	}

	public String getInfectedItemAttachmentName() {
		return infectedItemAttachmentName;
	}

	public void setInfectedItemAttachmentName(String infectedItemAttachmentName) {
		this.infectedItemAttachmentName = infectedItemAttachmentName;
	}

	public String getInfectedItemPackageName() {
		return infectedItemPackageName;
	}

	public void setInfectedItemPackageName(String infectedItemPackageName) {
		this.infectedItemPackageName = infectedItemPackageName;
	}

	public String getMalwareName() {
		return malwareName;
	}

	public void setMalwareName(String malwareName) {
		this.malwareName = malwareName;
	}

	public String getMalwareVariant() {
		return malwareVariant;
	}

	public void setMalwareVariant(String malwareVariant) {
		this.malwareVariant = malwareVariant;
	}

	public String getMalwareType() {
		return malwareType;
	}

	public void setMalwareType(String malwareType) {
		this.malwareType = malwareType;
	}

	public String getReputationRating() {
		return reputationRating;
	}

	public void setReputationRating(String reputationRating) {
		this.reputationRating = reputationRating;
	}

	@Override
	public String toString() {
		return "Threat [infectedItemName=" + infectedItemName + ", infectedItemType=" + infectedItemType
				+ ", infectedItemPath=" + infectedItemPath + ", infectedItemAttachmentName="
				+ infectedItemAttachmentName + ", infectedItemPackageName=" + infectedItemPackageName + ", malwareName="
				+ malwareName + ", malwareVariant=" + malwareVariant + ", malwareType=" + malwareType
				+ ", reputationRating=" + reputationRating + "]";
	}

	public Threat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Threat(String infectedItemName, String infectedItemType, String infectedItemPath,
			String infectedItemAttachmentName, String infectedItemPackageName, String malwareName,
			String malwareVariant, String malwareType, String reputationRating) {
		super();
		this.infectedItemName = infectedItemName;
		this.infectedItemType = infectedItemType;
		this.infectedItemPath = infectedItemPath;
		this.infectedItemAttachmentName = infectedItemAttachmentName;
		this.infectedItemPackageName = infectedItemPackageName;
		this.malwareName = malwareName;
		this.malwareVariant = malwareVariant;
		this.malwareType = malwareType;
		this.reputationRating = reputationRating;
	}

}
