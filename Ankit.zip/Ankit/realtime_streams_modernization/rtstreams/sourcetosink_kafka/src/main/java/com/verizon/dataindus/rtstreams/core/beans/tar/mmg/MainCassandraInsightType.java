package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class MainCassandraInsightType implements Serializable {

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public keyAttributesType1 getKeyAttributes1() {
		return keyAttributes1;
	}

	public void setKeyAttributes1(keyAttributesType1 keyAttributes1) {
		this.keyAttributes1 = keyAttributes1;
	}

	@SerializedName("requestType")
	@Nullable
	private String requestType;

	@SerializedName("keyAttributes1")
	@Nullable
	private keyAttributesType1 keyAttributes1;

}
