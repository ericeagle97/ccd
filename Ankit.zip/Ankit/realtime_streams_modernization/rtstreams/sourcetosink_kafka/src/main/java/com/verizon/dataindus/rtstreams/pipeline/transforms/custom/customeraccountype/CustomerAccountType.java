package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.customeraccountype;

import java.io.EOFException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.protobuf.ByteString;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.Setup;
import org.apache.beam.sdk.transforms.DoFn.Teardown;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.beans.src.customeraccount.CustomerAccountTypeStream;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.utils.RedisConnector;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.cat.SourceCustomerAccountType;

import redis.clients.jedis.Jedis;

public class CustomerAccountType extends DoFn<String, String>{
	
	private final Counter invalidCounter = Metrics.counter("SourceCustomerAccountType", "Input_Invaliddata");
	private final Counter validCounter = Metrics.counter("SourceCustomerAccountType", "Input_Validdata");
	private final Counter CassandraInsertionValidCounter = Metrics.counter("CassandraInsertion", "Cassandra_Valid_data");
	private final Counter CassandraInsertionInValidCounter = Metrics.counter("CassandraInsertion", "Cassandra_InValid_data");
	
	public static final TupleTag<String> deadletter = new TupleTag<String>() {
	};

	public static final TupleTag<String> Cassandradata = new TupleTag<String>() {
	};
	
	ObjectMapper objectMapper = new ObjectMapper();
	private Jedis redisClientDoFnObject;
	private String projectId;
	private Map<String, String> lookupData;

	private String keystorePassword;
	private byte[] jksBytes;
	private ByteString secretPayload;
	private boolean errorLog;
	boolean redisError = false;
	
	public CustomerAccountType(String keystorePassword, byte[] jksBytes, ByteString secretPayload, boolean errorLog) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;
		this.errorLog = errorLog;
	}

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword);

	}

	@ProcessElement
	public void processElement(ProcessContext c) throws IOException, ParseException,JSONException {

		String str = c.element();
		Gson gson = new Gson();
		
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
		objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);

		try {
			
		Map<String, Object> customerInsightsSink = new HashMap<String, Object>(); 
		Map<String, Object> keyAttributes = new HashMap<String, Object>(); 
		Map<String, Object>CCPAMObject=new HashMap<String, Object>();
		boolean customerWrite = false;	
		CustomerAccountTypeStream customerAccountString = null;

		customerAccountString = objectMapper.readValue(str, CustomerAccountTypeStream.class);
		validCounter.inc();
		
		String accNumber = customerAccountString.getAccountId();
		String cstId = customerAccountString.getCustId();
		String mtn = customerAccountString.getMtn();
		
		List<TimeDetails> timeDtlList = new LinkedList<TimeDetails>();
		TimeDetails timeDtls = new TimeDetails() ;

		timeDtls.setJobName("Customer_account_type");
		timeDtls = CommonUtility.addJobTimestamp("IN", timeDtls);		

		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		Date date1 = new Date();  
		String activitytime1 = formatter1.format(date1); 
		String updateTs = activitytime1 + " GMT"; 	
		
		keyAttributes.put(SourceCustomerAccountType.CUSTID,customerAccountString.getCustId());
		keyAttributes.put(SourceCustomerAccountType.ACCOUNTNO,customerAccountString.getAccountId());		
		keyAttributes.put(SourceCustomerAccountType.MTN,customerAccountString.getMtn());
		keyAttributes.put(SourceCustomerAccountType.INSIGHTCATEGORY, SourceCustomerAccountType.INSIGHTCATEGORYVALUE);
		keyAttributes.put(SourceCustomerAccountType.INSIGHTNAME, SourceCustomerAccountType.INSIGHTNAMEVALUE);    
		keyAttributes.put(SourceCustomerAccountType.UPDATEBY, SourceCustomerAccountType.UPDATEBYVALUE);
		keyAttributes.put(SourceCustomerAccountType.UPDATETS, updateTs);
		CCPAMObject.put(SourceCustomerAccountType.STARTTIME, updateTs);
		CCPAMObject.put(SourceCustomerAccountType.ENDTIME, SourceCustomerAccountType.ENDTIMEVALUE);
		CCPAMObject.put(SourceCustomerAccountType.CUSTOMERACCOUNTTYPE, customerAccountString.getBusinessUnit());
		keyAttributes.put(SourceCustomerAccountType.INSIGHTVALUES, new JSONObject(CCPAMObject).toString());
		//keyAttributes.put(SourceCustomerAccountType.INSIGHTVALUES, new JSONObject(CCPAMObject).toString());
		
		if ((accNumber == null || cstId == null) && mtn != null) {			
			String accountNoCustomerID = redisClientDoFnObject.get("EDW_" + customerAccountString.getMtn().toString().trim());
			if (accountNoCustomerID != null && accountNoCustomerID.contains("-")) {
				String[] accountNoCsid = accountNoCustomerID.split("-");
				keyAttributes.put(SourceCustomerAccountType.ACCOUNTNO, accountNoCsid[0]);
				keyAttributes.put(SourceCustomerAccountType.CUSTID, accountNoCsid[1]);
				customerWrite = true;
			}
		} else if(accNumber != null && cstId != null && mtn!= null
				&& accNumber.matches(Constants.REGEX_MTN) && 
				cstId.matches(Constants.REGEX_MTN) && mtn.matches(Constants.REGEX_MTN)) {
			customerWrite = true;
		}	
		if(keyAttributes.get("acctNo") != null && 
				keyAttributes.get("custId")!=null && 
				keyAttributes.get("mtn")!= null && 
				keyAttributes.get("acctNo").toString().matches(Constants.REGEX_MTN) &&
				keyAttributes.get("custId").toString().matches(Constants.REGEX_MTN) &&
				keyAttributes.get("mtn").toString().matches(Constants.REGEX_MTN) && 
				keyAttributes.get("insightCategory") != null &&
				keyAttributes.get("insightName") != null)
		{
			customerInsightsSink.put("keyAttributes",new JSONObject(keyAttributes).toString());
			CassandraInsertionValidCounter.inc();
			c.output(Cassandradata, gson.toJson(keyAttributes));
		}
		
		else
		{
			CassandraInsertionInValidCounter.inc();
			c.output(deadletter, c.element().toString());
		}
		
	}
		catch (Exception ex) {
			invalidCounter.inc();
			c.output(deadletter, c.element().toString());
			if(errorLog) {
				ex.printStackTrace(System.out);
			}
			redisError = true;
		}		
	}

	@Teardown
	public void teardown() {
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
	}
}
	
	
	
	