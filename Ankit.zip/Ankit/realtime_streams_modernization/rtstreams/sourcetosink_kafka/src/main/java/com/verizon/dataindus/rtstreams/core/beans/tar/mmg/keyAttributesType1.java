package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class keyAttributesType1 implements Serializable {

	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public String getInsightValues() {
		return insightValues;
	}

	public void setInsightValues(String insightValues) {
		this.insightValues = insightValues;
	}

	public String getInsightName() {
		return insightName;
	}

	public void setInsightName(String insightName) {
		this.insightName = insightName;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getInsightCategory() {
		return insightCategory;
	}

	public void setInsightCategory(String insightCategory) {
		this.insightCategory = insightCategory;
	}

	public String getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}

	@SerializedName("acctNo")
	@Nullable
	private String acctNo;

	@SerializedName("insightValues")
	@Nullable
	private String insightValues;

	@SerializedName("insightName")
	@Nullable
	private String insightName;

	@SerializedName("updateBy")
	@Nullable
	private String updateBy;

	@SerializedName("mtn")
	@Nullable
	private String mtn;

	@SerializedName("custId")
	@Nullable
	private String custId;

	@SerializedName("insightCategory")
	@Nullable
	private String insightCategory;

	@SerializedName("updateTs")
	@Nullable
	private String updateTs;

}
