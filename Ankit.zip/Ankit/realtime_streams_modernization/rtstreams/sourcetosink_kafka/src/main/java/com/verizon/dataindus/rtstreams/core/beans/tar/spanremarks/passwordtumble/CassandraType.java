package com.verizon.dataindus.rtstreams.core.beans.tar.spanremarks.passwordtumble;
import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

public class CassandraType implements Serializable{



	
	

	public String getKeyAttributes() {
		return keyAttributes;
	}

	public void setKeyAttributes(String keyAttributes) {
		this.keyAttributes = keyAttributes;
	}

	@Override
	public String toString() {
		return "CassandraType {" +  (keyAttributes != null ? "keyAttributes:" + keyAttributes : "") + "}";
	}

	
	
	@SerializedName("keyAttributes")
	@Nullable
	private String keyAttributes;
	
}