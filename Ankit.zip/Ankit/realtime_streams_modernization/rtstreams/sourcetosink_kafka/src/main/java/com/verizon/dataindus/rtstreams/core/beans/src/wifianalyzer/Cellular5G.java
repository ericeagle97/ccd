package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable

public class Cellular5G {

	@SerializedName("rssi")
	@Nullable
	int rssi;

	@SerializedName("ssRsrp")
	@Nullable
	int ssRsrp;

	@SerializedName("ssRsrq")
	@Nullable
	int ssRsrq;

	@SerializedName("ssSinr")
	@Nullable
	int ssSinr;

	@SerializedName("csiRsrp")
	@Nullable
	int csiRsrp;

	@SerializedName("csiRsrq")
	@Nullable
	int csiRsrq;

	@SerializedName("csiSinr")
	@Nullable
	int csiSinr;

	@SerializedName("pci")
	@Nullable
	int pci;

	@SerializedName("nci")
	@Nullable
	int nci;

	public int getRssi() {
		return rssi;
	}

	public void setRssi(int rssi) {
		this.rssi = rssi;
	}

	public int getSsRsrp() {
		return ssRsrp;
	}

	public void setSsRsrp(int ssRsrp) {
		this.ssRsrp = ssRsrp;
	}

	public int getSsRsrq() {
		return ssRsrq;
	}

	public void setSsRsrq(int ssRsrq) {
		this.ssRsrq = ssRsrq;
	}

	public int getSsSinr() {
		return ssSinr;
	}

	public void setSsSinr(int ssSinr) {
		this.ssSinr = ssSinr;
	}

	public int getCsiRsrp() {
		return csiRsrp;
	}

	public void setCsiRsrp(int csiRsrp) {
		this.csiRsrp = csiRsrp;
	}

	public int getCsiRsrq() {
		return csiRsrq;
	}

	public void setCsiRsrq(int csiRsrq) {
		this.csiRsrq = csiRsrq;
	}

	public int getCsiSinr() {
		return csiSinr;
	}

	public void setCsiSinr(int csiSinr) {
		this.csiSinr = csiSinr;
	}

	public int getPci() {
		return pci;
	}

	public void setPci(int pci) {
		this.pci = pci;
	}

	public int getNci() {
		return nci;
	}

	public void setNci(int nci) {
		this.nci = nci;
	}

	@Override
	public String toString() {
		return "Cellular5G [rssi=" + rssi + ", ssRsrp=" + ssRsrp + ", ssRsrq=" + ssRsrq + ", ssSinr=" + ssSinr
				+ ", csiRsrp=" + csiRsrp + ", csiRsrq=" + csiRsrq + ", csiSinr=" + csiSinr + ", pci=" + pci + ", nci="
				+ nci + "]";
	}

}