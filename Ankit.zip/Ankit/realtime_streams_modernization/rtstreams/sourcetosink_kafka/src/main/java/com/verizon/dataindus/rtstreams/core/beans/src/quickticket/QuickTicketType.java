package com.verizon.dataindus.rtstreams.core.beans.src.quickticket;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class QuickTicketType implements Serializable {

   @SerializedName("issue_status")
   @JsonProperty("issue_status")
   String issueStatus;

   @SerializedName("ref_number")
   @JsonProperty("ref_number")
   String refNumber;

   @SerializedName("comments")
   String comments;

   @SerializedName("operation")
   String operation;

   @SerializedName("jira_id")
   @JsonProperty("jira_id")
   String jiraId;

   @SerializedName("source")
   String source;

   @SerializedName("priority")
   String priority;

   @SerializedName("mtn")
   String mtn;

   @SerializedName("accountId")
   String accountId;

   @SerializedName("ticketRelation")
   String ticketRelation;

   @SerializedName("vzwdb_create_timestamp")
   @JsonProperty("vzwdb_create_timestamp")
   String vzwdbCreateTimestamp;

   @SerializedName("issue_desc")
   @JsonProperty("issue_desc")
   String issueDesc;

   @SerializedName("symptoms")
   String symptoms;

   @SerializedName("ord_loc_code")
   @JsonProperty("ord_loc_code")
   String ordLocCode;

   @SerializedName("child_count")
   @JsonProperty("child_count")
   String childCount;

   @SerializedName("channel_Id")
   @JsonProperty("channel_Id")
   String channelId;


    public void setIssueStatus(String issueStatus) {
        this.issueStatus = issueStatus;
    }
    public String getIssueStatus() {
        return issueStatus;
    }
    
    public void setRefNumber(String refNumber) {
        this.refNumber = refNumber;
    }
    public String getRefNumber() {
        return refNumber;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
    public String getComments() {
        return comments;
    }
    
    public void setOperation(String operation) {
        this.operation = operation;
    }
    public String getOperation() {
        return operation;
    }
    
    public void setJiraId(String jiraId) {
        this.jiraId = jiraId;
    }
    public String getJiraId() {
        return jiraId;
    }
    
    public void setSource(String source) {
        this.source = source;
    }
    public String getSource() {
        return source;
    }
    
    public void setPriority(String priority) {
        this.priority = priority;
    }
    public String getPriority() {
        return priority;
    }
    
    public void setMtn(String mtn) {
        this.mtn = mtn;
    }
    public String getMtn() {
        return mtn;
    }
    
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
    public String getAccountId() {
        return accountId;
    }
    
    public void setTicketRelation(String ticketRelation) {
        this.ticketRelation = ticketRelation;
    }
    public String getTicketRelation() {
        return ticketRelation;
    }
    
    public void setVzwdbCreateTimestamp(String vzwdbCreateTimestamp) {
        this.vzwdbCreateTimestamp = vzwdbCreateTimestamp;
    }
    public String getVzwdbCreateTimestamp() {
        return vzwdbCreateTimestamp;
    }
    
    public void setIssueDesc(String issueDesc) {
        this.issueDesc = issueDesc;
    }
    public String getIssueDesc() {
        return issueDesc;
    }
    
    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }
    public String getSymptoms() {
        return symptoms;
    }
    
    public void setOrdLocCode(String ordLocCode) {
        this.ordLocCode = ordLocCode;
    }
    public String getOrdLocCode() {
        return ordLocCode;
    }
    
    public void setChildCount(String childCount) {
        this.childCount = childCount;
    }
    public String getChildCount() {
        return childCount;
    }
    
    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }
    public String getChannelId() {
        return channelId;
    }
    
}