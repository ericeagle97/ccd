package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class Router5gHomeAlertTupleDelayStream implements Serializable {
    @SerializedName("timeDelay")
    @Nullable
    long timeDelay;

    @SerializedName("createTs")
    @Nullable
    String createTs;

    @SerializedName("createHour")
    @Nullable
    String createHour;

    public long getTimeDelay() {
        return timeDelay;
    }

    public void setTimeDelay(long timeDelay) {
        this.timeDelay = timeDelay;
    }

    @Nullable
    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(@Nullable String createTs) {
        this.createTs = createTs;
    }

    @Nullable
    public String getCreateHour() {
        return createHour;
    }

    public void setCreateHour(@Nullable String createHour) {
        this.createHour = createHour;
    }

    @Override
    public String toString() {
        return "Router5gHomeAlertTupleDelayStream{" +
                "timeDelay=" + timeDelay +
                ", createTs='" + createTs + '\'' +
                ", createHour='" + createHour + '\'' +
                '}';
    }
}
