package com.verizon.dataindus.rtstreams.core.lib;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class IVRIntentCassandraInsertion
{
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(IVRIntentCassandraInsertion.class);
	public HttpResponse<String> ivrIntentCassandraInsertion(HttpClient client, String httpURL, String strRequestBody)
	{
		HttpResponse<String> response = null;
		try
		{
		HttpRequest request = null;

		UUID uuid = UUID.randomUUID();
		Long lLsb = Math.abs(uuid.getLeastSignificantBits());
		String val = ""+"df"+lLsb;
		request = HttpRequest.newBuilder()
				.uri(URI.create(httpURL))
				.headers(Constants.HTTP_REQUEST_PROP_CONTENT_TYPE,Constants.HTTP_REQUEST_CONTENT_JSON,
						Constants.HTTP_REQUEST_PROP_CORRELATION_ID,val,
						Constants.HTTP_REQUEST_PROP_ORIGINAL_SERVICE,Constants.HTTP_REQUEST_SERVICE_WW,
						Constants.HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE,Constants.HTTP_REQUEST_SERVICE_WW)
				.POST(HttpRequest.BodyPublishers.ofString(strRequestBody))
				.build();
			//response = client.send(request,HttpResponse.BodyHandlers.ofString());
			response = client.sendAsync(request,HttpResponse.BodyHandlers.ofString()).get(Constants.HTTP_TIMEOUT, TimeUnit.MILLISECONDS);
		} 
		catch (InterruptedException e) 
		{
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				LOG.error(sw.toString());
				return null;
		}
		catch (Exception e) 
		{		
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				LOG.error(sw.toString());
				return null;
		}
		return response;
	}
}
