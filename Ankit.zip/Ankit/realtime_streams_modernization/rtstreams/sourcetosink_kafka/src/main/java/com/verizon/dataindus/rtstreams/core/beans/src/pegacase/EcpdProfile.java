package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class EcpdProfile implements Serializable{

	@Nullable
	@SerializedName("ecpdLiabilityTypeCode")
	String ecpdLiabilityTypeCode;

	@Nullable
	@SerializedName("profileId")
	String profileId;

	@Nullable
	@SerializedName("pxObjClass")
	String pxObjClass;

	@Nullable
	@SerializedName("pxUpdateDateTime")
	String pxUpdateDateTime;

	public String getEcpdLiabilityTypeCode() {
		return ecpdLiabilityTypeCode;
	}

	public void setEcpdLiabilityTypeCode(String ecpdLiabilityTypeCode) {
		this.ecpdLiabilityTypeCode = ecpdLiabilityTypeCode;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getPxObjClass() {
		return pxObjClass;
	}

	public void setPxObjClass(String pxObjClass) {
		this.pxObjClass = pxObjClass;
	}

	public String getPxUpdateDateTime() {
		return pxUpdateDateTime;
	}

	public void setPxUpdateDateTime(String pxUpdateDateTime) {
		this.pxUpdateDateTime = pxUpdateDateTime;
	}
}