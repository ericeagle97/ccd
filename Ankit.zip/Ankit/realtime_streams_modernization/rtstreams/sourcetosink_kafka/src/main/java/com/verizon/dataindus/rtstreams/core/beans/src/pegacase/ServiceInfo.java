package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


@javax.annotation.Nullable
public class ServiceInfo implements Serializable{
	
	@Nullable
	@SerializedName("primaryUserInfo")
	PrimaryUserInfo primaryUserInfo;
	
	@Nullable
	@SerializedName("selectedALPShareList")
	SelectedALPShareList selectedALPShareList;
	
	@Nullable
	@SerializedName("isSharePlanAdded")
	String isSharePlanAdded;
	
	@Nullable
	@SerializedName("newPricePlanInfo")
	NewPricePlanInfo newPricePlanInfo;

	public PrimaryUserInfo getPrimaryUserInfo() {
		return primaryUserInfo;
	}

	public void setPrimaryUserInfo(PrimaryUserInfo primaryUserInfo) {
		this.primaryUserInfo = primaryUserInfo;
	}

	public SelectedALPShareList getSelectedALPShareList() {
		return selectedALPShareList;
	}

	public void setSelectedALPShareList(SelectedALPShareList selectedALPShareList) {
		this.selectedALPShareList = selectedALPShareList;
	}

	public String getIsSharePlanAdded() {
		return isSharePlanAdded;
	}

	public void setIsSharePlanAdded(String isSharePlanAdded) {
		this.isSharePlanAdded = isSharePlanAdded;
	}

	public NewPricePlanInfo getNewPricePlanInfo() {
		return newPricePlanInfo;
	}

	public void setNewPricePlanInfo(NewPricePlanInfo newPricePlanInfo) {
		this.newPricePlanInfo = newPricePlanInfo;
	}
	
}
