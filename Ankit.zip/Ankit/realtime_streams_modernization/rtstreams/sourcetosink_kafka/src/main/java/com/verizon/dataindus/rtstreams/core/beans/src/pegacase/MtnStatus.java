package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class MtnStatus implements Serializable{
	
	@Nullable
	@SerializedName("isMtnChanged")
	String isMtnChanged;
	
	@Nullable
	@SerializedName("isTransfered")
	String isTransfered;
	
	@Nullable
	@SerializedName("mtnSuspendAllowed")
	String mtnSuspendAllowed;
	
	@Nullable
	@SerializedName("wasReactivatedInLast50Days")
	String wasReactivatedInLast50Days;
	
	@Nullable
	@SerializedName("isMtnSuspended")
	String isMtnSuspended;
	
	@Nullable
	@SerializedName("createdTimeStamp")
	String createdTimeStamp;
	
	@Nullable
	@SerializedName("activationReqDate")
	String activationReqDate;
	
	@Nullable
	@SerializedName("isSuspendedWithBilling")
	String isSuspendedWithBilling;
	
	@Nullable
	@SerializedName("isActive")
	String isActive;
	
	@Nullable
	@SerializedName("isReassignedAndInActive")
	String isReassignedAndInActive;
	
	@Nullable
	@SerializedName("isDisconnected")
	String isDisconnected;
	
	@Nullable
	@SerializedName("isSuspendedWithoutBilling")
	String isSuspendedWithoutBilling;
	
	@Nullable
	@SerializedName("involuntarySuspendedWithNonPayment")
	String involuntarySuspendedWithNonPayment;
	
	@Nullable
	@SerializedName("mtnStatusEffectiveDate")
	String mtnStatusEffectiveDate;
	
	@Nullable
	@SerializedName("isReassigned")
	String isReassigned;
	
	@Nullable
	@SerializedName("voluntarySuspended")
	String voluntarySuspended;
	
	@Nullable
	@SerializedName("involuntarySuspended")
	String involuntarySuspended;
	
	@Nullable
	@SerializedName("status")
	String status;
	
	@Nullable
	@SerializedName("mtnStatusReasonDesc")
	String mtnStatusReasonDesc;
	
	@Nullable
	@SerializedName("mtnStatusReasonCode")
	String mtnStatusReasonCode;
	
	

	public String getIsMtnChanged() {
		return isMtnChanged;
	}

	public void setIsMtnChanged(String isMtnChanged) {
		this.isMtnChanged = isMtnChanged;
	}

	public String getIsTransfered() {
		return isTransfered;
	}

	public void setIsTransfered(String isTransfered) {
		this.isTransfered = isTransfered;
	}

	public String getMtnSuspendAllowed() {
		return mtnSuspendAllowed;
	}

	public void setMtnSuspendAllowed(String mtnSuspendAllowed) {
		this.mtnSuspendAllowed = mtnSuspendAllowed;
	}

	public String getWasReactivatedInLast50Days() {
		return wasReactivatedInLast50Days;
	}

	public void setWasReactivatedInLast50Days(String wasReactivatedInLast50Days) {
		this.wasReactivatedInLast50Days = wasReactivatedInLast50Days;
	}

	public String getIsMtnSuspended() {
		return isMtnSuspended;
	}

	public void setIsMtnSuspended(String isMtnSuspended) {
		this.isMtnSuspended = isMtnSuspended;
	}

	public String getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(String createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getActivationReqDate() {
		return activationReqDate;
	}

	public void setActivationReqDate(String activationReqDate) {
		this.activationReqDate = activationReqDate;
	}

	public String getIsSuspendedWithBilling() {
		return isSuspendedWithBilling;
	}

	public void setIsSuspendedWithBilling(String isSuspendedWithBilling) {
		this.isSuspendedWithBilling = isSuspendedWithBilling;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsReassignedAndInActive() {
		return isReassignedAndInActive;
	}

	public void setIsReassignedAndInActive(String isReassignedAndInActive) {
		this.isReassignedAndInActive = isReassignedAndInActive;
	}

	public String getIsDisconnected() {
		return isDisconnected;
	}

	public void setIsDisconnected(String isDisconnected) {
		this.isDisconnected = isDisconnected;
	}

	public String getIsSuspendedWithoutBilling() {
		return isSuspendedWithoutBilling;
	}

	public void setIsSuspendedWithoutBilling(String isSuspendedWithoutBilling) {
		this.isSuspendedWithoutBilling = isSuspendedWithoutBilling;
	}

	public String getInvoluntarySuspendedWithNonPayment() {
		return involuntarySuspendedWithNonPayment;
	}

	public void setInvoluntarySuspendedWithNonPayment(String involuntarySuspendedWithNonPayment) {
		this.involuntarySuspendedWithNonPayment = involuntarySuspendedWithNonPayment;
	}

	public String getMtnStatusEffectiveDate() {
		return mtnStatusEffectiveDate;
	}

	public void setMtnStatusEffectiveDate(String mtnStatusEffectiveDate) {
		this.mtnStatusEffectiveDate = mtnStatusEffectiveDate;
	}

	public String getIsReassigned() {
		return isReassigned;
	}

	public void setIsReassigned(String isReassigned) {
		this.isReassigned = isReassigned;
	}

	public String getVoluntarySuspended() {
		return voluntarySuspended;
	}

	public void setVoluntarySuspended(String voluntarySuspended) {
		this.voluntarySuspended = voluntarySuspended;
	}

	public String getInvoluntarySuspended() {
		return involuntarySuspended;
	}

	public void setInvoluntarySuspended(String involuntarySuspended) {
		this.involuntarySuspended = involuntarySuspended;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMtnStatusReasonDesc() {
		return mtnStatusReasonDesc;
	}

	public void setMtnStatusReasonDesc(String mtnStatusReasonDesc) {
		this.mtnStatusReasonDesc = mtnStatusReasonDesc;
	}

	public String getMtnStatusReasonCode() {
		return mtnStatusReasonCode;
	}

	public void setMtnStatusReasonCode(String mtnStatusReasonCode) {
		this.mtnStatusReasonCode = mtnStatusReasonCode;
	}
		
	
}