package com.verizon.dataindus.rtstreams.jobDriver;

import com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka.MultiSourceKafkaIngestion;
import com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka.MultiTopicKafkaIngestion;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.pipeline.ingestion.kafka.KafkaIngestion;

public class StreamsJobRunner {
	public static KafkaIngestionOptions options;

	/*
	 * Interface to add custom pipeline options to pipeline
	 */
	public static interface KafkaIngestionOptions extends PipelineOptions {
		// Get GCP Project ID
		@Description("GCP Project ID")
		@Validation.Required
		@Default.String("vz-it-np-gh2v-test-rtstdo-0")
		String getProjectId();

		void setProjectId(String projectId);

		// Get KafkaIO read config bucket
		@Description("KafkaIO read config bucket")
		@Validation.Required
		@Default.String("vz-it-np-gh2v-test-rtstdo-0-devlopment_dataflow_rts")
		String getKafkaIOReadConfigBucket();

		void setKafkaIOReadConfigBucket(String kafkaIOReadConfigBucket);

		// Get KafkaIO read config file
		@Description("KafkaIO read config file")
		@Validation.Required
		@Default.String("DataflowSources/tpir/tpir_configuration.json")
		String getKafkaIOReadConfigFile();

		void setKafkaIOReadConfigFile(String kafkaIOReadConfigFile);

		// Get regions
		@Description("KafkaIO Read regions (comma-separated)")
		@Validation.Required
		@Default.String("east")
		String getKafkaIOReadRegions();

		void setKafkaIOReadRegions(String kafkaIOReadRegions);

		// Get regions
		@Description("KafkaIO Read source (source job name)")
		@Validation.Required
		@Default.String("Source-Tpir")
		String getKafkaIOReadSource();

		void setKafkaIOReadSource(String kafkaIOReadSource);

		/*
		 * Kafka topic to read messages
		 */
		@Description("Input Kafka Topic Names (comma-separated)")
		@Validation.Required
		@Default.String("soi_touchpoint,soi_rts_tpir")
		String getKafkaTopicNames();

		void setKafkaTopicNames(String kafkaTopicNames);

		@Description("Output PubSub topic to publish messages")
		@Validation.Required
		@Default.String("projects/vz-it-np-gh2v-test-rtstdo-0/topics/tp-cee-kafka-tpir")
		String getPubSubTopic();

		void setPubSubTopic(String pubSubTopic);

		@Description("Enable or Disable custom Logging and exceptions")
		@Validation.Required
		@Default.Boolean(true)
		boolean getErrorLog();

		void setErrorLog(boolean errorLog);

		// Parameters below are used only for writing dead letter records
		@Description("Number of shards for each windowing function ")
		@Default.Integer(1)
		// @Validation.Required
		int getNumShards();

		void setNumShards(int value);

		@Description("Dead Letter Output can be \"GCS\" or \"PubSub\" ")
		@Default.String("GCS")
		// @Validation.Required
		String getDeadLetterSink();

		void setDeadLetterSink(String value);

		@Description("Gcs path to store the data into runtime path")
		@Default.String("gs://vz-it-np-gh2v-test-rtstdo-0-devlopment_dataflow_rts/DataflowSources/tpir")
		// @Validation.Required
		String getPath();

		void setPath(String value);

		@Description("WindowDuration in Seconds")
		@Default.Integer(30)
		// @Validation.Required
		int getWindowDuration();

		void setWindowDuration(int value);

		@Description("FileName")
		@Default.String("source_tpir")
		// @Validation.Required
		String getFileName();

		void setFileName(String value);

		@Description("GCS Bucket Name")
		@Default.String("vz-it-pr-gh2v-rtstdo-0-prod_dataflow_rts_test")
		String getGcsBucket();

		void setGcsBucket(String value);

		@Description("DVS API for Unhashing MTNs")
		String getDvsApiUrl();

		void setDvsApiUrl(String value);

		@Description("Keyring API for GlobalID Lookup")
		String getKeyringApiUrl();

		void setKeyringApiUrl(String value);

		@Description("Mapping Files Name if any")
		// @Validation.Required
		String getMappingFileName();

		void setMappingFileName(String value);

		@Description("KafkaIO read config file")
		@Default.String("DataflowSources/port_configuration.json")
		String getKafkaIOReadTargetConfigFile();

		void setKafkaIOReadTargetConfigFile(String kafkaIOReadTargetConfigFile);

		@Description("HttpRequest")
		@Default.String("https://mcscmpt1-pnosoi.ebiz.verizon.com/PNO/request")
		// @Validation.Required
		String getHttpRequest();

		void setHttpRequest(String value);

		@Description("CassandraUrl")
		// @Validation.Required
		String getCassandraUrl();

		void setCassandraUrl(String value);

		@Description("CassandraRequestType")
		// @Validation.Required
		String getCassandraRequestType();

		void setCassandraRequestType(String value);

		@Description("MemoryStore Keystore File")
		String getKeystoreFile();

		void setKeystoreFile(String value);

		@Description("MemoryStore Keystore Password")
		String getKeystorePassword();

		void setKeystorePassword(String value);

		@Description("MemoryStore GCP Secrets")
		String getSecretCredentials();

		void setSecretCredentials(String value);

		@Description("Cassandra Insertion URL")
		@Validation.Required
		@Default.String("https://mcscmpt2-pnosoi.ebiz.verizon.com/PNO/request")
		String getHttpUrl();

		void setHttpUrl(String httpUrl);

		@Description("Flag for Multiple Kafka Topic Read")
		@Default.Boolean(false)
		boolean getFlagMultiKafkaTopicRead();

		void setFlagMultiKafkaTopicRead(boolean flagMultiKafkaTopicRead);

		@Description("Jarvis API for Model")
		@Default.String("https://oa-uat.ebiz.verizon.com/jarvis/")
		String getJarvisUrl();

		void setJarvisUrl(String value);

		@Description("Jarvis Token")
		@Default.String("tHg4R3CFo74nGbAjHONOgPg2iHZS2L96")
		String getJarvisApiKey();

		void setJarvisApiKey(String value);

		@Description("pnoRequestURL")
		@Default.String("https://mcscmpt1-pnosoi.ebiz.verizon.com/PNO/request")
		// @Validation.Required
		String getPnoRequestURL();

		void setPnoRequestURL(String value);

		@Description("pnoRequestBulkURL")
		@Default.String("https://mcscmpt3-pnosoi.ebiz.verizon.com/PNO/v2/requestList")
		// @Validation.Required
		String getPnoRequestBulkURL();

		void setPnoRequestBulkURL(String value);

		@Description("minutes for redis flag check")
		int getMinuteIntervalRedisFlagCheck();

		void setMinuteIntervalRedisFlagCheck(int value);

		@Description("seconds for redis flag check")
		int getTimeSecondsRedisFlagCheck();

		void setTimeSecondsRedisFlagCheck(int value);

		@Description("value for redis lookup")
		String getRedisFlagValue();

		void setRedisFlagValue(String value);

		@Description("key for redis lookup")
		String getRedisFlagKey();

		void setRedisFlagKey(String value);

		@Description("sink for parallel writes")
		String getGcsOrPubsubParallelWrite();

		void setGcsOrPubsubParallelWrite(String value);

		@Description("Output pubsub topic for cassandra insertion")
		@Default.String("projects/vz-it-np-gh2v-test-rtstdo-0/topics/tp-cee-kafka-remarks-cassandra-insert")
		String getOutputPubsubTopic();

		void setOutputPubsubTopic(String value);

		@Description("State clear min")
		@Default.Integer(30)
		int getStateClearMin();

		void setStateClearMin(int value);

		@Description("State delay")
		@Default.Integer(1)
		int getStateDelay();

		void setStateDelay(int value);

		// Parameter to enable pubsub write for prod parallel run
		@Description("Parameter to enable pubsub write for prod parallel run")
		@Default.Boolean(false)
		boolean getPubsubParallelWrite();

		void setPubsubParallelWrite(boolean pubsubParallelWrite);
		@Description("Flag for Multiple Kafka Topic Read")
		@Default.Boolean(false)
		boolean getFlagReadFromPubsub();
		void setFlagReadFromPubsub(boolean flagReadFromPubsub);

		@Description("Read from Pubsub for IvrCallPath in reconnect")
		@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/subscriptions/ivrcallpath-reconnect-sub")
		String getIvrCallPathSub();
		void setIvrCallPathSub(String value);
		@Description("Read from IvrCallPredictives in Reconnect")
		@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/subscriptions/ivrcallpredictives-reconnect-sub")
		String getIvrCallPredictivesSub();
		void setIvrCallPredictivesSub(String value);

		@Description("Deployment Mode for alternate kafka topic in non prod- test")
		@Default.String("prod")
		String getDeploymentMode();
		void setDeploymentMode(String deploymentMode);

		@Description("Event timestamp key for calculating source delay")
		String getEventTimestampKey();
		void setEventTimestampKey(String eventTimestampKey);

		@Description("Event timestamp input format")
		String getEventTimestampFormat();
		void setEventTimestampFormat(String eventTimestampFormat);

		@Description("check to see if input data is xml")
		@Default.Boolean(false)
		boolean getXmlData();
		void setXmlData(boolean value);

		@Description("write data to layer1/VMG in MTAS_CALL_FILTER")
		@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/topics/tp-cee-kafka-e2e-digital-secure")
		String getDigitalSecurePubsubTopic();
		void setDigitalSecurePubsubTopic(String value);

	}

	/*
	 * Main method gets arguments as custom pipeline options and triggers
	 * KafkaSource template
	 */
	public static void main(String args[]) {
		/* Creating object for custom exception class */
		ExceptionsUtils objCustomExceptions = new ExceptionsUtils();
		try {
			options = PipelineOptionsFactory.fromArgs(args).withValidation().as(KafkaIngestionOptions.class);
			ExceptionsUtils.pubsubParallelWrite = options.getPubsubParallelWrite();

			objCustomExceptions.errorLog = options.getErrorLog();
			if(options.getFlagReadFromPubsub()==true){
				MultiSourceKafkaIngestion kafka = new MultiSourceKafkaIngestion();
				kafka.multiSourceKafkaIngestion(options);
			}
			else if (options.getFlagMultiKafkaTopicRead()==true){
				MultiTopicKafkaIngestion kafka= new MultiTopicKafkaIngestion();
				kafka.multiTopicKafkaIngestion(options);
			}
			else {
				KafkaIngestion kafka= new KafkaIngestion();
				kafka.kafkaIngestion(options);
			}

		} catch (Exception e) {
			e.printStackTrace();
			objCustomExceptions.errorPipeline("StreamsJobRunner", e);
		}
	}
}
