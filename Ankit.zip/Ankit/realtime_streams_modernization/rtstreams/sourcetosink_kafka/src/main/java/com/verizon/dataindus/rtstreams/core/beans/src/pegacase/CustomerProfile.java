package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class CustomerProfile implements Serializable{
	
	@Nullable
	@SerializedName("customerAttributes")
	CustomerAttributes customerAttributes;
		
	@Nullable
	@SerializedName("customerId")
	String customerId;
	
	@Nullable
	@SerializedName("billAccounts")
	List<BillAccounts> billAccounts;
	
	@Nullable
	@SerializedName("customerName")
	CustomerName customerName;

	public CustomerAttributes getCustomerAttributes() {
		return customerAttributes;
	}

	public void setCustomerAttributes(CustomerAttributes customerAttributes) {
		this.customerAttributes = customerAttributes;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<BillAccounts> getBillAccounts() {
		return billAccounts;
	}

	public void setBillAccounts(List<BillAccounts> billAccounts) {
		this.billAccounts = billAccounts;
	}

	public CustomerName getCustomerName() {
		return customerName;
	}

	public void setCustomerName(CustomerName customerName) {
		this.customerName = customerName;
	}
	
	
}