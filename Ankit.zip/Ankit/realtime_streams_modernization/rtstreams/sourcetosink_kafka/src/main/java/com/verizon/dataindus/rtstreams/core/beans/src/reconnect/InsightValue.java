package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

@javax.annotation.Nullable
public class InsightValue {


}