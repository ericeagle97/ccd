package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;
import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;

   
public class RtModel implements Serializable {

   @SerializedName("rtModelReq")
   List<RtModelReq> rtModelReq;


    public void setRtModelReq(List<RtModelReq> rtModelReq) {
        this.rtModelReq = rtModelReq;
    }
    public List<RtModelReq> getRtModelReq() {
        return rtModelReq;
    }
    
}