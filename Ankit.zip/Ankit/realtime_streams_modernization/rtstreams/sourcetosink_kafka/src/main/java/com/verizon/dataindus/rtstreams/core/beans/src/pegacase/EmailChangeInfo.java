package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import java.io.Serializable;
import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

@javax.annotation.Nullable
public class EmailChangeInfo implements Serializable
{

	@Nullable
	@SerializedName("emailAddress")
	String emailAddress;

	@Nullable
	@SerializedName("phoneNumber")
	String phoneNumber;

	@Nullable
	@SerializedName("levelType")
	String levelType;

	public String getEmailAddress() 
	{
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	public String getPhoneNumber() 
	{
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}

	public String getLevelType() 
	{
		return levelType;
	}

	public void setLevelType(String levelType) 
	{
		this.levelType = levelType;
	}



}
