package com.verizon.dataindus.rtstreams.core.beans.tar.port;

import java.io.Serializable;

public class aepservice_convert_type implements Serializable{
	
	public String getLastQualificationTime() {
		return lastQualificationTime;
	}
	public void setLastQualificationTime(String lastQualificationTime) {
		this.lastQualificationTime = lastQualificationTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMtn() {
		return mtn;
	}
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	private String lastQualificationTime;
	private String  status;
	private String  mtn;
	private String  name;

}
