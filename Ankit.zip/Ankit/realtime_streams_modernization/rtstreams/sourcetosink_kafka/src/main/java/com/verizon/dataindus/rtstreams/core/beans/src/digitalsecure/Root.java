package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class Root implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@SerializedName("headers")
	@Nullable
	public Headers headers;
	@SerializedName("customerId")
	@Nullable
	public String customerId;
	@SerializedName("mtn")
	@Nullable
	public String mtn;
	@SerializedName("data")
	@Nullable
	public Data data;
	@SerializedName("deviceOS")
	@Nullable
	public String deviceOS;

	public Headers getHeaders() {
		return headers;
	}

	public void setHeaders(Headers headers) {
		this.headers = headers;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public String getDeviceOS() {
		return deviceOS;
	}

	public void setDeviceOS(String deviceOS) {
		this.deviceOS = deviceOS;
	}

	@Override
	public String toString() {
		return "Root [headers=" + headers + ", customerId=" + customerId + ", mtn=" + mtn + ", data=" + data
				+ ", deviceOS=" + deviceOS + "]";
	}

}
