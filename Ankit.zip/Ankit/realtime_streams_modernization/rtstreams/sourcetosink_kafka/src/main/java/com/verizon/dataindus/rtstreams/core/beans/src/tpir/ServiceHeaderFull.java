package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@XmlRootElement(name = "serviceHeader")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class ServiceHeaderFull implements Serializable {
	
	@SerializedName("subserviceName")
    @Nullable
    @XmlElement(name = "subserviceName")
    public String subserviceName;
	
	@SerializedName("clientName")
    @Nullable
    @XmlElement(name = "clientName")
	public String clientName;
	
	@SerializedName("requestID")
    @Nullable
    @XmlElement(name = "requestID")
	public String requestID;
	
	@SerializedName("serviceName")
    @Nullable
    @XmlElement(name = "serviceName")
	public String serviceName;
	
	@SerializedName("generatedID")
    @Nullable
    @XmlElement(name = "generatedID")
	public String generatedID;
	
    public String getsubserviceName() {
        return subserviceName;
    }
    public void setsubserviceName(String subserviceName) {
        this.subserviceName = subserviceName;
    }
    public String getclientName() {
        return clientName;
    }
    public void setclientName(String clientName) {
        this.clientName = clientName;
    }
    public String getrequestID() {
        return requestID;
    }
    public void setrequestID(String requestID) {
        this.requestID = requestID;
    }
    public String getserviceName() {
        return serviceName;
    }
    public void setserviceName(String serviceName) {
        this.serviceName = serviceName;
    }
    
    public String getgeneratedID() {
        return generatedID;
    }
    public void setgeneratedID(String generatedID) {
        this.generatedID = generatedID;
    }
    
    @Override
    public String toString() {
        return "serviceHeader [subserviceName = " + subserviceName + " , clientName = " + clientName + " , requestID = " + requestID + " , serviceName = " + serviceName + ", generatedID = " + generatedID + "]";

    }
}
