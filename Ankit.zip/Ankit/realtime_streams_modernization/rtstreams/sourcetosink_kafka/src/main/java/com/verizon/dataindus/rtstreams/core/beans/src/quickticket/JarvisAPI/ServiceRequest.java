package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class ServiceRequest implements Serializable {

	   @SerializedName("rtModel")
	   RtModel rtModel;
	
	
	    public void setRtModel(RtModel rtModel) {
	        this.rtModel = rtModel;
	    }
	    public RtModel getRtModel() {
	        return rtModel;
	    }
	    
}