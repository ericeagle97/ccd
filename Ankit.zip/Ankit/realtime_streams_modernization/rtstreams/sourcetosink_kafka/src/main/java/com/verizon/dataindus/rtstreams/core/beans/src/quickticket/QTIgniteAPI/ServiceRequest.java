package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.QTIgniteAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class ServiceRequest implements Serializable {

	@SerializedName("refNumber")
	   String refNumber;

	   @SerializedName("status")
	   String status;

	   @SerializedName("source")
	   String source;

	   @SerializedName("type")
	   String type;

	   @SerializedName("createSourceDate")
	   String createSourceDate;

	   @SerializedName("features")
	   Features features;

	   @SerializedName("createdBy")
	   String createdBy;

	   @SerializedName("updatedBy")
	   String updatedBy;


	    public void setRefNumber(String refNumber) {
	        this.refNumber = refNumber;
	    }
	    public String getRefNumber() {
	        return refNumber;
	    }
	    
	    public void setStatus(String status) {
	        this.status = status;
	    }
	    public String getStatus() {
	        return status;
	    }
	    
	    public void setSource(String source) {
	        this.source = source;
	    }
	    public String getSource() {
	        return source;
	    }
	    
	    public void setType(String type) {
	        this.type = type;
	    }
	    public String getType() {
	        return type;
	    }
	    
	    public void setCreateSourceDate(String createSourceDate) {
	        this.createSourceDate = createSourceDate;
	    }
	    public String getCreateSourceDate() {
	        return createSourceDate;
	    }
	    
	    public void setFeatures(Features features) {
	        this.features = features;
	    }
	    public Features getFeatures() {
	        return features;
	    }
	    
	    public void setCreatedBy(String createdBy) {
	        this.createdBy = createdBy;
	    }
	    public String getCreatedBy() {
	        return createdBy;
	    }
	    
	    public void setUpdatedBy(String updatedBy) {
	        this.updatedBy = updatedBy;
	    }
	    public String getUpdatedBy() {
	        return updatedBy;
	    }
	    
}