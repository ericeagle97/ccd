package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class IgnoredWifiAlertsByDay implements Serializable {
	private static final long serialVersionUID = 1L;
	@SerializedName("date")
	@Nullable
	public String date;
	@SerializedName("count")
	@Nullable
	public String count;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "IgnoredWifiAlertsByDay [date=" + date + ", count=" + count + "]";
	}

	public IgnoredWifiAlertsByDay(String date, String count) {
		super();
		this.date = date;
		this.count = count;
	}

	public IgnoredWifiAlertsByDay() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
