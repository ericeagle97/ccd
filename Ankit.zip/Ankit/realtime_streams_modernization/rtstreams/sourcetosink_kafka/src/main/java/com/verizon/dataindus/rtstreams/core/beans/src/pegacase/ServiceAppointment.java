package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class ServiceAppointment implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("ServiceDate")
   @JsonProperty("ServiceDate")
   String ServiceDate;

   @Nullable
	@SerializedName("slotEndTime")
   String slotEndTime;

   @Nullable
	@SerializedName("ServiceJobID")
   @JsonProperty("ServiceJobID")
   String ServiceJobID;

   @Nullable
	@SerializedName("rescheduleCode")
   String rescheduleCode;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;

   @Nullable
	@SerializedName("slotStartTime")
   String slotStartTime;

   @Nullable
	@SerializedName("rescheduleDescription")
   String rescheduleDescription;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setServiceDate(String ServiceDate) {
        this.ServiceDate = ServiceDate;
    }
    public String getServiceDate() {
        return ServiceDate;
    }
    
    public void setSlotEndTime(String slotEndTime) {
        this.slotEndTime = slotEndTime;
    }
    public String getSlotEndTime() {
        return slotEndTime;
    }
    
    public void setServiceJobID(String ServiceJobID) {
        this.ServiceJobID = ServiceJobID;
    }
    public String getServiceJobID() {
        return ServiceJobID;
    }
    
    public void setRescheduleCode(String rescheduleCode) {
        this.rescheduleCode = rescheduleCode;
    }
    public String getRescheduleCode() {
        return rescheduleCode;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
    public void setSlotStartTime(String slotStartTime) {
        this.slotStartTime = slotStartTime;
    }
    public String getSlotStartTime() {
        return slotStartTime;
    }
    
    public void setRescheduleDescription(String rescheduleDescription) {
        this.rescheduleDescription = rescheduleDescription;
    }
    public String getRescheduleDescription() {
        return rescheduleDescription;
    }
    
}