package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class OutcomeCFDType implements Serializable {


    // rstring actionTier, rstring ppscore, rstring outcomeTimeStamp, rstring scCount, infoCFDType info;

   @SerializedName("actionTier")
   @Nullable
   String actionTier;

   @SerializedName("ppscore")
   @Nullable
   String ppscore;

   @SerializedName("outcomeTimeStamp")
   @Nullable
   String outcomeTimeStamp;

    @SerializedName("scCount")
    @Nullable
    String scCount;

    @SerializedName("info")
    @Nullable
    InfoCFDType info;

    public String getActionTier() {
        return actionTier;
    }

    public void setActionTier(String actionTier) {
        this.actionTier = actionTier;
    }

    public String getPpscore() {
        return ppscore;
    }

    public void setPpscore(String ppscore) {
        this.ppscore = ppscore;
    }

    public String getOutcomeTimeStamp() {
        return outcomeTimeStamp;
    }

    public void setOutcomeTimeStamp(String outcomeTimeStamp) {
        this.outcomeTimeStamp = outcomeTimeStamp;
    }

    public String getScCount() {
        return scCount;
    }

    public void setScCount(String scCount) {
        this.scCount = scCount;
    }

    public InfoCFDType getInfo() {
        return info;
    }

    public void setInfo(InfoCFDType info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "OutcomeCFDType{" +
                "actionTier='" + actionTier + '\'' +
                ", ppscore='" + ppscore + '\'' +
                ", outcomeTimeStamp='" + outcomeTimeStamp + '\'' +
                ", scCount='" + scCount + '\'' +
                ", info=" + info +
                '}';
    }
}