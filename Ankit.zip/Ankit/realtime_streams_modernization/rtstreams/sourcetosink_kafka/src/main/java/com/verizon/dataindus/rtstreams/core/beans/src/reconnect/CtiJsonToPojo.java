package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class CtiJsonToPojo implements Serializable {
    @SerializedName("transactionType")
    @Nullable
    String transactionType;
    @SerializedName("transactionData")
    @Nullable
    transactionData transactionData;

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public com.verizon.dataindus.rtstreams.core.beans.src.reconnect.transactionData getTransactionData() {
        return transactionData;
    }

    public void setTransactionData(com.verizon.dataindus.rtstreams.core.beans.src.reconnect.transactionData transactionData) {
        this.transactionData = transactionData;
    }

    @Override
    public String toString() {
        return "CtiJsonToPojo{" +
                "transactionType='" + transactionType + '\'' +
                ", transactionData=" + transactionData +
                '}';
    }
}
