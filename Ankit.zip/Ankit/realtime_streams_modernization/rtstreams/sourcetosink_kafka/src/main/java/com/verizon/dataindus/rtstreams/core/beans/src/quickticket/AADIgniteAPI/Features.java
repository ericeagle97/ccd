package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.AADIgniteAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class Features implements Serializable {

	@SerializedName("comments")
	   String comments;

	   @SerializedName("searchTerm")
	   String searchTerm;

	   @SerializedName("ratingcount")
	   String ratingcount;

	   @SerializedName("ticket")
	   String ticket;


	    public void setComments(String comments) {
	        this.comments = comments;
	    }
	    public String getComments() {
	        return comments;
	    }
	    
	    public void setSearchTerm(String searchTerm) {
	        this.searchTerm = searchTerm;
	    }
	    public String getSearchTerm() {
	        return searchTerm;
	    }
	    
	    public void setRatingcount(String ratingcount) {
	        this.ratingcount = ratingcount;
	    }
	    public String getRatingcount() {
	        return ratingcount;
	    }
	    
	    public void setTicket(String ticket) {
	        this.ticket = ticket;
	    }
	    public String getTicket() {
	        return ticket;
	    }
	    
	}