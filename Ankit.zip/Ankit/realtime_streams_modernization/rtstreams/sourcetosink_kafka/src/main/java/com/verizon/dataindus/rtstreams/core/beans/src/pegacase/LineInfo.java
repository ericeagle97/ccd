package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class LineInfo implements Serializable{
	
	@Nullable
	@SerializedName("isISPUOrder")
	String isISPUOrder;
	
	@Nullable
	@SerializedName("giftIndicator")
	String giftIndicator;

	@Nullable
	@SerializedName("mtn")
	String mtn;
	
	@Nullable
	@SerializedName("lineActivityType")
	String lineActivityType;
	
	public String getIsISPUOrder() {
		return isISPUOrder;
	}

	public void setIsISPUOrder(String isISPUOrder) {
		this.isISPUOrder = isISPUOrder;
	}

	public String getGiftIndicator() {
		return giftIndicator;
	}

	public void setGiftIndicator(String giftIndicator) {
		this.giftIndicator = giftIndicator;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getLineActivityType() {
		return lineActivityType;
	}

	public void setLineActivityType(String lineActivityType) {
		this.lineActivityType = lineActivityType;
	}

	
	
}