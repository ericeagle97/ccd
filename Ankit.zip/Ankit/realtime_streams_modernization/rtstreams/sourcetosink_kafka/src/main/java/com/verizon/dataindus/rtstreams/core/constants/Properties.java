package com.verizon.dataindus.rtstreams.core.constants;

import java.util.EnumMap;

public class Properties 
{


	/*Creating enums for different modules to and assigining enums*/
	public enum className{
		STREAMSJOBLAUNCHER, STREAMSJOBRUNNER, ACCESSSECRETVERSION, KAFKAREADER, CONSUMERFACTORY, COMMONUTILITY,SOURCETRANSFORMATION};

		/*Creating EnumMap for each module */
		public static  EnumMap<className,String> ClassName = new EnumMap<className,String>(className.class);

		public void properties() 
		{
			/* Assigining custom string to Class module which store all class names inside this project*/
			ClassName.put(className.STREAMSJOBLAUNCHER, "JobLauncher");
			ClassName.put(className.STREAMSJOBRUNNER, "Runner");
			ClassName.put(className.ACCESSSECRETVERSION, "AccessSecretVersion");
			ClassName.put(className.KAFKAREADER, "KafkaReader");
			ClassName.put(className.CONSUMERFACTORY, "ConsumerFactoryFn");
			ClassName.put(className.COMMONUTILITY, "CommonUtility");
			ClassName.put(className.SOURCETRANSFORMATION, "SourceTransformation");
		}

		public static final String CLASS_STREAMSJOBLAUNCHER= "JobLauncher";
		public static final String CLASS_STREAMSJOBRUNNER= "Runner";
		public static final String CLASS_ACCESSSECRETVERSION= "AccessSecretVersion";
		public static final String CLASS_KAFKAREADER= "KafkaReader";
		public static final String CLASS_CONSUMERFACTORY= "ConsumerFactoryFn";
		public static final String CLASS_KAFKAREADJKS= "KafkaReadJKS";
		public static final String CLASS_KAFKAWRITEJKS= "KafkaWriteJKS";
		public static final String CLASS_COMMONUTILITY= "CommonUtility";
		public static final String CLASS_SOURCETRANSFORMATION= "SourceTransformation";

		
}
