package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;

import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

public class Messages implements Serializable{
	
	@Override
	public String toString() {
		return "Messages [Verizon=" + Verizon + ", identityMap=" + identityMap + ", segmentMembership="
				+ segmentMembership + "]";
	}
	@Nullable
	@SerializedName("_verizon")
	@JsonAlias("_verizon")
	@JsonProperty("_verizon")
	Verizon Verizon;

	@Nullable
	@JsonAlias("identityMap")
	@JsonProperty("identityMap")
	@SerializedName("identityMap")
	IdentityMap identityMap;

	@Nullable
	@JsonAlias("segmentMembership")
	@JsonProperty("segmentMembership")
	@SerializedName("segmentMembership")
	SegmentMembership segmentMembership;


	    public void setVerizon(Verizon Verizon) {
	        this.Verizon = Verizon;
	    }
	    public Verizon getVerizon() {
	        return Verizon;
	    }
	    
	    public void setIdentityMap(IdentityMap identityMap) {
	        this.identityMap = identityMap;
	    }
	    public IdentityMap getIdentityMap() {
	        return identityMap;
	    }
	    
	    public void setSegmentMembership(SegmentMembership segmentMembership) {
	        this.segmentMembership = segmentMembership;
	    }
	    public SegmentMembership getSegmentMembership() {
	        return segmentMembership;
	    }
	    

}
