package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class LocalNumberPortability implements Serializable{
	
	@Nullable
	@SerializedName("portInNumber")
	String portInNumber;
	
	@Nullable
	@SerializedName("accountNumber")
	String accountNumber;
	
	@Nullable
	@SerializedName("spidOcn")
	String spidOcn;
	
	@Nullable
	@SerializedName("sid")
	String sid;

	public String getPortInNumber() {
		return portInNumber;
	}

	public void setPortInNumber(String portInNumber) {
		this.portInNumber = portInNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getSpidOcn() {
		return spidOcn;
	}

	public void setSpidOcn(String spidOcn) {
		this.spidOcn = spidOcn;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}
	
	

}
