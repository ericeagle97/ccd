package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;


import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class SelectedALPShareList implements Serializable {
	
	@Nullable
	@SerializedName("newAlpShareInfo")
	List<NewAlpShareInfo> newAlpShareInfo;

	public List<NewAlpShareInfo> getNewAlpShareInfo() {
		return newAlpShareInfo;
	}

	public void setNewAlpShareInfo(List<NewAlpShareInfo> newAlpShareInfo) {
		this.newAlpShareInfo = newAlpShareInfo;
	}
	
}
