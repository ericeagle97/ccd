package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.am;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.beans.tar.am.CassandraStreamType;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.am.AmConstants;
import com.verizon.dataindus.rtstreams.core.utils.RedisConnector;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;

import java.io.EOFException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.verizon.dataindus.rtstreams.core.constants.am.AmConstants.CUSTINSIGHTS;

public class CassandraNormalizationStreamFn extends DoFn<CassandraStreamType, String>{

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(CassandraNormalizationStreamFn.class);

	private Jedis redisClientDoFnObject;

	/**
	 * Type - String, use - holds keystore password for redis connection
	 **/
	private String keystorePassword;

	/**
	 * Type - byte array, use - holds jks bytes for redis connection
	 **/
	private byte[] jksBytes;

	/**
	 * Type - byte string, use - holds secret payload for redis connection
	 **/
	private ByteString secretPayload;

	private boolean errorLog;
	boolean redisError = false;
	/**
	 * Sets the lookupData variable for with values from lookup file, and other variables required for redis connection
	 **/
	public CassandraNormalizationStreamFn(String keystorePassword, byte[] jksBytes, ByteString secretPayload, boolean errorLog) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;
		this.errorLog= errorLog;
	}

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, EOFException {

		RedisConnector redis = new RedisConnector();
		//redisClientDoFnObject = redis.redisConnector(projectId);
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword);
	}

	public static final TupleTag<String> AmInsights = new TupleTag<String>() { // MainCassandraAggType
	};
	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
	};
	private final Counter CassandraInsert_total_vol = Metrics.counter(CUSTINSIGHTS, AmConstants.custinsights_success);
	private final Counter CassandraInsert_total_error = Metrics.counter(CUSTINSIGHTS, AmConstants.custinsights_failure);

	public static org.json.simple.JSONObject getEmptyJsobObjIfNull(org.json.simple.JSONObject jsonObject) {
		if (null == jsonObject) {
			return null;
		} else {
			return jsonObject;
		}

	}

	@ProcessElement
	public void processElement(ProcessContext c ) throws IOException, ParseException {

		CassandraStreamType CustomeInsightImport = c.element();

		Map<String, Object> AMInsightsSink = new HashMap<String, Object>(); 
		Map<String, Object> keyAttributes = new HashMap<String, Object>(); 


		try
		{
			String mtn = CustomeInsightImport.getMtn();
			String accountNo = CustomeInsightImport.getAcct_no();
			String customerId = CustomeInsightImport.getCust_id_no();
			JSONObject insightValues=CustomeInsightImport.getInsight_values();
			String insightCategory=CustomeInsightImport.getInsight_category();
			String insightName=CustomeInsightImport.getInsight_name();

//			System.out.println("starting the flow");
			keyAttributes.put("acctNo",accountNo);
			keyAttributes.put("custId",customerId);


//			LOG.info("Tesgint the memstore for connectivity");

			if ((CommonUtility.isNullEmptyOrBlank(accountNo) || CommonUtility.isNullEmptyOrBlank(customerId)) && !CommonUtility.isNullEmptyOrBlank(mtn)) {

				String edwKey = AmConstants.EDW +CustomeInsightImport.getMtn().toString().trim();
				//LOG.info(edwKey);

				//String commandStatus = redisClientDoFnObject.set("EDW_"+IVRFeaturesImport.getMtn().toString().trim(),"123456789-0002");
				String accountNoCustomerID = redisClientDoFnObject.get(edwKey);
				//LOG.info(accountNoCustomerID);

				if (accountNoCustomerID != null && accountNoCustomerID.contains("-")) {
					String[] accountNoCsid = accountNoCustomerID.split("-");
					if (accountNoCsid[0].matches(Constants.REGEX_MTN) && accountNoCsid[1].matches(Constants.REGEX_MTN)) {
						keyAttributes.put("acctNo", accountNoCsid[1]);
						keyAttributes.put("custId", accountNoCsid[0]);
					} else {
						c.output(deadLetter, c.element().toString());
						return;
					}
				}
			}
			
			Date currentTime = new Date();
			SimpleDateFormat dtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'GMT'");
			String activitytime = dtFormat.format(currentTime);

			if(insightValues==null)
			{
				keyAttributes.put("insightValues","");
			}
			else
			{
				keyAttributes.put("insightValues",insightValues.toString());
			}
			
			keyAttributes.put("insightCategory",insightCategory);
			keyAttributes.put("updateBy","streams");
			keyAttributes.put("insightName",insightName);
			keyAttributes.put("updateTs",activitytime);
			keyAttributes.put("mtn",mtn);


			List<TimeDetails> timeDtlList = new LinkedList<TimeDetails>();
			TimeDetails timeDtls = new TimeDetails() ;
			timeDtls.setJobName("customerInsightsCassandraInsertAll");

			timeDtls = CommonUtility.addJobTimestamp("IN", timeDtls);
			timeDtls = CommonUtility.addJobTimestamp("OUT", timeDtls);

			timeDtlList.add(timeDtls);

			
			if(keyAttributes.get("acctNo")!="" && 
					keyAttributes.get("custId")!="" && 
					keyAttributes.get("mtn")!="" && 
					keyAttributes.get("acctNo")!= null && 
					keyAttributes.get("custId")!=null && 
					keyAttributes.get("mtn")!=null
				&& keyAttributes.get("acctNo").toString().matches(Constants.REGEX_MTN) 
				&& keyAttributes.get("custId").toString().matches(Constants.REGEX_MTN) 
				&& keyAttributes.get("mtn").toString().matches(Constants.REGEX_MTN) 
				&& keyAttributes.get("mtn").toString().length() == 10)
			{
				AMInsightsSink.put("keyAttributes",new JSONObject(keyAttributes).toString());
				CassandraInsert_total_vol.inc();
				c.output(AmInsights,new JSONObject(keyAttributes).toString());
//				LOG.info(new JSONObject(AMInsightsSink).toString());
			}

		}
		catch (Exception e) {
			CassandraInsert_total_error.inc();
			c.output(deadLetter,c.element().toString());
			e.printStackTrace();
			LOG.error(e.getMessage());
		}
	}
	@Teardown
	public void teardown()
	{
		redisClientDoFnObject.close();
		RedisConnector redis =new RedisConnector();
		redis.tearDown();
	}

}
