package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;
import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;

   
public class RtModel implements Serializable {

   @SerializedName("rtModelRes")
   List<RtModelRes> rtModelRes;


    public void setRtModelRes(List<RtModelRes> rtModelRes) {
        this.rtModelRes = rtModelRes;
    }
    public List<RtModelRes> getRtModelRes() {
        return rtModelRes;
    }
    
}