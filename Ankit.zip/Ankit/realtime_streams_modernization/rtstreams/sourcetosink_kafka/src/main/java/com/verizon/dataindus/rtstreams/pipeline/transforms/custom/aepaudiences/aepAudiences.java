package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.aepaudiences;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.beans.src.aepaudiences.audience_convert_type;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.aepaudiences.aepaudiencesConstants;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;

import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


public class aepAudiences extends DoFn<String, String>{
    private final Counter inputCounter = Metrics.counter("aep_audiences","inputData");

    private final Counter processedCounter = Metrics.counter("aep_audiences", "ValidData");
    private final Counter invalidcounter = Metrics.counter("aep_audiences", "FailedData");
    private final Counter ExceptionCounter = Metrics.counter("aep_audiences", "InValidData");
    public static final TupleTag<String> validTag = new TupleTag<String>() {};
    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };
    public static final TupleTag<String> invalidTag = new TupleTag<String>() {};
    @ProcessElement
    public void processElement(ProcessContext c) {
        try {
            inputCounter.inc();
            List<TimeDetails> timeDtlList = new LinkedList<TimeDetails>();
            TimeDetails timeDtls = new TimeDetails();

            timeDtls.setJobName(aepaudiencesConstants.JOBNAME);
            timeDtls = CommonUtility.addJobTimestamp("IN", timeDtls);
            String inputString = (String) c.element();
            audience_convert_type audConvert = new audience_convert_type();
            ObjectMapper om = new ObjectMapper();
            JsonNode root = om.readTree(inputString);
            JsonNode msgArr = root.get("messages");
            if (msgArr != null && msgArr.isArray()) {
                for (JsonNode node : msgArr) {
                    JsonNode vzNode = node.get("_verizon");
                    if (vzNode != null && vzNode.hasNonNull("mtn"))
                    {
                        audConvert.setMtn(vzNode.get("mtn").asText());
                        if (node.get("segmentMembership") != null && node.get("segmentMembership").get("ups") != null) {
                            JsonNode ups = node.get("segmentMembership").get("ups");
                            for (JsonNode aud : ups) {
                                String audStatus = aud.get("status").asText();
                                String audname = aud.get("name").asText();
                                if (aud.hasNonNull("name") && !"Segment Membership Changes".equalsIgnoreCase(audname) && !"exited".equalsIgnoreCase(audStatus) && !"exiting".equalsIgnoreCase(audStatus) && !audname.isEmpty()) {
                                    audConvert.addAudience(aud.get("name").asText());
                                }
                            }
                        }
                    }
                }
            }
            Map<String, Object> jsonObject = new HashMap<String, Object>();
            Map<String, Object> mapCustomerInsightsSink = new HashMap<String, Object>();
            jsonObject.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHT_CATEGORY,
                    aepaudiencesConstants.AEPAUDIENCE_INTERACTIONS);
            jsonObject.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHT_NAME,
                    aepaudiencesConstants.AEPAUDIENCE_INSIGHT);
            Map<String, Object> insightvalaud = new HashMap<String, Object>();
            Map<String, Object> keyAttributes = new HashMap<String, Object>();

            insightvalaud.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHTVAL_AUDLIST,
                    audConvert.getAudiences());
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHTNAME,
                    jsonObject.get(aepaudiencesConstants.AEPAUDIENCE_INSIGHT_NAME));
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_TTL,
                    aepaudiencesConstants.AEPAUDIENCE_TTL_VALUE);
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHTVALUES,
                    new JSONObject(insightvalaud).toString());
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_MTN, audConvert.getMtn());
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_INSIGHTCATEGORY,
                    jsonObject.get(aepaudiencesConstants.AEPAUDIENCE_INSIGHT_CATEGORY));
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_UPDATEDBY,
                    aepaudiencesConstants.AEPAUDIENCE_STREAMS);
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_CREATEDBY,
                    aepaudiencesConstants.AEPAUDIENCE_STREAMS);
            Instant instant = Instant.now();
            keyAttributes.put(aepaudiencesConstants.AEPAUDIENCE_UPDATETS, instant.toString());
            timeDtls = CommonUtility.addJobTimestamp("OUT", timeDtls);
            timeDtlList.add(timeDtls);
            mapCustomerInsightsSink.put(aepaudiencesConstants.KEYATTRIBUTES, keyAttributes);
            mapCustomerInsightsSink.put(aepaudiencesConstants.REQUESTTYPE,
                    aepaudiencesConstants.AEPAUDIENCE_REQUESTTYPE_VALUE);
            if(keyAttributes.get("mtn")!= null && keyAttributes.get("mtn").toString().matches("[0-9]+") && keyAttributes.get("mtn").toString().length() == 10  && keyAttributes.get("mtn")!= "" && null != audConvert.getAudiences() && !audConvert.getAudiences().isEmpty())
            {
                processedCounter.inc();
                c.output(validTag, new JSONObject(keyAttributes).toString());
            }
            else
            {
                invalidcounter.inc();
                c.output(invalidTag, new JSONObject(keyAttributes).toString());
            }
        }
        catch (Exception e)
            {
            /* Throws an generic exception */
            ExceptionCounter.inc();
            c.output(deadLetter, c.element());
            e.printStackTrace(System.out);
        }
    }
}
