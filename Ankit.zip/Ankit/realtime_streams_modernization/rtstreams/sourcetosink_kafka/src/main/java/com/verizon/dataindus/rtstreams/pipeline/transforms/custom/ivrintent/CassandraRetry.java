package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ivrintent;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.lib.IVRIntentCassandraInsertion;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.text.ParseException;

public class CassandraRetry extends DoFn<String, String> {

    private String httpRequest;
    private String requestType;
    static HttpClient client;

    final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_FEATURES+"_"+ "retry_success");
    final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_FEATURES+"_"+ "retry_failure");

    public static final TupleTag<String> deadLetterQueue = new TupleTag<String>() {
    };
    public static final TupleTag<String> responseSuccess = new TupleTag<String>() {
    };

    @Setup
    public void setup(){
        client = HttpClient.newHttpClient();
    }

    @Teardown
    public void teardown(){
        if(client != null){
            client=null;
        }
    }


    @ProcessElement
    public void processElement(ProcessContext c) throws ParseException, IOException, InterruptedException {
        if(c.element() == null) {
            return;
        }
        try {
            /** object of cassandra insertion library */
        	IVRIntentCassandraInsertion insertData = new IVRIntentCassandraInsertion();
            long StartTime = System.currentTimeMillis();
            /** send metadata and data of http request to  cassandra insertion library and stores the response to 'response' variable */
            HttpResponse<String> response = insertData.ivrIntentCassandraInsertion(client, httpRequest,
                    c.element());

            //LOG.info(" response=" + response.statusCode() + " StartTime=" + StartTime + " EndTime=" + EndTime + " TimeTaken=" + TimeTaken);
            if (response != null && response.statusCode() == 200 && response.body().toString().matches(Constants.REGEX_PNO_SUCCESS)) {
                successCounter.inc();
                c.output(c.element());
            }
            else if (response == null || ! (response.body().toString().matches(Constants.REGEX_PNO_SUCCESS))) {
                failureCounter.inc();
                c.output(deadLetterQueue, c.element());
            }
            else {
                failureCounter.inc();
                c.output(deadLetterQueue, c.element());
            }
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            failureCounter.inc();
        }
    }
}
