package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class IvrCallPath implements Serializable {
    @SerializedName("callId")
    @Nullable
    String callId;
    @SerializedName("startDate")
    @Nullable
    String startDate;
    @SerializedName("endDate")
    @Nullable
    String endDate;
    @SerializedName("Activity_ID")
    @Nullable
    String Activity_ID;
    @SerializedName("callerSpeechTag")
    @Nullable
    String callerSpeechTag;

    public String getCallId() {
        return callId;
    }

    public void setCallId(String callId) {
        this.callId = callId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getActivity_ID() {
        return Activity_ID;
    }

    public void setActivity_ID(String activity_ID) {
        Activity_ID = activity_ID;
    }

    public String getCallerSpeechTag() {
        return callerSpeechTag;
    }

    public void setCallerSpeechTag(String callerSpeechTag) {
        this.callerSpeechTag = callerSpeechTag;
    }

    @Override
    public String toString() {
        return "IvrCallPathPojo{" +
                "callId='" + callId + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", Activity_ID='" + Activity_ID + '\'' +
                ", callerSpeechTag='" + callerSpeechTag + '\'' +
                '}';
    }
}
