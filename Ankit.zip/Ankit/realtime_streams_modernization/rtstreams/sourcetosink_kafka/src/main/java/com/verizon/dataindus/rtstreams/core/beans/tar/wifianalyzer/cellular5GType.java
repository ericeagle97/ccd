package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

@javax.annotation.Nullable
public class cellular5GType implements Serializable {

	@SerializedName("rssi")
	@Nullable
	private long rssi;

	@SerializedName("ssSinr")
	@Nullable
	private long ssSinr;

	@SerializedName("nci")
	@Nullable
	private long nci;

	@SerializedName("csiSinr")
	@Nullable
	private long csiSinr;

	@SerializedName("ssRsrp")
	@Nullable
	private long ssRsrp;
	
	@SerializedName("ssRsrq")
	@Nullable
	private long ssRsrq;
	
	@SerializedName("pci")
	@Nullable
	private long pci;
	
	@SerializedName("csiRsrp")
	@Nullable
	private long csiRsrp;
	
	@SerializedName("csiRsrq")
	@Nullable
	private long csiRsrq;

	public long getRssi() {
		return rssi;
	}

	public void setRssi(long rssi) {
		this.rssi = rssi;
	}

	public long getSsSinr() {
		return ssSinr;
	}

	public void setSsSinr(long ssSinr) {
		this.ssSinr = ssSinr;
	}

	public long getNci() {
		return nci;
	}

	public void setNci(long nci) {
		this.nci = nci;
	}

	public long getCsiSinr() {
		return csiSinr;
	}

	public void setCsiSinr(long csiSinr) {
		this.csiSinr = csiSinr;
	}

	public long getSsRsrp() {
		return ssRsrp;
	}

	public void setSsRsrp(long ssRsrp) {
		this.ssRsrp = ssRsrp;
	}

	public long getSsRsrq() {
		return ssRsrq;
	}

	public void setSsRsrq(long ssRsrq) {
		this.ssRsrq = ssRsrq;
	}

	public long getPci() {
		return pci;
	}

	public void setPci(long pci) {
		this.pci = pci;
	}

	public long getCsiRsrp() {
		return csiRsrp;
	}

	public void setCsiRsrp(long csiRsrp) {
		this.csiRsrp = csiRsrp;
	}

	public long getCsiRsrq() {
		return csiRsrq;
	}

	public void setCsiRsrq(long csiRsrq) {
		this.csiRsrq = csiRsrq;
	}

	@Override
	public String toString() {
		return "cellular5GType [rssi=" + rssi + ", ssSinr=" + ssSinr + ", nci=" + nci + ", csiSinr=" + csiSinr
				+ ", ssRsrp=" + ssRsrp + ", ssRsrq=" + ssRsrq + ", pci=" + pci + ", csiRsrp=" + csiRsrp + ", csiRsrq="
				+ csiRsrq + "]";
	}

	
	
	
	

}