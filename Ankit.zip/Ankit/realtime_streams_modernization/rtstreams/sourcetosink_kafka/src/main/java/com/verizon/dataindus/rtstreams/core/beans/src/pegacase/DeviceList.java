package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;
import java.util.List;


   

@javax.annotation.Nullable
public class DeviceList implements Serializable {

      
	@Nullable
	@SerializedName("IMEI")
   @JsonProperty("IMEI")
   String IMEI;

   @Nullable
	@SerializedName("deviceId")
   String deviceId;

public String getIMEI() {
	return IMEI;
}

public void setIMEI(String iMEI) {
	IMEI = iMEI;
}

public String getDeviceId() {
	return deviceId;
}

public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
}
   

        
}
