package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class keyAttributesType implements Serializable {

	public String getRequestedBy() {
		return requestedBy;
	}

	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}

	public String getAggrValues() {
		return aggrValues;
	}

	public void setAggrValues(String aggrValues) {
		this.aggrValues = aggrValues;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getAggrCategory() {
		return aggrCategory;
	}

	public void setAggrCategory(String aggrCategory) {
		this.aggrCategory = aggrCategory;
	}

	public String getAggrProdId() {
		return aggrProdId;
	}

	public void setAggrProdId(String aggrProdId) {
		this.aggrProdId = aggrProdId;
	}

	public String getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}

	public String getAggrName() {
		return aggrName;
	}

	public void setAggrName(String aggrName) {
		this.aggrName = aggrName;
	}

	@SerializedName("requestedBy")
	@Nullable
	private String requestedBy;

	@SerializedName("aggrValues")
	@Nullable
	private String aggrValues;

	@SerializedName("updateBy")
	@Nullable
	private String updateBy;

	@SerializedName("aggrCategory")
	@Nullable
	private String aggrCategory;

	@SerializedName("aggrProdId")
	@Nullable
	private String aggrProdId;

	@SerializedName("updateTs")
	@Nullable
	private String updateTs;

	@SerializedName("aggrName")
	@Nullable
	private String aggrName;

}
