package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Utm implements Serializable {
	
	

	@Override
	public String toString() {
		return "Utm [utmSource=" + utmSource + ", utmCampaign=" + utmCampaign + ", utmMedium=" + utmMedium
				+ ", utmContent=" + utmContent + "]";
	}

	@SerializedName("utm_source")
	@Nullable
	String utmSource;

	@SerializedName("utm_campaign")
	@Nullable
	String utmCampaign;

	@SerializedName("utm_medium")
	@Nullable
	String utmMedium;

	@SerializedName("utm_content")
	@Nullable
	String utmContent;

	public void setUtmSource(String utmSource) {
		this.utmSource = utmSource;
	}

	public String getUtmSource() {
		return utmSource;
	}

	public void setUtmCampaign(String utmCampaign) {
		this.utmCampaign = utmCampaign;
	}

	public String getUtmCampaign() {
		return utmCampaign;
	}

	public void setUtmMedium(String utmMedium) {
		this.utmMedium = utmMedium;
	}

	public String getUtmMedium() {
		return utmMedium;
	}

	public void setUtmContent(String utmContent) {
		this.utmContent = utmContent;
	}

	public String getUtmContent() {
		return utmContent;
	}

}
