package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;

import com.google.gson.annotations.SerializedName;

   
public class Wifi {

   @SerializedName("bandwidthChannel")
   String bandwidthChannel;

   @SerializedName("bssid")
   String bssid;

   @SerializedName("channelNumber")
   int channelNumber;

   @SerializedName("frequency")
   int frequency;

   @SerializedName("wifiRSSI")
   int wifiRSSI;


    public void setBandwidthChannel(String bandwidthChannel) {
        this.bandwidthChannel = bandwidthChannel;
    }
    public String getBandwidthChannel() {
        return bandwidthChannel;
    }
    
    public void setBssid(String bssid) {
        this.bssid = bssid;
    }
    public String getBssid() {
        return bssid;
    }
    
    public void setChannelNumber(int channelNumber) {
        this.channelNumber = channelNumber;
    }
    public int getChannelNumber() {
        return channelNumber;
    }
    
    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }
    public int getFrequency() {
        return frequency;
    }
    
    public void setWifiRSSI(int wifiRSSI) {
        this.wifiRSSI = wifiRSSI;
    }
    public int getWifiRSSI() {
        return wifiRSSI;
    }
    
}