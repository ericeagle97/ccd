package com.verizon.dataindus.rtstreams.core.constants.sourcedigitalsecure;

public class DigitalSecureConstants {
	public DigitalSecureConstants(String projectId) {
	}

	public static final String CUSTTYPE = "custType";
	public static final String CUSTID = "custId";
	public static final String ACTIVITYID = "activityId";
	public static final String EXISTINGACCOUNTFLAG = "existingAccountFlag";
	public static final String SUBMITTERID = "submitterId";
	public static final String SUBMITTERDEPTNAME = "submitterDeptName";
	public static final String SUBMITTEREMAIL = "submitterEmail";
	public static final String SUBMITTERNAME = "submitterName";
	public static final String ISSUEID = "issueId";
	public static final String REMARKS = "remarks";
	public static final String TIME = "time";
	public static final String EVENTTIME = "eventTime";
	public static final String DATE = "date";
	public static final String DATA = "data";

	public static final String EVENTDATE = "eventDate";
	public static final String INSIGHTVALUES = "insightValues";
	public static final String UPDATEBY = "updateBy";
	public static final String CREATEDBY = "createdBy";
	public static final String UPDATETS = "updateTs";
	public static final String KEYATTRIBUTES = "keyAttributes";
	public static final String INTERACTIONS = "interactions";
	public static final String INSIGHTCATEGORY = "insightCategory";
	public static final String INSIGHTNAME = "insightName";
	public static final String INSIGHTNAME_VALUE = "securityscore_raw,securityscore_hist";
	public static final String EFFECTIVETIMESTAMP = "effectiveTimestamp";
	public static final String FRAUDINTAKE = "fraud_intake";
	public static final String TTL = "ttl";
	public static final String TTL_604800 = "604800";
	public static final String TTL_31536000 = "31536000";
	public static final String TTL_94608000 = "94608000";

	public static final String MTN = "mtn";
	public static final String MTN_VALUE = "9999999999";
	public static final String ACCTNO = "acctNo";
	public static final String ACCTNUM = "acctNum";
	public static final String CURRENTVALUES = "currentvalues";
	public static final String REQUESTTYPE = "requestType";
	public static final String REQUESTTYPE_VALUE_NAME = "SOI_CustomerInsights_by_name";
	public static final String STREAMS = "streams";
	public static final String DEVICE = "device";
	public static final String CUSTOMERID = "customerId";
	public static final String RESULTS = "results";
	public static final String CUSTOMERINSIGHT = "customerInsight";
	public static final String SECURITYSCORE_RAW = "securityscore_raw";
	public static final String SECURITYSCORE_HIST = "securityscore_hist";
	public static final String REQUESTTYPE_VALUE_BY_NAME = "SOI_CustomerInsights_by_name";
	public static final String REQUESTTYPE_VALUE_TTL = "SOI_InsertCustomerInsights_ttl";
	public static final String STATUS = "status";
	public static final String ISDIGITALSECUREAPPINSTALLED = "isDigitalSecureAppInstalled";
	public static final String ISREALTIMESCANENABLED = "isRealTimeScanEnabled";

	public static final String ISDIGITALSECUREACTIVATED = "isDigitalSecureActivated";
	public static final String ISSCHEDULEDSCANENABLED = "isScheduledScanEnabled";
	public static final String PRIVACYALERTCOUNT = "privacyAlertCount";
	public static final String ISWEBSECURITYENABLED = "isWebSecurityEnabled";
	public static final String ISWIFISECURITYENABLED = "isWifiSecurityEnabled";
	public static final String ISVPNAUTOCONNECTENABLED = "isVPNAutoConnectEnabled";
	public static final String ISUSERENROLLEDTODWM = "isUserEnrolledToDwm";
	public static final String ISUSERENROLLEDTOCSID = "isUserEnrolledToCSID";

	public static final String DOWNLOADED = "DOWNLOADED";

	public static final String ACTIVATED = "ACTIVATED";
	public static final String ENROLLED = "ENROLLED";

	public static final String ISVPNCONNECTED = "isVPNConnected";

	public static final String ACTIVITYHISTORY = "activityHistory";
	public static final String DOWNLOADDIGITALSECURE = "downloadDigitalSecure";
	public static final String ACTIVATEDIGITALSECURE = "activateDigitalSecure";
	public static final String SCHEDULEDSCANS = "scheduledScans";
	public static final String DEVICEOS = "deviceOS";
	public static final String DEVICEOS_IOS = "IOS";
	public static final String ISRUNNING = "isRunning";
	public static final String ISROOTED = "isRooted";
	public static final String ISMDNCAPTURED = "isMdnCaptured";

	public static final String PRIVACYALERT = "privacyAlert";
	public static final String WEBSECURITY = "webSecurity";
	public static final String WIFISECURITY = "wifiSecurity";
	public static final String DARKWEBMONITORING = "darkWebMonitoring";
	public static final String VPNAUTOCONNECT = "vpnAutoConnect";
	public static final String DSINSIGHT_CHANNEL = "DSInsights";
	public static final String CASSANDRA_PREVIOUS_CHANNEL = "CassandrapreviousInsightStream";
	public static final String IGNOREWIFIALERTBYDAY = "ignoredWifiAlertsByDay";
	public static final String WIFIALERTBYDAY = "wifiAlertsByDay";
	public static final String LASTSIGNATURECHECKTIME = "lastSignatureCheckTime";
	public static final String LASTSCANTIME = "lastScanTime";
	public static final String LASTUPDATETIME = "lastUpdateTime";
	public static final String NEXTSCANTIME = "nextScanTime";
	public static final String SCANNEDTHREATLOGS = "scannedThreatLogs";
	public static final String THREATCOUNT = "threatCount";
	public static final String THREATHISTORYLOGS = "threatHistoryLogs";
	public static final String DETECTEDTIME = "detectedTime";
	public static final String THREATHISTORYCOUNTDARKWEB = "threatHistoryCountDarkWeb";
	public static final String THREATHISTORYCOUNTWIFI = "threatHistoryCountWifi";
	public static final String THREATHISTORYCOUNTTOTAL = "threatHistoryCountTotal";
	public static final String THREATHISTORYCOUNTSYSTEMTHREAT = "threatHistoryCountSystemThreat";
	public static final String THREATHISTORYCOUNT = "threatHistoryCount";
	public static final String BUILDTIME = "buildTime";
	public static final String METADATA = "metaData";
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String FALSE = "false";
	public static final String TRUE = "true";
	public static final String ACCOUNTNO = "accountNo";
	public static final String GMT = " GMT";
	public static final String OTHERS = "Others";
	public static final String DARKWEB = "DarkWeb";
	public static final String WIFI = "Wifi";
	public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String DATEFORMAT_SLASH = "yyyy/MM/dd HH:mm:ss";
	public static final String COUNT = "count";

	public static final String THREATHISTORY = "threathistory";
	public static final String ANDROID = "ANDROID";
	public static final String WI_FI = "Wi-Fi";
	public static final String DARK_WEB = "Dark Web";
	public static final String TYPE = "type";
	public static final String RESOLVEDTIME = "resolvedTime";
	public static final String TYPE1 = "type1";
	public static final String TURNEDON = "TURNED ON";

}
