package com.verizon.dataindus.rtstreams.core.beans.tar.spanremarks.pintumble;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

import autovalue.shaded.org.jetbrains.annotations.Nullable;

public class SpanPintumbleData implements Serializable {
	
	public String getdate() {
		return date;
	}
	public void setdate(String date) {
		this.date = date;
		
	}
	
	public String getclientApp() {
		return clientApp;
	}
	public void setclientApp(String clientApp) {
		this.clientApp = clientApp;
		
	}
	
	public String getcustomerId() {
		return customerId;
	}
	public void setcustomerId(String customerId) {
		this.customerId = customerId;
		
	}
	
	public String gettime() {
		return time;
	}
	public void settime(String time) {
		this.time = time;
		
	}
	
	
	@Nullable
	@SerializedName("date")
	private String date;
	
	
	
	@Nullable
	@SerializedName("clientApp")
	private String clientApp;
	
	
	@Nullable
	@SerializedName("customerId")
	private String customerId;
	
	@Nullable
	@SerializedName("time")
	private String time;

}
