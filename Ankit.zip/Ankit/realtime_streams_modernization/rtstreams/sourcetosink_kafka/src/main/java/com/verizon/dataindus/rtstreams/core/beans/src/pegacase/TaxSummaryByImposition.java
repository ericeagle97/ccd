package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class TaxSummaryByImposition implements Serializable {

   @Nullable
	@SerializedName("taxDescription")
   String taxDescription;

   @Nullable
	@SerializedName("totalMandatoryTaxesbyImpName")
   String totalMandatoryTaxesbyImpName;


    public void setTaxDescription(String taxDescription) {
        this.taxDescription = taxDescription;
    }
    public String getTaxDescription() {
        return taxDescription;
    }
    
    public void setTotalMandatoryTaxesbyImpName(String totalMandatoryTaxesbyImpName) {
        this.totalMandatoryTaxesbyImpName = totalMandatoryTaxesbyImpName;
    }
    public String getTotalMandatoryTaxesbyImpName() {
        return totalMandatoryTaxesbyImpName;
    }
    
}