package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class AccountAttributes implements Serializable{
	
	@Nullable
	@SerializedName("isActive")
	String isActive;
	
	@Nullable
	@SerializedName("isCashOnly")
	String isCashOnly;

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsCashOnly() {
		return isCashOnly;
	}

	public void setIsCashOnly(String isCashOnly) {
		this.isCashOnly = isCashOnly;
	}
	
	
	
}