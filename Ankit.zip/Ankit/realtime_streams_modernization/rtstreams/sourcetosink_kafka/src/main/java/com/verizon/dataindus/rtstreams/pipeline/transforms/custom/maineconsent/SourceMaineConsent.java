package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.maineconsent;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;


public class SourceMaineConsent {

    /**
     *TupleTag, used to produce output being send to dead letter queue
     */
    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };

    public static final TupleTag<String> validTag = new TupleTag<String>() {
    };
    private static final Counter validData = Metrics.counter(Constants.METRICS_PREPROCESSING,
            Constants.METRICS_COUNTER_SUCCESS);
    private static final Counter invalidData = Metrics.counter(Constants.METRICS_PREPROCESSING,
            Constants.METRICS_COUNTER_FAILURE);
    public static class IVR extends DoFn<String, String>
    {
        private static final long serialVersionUID = 1L;
        private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(IVR.class);
        /*Flag to enable and disable logging*/
        ValueProvider<Boolean> errorLog;

        public static final TupleTag<String> deadLetterIvr = new TupleTag<String>() {
        };
        public static final TupleTag<String> validTagIvr = new TupleTag<String>() {
        };

        private static final Counter validDataIvr = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_SUCCESS+"_ivr");
        private static final Counter invalidDataIvr = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_FAILURE+"_ivr");

        public IVR(StaticValueProvider<Boolean> errorLog) {
            this.errorLog=errorLog;
        }
        @ProcessElement
        public void processElement(ProcessContext c)
        {
            try
            {
                String strSourceData = c.element();
                JsonObject objRootJson =  JsonParser.parseString(strSourceData).getAsJsonObject();
                Map<String,Object> mapIVRConsent = new HashMap<String,Object> ();
                Map<String,String> mapEventValues = new HashMap<String,String> ();
                mapIVRConsent.put("mtn", objRootJson.get("mtn").toString().replace("\"", ""));
                String[] token =objRootJson.get("accountNumber").toString().split("-");
                if(token.length==1)
                {
                    mapIVRConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapIVRConsent.put("account_number","");
                }
                else if(token.length==2)
                {
                    mapIVRConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapIVRConsent.put("account_number",token[1].toString().replace("\"", ""));
                }
                if(objRootJson.get("maineConsentAccepted").toString() =="true")
                {
                    mapIVRConsent.put("event_name","MAINE OPT IN");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent received.");
                }
                else
                {
                    mapIVRConsent.put("event_name","MAINE OPT OUT");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent NOT received.");
                }
                mapIVRConsent.put("event_category", "IVR");
                mapEventValues.put("start_time",objRootJson.get("consentDate").toString().replace("\"", ""));
                mapEventValues.put("session_id", objRootJson.get("callId").toString().replace("\"", ""));
                mapEventValues.put("end_time","");
                mapIVRConsent.put("event_values",mapEventValues);
                c.output(validTagIvr,(new JSONObject(mapIVRConsent).toString()));
                validDataIvr.inc();
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
                invalidDataIvr.inc();
                c.output(deadLetterIvr,c.element());
            }
        }
    }

    /**/
    public static class ChatbotmaineConsentStream extends DoFn<String, String>
    {
        private static final long serialVersionUID = 1L;
        private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(ChatbotmaineConsentStream.class);
        public static final TupleTag<String> deadLetterChatbot = new TupleTag<String>() {
        };
        public static final TupleTag<String> validTagChatBot = new TupleTag<String>() {
        };

        private static final Counter validDataChatbot = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_SUCCESS+"_chatbot");
        private static final Counter invalidDataChatbot = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_FAILURE+"_chatbot");
        /*Flag to enable and disable logging*/
        ValueProvider<Boolean> errorLog;

        public ChatbotmaineConsentStream(StaticValueProvider<Boolean> errorLog)
        {
            this.errorLog=errorLog;
        }
        @ProcessElement
        public void processElement(ProcessContext c)
        {
            try
            {
                String strSourceData = c.element();
                JsonObject objRootJson =  JsonParser.parseString(strSourceData).getAsJsonObject();
                Map<String,Object> mapChatbotConsent = new HashMap<String,Object> ();
                Map<String,String> mapEventValues = new HashMap<String,String> ();
                mapChatbotConsent.put("mtn", objRootJson.get("mtn").toString().replace("\"", ""));
                String[] token =objRootJson.get("accountNumber").toString().split("-");
                if(token.length==1)
                {
                    mapChatbotConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapChatbotConsent.put("account_number","");
                }
                else if(token.length==2)
                {
                    mapChatbotConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapChatbotConsent.put("account_number",token[1].toString().replace("\"", ""));
                }
                if(objRootJson.get("maineConsentAccepted").toString() =="true")
                {
                    mapChatbotConsent.put("event_name","MAINE OPT IN");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent received.");
                }
                else
                {
                    mapChatbotConsent.put("event_name","MAINE OPT OUT");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent NOT received.");
                }
                mapChatbotConsent.put("event_category", "CHATBOT");
                mapEventValues.put("start_time",objRootJson.get("consentDate").toString().replace("\"", ""));
                mapEventValues.put("session_id", objRootJson.get("callId").toString().replace("\"", ""));
                mapEventValues.put("end_time","");
                mapChatbotConsent.put("event_values",mapEventValues);
                c.output(validTagChatBot,(new JSONObject(mapChatbotConsent).toString()));
                validDataChatbot.inc();
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
                invalidDataChatbot.inc();
                c.output(deadLetterChatbot,c.element());
            }
        }
    }

    /*SocialMediaconsentStream recieves data from kafka and sends insight to */
    public static class SocialMediaConsentStream extends DoFn<String, String>
    {
        private static final long serialVersionUID = 1L;
        private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(SocialMediaConsentStream.class);

        public static final TupleTag<String> deadLetterSocialMedia = new TupleTag<String>() {
        };
        public static final TupleTag<String> validTagSocialMedia = new TupleTag<String>() {
        };

        private static final Counter validDataSocialmedia = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_SUCCESS+"_social_media");
        private static final Counter invalidDataSocialMedia = Metrics.counter(Constants.METRICS_PREPROCESSING,
                Constants.METRICS_COUNTER_FAILURE+"_social_media");
        /*Flag to enable and disable logging*/
        ValueProvider<Boolean> errorLog;

        public SocialMediaConsentStream(StaticValueProvider<Boolean> errorLog)
        {
            this.errorLog=errorLog;
        }
        @ProcessElement
        public void processElement(ProcessContext c)
        {
            try
            {
                String strSourceData = c.element();
                JsonObject objRootJson =  JsonParser.parseString(strSourceData).getAsJsonObject();
                Map<String,Object> mapSocialConsent = new HashMap<String,Object> ();
                Map<String,String> mapEventValues = new HashMap<String,String> ();
                mapSocialConsent.put("mtn", objRootJson.get("mtn").toString().replace("\"", ""));
                String[] token =objRootJson.get("accountNumber").toString().split("-");
                if(token.length==1)
                {
                    mapSocialConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapSocialConsent.put("account_number","");
                }
                else if(token.length==2)
                {
                    mapSocialConsent.put("cust_id" , token[0].toString().replace("\"", ""));
                    mapSocialConsent.put("account_number",token[1].toString().replace("\"", ""));
                }
                if(objRootJson.get("maineConsentAccepted").toString().equalsIgnoreCase("true"))
                {
                    mapSocialConsent.put("event_name","MAINE OPT IN");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent received.");
                }
                else
                {
                    mapSocialConsent.put("event_name","MAINE OPT OUT");
                    mapEventValues.put("event_desc", "Maine Resident - OPT-IN consent NOT received.");
                }
                mapSocialConsent.put("event_category", "SOCIAL MEDIA");
                mapEventValues.put("start_time",objRootJson.get("consentDate").toString().replace("\"", ""));
                mapEventValues.put("session_id", objRootJson.get("callId").toString().replace("\"", ""));
                mapEventValues.put("end_time","");
                mapSocialConsent.put("event_values",mapEventValues);
                c.output(validTagSocialMedia,(new JSONObject(mapSocialConsent).toString()));
                validDataSocialmedia.inc();
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
                invalidDataSocialMedia.inc();
                c.output(deadLetterSocialMedia, c.element());
            }
        }
    }

    public static class MaineInsights extends DoFn<String, String>
    {

        public MaineInsights(StaticValueProvider< Boolean> of)
        {
            // TODO Auto-generated constructor stub
        }

        @ProcessElement
        public void processElement(DoFn<String, String>.ProcessContext c)
        {
            try {
                String strSourceData = c.element();
                JsonObject objRootJson = JsonParser.parseString(strSourceData).getAsJsonObject();
                Map<String, Object> mapMaine = new HashMap<String, Object>();
                Map<String, String> mapEventValues = new HashMap<String, String>();
                mapMaine.put("custId", objRootJson.get("cust_id").toString().replace("\"", ""));
                mapMaine.put("acctNo", objRootJson.get("account_number").toString().replace("\"", ""));
                Date localTime = new Date();
                SimpleDateFormat s1 = new SimpleDateFormat("yyyy/MM/dd");
                SimpleDateFormat s2 = new SimpleDateFormat("yyyy-MM-dd" + " " + "HH:mm:ss");
                s1.setTimeZone(TimeZone.getTimeZone("GMT"));
                s2.setTimeZone(TimeZone.getTimeZone("GMT"));
                String strCreateDayFormat = s1.format(localTime);
                String strCreateTs = s2.format(localTime);
                String strCreateDay = strCreateDayFormat.toString().replace("/","");
                mapMaine.put("createDay", strCreateDay);
                mapMaine.put("createTs", strCreateTs + " GMT");
                mapMaine.put("mtn", objRootJson.get("mtn").toString().replace("\"", ""));
                mapMaine.put("eventCategory", objRootJson.get("event_category").toString().replace("\"", ""));
                mapMaine.put("eventName", objRootJson.get("event_name").toString().replace("\"", ""));
                mapMaine.put("createBy", "stream");
                JsonObject objEventValues = objRootJson.get("event_values").getAsJsonObject();
                mapEventValues.put("start_time", CommonUtility.getEmptyIfNull(objEventValues.get("start_time")).toString().replace("\"", ""));
                mapEventValues.put("end_time", CommonUtility.getEmptyIfNull(objEventValues.get("end_time")).toString().replace("\"", ""));
                mapEventValues.put("session_id", CommonUtility.getEmptyIfNull(objEventValues.get("session_id")).toString().replace("\"", ""));
                mapEventValues.put("event_status","");
                if (CommonUtility.getEmptyIfNull(mapMaine.get("eventName"))
                        .toString().contains("MAINE OPT IN") || CommonUtility.getEmptyIfNull(mapMaine.get("eventName"))
                        .toString().contains("MAINE OPT OUT")) {
                    mapMaine.put("eventName", mapMaine.get("eventName").toString().replaceAll("_", " "));
                    mapMaine.put("eventCategory", mapMaine.get("eventCategory").toString().replaceAll("_", " "));
                    mapEventValues.put("event_desc", "MAINE COMPLIANCE- MAINE");
                    mapMaine.put("eventValues", new JSONObject(mapEventValues).toString());
                    if (!CommonUtility.getEmptyIfNull(mapMaine.get("mtn")).toString().isEmpty() ||
                            !CommonUtility.getEmptyIfNull(mapMaine.get("mtn")).toString().equalsIgnoreCase("a0")) {
                        validData.inc();
                        c.output(validTag, new JSONObject(mapMaine).toString());
//                        c.output(new JSONObject(mapMaine).toString());
                    }
                }
            } catch (Exception e) {
                invalidData.inc();
                e.printStackTrace(System.out);
                c.output(deadLetter,c.element());
//                c.output(c.element());
            }
        }

    }

}
