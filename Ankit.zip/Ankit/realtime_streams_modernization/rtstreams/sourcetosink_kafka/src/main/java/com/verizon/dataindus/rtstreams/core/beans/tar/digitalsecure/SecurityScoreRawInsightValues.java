package com.verizon.dataindus.rtstreams.core.beans.tar.digitalsecure;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.IgnoredWifiAlertsByDay;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.MetaData;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.ScannedThreatLog;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.Threat;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.ThreatHistoryLog;
import com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure.WifiAlertsByDay;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class SecurityScoreRawInsightValues implements Serializable {
	private static final long serialVersionUID = 1L;
	/*
	 * rstring lastScanTime, int64 isScheduledScanEnabled, rstring
	 * lastSignatureCheckTime, int64 isUserEnrolledToDwm, int64
	 * isDigitalSecureActivated, int64 isDigitalSecureAppInstalled, rstring
	 * signatureVersion, int64 isRooted, metaDataType1 metaData, int64
	 * privacyAlertCount, int64 isUserEnrolledToCSID, list<threatsType> threats,
	 * list<rstring> appsWithHighDataExposure, int64 isWifiSecurityEnabled,
	 * list<wifiAlertsByDayType> wifiAlertsByDay, list<threatHistoryLogsType1>
	 * threatHistoryLogs, int64 mmsVersionCode, rstring subscriptionType, rstring
	 * mmsVersion, rstring nextScanTime, int64 isVPNAutoConnectEnabled, int64
	 * isVPNConnected, int64 isMdnCaptured, list<ignoredWifiAlertsByDayType>
	 * ignoredWifiAlertsByDay, int64 isRealTimeScanEnabled, int64
	 * isWebSecurityEnabled, rstring lastUpdateTime,rstring deviceOS;
	 */

	// int64 isRunning
	@SerializedName("isRunning")
	@Nullable
	public int isRunning;

	@SerializedName("mtn")
	@Nullable
	public String mtn;

	@SerializedName("customerId")
	@Nullable
	public String customerId;

	@SerializedName("AccountNo")
	@Nullable
	public String AccountNo;

	@SerializedName("deviceOS")
	@Nullable
	public String deviceOS;

	@SerializedName("mmsVersion")
	@Nullable
	public String mmsVersion;
	@SerializedName("signatureVersion")
	@Nullable
	public String signatureVersion;
	@SerializedName("lastUpdateTime")
	@Nullable
	public String lastUpdateTime;
	@SerializedName("lastScanTime")
	@Nullable
	public String lastScanTime;
	@SerializedName("lastSignatureCheckTime")
	@Nullable
	public String lastSignatureCheckTime;
	@SerializedName("threats")
	@Nullable
	public List<Threat> threats;
	@SerializedName("isRooted")
	@Nullable
	public int isRooted;
	@SerializedName("nextScanTime")
	@Nullable
	public String nextScanTime;
	@SerializedName("privacyAlertCount")
	@Nullable
	public String privacyAlertCount;
	@SerializedName("appsWithHighDataExposure")
	@Nullable
	public List<String> appsWithHighDataExposure;
	@SerializedName("isDigitalSecureActivated")
	@Nullable
	public int isDigitalSecureActivated;
	@SerializedName("isDigitalSecureAppInstalled")
	@Nullable
	public int isDigitalSecureAppInstalled;
	@SerializedName("isMdnCaptured")
	@Nullable
	public int isMdnCaptured;
	@SerializedName("subscriptionType")
	@Nullable
	public String subscriptionType;

	// list<scannedThreatLogsType1>scannedThreatLogs
	@SerializedName("scannedThreatLogs")
	@Nullable
	public List<ScannedThreatLog> scannedThreatLogs;

	@SerializedName("threatHistoryLogs")
	@Nullable
	public List<ThreatHistoryLog> threatHistoryLogs;
	@SerializedName("isWebSecurityEnabled")
	@Nullable
	public int isWebSecurityEnabled;
	@SerializedName("isWifiSecurityEnabled")
	@Nullable
	public int isWifiSecurityEnabled;
	@SerializedName("wifiAlertsByDay")
	@Nullable
	public List<WifiAlertsByDay> wifiAlertsByDay;
	@SerializedName("ignoredWifiAlertsByDay")
	@Nullable
	public List<IgnoredWifiAlertsByDay> ignoredWifiAlertsByDay;
	@SerializedName("isVPNConnected")
	@Nullable
	public int isVPNConnected;
	@SerializedName("isVPNAutoConnectEnabled")
	@Nullable
	public int isVPNAutoConnectEnabled;
	@SerializedName("isUserEnrolledToDwm")
	@Nullable
	public int isUserEnrolledToDwm;
	@SerializedName("isUserEnrolledToCSID")
	@Nullable
	public int isUserEnrolledToCSID;
	@SerializedName("isRealTimeScanEnabled")
	@Nullable
	public int isRealTimeScanEnabled;
	@SerializedName("isScheduledScanEnabled")
	@Nullable
	public int isScheduledScanEnabled;
	@SerializedName("mmsVersionCode")
	@Nullable
	public String mmsVersionCode;

	@SerializedName("readTimeStamp")
	@Nullable
	public String readTimeStamp;

	@SerializedName("kafkaTimeStamp")
	@Nullable
	public String kafkaTimeStamp;

	@SerializedName("metaData")
	@Nullable
	public MetaData metaData;

	public String getReadTimeStamp() {
		return readTimeStamp;
	}

	public void setReadTimeStamp(String readTimeStamp) {
		this.readTimeStamp = readTimeStamp;
	}

	public String getKafkaTimeStamp() {
		return kafkaTimeStamp;
	}

	public void setKafkaTimeStamp(String kafkaTimeStamp) {
		this.kafkaTimeStamp = kafkaTimeStamp;
	}

	public int getIsRunning() {
		return isRunning;
	}

	public void setIsRunning(int isRunning) {
		this.isRunning = isRunning;
	}

	public String getMmsVersion() {
		return mmsVersion;
	}

	public void setMmsVersion(String mmsVersion) {
		this.mmsVersion = mmsVersion;
	}

	public String getSignatureVersion() {
		return signatureVersion;
	}

	public void setSignatureVersion(String signatureVersion) {
		this.signatureVersion = signatureVersion;
	}

	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getLastScanTime() {
		return lastScanTime;
	}

	public void setLastScanTime(String lastScanTime) {
		this.lastScanTime = lastScanTime;
	}

	public String getLastSignatureCheckTime() {
		return lastSignatureCheckTime;
	}

	public void setLastSignatureCheckTime(String lastSignatureCheckTime) {
		this.lastSignatureCheckTime = lastSignatureCheckTime;
	}

	public List<Threat> getThreats() {
		return threats;
	}

	public void setThreats(List<Threat> threats) {
		this.threats = threats;
	}

	public int getIsRooted() {
		return isRooted;
	}

	public void setIsRooted(int isRooted) {
		this.isRooted = isRooted;
	}

	public String getNextScanTime() {
		return nextScanTime;
	}

	public void setNextScanTime(String nextScanTime) {
		this.nextScanTime = nextScanTime;
	}

	public String getPrivacyAlertCount() {
		return privacyAlertCount;
	}

	public void setPrivacyAlertCount(String privacyAlertCount) {
		this.privacyAlertCount = privacyAlertCount;
	}

	public List<String> getAppsWithHighDataExposure() {
		return appsWithHighDataExposure;
	}

	public void setAppsWithHighDataExposure(List<String> appsWithHighDataExposure) {
		this.appsWithHighDataExposure = appsWithHighDataExposure;
	}

	public int getIsDigitalSecureActivated() {
		return isDigitalSecureActivated;
	}

	public void setIsDigitalSecureActivated(int isDigitalSecureActivated) {
		this.isDigitalSecureActivated = isDigitalSecureActivated;
	}

	public int getIsDigitalSecureAppInstalled() {
		return isDigitalSecureAppInstalled;
	}

	public void setIsDigitalSecureAppInstalled(int isDigitalSecureAppInstalled) {
		this.isDigitalSecureAppInstalled = isDigitalSecureAppInstalled;
	}

	public int getIsMdnCaptured() {
		return isMdnCaptured;
	}

	public void setIsMdnCaptured(int isMdnCaptured) {
		this.isMdnCaptured = isMdnCaptured;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public List<ScannedThreatLog> getScannedThreatLogs() {
		return scannedThreatLogs;
	}

	public void setScannedThreatLogs(List<ScannedThreatLog> scannedThreatLogs) {
		this.scannedThreatLogs = scannedThreatLogs;
	}

	public List<ThreatHistoryLog> getThreatHistoryLogs() {
		return threatHistoryLogs;
	}

	public void setThreatHistoryLogs(List<ThreatHistoryLog> threatHistoryLogs) {
		this.threatHistoryLogs = threatHistoryLogs;
	}

	public int getIsWebSecurityEnabled() {
		return isWebSecurityEnabled;
	}

	public void setIsWebSecurityEnabled(int isWebSecurityEnabled) {
		this.isWebSecurityEnabled = isWebSecurityEnabled;
	}

	public int getIsWifiSecurityEnabled() {
		return isWifiSecurityEnabled;
	}

	public void setIsWifiSecurityEnabled(int isWifiSecurityEnabled) {
		this.isWifiSecurityEnabled = isWifiSecurityEnabled;
	}

	public List<WifiAlertsByDay> getWifiAlertsByDay() {
		return wifiAlertsByDay;
	}

	public void setWifiAlertsByDay(List<WifiAlertsByDay> wifiAlertsByDay) {
		this.wifiAlertsByDay = wifiAlertsByDay;
	}

	public List<IgnoredWifiAlertsByDay> getIgnoredWifiAlertsByDay() {
		return ignoredWifiAlertsByDay;
	}

	public void setIgnoredWifiAlertsByDay(List<IgnoredWifiAlertsByDay> ignoredWifiAlertsByDay) {
		this.ignoredWifiAlertsByDay = ignoredWifiAlertsByDay;
	}

	public int getIsVPNConnected() {
		return isVPNConnected;
	}

	public void setIsVPNConnected(int isVPNConnected) {
		this.isVPNConnected = isVPNConnected;
	}

	public int getIsVPNAutoConnectEnabled() {
		return isVPNAutoConnectEnabled;
	}

	public void setIsVPNAutoConnectEnabled(int isVPNAutoConnectEnabled) {
		this.isVPNAutoConnectEnabled = isVPNAutoConnectEnabled;
	}

	public int getIsUserEnrolledToDwm() {
		return isUserEnrolledToDwm;
	}

	public void setIsUserEnrolledToDwm(int isUserEnrolledToDwm) {
		this.isUserEnrolledToDwm = isUserEnrolledToDwm;
	}

	public int getIsUserEnrolledToCSID() {
		return isUserEnrolledToCSID;
	}

	public void setIsUserEnrolledToCSID(int isUserEnrolledToCSID) {
		this.isUserEnrolledToCSID = isUserEnrolledToCSID;
	}

	public int getIsRealTimeScanEnabled() {
		return isRealTimeScanEnabled;
	}

	public void setIsRealTimeScanEnabled(int isRealTimeScanEnabled) {
		this.isRealTimeScanEnabled = isRealTimeScanEnabled;
	}

	public int getIsScheduledScanEnabled() {
		return isScheduledScanEnabled;
	}

	public void setIsScheduledScanEnabled(int isScheduledScanEnabled) {
		this.isScheduledScanEnabled = isScheduledScanEnabled;
	}

	public String getMmsVersionCode() {
		return mmsVersionCode;
	}

	public void setMmsVersionCode(String mmsVersionCode) {
		this.mmsVersionCode = mmsVersionCode;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	public String getDeviceOS() {
		return deviceOS;
	}

	public void setDeviceOS(String deviceOS) {
		this.deviceOS = deviceOS;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}

	@Override
	public String toString() {
		return "SecurityScoreRawInsightValues [isRunning=" + isRunning + ", mtn=" + mtn + ", customerId=" + customerId
				+ ", AccountNo=" + AccountNo + ", deviceOS=" + deviceOS + ", mmsVersion=" + mmsVersion
				+ ", signatureVersion=" + signatureVersion + ", lastUpdateTime=" + lastUpdateTime + ", lastScanTime="
				+ lastScanTime + ", lastSignatureCheckTime=" + lastSignatureCheckTime + ", threats=" + threats
				+ ", isRooted=" + isRooted + ", nextScanTime=" + nextScanTime + ", privacyAlertCount="
				+ privacyAlertCount + ", appsWithHighDataExposure=" + appsWithHighDataExposure
				+ ", isDigitalSecureActivated=" + isDigitalSecureActivated + ", isDigitalSecureAppInstalled="
				+ isDigitalSecureAppInstalled + ", isMdnCaptured=" + isMdnCaptured + ", subscriptionType="
				+ subscriptionType + ", scannedThreatLogs=" + scannedThreatLogs + ", threatHistoryLogs="
				+ threatHistoryLogs + ", isWebSecurityEnabled=" + isWebSecurityEnabled + ", isWifiSecurityEnabled="
				+ isWifiSecurityEnabled + ", wifiAlertsByDay=" + wifiAlertsByDay + ", ignoredWifiAlertsByDay="
				+ ignoredWifiAlertsByDay + ", isVPNConnected=" + isVPNConnected + ", isVPNAutoConnectEnabled="
				+ isVPNAutoConnectEnabled + ", isUserEnrolledToDwm=" + isUserEnrolledToDwm + ", isUserEnrolledToCSID="
				+ isUserEnrolledToCSID + ", isRealTimeScanEnabled=" + isRealTimeScanEnabled
				+ ", isScheduledScanEnabled=" + isScheduledScanEnabled + ", mmsVersionCode=" + mmsVersionCode
				+ ", readTimeStamp=" + readTimeStamp + ", kafkaTimeStamp=" + kafkaTimeStamp + ", metaData=" + metaData
				+ "]";
	}

}
