package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class ErrorMessages implements Serializable {

   @Nullable
	@SerializedName("backendError")
   String backendError;

   @Nullable
	@SerializedName("intentProcessStep")
   String intentProcessStep;

   @Nullable
	@SerializedName("uiError")
   String uiError;

   @Nullable
	@SerializedName("backendErrorCode")
   String backendErrorCode;

   @Nullable
	@SerializedName("externalSystem")
   String externalSystem;


    public void setBackendError(String backendError) {
        this.backendError = backendError;
    }
    public String getBackendError() {
        return backendError;
    }
    
    public void setIntentProcessStep(String intentProcessStep) {
        this.intentProcessStep = intentProcessStep;
    }
    public String getIntentProcessStep() {
        return intentProcessStep;
    }
    
    public void setUiError(String uiError) {
        this.uiError = uiError;
    }
    public String getUiError() {
        return uiError;
    }
    
    public void setBackendErrorCode(String backendErrorCode) {
        this.backendErrorCode = backendErrorCode;
    }
    public String getBackendErrorCode() {
        return backendErrorCode;
    }
    
    public void setExternalSystem(String externalSystem) {
        this.externalSystem = externalSystem;
    }
    public String getExternalSystem() {
        return externalSystem;
    }
    
}