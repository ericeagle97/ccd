package com.verizon.dataindus.rtstreams.core.beans.src.networklocationviolation;

import org.apache.avro.reflect.Nullable;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
@JsonInclude(JsonInclude.Include.NON_NULL)
@javax.annotation.Nullable
public class Addresstype {

	@Nullable
	@JsonProperty("GEOCODED_ADDRESS")
	@JsonAlias({ "GEOCODED_ADDRESS" })
	@SerializedName("GEOCODED_ADDRESS")
	String GEOCODED_ADDRESS = "";
	
	@Nullable
	@JsonProperty("GEOCODED_STATE")
	@JsonAlias({ "GEOCODED_STATE" })
	@SerializedName("GEOCODED_STATE")
	String GEOCODED_STATE = "";
	
	@Nullable
	@JsonProperty("GEOCODED_ZIP")
	@JsonAlias({ "GEOCODED_ZIP" })
	@SerializedName("GEOCODED_ZIP")
	String GEOCODED_ZIP = "";
	
	@Nullable
	@JsonProperty("SVC_LATITUDE")
	@JsonAlias({ "SVC_LATITUDE" })
	@SerializedName("SVC_LATITUDE")
	String SVC_LATITUDE = "";
	
	@Nullable
	@JsonProperty("SVC_LONGITUDE")
	@JsonAlias({ "SVC_LONGITUDE" })
	@SerializedName("SVC_LONGITUDE")
	String SVC_LONGITUDE = "";
	
	@Nullable
	@JsonProperty("SERVICE_TECH_TYPE")
	@JsonAlias({ "SERVICE_TECH_TYPE" })
	@SerializedName("SERVICE_TECH_TYPE")
	String SERVICE_TECH_TYPE = "";
	
	@Nullable
	@JsonProperty("LV_DISTANCE")
	@JsonAlias({ "LV_DISTANCE" })
	@SerializedName("LV_DISTANCE")
	String LV_DISTANCE = "";

	public String getGEOCODED_ADDRESS() {
		return GEOCODED_ADDRESS;
	}

	public void setGEOCODED_ADDRESS(String gEOCODED_ADDRESS) {
		GEOCODED_ADDRESS = gEOCODED_ADDRESS;
	}

	public String getGEOCODED_STATE() {
		return GEOCODED_STATE;
	}

	public void setGEOCODED_STATE(String gEOCODED_STATE) {
		GEOCODED_STATE = gEOCODED_STATE;
	}

	public String getGEOCODED_ZIP() {
		return GEOCODED_ZIP;
	}

	public void setGEOCODED_ZIP(String gEOCODED_ZIP) {
		GEOCODED_ZIP = gEOCODED_ZIP;
	}

	public String getSVC_LATITUDE() {
		return SVC_LATITUDE;
	}

	public void setSVC_LATITUDE(String sVC_LATITUDE) {
		SVC_LATITUDE = sVC_LATITUDE;
	}

	public String getSVC_LONGITUDE() {
		return SVC_LONGITUDE;
	}

	public void setSVC_LONGITUDE(String sVC_LONGITUDE) {
		SVC_LONGITUDE = sVC_LONGITUDE;
	}

	public String getSERVICE_TECH_TYPE() {
		return SERVICE_TECH_TYPE;
	}

	public void setSERVICE_TECH_TYPE(String sERVICE_TECH_TYPE) {
		SERVICE_TECH_TYPE = sERVICE_TECH_TYPE;
	}

	public String getLV_DISTANCE() {
		return LV_DISTANCE;
	}

	public void setLV_DISTANCE(String lV_DISTANCE) {
		LV_DISTANCE = lV_DISTANCE;
	}

	@Override
	public String toString() {
		return "Addresstype [GEOCODED_ADDRESS=" + GEOCODED_ADDRESS + ", GEOCODED_STATE=" + GEOCODED_STATE
				+ ", GEOCODED_ZIP=" + GEOCODED_ZIP + ", SVC_LATITUDE=" + SVC_LATITUDE + ", SVC_LONGITUDE="
				+ SVC_LONGITUDE + ", SERVICE_TECH_TYPE=" + SERVICE_TECH_TYPE + ", LV_DISTANCE=" + LV_DISTANCE + "]";
	}


	
}
