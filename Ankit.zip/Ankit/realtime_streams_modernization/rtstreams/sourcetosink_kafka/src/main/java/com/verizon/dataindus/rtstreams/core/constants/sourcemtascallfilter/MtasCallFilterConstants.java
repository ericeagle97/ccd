package com.verizon.dataindus.rtstreams.core.constants.sourcemtascallfilter;

public class MtasCallFilterConstants {
	public static final String MTASCALLFILTER_MTN = "mtn";
	public static final String MTASCALLFILTER_CFRISKLEVEL = "cf_risk_level";
	public static final String MTASCALLFILTER_CFSTATUS = "cf_status";
	public static final String MTASCALLFILTER_READTIMESTAMP = "readtimestamp";
	public static final String MTASCALLFILTER_EFFECTIVETIMESTAMP = "effectiveTimestamp";
	public static final String MTASCALLFILTER_DATA = "data";
	public static final String MTASCALLFILTER_ACTION = "action";
	public static final String MTASCALLFILTER_NONE = "none";
	public static final String MTASCALLFILTER_BLOCK = "block";
	public static final String GMT = " GMT";
	public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String MTASCALLFILTER_VOICEMAIL = "voicemail";
	public static final String MTASCALLFILTER_CRITERIA = "criteria";
	public static final String MTASCALLFILTER_INSIGHTCATEGORY = "insightCategory";
	public static final String MTASCALLFILTER_DEVICE = "device";
	public static final String MTASCALLFILTER_INSIGHTNAME = "insightName";
	public static final String MTASCALLFILTER_INSIGHT_NAME = "insight_name";
	public static final String MTASCALLFILTER_CALLFILTER = "callfilter";
	public static final String MTASCALLFILTER_INSIGHTVALUES = "insightValues";
	public static final String MTASCALLFILTER_INSIGHT_VALUES = "insight_values";
	public static final String MTASCALLFILTER_TTL = "ttl";
	public static final String MTASCALLFILTER_TTL_VALUE = "94608000";
	public static final String MTASCALLFILTER_STREAMS = "streams";
	public static final String MTASCALLFILTER_UPDATEDBY = "updateBy";
	public static final String MTASCALLFILTER_CREATEDBY = "createdBy";
	public static final String MTASCALLFILTER_UPDATETS = "updateTs";
	public static final String MTASCALLFILTER_KEYATTRIBUTES = "keyAttributes";
	public static final String MTASCALLFILTER_REQUESTTYPE = "requestType";
	public static final String MTASCALLFILTER_INSIGHT_CATEGORY = "insight_category";
	public static final String MTASCALLFILTER_REQUESTTYPE_VALUE = "SOI_InsertCustomerMtnInsights_ttl";
	public static final String MTASCALLFILTER_CHANNEL = "MtasCallFilter";
	public static final String MTASCALLFILTER_CUSTOMERID = "customerId";
	public static final String MTASCALLFILTER_CUSTID = "custId";

	public static final String MTASCALLFILTER_ACCOUNTNO = "accountNo";
	public static final Object FRAUDREMARK_MTN_VALUE = "6308096007";
	public static final String JOBNAME = "mtas_call_filter";
	public static final String REQUESTTYPE_VALUE_TTL = "SOI_InsertCustomerInsights_ttl";

	public static final String KEYATTRIBUTES = "keyAttributes";
	public static final String REQUESTTYPE = "requestType";
}
