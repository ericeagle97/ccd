package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;


@javax.annotation.Nullable
public class MmgClickType implements Serializable {
		
	@SerializedName("transactionId")
	@Nullable
	String transactionId;
	
	@SerializedName("metadata")
	@Nullable
	metadataType metadata;
	
	@Nullable
	@SerializedName("mdn")
	String mdn;
	
	@Nullable
	@SerializedName("time")
	String time;
	
	@Nullable
	@SerializedName("mmgType")
	String mmgType;
	
	@Nullable
	@SerializedName("application")
	String application;
	
	@Nullable
	@SerializedName("client")
	String client;
	
	@Nullable
	@SerializedName("userId")
	String userId;
	
	@Nullable
	@SerializedName("deviceInstanceId")
	String deviceInstanceId;
	
	@Nullable
	@SerializedName("event")
	String event;
	
	@Nullable
	@SerializedName("status")
	String status;

	@SerializedName("message")
	@Nullable
	String message;

	@SerializedName("date")
	@Nullable
	String date;

	@SerializedName("userAgent")
	@Nullable
	String userAgent;
	
	@SerializedName("referrer")
	@Nullable
	String referrer;

	@SerializedName("smartLinkUrl")
	@Nullable
	String smartLinkUrl;

	@SerializedName("smartLinkId")
	@Nullable
	String smartLinkId;

	@SerializedName("smartLinkClickId")
	@Nullable
	String smartLinkClickId;

	@SerializedName("channel")
	@Nullable
	String channel;

	@SerializedName("destination")
	@Nullable
	String destination;

	@SerializedName("ipAddress")
	@Nullable
	String ipAddress;

	@SerializedName("campaign")
	@Nullable
	Campaign campaign;

	@SerializedName("utm")
	@Nullable
	Utm utm;
	
	@SerializedName("deviceInfo")
	@Nullable
	deviceInfoType deviceInfo;

	@SerializedName("data")
	@Nullable
	Data data;
	
	@SerializedName("queryString")
	@Nullable
	String queryString;
	
	@SerializedName("launchType")
	@Nullable
	String launchType;
	
	@SerializedName("subLaunchType")
	@Nullable
	String subLaunchType;
	
	@SerializedName("externalUserId")
	@Nullable
	String externalUserId;
	
	@SerializedName("linkageID")
	@Nullable
	String linkageID;

	public String getLinkageID() {
		return linkageID;
	}

	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	}

	@SerializedName("tupleTimestamp")
	@Nullable
	List<TimeDetails> tupleTimestamp;

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public metadataType getMetadata() {
		return metadata;
	}

	public void setMetadata(metadataType metadata) {
		this.metadata = metadata;
	}

	public String getMdn() {
		return mdn;
	}

	public void setMdn(String mdn) {
		this.mdn = mdn;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getMmgType() {
		return mmgType;
	}

	public void setMmgType(String mmgType) {
		this.mmgType = mmgType;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeviceInstanceId() {
		return deviceInstanceId;
	}

	public void setDeviceInstanceId(String deviceInstanceId) {
		this.deviceInstanceId = deviceInstanceId;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getReferrer() {
		return referrer;
	}

	public void setReferrer(String referrer) {
		this.referrer = referrer;
	}

	public String getSmartLinkUrl() {
		return smartLinkUrl;
	}

	public void setSmartLinkUrl(String smartLinkUrl) {
		this.smartLinkUrl = smartLinkUrl;
	}

	public String getSmartLinkId() {
		return smartLinkId;
	}

	public void setSmartLinkId(String smartLinkId) {
		this.smartLinkId = smartLinkId;
	}

	public String getSmartLinkClickId() {
		return smartLinkClickId;
	}

	public void setSmartLinkClickId(String smartLinkClickId) {
		this.smartLinkClickId = smartLinkClickId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Campaign getCampaign() {
		return campaign;
	}

	public void setCampaign(Campaign campaign) {
		this.campaign = campaign;
	}

	public Utm getUtm() {
		return utm;
	}

	public void setUtm(Utm utm) {
		this.utm = utm;
	}

	public deviceInfoType getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(deviceInfoType deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public String getQueryString() {
		return queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public String getLaunchType() {
		return launchType;
	}

	public void setLaunchType(String launchType) {
		this.launchType = launchType;
	}

	public String getSubLaunchType() {
		return subLaunchType;
	}

	public void setSubLaunchType(String subLaunchType) {
		this.subLaunchType = subLaunchType;
	}

	public String getExternalUserId() {
		return externalUserId;
	}

	public void setExternalUserId(String externalUserId) {
		this.externalUserId = externalUserId;
	}

	public List<TimeDetails> getTupleTimestamp() {
		return tupleTimestamp;
	}

	public void setTupleTimestamp(List<TimeDetails> tupleTimestamp) {
		this.tupleTimestamp = tupleTimestamp;
	}

	@Override
	public String toString() {
		return "MmgClickType [transactionId=" + transactionId + ", metadata=" + metadata + ", mdn=" + mdn + ", time="
				+ time + ", mmgType=" + mmgType + ", application=" + application + ", client=" + client + ", userId="
				+ userId + ", deviceInstanceId=" + deviceInstanceId + ", event=" + event + ", status=" + status
				+ ", message=" + message + ", date=" + date + ", userAgent=" + userAgent + ", referrer=" + referrer
				+ ", smartLinkUrl=" + smartLinkUrl + ", smartLinkId=" + smartLinkId + ", smartLinkClickId="
				+ smartLinkClickId + ", channel=" + channel + ", destination=" + destination + ", ipAddress="
				+ ipAddress + ", campaign=" + campaign + ", utm=" + utm + ", deviceInfo=" + deviceInfo + ", data="
				+ data + ", queryString=" + queryString + ", launchType=" + launchType + ", subLaunchType="
				+ subLaunchType + ", externalUserId=" + externalUserId + ", linkageID=" + linkageID
				+ ", tupleTimestamp=" + tupleTimestamp + "]";
	}

	



}
