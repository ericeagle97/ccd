package com.verizon.dataindus.rtstreams.core.utils;


import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;


public class Counter extends DoFn<String, String> {
    private final org.apache.beam.sdk.metrics.Counter deadLetterCounter = Metrics.counter("DeadLetterCounter", "DeadLetter");

    @ProcessElement
    public void processElement(ProcessContext c){
        deadLetterCounter.inc();
        c.output(c.element());
    }
}
