package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;


@XmlRootElement(name = "service")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class Service implements Serializable{
	
	@SerializedName("serviceBody")
    @Nullable
    @XmlElement(name = "serviceBody")
	public serviceBody serviceBody;
	
	@SerializedName("serviceHeader")
	@Nullable
    @XmlElement(name = "serviceHeader")
	public ServiceHeader serviceHeader;
	
	@SerializedName("linkageId")
	@Nullable
    @XmlElement(name = "linkageId")
	public String linkageId;
	
	@SerializedName("tupleTimestamp")
	@Nullable
	@XmlElement(name = "tupleTimestamp")
	List<TimeDetails> tupleTimestamp;

	public serviceBody getServiceBody() {
		return serviceBody;
	}

	public void setServiceBody(serviceBody serviceBody) {
		this.serviceBody = serviceBody;
	}

	public ServiceHeader getServiceHeader() {
		return serviceHeader;
	}

	public void setServiceHeader(ServiceHeader serviceHeader) {
		this.serviceHeader = serviceHeader;
	}

	public String getLinkageId() {
		return linkageId;
	}

	public void setLinkageId(String linkageId) {
		this.linkageId = linkageId;
	}

	public List<TimeDetails> getTupleTimestamp() {
		return tupleTimestamp;
	}

	public void setTupleTimestamp(List<TimeDetails> tupleTimestamp) {
		this.tupleTimestamp = tupleTimestamp;
	}

	@Override
	public String toString() {
		return "Service [serviceBody=" + serviceBody + ", serviceHeader=" + serviceHeader + ", linkageId=" + linkageId
				+ ", tupleTimestamp=" + tupleTimestamp + "]";
	}
}

