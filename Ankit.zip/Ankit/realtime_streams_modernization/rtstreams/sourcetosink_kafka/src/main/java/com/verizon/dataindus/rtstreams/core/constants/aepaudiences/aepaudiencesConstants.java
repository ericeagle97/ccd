package com.verizon.dataindus.rtstreams.core.constants.aepaudiences;

public class aepaudiencesConstants {
    public static final String AEPAUDIENCE_MTN = "mtn";
    public static final String AEPAUDIENCE_INSIGHTCATEGORY = "insightCategory";
    public static final String AEPAUDIENCE_INTERACTIONS = "interactions";
    public static final String AEPAUDIENCE_INSIGHTNAME = "insightName";
    public static final String AEPAUDIENCE_INSIGHT_NAME = "insight_name";
    public static final String AEPAUDIENCE_INSIGHT = "aep_audiences";
    public static final String AEPAUDIENCE_INSIGHTVALUES = "insightValues";
    public static final String AEPAUDIENCE_INSIGHT_VALUES = "insight_values";
    public static final String AEPAUDIENCE_TTL = "ttl";
    public static final String AEPAUDIENCE_TTL_VALUE = "7776000";
    public static final String AEPAUDIENCE_STREAMS = "streams";
    public static final String AEPAUDIENCE_UPDATEDBY = "updateBy";
    public static final String AEPAUDIENCE_CREATEDBY = "createdBy";
    public static final String AEPAUDIENCE_UPDATETS = "updateTs";
    public static final String AEPAUDIENCE_KEYATTRIBUTES = "keyAttributes";
    public static final String AEPAUDIENCE_REQUESTTYPE = "requestType";
    public static final String AEPAUDIENCE_INSIGHT_CATEGORY = "insight_category";
    public static final String AEPAUDIENCE_REQUESTTYPE_VALUE = "SOI_InsertCustomerMtnInsights_ttl";
    public static final String JOBNAME = "aep_audiences";
    public static final String REQUESTTYPE_VALUE_TTL = "SOI_InsertCustomerInsights_ttl";

    public static final String KEYATTRIBUTES = "keyAttributes";
    public static final String REQUESTTYPE = "requestType";
    public static final String AEPAUDIENCE_INSIGHTVAL_AUDLIST = "audiences";
}
