package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class InsightValuesType implements Serializable{
	
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSmartLinkUrl() {
		return smartLinkUrl;
	}

	public void setSmartLinkUrl(String smartLinkUrl) {
		this.smartLinkUrl = smartLinkUrl;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	@SerializedName("event")
	@Nullable
	private String event;

	@SerializedName("status")
	@Nullable
	private String status;

	@SerializedName("smartLinkUrl")
	@Nullable
	private String smartLinkUrl;

	@SerializedName("trackingId")
	@Nullable
	private String trackingId;

}
