package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.am;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.dataindus.rtstreams.core.beans.src.am.SourceAMPojo;
import com.verizon.dataindus.rtstreams.core.beans.tar.tpir.CassandraStreamType;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;

import static com.verizon.dataindus.rtstreams.core.constants.Constants.METRICS_COUNTER_INVALID;
import static com.verizon.dataindus.rtstreams.core.constants.Constants.METRICS_COUNTER_VALID;
import static com.verizon.dataindus.rtstreams.core.constants.am.AmConstants.*;



public class ProcessAM extends DoFn<String, SourceAMPojo> {


    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };
    public static final TupleTag<SourceAMPojo> validTag = new TupleTag<SourceAMPojo>() {
    };
    public static final TupleTag<CassandraStreamType> CassandraAM = new TupleTag<CassandraStreamType>() {
    };

    private final Counter validCounter = Metrics.counter(AM_NAMESPACE, METRICS_COUNTER_VALID);
    private final Counter invalidCounter = Metrics.counter(AM_NAMESPACE, METRICS_COUNTER_INVALID);
    private final Counter totalImportCount = Metrics.counter(AM_NAMESPACE, metrics_total_count);


    @ProcessElement
    public void processElement(ProcessContext processElement) throws JsonProcessingException {

        totalImportCount.inc();
        try {
            String rawData = processElement.element();
            ObjectMapper objectMapper = new ObjectMapper();
            SourceAMPojo sourceData = objectMapper
                    .readValue(rawData, SourceAMPojo.class);
            validCounter.inc();
            processElement.output(sourceData);

        } catch (Exception e) {
            invalidCounter.inc();
            processElement.output(deadLetter, processElement.element());
            e.printStackTrace(System.out);
        }

    }
}
