package com.verizon.dataindus.rtstreams.core.constants.quickticket;

public class QuickTicketConstants {
	
    public static final String QUICKTICKET_NAMESPACE = "QuickTicket";
    
    public static final String QT_IGNITE_IMPORT_COUNTER = "qt_stream_import_count";
    public static final String QT_IGNITE_VALID_COUNTER = "qt_ignite_api_new_count";
    public static final String QT_IGNITE_INVALID_COUNTER = "qt_ignite_api_existing_count";
    public static final String QT_IGNITE_ERROR_COUNTER = "qt_ignite_error_count";
    
    public static final String QT_JARVIS_IMPORT_COUNTER = "qt_jarvis_encoder_call";
    public static final String QT_JARVIS_VALID_COUNTER = "qt_jarvis_encoder_success_response_count";
    public static final String QT_JARVIS_INVALID_COUNTER = "qt_jarvis_encoder_failure_response_count";
    public static final String QT_JARVIS_ERROR_COUNTER = "qt_jarvis_encoder_error_count";
    
    public static final String AAD_IGNITE_IMPORT_COUNTER = "AAD_stream_count";
    public static final String AAD_IGNITE_VALID_COUNTER = "AAD_ignite_apiscorestream";
    public static final String AAD_IGNITE_INVALID_COUNTER = "AAD_ignite_invalidresponsecount";
    public static final String AAD_IGNITE_ERROR_COUNTER = "AAD_ignite_errorcount";
    
    public static final String AAD_JARVIS_IMPORT_COUNTER = "AAD_jarvis_encodercall";
    public static final String AAD_JARVIS_VALID_COUNTER = "AAD_jarvis_encoderstream";
    public static final String AAD_JARVIS_INVALID_COUNTER = "AAD_jarvis_invalidresponsecount";
    public static final String AAD_JARVIS_ERROR_COUNTER = "AAD_jarvis_errorcount";
    

    public static final String QUICK_TICKET_TOPIC = "soi_pos_quick_ticket";
    public static final String AAD_TOPIC = "soi_pos_aad";
}
