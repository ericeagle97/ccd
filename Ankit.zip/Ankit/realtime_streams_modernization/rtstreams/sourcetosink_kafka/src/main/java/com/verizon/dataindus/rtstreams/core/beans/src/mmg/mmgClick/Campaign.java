package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Campaign implements Serializable {
	
	

	@Override
	public String toString() {
		return "Campaign [trackingId=" + trackingId + ", name=" + name + ", group=" + group + ", source=" + source
				+ ", expectedTransaction=" + expectedTransaction + "]";
	}

	@SerializedName("trackingId")
	@Nullable
	String trackingId;

	@SerializedName("name")
	@Nullable
	String name;

	@SerializedName("group")
	@Nullable
	String group;

	@SerializedName("source")
	@Nullable
	String source;

	@SerializedName("expectedTransaction")
	@Nullable
	String expectedTransaction;

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getGroup() {
		return group;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSource() {
		return source;
	}

	public void setExpectedTransaction(String expectedTransaction) {
		this.expectedTransaction = expectedTransaction;
	}

	public String getExpectedTransaction() {
		return expectedTransaction;
	}

}
