package com.verizon.dataindus.rtstreams.core.beans.tar.tpir;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
import java.util.List;


@javax.annotation.Nullable
public class Service_Convert_type implements Serializable{
	
	@SerializedName("serviceName")
	@Nullable
	public String serviceName; 

	@SerializedName("subserviceName")
	@Nullable
	public String subserviceName; 

	@SerializedName("requestID")
	@Nullable
	public String requestID; 

	@SerializedName("clientName")
	@Nullable
	public String clientName; 

	@SerializedName("generatedID")
	@Nullable
	public String generatedID; 

	@SerializedName("version")
	@Nullable
	public String version; 

	@SerializedName("channelId")
	@Nullable
	public String channelId; 

	@SerializedName("activitySummary")
	@Nullable
	public String activitySummary; 

	@SerializedName("activityDetail")
	@Nullable
	public String activityDetail; 

	@SerializedName("status")
	@Nullable
	public String status; 

	@SerializedName("selfServe")
	@Nullable
	public String selfServe; 

	@SerializedName("accountNumber")
	@Nullable
	public String accountNumber; 

	@SerializedName("mtn")
	@Nullable
	public String mtn; 

	@SerializedName("timeStamp")
	@Nullable
	public String timeStamp; 

	@SerializedName("congestedHrs")
	@Nullable
	public String congestedHrs; 

	@SerializedName("outageID")
	@Nullable
	public String outageID; 

	@SerializedName("outageState")
	@Nullable
	public String outageState; 

	@SerializedName("activityDate")
	@Nullable
	public String activityDate; 

	@SerializedName("statusCode")
	@Nullable
	public String statusCode; 

	@SerializedName("statusMessage")
	@Nullable
	public String statusMessage; 

	@SerializedName("subChannel")
	@Nullable
	public String subChannel; 

	@SerializedName("additionalInfo")
	@Nullable
	public String additionalInfo; 

	@SerializedName("agentUserName")
	@Nullable
	public String agentUserName; 

	@SerializedName("accountTenure")
	@Nullable
	public String accountTenure; 

	@SerializedName("callCenterDesc")
	@Nullable
	public String callCenterDesc; 

	@SerializedName("callDisputeInd")
	@Nullable
	public String callDisputeInd; 

	@SerializedName("callReason")
	@Nullable
	public String callReason; 

	@SerializedName("cartID")
	@Nullable
	public String cartID; 

	@SerializedName("cbr")
	@Nullable
	public String cbr; 

	@SerializedName("departmentDesc")
	@Nullable
	public String departmentDesc; 

	@SerializedName("destinationDept")
	@Nullable
	public String destinationDept; 

	@SerializedName("repName")
	@Nullable
	public String repName; 

	@SerializedName("errorMsg")
	@Nullable
	public String errorMsg; 

	@SerializedName("failReason")
	@Nullable
	public String failReason; 

	@SerializedName("finalStatus")
	@Nullable
	public String finalStatus; 

	@SerializedName("lastName")
	@Nullable
	public String lastName; 

	@SerializedName("lob")
	@Nullable
	public String lob; 

	@SerializedName("pageName")
	@Nullable
	public String pageName; 

	@SerializedName("purchaseFlow")
	@Nullable
	public String purchaseFlow; 

	@SerializedName("remedyFlag")
	@Nullable
	public String remedyFlag; 

	@SerializedName("revenue")
	@Nullable
	public String revenue; 

	@SerializedName("toolkit")
	@Nullable
	public String toolkit; 

	@SerializedName("transferPoint")
	@Nullable
	public String transferPoint; 

	@SerializedName("treatmentFlag")
	@Nullable
	public String treatmentFlag; 

	@SerializedName("tsrNextStep")
	@Nullable
	public String tsrNextStep; 

	@SerializedName("tsrSymptom")
	@Nullable
	public String tsrSymptom; 

	@SerializedName("typeOfBilling")
	@Nullable
	public String typeOfBilling; 

	@SerializedName("userRole")
	@Nullable
	public String userRole; 

	@SerializedName("workState")
	@Nullable
	public String workState; 

	@SerializedName("speechTag")
	@Nullable
	public String speechTag; 

	@SerializedName("intent")
	@Nullable
	public String intent; 

	@SerializedName("time_details")
	@Nullable
	List<TimeDetails> timeDetails;

	@SerializedName("linkageID")
	@Nullable
	public String linkageID;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getSubserviceName() {
		return subserviceName;
	}

	public void setSubserviceName(String subserviceName) {
		this.subserviceName = subserviceName;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getGeneratedID() {
		return generatedID;
	}

	public void setGeneratedID(String generatedID) {
		this.generatedID = generatedID;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getActivitySummary() {
		return activitySummary;
	}

	public void setActivitySummary(String activitySummary) {
		this.activitySummary = activitySummary;
	}

	public String getActivityDetail() {
		return activityDetail;
	}

	public void setActivityDetail(String activityDetail) {
		this.activityDetail = activityDetail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSelfServe() {
		return selfServe;
	}

	public void setSelfServe(String selfServe) {
		this.selfServe = selfServe;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getCongestedHrs() {
		return congestedHrs;
	}

	public void setCongestedHrs(String congestedHrs) {
		this.congestedHrs = congestedHrs;
	}

	public String getOutageID() {
		return outageID;
	}

	public void setOutageID(String outageID) {
		this.outageID = outageID;
	}

	public String getOutageState() {
		return outageState;
	}

	public void setOutageState(String outageState) {
		this.outageState = outageState;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getSubChannel() {
		return subChannel;
	}

	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getAgentUserName() {
		return agentUserName;
	}

	public void setAgentUserName(String agentUserName) {
		this.agentUserName = agentUserName;
	}

	public String getAccountTenure() {
		return accountTenure;
	}

	public void setAccountTenure(String accountTenure) {
		this.accountTenure = accountTenure;
	}

	public String getCallCenterDesc() {
		return callCenterDesc;
	}

	public void setCallCenterDesc(String callCenterDesc) {
		this.callCenterDesc = callCenterDesc;
	}

	public String getCallDisputeInd() {
		return callDisputeInd;
	}

	public void setCallDisputeInd(String callDisputeInd) {
		this.callDisputeInd = callDisputeInd;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCartID() {
		return cartID;
	}

	public void setCartID(String cartID) {
		this.cartID = cartID;
	}

	public String getCbr() {
		return cbr;
	}

	public void setCbr(String cbr) {
		this.cbr = cbr;
	}

	public String getDepartmentDesc() {
		return departmentDesc;
	}

	public void setDepartmentDesc(String departmentDesc) {
		this.departmentDesc = departmentDesc;
	}

	public String getDestinationDept() {
		return destinationDept;
	}

	public void setDestinationDept(String destinationDept) {
		this.destinationDept = destinationDept;
	}

	public String getRepName() {
		return repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getFinalStatus() {
		return finalStatus;
	}

	public void setFinalStatus(String finalStatus) {
		this.finalStatus = finalStatus;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPurchaseFlow() {
		return purchaseFlow;
	}

	public void setPurchaseFlow(String purchaseFlow) {
		this.purchaseFlow = purchaseFlow;
	}

	public String getRemedyFlag() {
		return remedyFlag;
	}

	public void setRemedyFlag(String remedyFlag) {
		this.remedyFlag = remedyFlag;
	}

	public String getRevenue() {
		return revenue;
	}

	public void setRevenue(String revenue) {
		this.revenue = revenue;
	}

	public String getToolkit() {
		return toolkit;
	}

	public void setToolkit(String toolkit) {
		this.toolkit = toolkit;
	}

	public String getTransferPoint() {
		return transferPoint;
	}

	public void setTransferPoint(String transferPoint) {
		this.transferPoint = transferPoint;
	}

	public String getTreatmentFlag() {
		return treatmentFlag;
	}

	public void setTreatmentFlag(String treatmentFlag) {
		this.treatmentFlag = treatmentFlag;
	}

	public String getTsrNextStep() {
		return tsrNextStep;
	}

	public void setTsrNextStep(String tsrNextStep) {
		this.tsrNextStep = tsrNextStep;
	}

	public String getTsrSymptom() {
		return tsrSymptom;
	}

	public void setTsrSymptom(String tsrSymptom) {
		this.tsrSymptom = tsrSymptom;
	}

	public String getTypeOfBilling() {
		return typeOfBilling;
	}

	public void setTypeOfBilling(String typeOfBilling) {
		this.typeOfBilling = typeOfBilling;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getWorkState() {
		return workState;
	}

	public void setWorkState(String workState) {
		this.workState = workState;
	}

	public String getSpeechTag() {
		return speechTag;
	}

	public void setSpeechTag(String speechTag) {
		this.speechTag = speechTag;
	}

	public String getIntent() {
		return intent;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}

	public void setTimeDetails(List<TimeDetails> timeDetails) {
		this.timeDetails = timeDetails;
	}
	public List<TimeDetails> getTimeDetails() {
		return timeDetails;
	}

	public String getLinkageID() {
		return linkageID;
	}

	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	} 
	
	@Override
	public String toString() {
		
		return "Service_Convert_type [serviceName=" + serviceName + ", subserviceName=" + subserviceName + ", requestID=" + requestID + ", clientName=" + clientName + ", generatedID=" + generatedID + ", version=" + version + ", channelId=" + channelId + ", activitySummary=" + activitySummary + ", activityDetail=" + activityDetail + ", status=" + status + ", selfServe=" + selfServe + ", accountNumber=" + accountNumber + ", mtn=" + mtn + ", timeStamp=" + timeStamp + ", congestedHrs=" + congestedHrs + ", outageID=" + outageID + ", outageState=" + outageState + ", activityDate=" + activityDate + ", statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", subChannel=" + subChannel + ", additionalInfo=" + additionalInfo + ", agentUserName=" + agentUserName + ", accountTenure=" + accountTenure + ", callCenterDesc=" + callCenterDesc + ", callDisputeInd=" + callDisputeInd + ", callReason=" + callReason + ", cartID=" + cartID + ", cbr=" + cbr + ", departmentDesc=" + departmentDesc + ", destinationDept=" + destinationDept + ", repName=" + repName + ", errorMsg=" + errorMsg + ", failReason=" + failReason + ", finalStatus=" + finalStatus + ", lastName=" + lastName + ", lob=" + lob + ", pageName=" + pageName + ", purchaseFlow=" + purchaseFlow + ", remedyFlag=" + remedyFlag + ", revenue=" + revenue + ", toolkit=" + toolkit + ", transferPoint=" + transferPoint + ", treatmentFlag=" + treatmentFlag + ", tsrNextStep=" + tsrNextStep + ", tsrSymptom=" + tsrSymptom + ", typeOfBilling=" + typeOfBilling + ", userRole=" + userRole + ", workState=" + workState + ", speechTag=" + speechTag + ", intent=" + intent + ", tupleTimestamp=" + timeDetails + ", linkageID=" + linkageID + " ]";
		
	}
}
