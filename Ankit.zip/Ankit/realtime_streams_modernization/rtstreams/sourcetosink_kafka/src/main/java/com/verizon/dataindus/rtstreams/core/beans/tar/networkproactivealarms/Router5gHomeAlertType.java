package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class Router5gHomeAlertType implements Serializable {
    @SerializedName("mdn_5g")
    @Nullable
    String mdn_5g;

    @SerializedName("serialnumber")
    @Nullable
    String serialnumber;

    @SerializedName("site_market")
    @Nullable
    String site_market;

    @SerializedName("active_user")
    @Nullable
    String active_user;

    @SerializedName("user_type")
    @Nullable
    float user_type;

    @SerializedName("install_status")
    @Nullable
    String install_status;

    @SerializedName("model_name")
    @Nullable
    String model_name;

    @SerializedName("firmware_ver")
    @Nullable
    String firmware_ver;

    @SerializedName("time_zone")
    @Nullable
    String time_zone;

    @SerializedName("local_time")
    @Nullable
    String local_time;

    @SerializedName("cpu_usage")
    @Nullable
    float cpu_usage;

    @SerializedName("timestamp_1stwatch")
    @Nullable
    String timestamp_1stwatch;

    @SerializedName("timestamp_3rdwatch")
    @Nullable
    String timestamp_3rdwatch;

    @SerializedName("latest_powercycle")
    @Nullable
    String latest_powercycle;

    @SerializedName("filtered_temperature")
    @Nullable
    float filtered_temperature;

    @SerializedName("pct_speed_met_target")
    @Nullable
    String pct_speed_met_target;

    @SerializedName("avg_dl_test_speed")
    @Nullable
    String avg_dl_test_speed;

    @SerializedName("avg_ul_test_speed")
    @Nullable
    String avg_ul_test_speed;

    @SerializedName("extender_sn")
    @Nullable
    String extender_sn;

    @SerializedName("extender_mac")
    @Nullable
    String extender_mac;

    @SerializedName("relocation_rec_level")
    @Nullable
    String relocation_rec_level;

    @SerializedName("filtered_rssi")
    @Nullable
    String filtered_rssi;

    @SerializedName("filtered_cpe_router_phy_rate")
    @Nullable
    String filtered_cpe_router_phy_rate;

    @SerializedName("filtered_cpe_router_conn_rssi")
    @Nullable
    String filtered_cpe_router_conn_rssi;

    @SerializedName("extender_recomm_level")
    @Nullable
    String extender_recomm_level;

    @SerializedName("reboot_recommendation")
    @Nullable
    String reboot_recommendation;

    @SerializedName("reboot_order")
    @Nullable
    String reboot_order;

    @SerializedName("report_time")
    @Nullable
    String report_time;

    @SerializedName("trans_dt")
    @Nullable
    String trans_dt;

    @SerializedName("alarm_type")
    @Nullable
    String alarm_type;

    @SerializedName("alarm_category")
    @Nullable
    String alarm_category;

    @SerializedName("num_reboot_7days")
    @Nullable
    float num_reboot_7days;

    @SerializedName("poor_rssi_client_info")
    @Nullable
    String poor_rssi_client_info;

    @SerializedName("alert_id")
    @Nullable
    int alert_id;

    @SerializedName("id")
    @Nullable
    int id;

    @SerializedName("linkageId")
    @Nullable
    String linkageId;

    @Nullable
    public String getMdn_5g() {
        return mdn_5g;
    }

    public void setMdn_5g(@Nullable String mdn_5g) {
        this.mdn_5g = mdn_5g;
    }

    @Nullable
    public String getSerialnumber() {
        return serialnumber;
    }

    public void setSerialnumber(@Nullable String serialnumber) {
        this.serialnumber = serialnumber;
    }

    @Nullable
    public String getSite_market() {
        return site_market;
    }

    public void setSite_market(@Nullable String site_market) {
        this.site_market = site_market;
    }

    @Nullable
    public String getActive_user() {
        return active_user;
    }

    public void setActive_user(@Nullable String active_user) {
        this.active_user = active_user;
    }

    public float getUser_type() {
        return user_type;
    }

    public void setUser_type(float user_type) {
        this.user_type = user_type;
    }

    @Nullable
    public String getInstall_status() {
        return install_status;
    }

    public void setInstall_status(@Nullable String install_status) {
        this.install_status = install_status;
    }

    @Nullable
    public String getModel_name() {
        return model_name;
    }

    public void setModel_name(@Nullable String model_name) {
        this.model_name = model_name;
    }

    @Nullable
    public String getFirmware_ver() {
        return firmware_ver;
    }

    public void setFirmware_ver(@Nullable String firmware_ver) {
        this.firmware_ver = firmware_ver;
    }

    @Nullable
    public String getTime_zone() {
        return time_zone;
    }

    public void setTime_zone(@Nullable String time_zone) {
        this.time_zone = time_zone;
    }

    @Nullable
    public String getLocal_time() {
        return local_time;
    }

    public void setLocal_time(@Nullable String local_time) {
        this.local_time = local_time;
    }

    public float getCpu_usage() {
        return cpu_usage;
    }

    public void setCpu_usage(float cpu_usage) {
        this.cpu_usage = cpu_usage;
    }

    @Nullable
    public String getTimestamp_1stwatch() {
        return timestamp_1stwatch;
    }

    public void setTimestamp_1stwatch(@Nullable String timestamp_1stwatch) {
        this.timestamp_1stwatch = timestamp_1stwatch;
    }

    @Nullable
    public String getTimestamp_3rdwatch() {
        return timestamp_3rdwatch;
    }

    public void setTimestamp_3rdwatch(@Nullable String timestamp_3rdwatch) {
        this.timestamp_3rdwatch = timestamp_3rdwatch;
    }

    @Nullable
    public String getLatest_powercycle() {
        return latest_powercycle;
    }

    public void setLatest_powercycle(@Nullable String latest_powercycle) {
        this.latest_powercycle = latest_powercycle;
    }

    public float getFiltered_temperature() {
        return filtered_temperature;
    }

    public void setFiltered_temperature(float filtered_temperature) {
        this.filtered_temperature = filtered_temperature;
    }

    @Nullable
    public String getPct_speed_met_target() {
        return pct_speed_met_target;
    }

    public void setPct_speed_met_target(@Nullable String pct_speed_met_target) {
        this.pct_speed_met_target = pct_speed_met_target;
    }

    @Nullable
    public String getAvg_dl_test_speed() {
        return avg_dl_test_speed;
    }

    public void setAvg_dl_test_speed(@Nullable String avg_dl_test_speed) {
        this.avg_dl_test_speed = avg_dl_test_speed;
    }

    @Nullable
    public String getAvg_ul_test_speed() {
        return avg_ul_test_speed;
    }

    public void setAvg_ul_test_speed(@Nullable String avg_ul_test_speed) {
        this.avg_ul_test_speed = avg_ul_test_speed;
    }

    @Nullable
    public String getExtender_sn() {
        return extender_sn;
    }

    public void setExtender_sn(@Nullable String extender_sn) {
        this.extender_sn = extender_sn;
    }

    @Nullable
    public String getExtender_mac() {
        return extender_mac;
    }

    public void setExtender_mac(@Nullable String extender_mac) {
        this.extender_mac = extender_mac;
    }

    @Nullable
    public String getRelocation_rec_level() {
        return relocation_rec_level;
    }

    public void setRelocation_rec_level(@Nullable String relocation_rec_level) {
        this.relocation_rec_level = relocation_rec_level;
    }

    @Nullable
    public String getFiltered_rssi() {
        return filtered_rssi;
    }

    public void setFiltered_rssi(@Nullable String filtered_rssi) {
        this.filtered_rssi = filtered_rssi;
    }

    @Nullable
    public String getFiltered_cpe_router_phy_rate() {
        return filtered_cpe_router_phy_rate;
    }

    public void setFiltered_cpe_router_phy_rate(@Nullable String filtered_cpe_router_phy_rate) {
        this.filtered_cpe_router_phy_rate = filtered_cpe_router_phy_rate;
    }

    @Nullable
    public String getFiltered_cpe_router_conn_rssi() {
        return filtered_cpe_router_conn_rssi;
    }

    public void setFiltered_cpe_router_conn_rssi(@Nullable String filtered_cpe_router_conn_rssi) {
        this.filtered_cpe_router_conn_rssi = filtered_cpe_router_conn_rssi;
    }

    @Nullable
    public String getExtender_recomm_level() {
        return extender_recomm_level;
    }

    public void setExtender_recomm_level(@Nullable String extender_recomm_level) {
        this.extender_recomm_level = extender_recomm_level;
    }

    @Nullable
    public String getReboot_recommendation() {
        return reboot_recommendation;
    }

    public void setReboot_recommendation(@Nullable String reboot_recommendation) {
        this.reboot_recommendation = reboot_recommendation;
    }

    @Nullable
    public String getReboot_order() {
        return reboot_order;
    }

    public void setReboot_order(@Nullable String reboot_order) {
        this.reboot_order = reboot_order;
    }

    @Nullable
    public String getReport_time() {
        return report_time;
    }

    public void setReport_time(@Nullable String report_time) {
        this.report_time = report_time;
    }

    @Nullable
    public String getTrans_dt() {
        return trans_dt;
    }

    public void setTrans_dt(@Nullable String trans_dt) {
        this.trans_dt = trans_dt;
    }

    @Nullable
    public String getAlarm_type() {
        return alarm_type;
    }

    public void setAlarm_type(@Nullable String alarm_type) {
        this.alarm_type = alarm_type;
    }

    @Nullable
    public String getAlarm_category() {
        return alarm_category;
    }

    public void setAlarm_category(@Nullable String alarm_category) {
        this.alarm_category = alarm_category;
    }

    public float getNum_reboot_7days() {
        return num_reboot_7days;
    }

    public void setNum_reboot_7days(float num_reboot_7days) {
        this.num_reboot_7days = num_reboot_7days;
    }

    @Nullable
    public String getPoor_rssi_client_info() {
        return poor_rssi_client_info;
    }

    public void setPoor_rssi_client_info(@Nullable String poor_rssi_client_info) {
        this.poor_rssi_client_info = poor_rssi_client_info;
    }

    public int getAlert_id() {
        return alert_id;
    }

    public void setAlert_id(int alert_id) {
        this.alert_id = alert_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    @Override
    public String toString() {
        return "Router5gHomeAlertType{" +
                "mdn_5g='" + mdn_5g + '\'' +
                ", serialnumber='" + serialnumber + '\'' +
                ", site_market='" + site_market + '\'' +
                ", active_user='" + active_user + '\'' +
                ", user_type=" + user_type +
                ", install_status='" + install_status + '\'' +
                ", model_name='" + model_name + '\'' +
                ", firmware_ver='" + firmware_ver + '\'' +
                ", time_zone='" + time_zone + '\'' +
                ", local_time='" + local_time + '\'' +
                ", cpu_usage=" + cpu_usage +
                ", timestamp_1stwatch='" + timestamp_1stwatch + '\'' +
                ", timestamp_3rdwatch='" + timestamp_3rdwatch + '\'' +
                ", latest_powercycle='" + latest_powercycle + '\'' +
                ", filtered_temperature=" + filtered_temperature +
                ", pct_speed_met_target='" + pct_speed_met_target + '\'' +
                ", avg_dl_test_speed='" + avg_dl_test_speed + '\'' +
                ", avg_ul_test_speed='" + avg_ul_test_speed + '\'' +
                ", extender_sn='" + extender_sn + '\'' +
                ", extender_mac='" + extender_mac + '\'' +
                ", relocation_rec_level='" + relocation_rec_level + '\'' +
                ", filtered_rssi='" + filtered_rssi + '\'' +
                ", filtered_cpe_router_phy_rate='" + filtered_cpe_router_phy_rate + '\'' +
                ", filtered_cpe_router_conn_rssi='" + filtered_cpe_router_conn_rssi + '\'' +
                ", extender_recomm_level='" + extender_recomm_level + '\'' +
                ", reboot_recommendation='" + reboot_recommendation + '\'' +
                ", reboot_order='" + reboot_order + '\'' +
                ", report_time='" + report_time + '\'' +
                ", trans_dt='" + trans_dt + '\'' +
                ", alarm_type='" + alarm_type + '\'' +
                ", alarm_category='" + alarm_category + '\'' +
                ", num_reboot_7days=" + num_reboot_7days +
                ", poor_rssi_client_info='" + poor_rssi_client_info + '\'' +
                ", alert_id=" + alert_id +
                ", id=" + id +
                ", linkageId=" + linkageId +
                '}';
    }
}
