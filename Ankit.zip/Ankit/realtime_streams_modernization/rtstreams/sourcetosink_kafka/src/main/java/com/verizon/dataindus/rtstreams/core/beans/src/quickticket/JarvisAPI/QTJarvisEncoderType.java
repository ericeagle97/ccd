package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class QTJarvisEncoderType implements Serializable {

	   @SerializedName("REF_NUMBER")
	   String REFNUMBER;

	   @SerializedName("Operation")
	   String Operation;

	   @SerializedName("COMMENTS")
	   String COMMENTS;

	   @SerializedName("JIRA_ID")
	   String JIRAID;

	   @SerializedName("ISSUE_STATUS")
	   String ISSUESTATUS;

	   @SerializedName("SOURCE")
	   String SOURCE;

	   @SerializedName("PRIORITY")
	   String PRIORITY;

	   @SerializedName("MTN")
	   String MTN;

	   @SerializedName("ACCOUNT_ID")
	   String ACCOUNTID;

	   @SerializedName("TICKET_TYPE")
	   String TICKETTYPE;

	   @SerializedName("vzwdb_create_timestamp")
	   String vzwdbCreateTimestamp;

	   @SerializedName("issue_desc")
	   String issueDesc;

	   @SerializedName("symptoms")
	   String symptoms;

	   @SerializedName("ord_loc_code")
	   String ordLocCode;

	   @SerializedName("child_count")
	   String childCount;

	   @SerializedName("channel_Id")
	   String channelId;

	   @SerializedName("REQUEST")
	   String REQUEST;

	   @SerializedName("START_TIME")
	   String STARTTIME;

	   @SerializedName("END_TIME")
	   String ENDTIME;

	   @SerializedName("timeTaken")
	   String timeTaken;

	   @SerializedName("score")
	   String score;

	   @SerializedName("temp")
	   String temp;


	    public void setREFNUMBER(String REFNUMBER) {
	        this.REFNUMBER = REFNUMBER;
	    }
	    public String getREFNUMBER() {
	        return REFNUMBER;
	    }
	    
	    public void setOperation(String Operation) {
	        this.Operation = Operation;
	    }
	    public String getOperation() {
	        return Operation;
	    }
	    
	    public void setCOMMENTS(String COMMENTS) {
	        this.COMMENTS = COMMENTS;
	    }
	    public String getCOMMENTS() {
	        return COMMENTS;
	    }
	    
	    public void setJIRAID(String JIRAID) {
	        this.JIRAID = JIRAID;
	    }
	    public String getJIRAID() {
	        return JIRAID;
	    }
	    
	    public void setISSUESTATUS(String ISSUESTATUS) {
	        this.ISSUESTATUS = ISSUESTATUS;
	    }
	    public String getISSUESTATUS() {
	        return ISSUESTATUS;
	    }
	    
	    public void setSOURCE(String SOURCE) {
	        this.SOURCE = SOURCE;
	    }
	    public String getSOURCE() {
	        return SOURCE;
	    }
	    
	    public void setPRIORITY(String PRIORITY) {
	        this.PRIORITY = PRIORITY;
	    }
	    public String getPRIORITY() {
	        return PRIORITY;
	    }
	    
	    public void setMTN(String MTN) {
	        this.MTN = MTN;
	    }
	    public String getMTN() {
	        return MTN;
	    }
	    
	    public void setACCOUNTID(String ACCOUNTID) {
	        this.ACCOUNTID = ACCOUNTID;
	    }
	    public String getACCOUNTID() {
	        return ACCOUNTID;
	    }
	    
	    public void setTICKETTYPE(String TICKETTYPE) {
	        this.TICKETTYPE = TICKETTYPE;
	    }
	    public String getTICKETTYPE() {
	        return TICKETTYPE;
	    }
	    
	    public void setVzwdbCreateTimestamp(String vzwdbCreateTimestamp) {
	        this.vzwdbCreateTimestamp = vzwdbCreateTimestamp;
	    }
	    public String getVzwdbCreateTimestamp() {
	        return vzwdbCreateTimestamp;
	    }
	    
	    public void setIssueDesc(String issueDesc) {
	        this.issueDesc = issueDesc;
	    }
	    public String getIssueDesc() {
	        return issueDesc;
	    }
	    
	    public void setSymptoms(String symptoms) {
	        this.symptoms = symptoms;
	    }
	    public String getSymptoms() {
	        return symptoms;
	    }
	    
	    public void setOrdLocCode(String ordLocCode) {
	        this.ordLocCode = ordLocCode;
	    }
	    public String getOrdLocCode() {
	        return ordLocCode;
	    }
	    
	    public void setChildCount(String childCount) {
	        this.childCount = childCount;
	    }
	    public String getChildCount() {
	        return childCount;
	    }
	    
	    public void setChannelId(String channelId) {
	        this.channelId = channelId;
	    }
	    public String getChannelId() {
	        return channelId;
	    }
	    
	    public void setREQUEST(String REQUEST) {
	        this.REQUEST = REQUEST;
	    }
	    public String getREQUEST() {
	        return REQUEST;
	    }
	    
	    public void setSTARTTIME(String STARTTIME) {
	        this.STARTTIME = STARTTIME;
	    }
	    public String getSTARTTIME() {
	        return STARTTIME;
	    }
	    
	    public void setENDTIME(String ENDTIME) {
	        this.ENDTIME = ENDTIME;
	    }
	    public String getENDTIME() {
	        return ENDTIME;
	    }
	    
	    public void setTimeTaken(String timeTaken) {
	        this.timeTaken = timeTaken;
	    }
	    public String getTimeTaken() {
	        return timeTaken;
	    }
	    
	    public void setScore(String score) {
	        this.score = score;
	    }
	    public String getScore() {
	        return score;
	    }
	    
	    public void setTemp(String temp) {
	        this.temp = temp;
	    }
	    public String getTemp() {
	        return temp;
	    }
	    
	}