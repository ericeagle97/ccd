package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class deviceInfoType implements Serializable {
	@SerializedName("applicationVersion")
	@Nullable
	private String applicationVersion;
	
	@SerializedName("sdkVersion")
	@Nullable
	private String sdkVersion;
	
	@SerializedName("packageName")
	@Nullable
	private String packageName;
	
	@SerializedName("deviceName")
	@Nullable
	private String deviceName;
	
	@SerializedName("deviceModel")
	@Nullable
	private String deviceModel;
	
	@SerializedName("os")
	@Nullable
	private String os;
	
	@SerializedName("osVersion")
	@Nullable
	private String osVersion;
	
	@SerializedName("timezone")
	@Nullable
	private String timezone;
	
	@SerializedName("locale")
	@Nullable
	private String locale;
	
	@SerializedName("connectionType")
	@Nullable
	private String connectionType;
	
	@SerializedName("networkMode")
	@Nullable
	private String networkMode;

	public String getApplicationVersion() {
		return applicationVersion;
	}

	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}

	public String getSdkVersion() {
		return sdkVersion;
	}

	public void setSdkVersion(String sdkVersion) {
		this.sdkVersion = sdkVersion;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDeviceModel() {
		return deviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	public String getNetworkMode() {
		return networkMode;
	}

	public void setNetworkMode(String networkMode) {
		this.networkMode = networkMode;
	}
	
	

}
