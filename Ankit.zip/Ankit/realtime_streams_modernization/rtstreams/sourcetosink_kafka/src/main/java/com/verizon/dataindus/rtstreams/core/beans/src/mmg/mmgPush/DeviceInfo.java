package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class DeviceInfo implements Serializable{
	
	
	
	
	@Override
	public String toString() {
		return "DeviceInfo [dropWhenForeground=" + dropWhenForeground + ", deviceInstanceId=" + deviceInstanceId
				+ ", restart=" + restart + ", externalDeeplink=" + externalDeeplink + "]";
	}
	@SerializedName("dropWhenForeground")
	@Nullable
	   boolean dropWhenForeground;

	   @SerializedName("deviceInstanceId")
	   @Nullable
	   String deviceInstanceId;

	   @SerializedName("restart")
	   @Nullable
	   String restart;

	   @SerializedName("externalDeeplink")
	   @Nullable
	   boolean externalDeeplink;


	    public void setDropWhenForeground(boolean dropWhenForeground) {
	        this.dropWhenForeground = dropWhenForeground;
	    }
	    public boolean getDropWhenForeground() {
	        return dropWhenForeground;
	    }
	    
	    public void setDeviceInstanceId(String deviceInstanceId) {
	        this.deviceInstanceId = deviceInstanceId;
	    }
	    public String getDeviceInstanceId() {
	        return deviceInstanceId;
	    }
	    
	    public void setRestart(String restart) {
	        this.restart = restart;
	    }
	    public String getRestart() {
	        return restart;
	    }
	    
	    public void setExternalDeeplink(boolean externalDeeplink) {
	        this.externalDeeplink = externalDeeplink;
	    }
	    public boolean getExternalDeeplink() {
	        return externalDeeplink;
	    }
	    
	}
