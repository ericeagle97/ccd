package com.verizon.dataindus.rtstreams.core.beans.src.quickticket;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class AADType implements Serializable {

	@SerializedName("id")
	   String id;

	   @SerializedName("search_term")
	   @JsonProperty("search_term")
	   String searchTerm;

	   @SerializedName("bot_status")
	   @JsonProperty("bot_status")
	   String botStatus;

	   @SerializedName("ratingcount")
	   String ratingcount;

	   @SerializedName("article_type")
	   @JsonProperty("article_type")
	   String articleType;

	   @SerializedName("source")
	   String source;

	   @SerializedName("calling_system")
	   @JsonProperty("calling_system")
	   String callingSystem;

	   @SerializedName("comment")
	   String comment;

	   @SerializedName("ticket")
	   String ticket;


	    public void setId(String id) {
	        this.id = id;
	    }
	    public String getId() {
	        return id;
	    }
	    
	    public void setSearchTerm(String searchTerm) {
	        this.searchTerm = searchTerm;
	    }
	    public String getSearchTerm() {
	        return searchTerm;
	    }
	    
	    public void setBotStatus(String botStatus) {
	        this.botStatus = botStatus;
	    }
	    public String getBotStatus() {
	        return botStatus;
	    }
	    
	    public void setRatingcount(String ratingcount) {
	        this.ratingcount = ratingcount;
	    }
	    public String getRatingcount() {
	        return ratingcount;
	    }
	    
	    public void setArticleType(String articleType) {
	        this.articleType = articleType;
	    }
	    public String getArticleType() {
	        return articleType;
	    }
	    
	    public void setSource(String source) {
	        this.source = source;
	    }
	    public String getSource() {
	        return source;
	    }
	    
	    public void setCallingSystem(String callingSystem) {
	        this.callingSystem = callingSystem;
	    }
	    public String getCallingSystem() {
	        return callingSystem;
	    }
	    
	    public void setComment(String comment) {
	        this.comment = comment;
	    }
	    public String getComment() {
	        return comment;
	    }
	    
	    public void setTicket(String ticket) {
	        this.ticket = ticket;
	    }
	    public String getTicket() {
	        return ticket;
	    }
	    
	}