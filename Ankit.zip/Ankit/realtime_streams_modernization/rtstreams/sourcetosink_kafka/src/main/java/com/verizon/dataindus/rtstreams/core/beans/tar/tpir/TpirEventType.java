package com.verizon.dataindus.rtstreams.core.beans.tar.tpir;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;

import org.apache.avro.reflect.Nullable;
import org.json.simple.JSONObject;

import java.io.Serializable;
import java.util.List;


@javax.annotation.Nullable

public class TpirEventType implements Serializable{
	
	@SerializedName("tpirxml")
	@Nullable
	public String tpirxml;
	
	@SerializedName("requestID")
	@Nullable
	public String requestID;
	
	@SerializedName("mtn")
	@Nullable
	List<String> mtn;

	public String getTpirxml() {
		return tpirxml;
	}

	public void setTpirxml(String tpirxml) {
		this.tpirxml = tpirxml;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public List<String> getMtn() {
		return mtn;
	}

	public void setMtn(List<String> mtn) {
		this.mtn = mtn;
	}

	@Override
	public String toString() {
		return "TpirEventType [tpirxml=" + tpirxml + ", requestID=" + requestID + ", mtn=" + mtn + "]";
	}

}
