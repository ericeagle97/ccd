package com.verizon.dataindus.rtstreams.core.beans.tar.port;

import java.io.Serializable;

public class keyAttributesType implements Serializable{
	
	 public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public String getInsightValues() {
		return insightValues;
	}
	public void setInsightValues(String insightValues) {
		this.insightValues = insightValues;
	}
	public String getInsightName() {
		return insightName;
	}
	public void setInsightName(String insightName) {
		this.insightName = insightName;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getMtn() {
		return mtn;
	}
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getInsightCategory() {
		return insightCategory;
	}
	public void setInsightCategory(String insightCategory) {
		this.insightCategory = insightCategory;
	}
	public String getUpdateTs() {
		return updateTs;
	}
	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}
	public String getTtl() {
		return ttl;
	}
	public void setTtl(String ttl) {
		this.ttl = ttl;
	}
	private String acctNo;
	 private String insightValues;
	 private String insightName;
	 private String updateBy;
	 private String mtn;
	 private String custId;
	 private String insightCategory;
	 private String updateTs;
	 private String ttl;

}
