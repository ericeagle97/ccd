package com.verizon.dataindus.rtstreams.core.constants.wifianalyzer;

public class WifiAnalyzerLogicConstants {

    public static final String CASSANDRA_REQUEST_TYPE = "SOI_InsertAggrProductInsights_ttl";

   // public static final String CASSANDRA_ENDPOINT = "https://mcscmpt3-pnosoi.ebiz.verizon.com/PNO/request";
    public static final String CHANNEL = "ZineoneStream";
   
    public static final String SESSION_Id = "sessionId";
    public static final String INSIGHT_VALUES = "insightValues";
    public static final String INSIGHT_CATEGORY = "insightCategory";
   
    
    public static final String INSIGHT_NAME = "insightName";
   
    public static final String EPP = "epp";
   
   
    public static final String KEY_ATTRIBUTES = "keyAttributes";
    public static final String USER_ID = "userID";
    public static final String SESSION_ID = "sessionID";
    public static final String USECASE_ID = "usecaseID";
    public static final String VIS_HASHED_ACCOUNT_NO = "visHashedAccountNumber";
    public static final String VIS_HASED_MDN = "visHashedMdn";
    public static final Object CUSTOMER ="customer" ;
    public static final Object KEY_RING_TABLE = "keyring";
    public static final String GENERIC_SCORE = "GenericScore";
    public static final String MTN ="mtn" ;
    public static final String CUST_ID = "cust_id";
    public static final String ACCT_NO = "acct_no";
    public static final String SESSION_INSIGHTS = "SessionInsights";
    public static final String RESULTS = "results";
    public static final String OUTCOME = "outcome";
    public static final String CFD = "cfd";
    public static final String SCORES = "scores";

    
    public static final String AGGR_PRODID = "aggrProdId";
    public static final String AGGR_NAME = "aggrName";
    public static final String AGGR_VALUES = "aggrValues";
    public static final String AGGR_CATEGORY = "aggrCategory";
    public static final String UPDATE_BY = "updateBy";
    public static final String LOWER_STREAMS = "streams";
    public static final String STREAMS = "Streams";
    public static final String REQUESTED_BY = "requestedBy";
    public static final String TTL_VALUE = "15780000";
    public static final String TTL = "ttl";
    public static final String TIME = "time";
    public static final String MDN ="mdn" ;
    public static final String WIFIANLYZER_RAW ="wifianlyzer_raw" ;
    public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String TIME_ZONE = " GMT";
    public static final String UPDATE_TS = "updateTs";
    
    
   
}
