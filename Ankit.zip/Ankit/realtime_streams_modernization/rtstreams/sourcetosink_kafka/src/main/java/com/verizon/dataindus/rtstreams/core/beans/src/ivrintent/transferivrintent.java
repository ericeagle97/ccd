package com.verizon.dataindus.rtstreams.core.beans.src.ivrintent;

import autovalue.shaded.org.jetbrains.annotations.Nullable;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class transferivrintent implements Serializable {
	
	
	
	
	
	
	
	public String getCall_ivr_device_id() {
		return call_ivr_device_id;
	}


	public void setCall_ivr_device_id(String call_ivr_device_id) {
		this.call_ivr_device_id = call_ivr_device_id;
	}


	public String getCall_ivr_fb_npp_tsr_seg_cplx() {
		return call_ivr_fb_npp_tsr_seg_cplx;
	}


	public void setCall_ivr_fb_npp_tsr_seg_cplx(String call_ivr_fb_npp_tsr_seg_cplx) {
		this.call_ivr_fb_npp_tsr_seg_cplx = call_ivr_fb_npp_tsr_seg_cplx;
	}


	public String getCall_ivr_lang() {
		return call_ivr_lang;
	}


	public void setCall_ivr_lang(String call_ivr_lang) {
		this.call_ivr_lang = call_ivr_lang;
	}


	public String getCall_is_save_call() {
		return call_is_save_call;
	}


	public void setCall_is_save_call(String call_is_save_call) {
		this.call_is_save_call = call_is_save_call;
	}


	public String getCall_timestamp() {
		return call_timestamp;
	}


	public void setCall_timestamp(String call_timestamp) {
		this.call_timestamp = call_timestamp;
	}


	public String getCall_ivr_customer_intent() {
		return call_ivr_customer_intent;
	}


	public void setCall_ivr_customer_intent(String call_ivr_customer_intent) {
		this.call_ivr_customer_intent = call_ivr_customer_intent;
	}


	public String getCall_ivr_cacs_level() {
		return call_ivr_cacs_level;
	}


	public void setCall_ivr_cacs_level(String call_ivr_cacs_level) {
		this.call_ivr_cacs_level = call_ivr_cacs_level;
	}


	public String getCall_ivr_device_category() {
		return call_ivr_device_category;
	}


	public void setCall_ivr_device_category(String call_ivr_device_category) {
		this.call_ivr_device_category = call_ivr_device_category;
	}


	public String getAni() {
		return ani;
	}


	public void setAni(String ani) {
		this.ani = ani;
	}


	public String getCallId() {
		return callId;
	}


	public void setCallId(String callId) {
		this.callId = callId;
	}


	public String getCall_ivr_wallet() {
		return call_ivr_wallet;
	}


	public void setCall_ivr_wallet(String call_ivr_wallet) {
		this.call_ivr_wallet = call_ivr_wallet;
	}


	public String getCall_category_stated_intent() {
		return call_category_stated_intent;
	}


	public void setCall_category_stated_intent(String call_category_stated_intent) {
		this.call_category_stated_intent = call_category_stated_intent;
	}


	public String getCall_ivr_work_state() {
		return call_ivr_work_state;
	}


	public void setCall_ivr_work_state(String call_ivr_work_state) {
		this.call_ivr_work_state = call_ivr_work_state;
	}


	public String getMtn() {
		return mtn;
	}


	public void setMtn(String mtn) {
		this.mtn = mtn;
	}


	public String getCall_ivr_hrp() {
		return call_ivr_hrp;
	}


	public void setCall_ivr_hrp(String call_ivr_hrp) {
		this.call_ivr_hrp = call_ivr_hrp;
	}


	public String getCall_time_of_day() {
		return call_time_of_day;
	}


	public void setCall_time_of_day(String call_time_of_day) {
		this.call_time_of_day = call_time_of_day;
	}


	public String getEventts() {
		return eventts;
	}


	public void setEventts(String eventts) {
		this.eventts = eventts;
	}


	public String getCall_ivr_solution_teams() {
		return call_ivr_solution_teams;
	}


	public void setCall_ivr_solution_teams(String call_ivr_solution_teams) {
		this.call_ivr_solution_teams = call_ivr_solution_teams;
	}


	public String getCall_day_of_week() {
		return call_day_of_week;
	}


	public void setCall_day_of_week(String call_day_of_week) {
		this.call_day_of_week = call_day_of_week;
	}


	public String getCall_ivr_high_risk_loe() {
		return call_ivr_high_risk_loe;
	}


	public void setCall_ivr_high_risk_loe(String call_ivr_high_risk_loe) {
		this.call_ivr_high_risk_loe = call_ivr_high_risk_loe;
	}


	public String getCall_ivr_account_type() {
		return call_ivr_account_type;
	}


	public void setCall_ivr_account_type(String call_ivr_account_type) {
		this.call_ivr_account_type = call_ivr_account_type;
	}


	public String getCall_ivr_cust_value() {
		return call_ivr_cust_value;
	}


	public void setCall_ivr_cust_value(String call_ivr_cust_value) {
		this.call_ivr_cust_value = call_ivr_cust_value;
	}


	public String getCall_ivr_onebill() {
		return call_ivr_onebill;
	}


	public void setCall_ivr_onebill(String call_ivr_onebill) {
		this.call_ivr_onebill = call_ivr_onebill;
	}


	public String getCall_ivr_onstar_qes() {
		return call_ivr_onstar_qes;
	}


	public void setCall_ivr_onstar_qes(String call_ivr_onstar_qes) {
		this.call_ivr_onstar_qes = call_ivr_onstar_qes;
	}


	public String getCustomerid() {
		return customerid;
	}


	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}


	public String getCall_ivr_special_handling() {
		return call_ivr_special_handling;
	}


	public void setCall_ivr_special_handling(String call_ivr_special_handling) {
		this.call_ivr_special_handling = call_ivr_special_handling;
	}


	public String getCall_ivr_assoc() {
		return call_ivr_assoc;
	}


	public void setCall_ivr_assoc(String call_ivr_assoc) {
		this.call_ivr_assoc = call_ivr_assoc;
	}


	public String getCall_ivr_hq_route_value() {
		return call_ivr_hq_route_value;
	}


	public void setCall_ivr_hq_route_value(String call_ivr_hq_route_value) {
		this.call_ivr_hq_route_value = call_ivr_hq_route_value;
	}


	public String getCall_speech_tag() {
		return call_speech_tag;
	}


	public void setCall_speech_tag(String call_speech_tag) {
		this.call_speech_tag = call_speech_tag;
	}


	@Nullable
	@SerializedName("call_ivr_device_id")
	private String call_ivr_device_id;
	
	@Nullable
	@SerializedName("call_ivr_fb_npp_tsr_seg_cplx")
	private String call_ivr_fb_npp_tsr_seg_cplx;
	
	@Nullable
	@SerializedName("call_ivr_lang")
	private String call_ivr_lang;
	
	@Nullable
	@SerializedName("call_is_save_call")
	private String call_is_save_call;
	
	@Nullable
	@SerializedName("call_timestamp")
	private String call_timestamp;
	
	@Nullable
	@SerializedName("call_ivr_customer_intent")
	private String call_ivr_customer_intent;
	
	@Nullable
	@SerializedName("call_ivr_cacs_level")
	private String call_ivr_cacs_level;
	
	@Nullable
	@SerializedName("call_ivr_device_category")
	private String call_ivr_device_category;
	
	@Nullable
	@SerializedName("ani")
	private String ani;

	
	@Nullable
	@SerializedName("callId")
	private String callId;
	
	@Nullable
	@SerializedName("call_ivr_wallet")
	private String call_ivr_wallet;
	
	
	@Nullable
	@SerializedName("call_category_stated_intent")
	private String call_category_stated_intent;

	@Nullable
	@SerializedName("call_ivr_work_state")
	private String call_ivr_work_state;
	
	@Nullable
	@SerializedName("mtn")
	private String mtn;
	
	@Nullable
	@SerializedName("call_ivr_hrp")
	private String call_ivr_hrp;
	
	
	@Nullable
	@SerializedName("call_time_of_day")
	private String call_time_of_day;
	
	
	@Nullable
	@SerializedName("eventts")
	private String eventts;
	
	@Nullable
	@SerializedName("call_ivr_solution_teams")
	private String call_ivr_solution_teams;
	
	
	@Nullable
	@SerializedName("call_day_of_week")
	private String call_day_of_week;
	
	@Nullable
	@SerializedName("call_ivr_high_risk_loe")
	private String call_ivr_high_risk_loe;
	
	@Nullable
	@SerializedName("call_ivr_account_type")
	private String call_ivr_account_type;
	
	@Nullable
	@SerializedName("call_ivr_cust_value")
	private String call_ivr_cust_value;
	
	@Nullable
	@SerializedName("call_ivr_onebill")
	private String call_ivr_onebill;
	
	@Nullable
	@SerializedName("call_ivr_onstar_qes")
	private String call_ivr_onstar_qes;
	
	@Nullable
	@SerializedName("customerid")
	private String customerid;
	
	
	@Nullable
	@SerializedName("call_ivr_special_handling")
	private String call_ivr_special_handling;
	
	@Nullable
	@SerializedName("call_ivr_assoc")
	private String call_ivr_assoc;
	
	@Nullable
	@SerializedName("call_ivr_hq_route_value")
	private String call_ivr_hq_route_value;
	
	
	@Nullable
	@SerializedName("call_speech_tag")
	private String call_speech_tag;
	
	
}
