package com.verizon.dataindus.rtstreams.core.beans.src.aepaudiences;

import java.util.ArrayList;
import java.util.List;

public class audience_convert_type {
    private String lastQualificationTime;
    private String  status;
    private String  mtn;
    private String mtnCustHash;
    private String  name;

    List<String> audiences;

    public List<String> getAudiences() {
        return audiences;
    }

    public void setAudiences(List<String> audiences) {
        this.audiences = audiences;
    }

    public void addAudience(String audience) {
        if(audiences==null) {
            audiences = new ArrayList<String>();
        }
        audiences.add(audience);
    }
    public String getMtnCustHash() {
        return mtnCustHash;
    }
    public void setMtnCustHash(String mtnCustHash) {
        this.mtnCustHash = mtnCustHash;
    }

    public String getLastQualificationTime() {
        return lastQualificationTime;
    }

    public void setLastQualificationTime(String lastQualificationTime) {
        this.lastQualificationTime = lastQualificationTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "aepservice_convert_type [lastQualificationTime=" + lastQualificationTime + ", status=" + status
                + ", mtn=" + mtn + ", mtnCustHash=" + mtnCustHash + ", name=" + name + ", audiences=" + audiences + "]";
    }
}
