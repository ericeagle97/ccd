package com.verizon.dataindus.rtstreams.core.factory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Map;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.serialization.StringSerializer;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.StorageOptions;
import com.google.common.collect.Lists;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.Properties;

class KafkaWriteJKS 
{
	private static volatile KafkaWriteJKS singleton;
	static String bucket;
	static String keyFile;
	private KafkaWriteJKS(String  strBucket,String strKeyFile)
	{
		KafkaWriteJKS.bucket=strBucket;
		KafkaWriteJKS.keyFile=strKeyFile;
		/* Creating object for custom exception class*/
		ExceptionsUtils exceptions=new ExceptionsUtils();
		try {
			/*Accessing the kafka credentials from GCS bucket and passing to SSLTrustStore*/
			GoogleCredentials credentialsNew = GoogleCredentials.getApplicationDefault().createScoped(Lists.newArrayList(Constants.GCP_AUTH_CRED));
			com.google.cloud.storage.Storage storage = StorageOptions.newBuilder().setCredentials(credentialsNew).build().getService();
						
			/*Specifying Bucket and file name where JKS file located*/			
			Blob blob = storage.get(bucket, keyFile);
			ReadChannel readChannel = blob.reader();
			FileOutputStream fileOuputStream;

			/*Downloads file from GCS and store in tmp location*/
			fileOuputStream = new FileOutputStream(Constants.TMP_PATH+
					keyFile.substring(keyFile.lastIndexOf("/") + 1)); //path where the jks file will be stored
			fileOuputStream.getChannel().transferFrom(readChannel, 0, Long.MAX_VALUE);
			fileOuputStream.close(); 
		}
		catch (IOException e) 
		{
			/*Throws excpetion when not able to read file*/
			exceptions.ioException(Properties.CLASS_KAFKAWRITEJKS,e);
		}
	}
	public static KafkaWriteJKS getInstance(String bucket, String keyFile) throws IOException, UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException{
		if(singleton == null) {
			synchronized (KafkaWriteJKS.class) {	
				if (singleton == null) {
					singleton = new KafkaWriteJKS(bucket,keyFile); 
				}
			}
		}
		return singleton;
	}
}

public class ProducerFactoryFn implements SerializableFunction<Map<String, Object>, Producer<Void, String>>
{
	private static final long serialVersionUID = 1L;
	String bucket;
	String keyFile;

	public ProducerFactoryFn(String  strBucket,String strKeyFile)
	{
		this.bucket=strBucket;
		this.keyFile=strKeyFile;
	}
	public Producer<Void, String> apply(Map<String, Object> config) 
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils exceptions=new ExceptionsUtils();
		/*assuring the store file exists*/
		File f = new File(Constants.TMP_PATH+keyFile.substring(keyFile.lastIndexOf("/") + 1)); 
		if (f.exists())
		{

		}
		else
		{
			try {
				KafkaWriteJKS.getInstance(bucket,keyFile);
			} catch (UnrecoverableKeyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KeyManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (KeyStoreException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CertificateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*Assigning download object o TRUSTSTORE*/
		config.put(Constants.SSL_TRUSTSTORE_LOCATION,(Object) Constants.TMP_PATH+keyFile.substring(keyFile.lastIndexOf("/") + 1));
		//return new KafkaProducer<String, String>(config);
		return new KafkaProducer<>(config);
	}
}
