package com.verizon.dataindus.rtstreams.core.beans.src.ivrcallpredictives;

@javax.annotation.Nullable
public class InsightValue {


}