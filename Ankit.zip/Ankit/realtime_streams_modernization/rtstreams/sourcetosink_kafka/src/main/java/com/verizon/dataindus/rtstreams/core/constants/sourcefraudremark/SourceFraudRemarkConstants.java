package com.verizon.dataindus.rtstreams.core.constants.sourcefraudremark;

public class SourceFraudRemarkConstants {
	public static final String FRAUDREMARK_CUSTTYPE = "custType";
	public static final String FRAUDREMARK_CUSTID = "custId";
	public static final String FRAUDREMARK_EXISTINGACCOUNTFLAG = "existingAccountFlag";
	public static final String FRAUDREMARK_SUBMITTERID = "submitterId";
	public static final String FRAUDREMARK_SUBMITTERDEPTNAME = "submitterDeptName";
	public static final String FRAUDREMARK_SUBMITTEREMAIL = "submitterEmail";
	public static final String FRAUDREMARK_SUBMITTERNAME = "submitterName";
	public static final String FRAUDREMARK_ISSUEID = "issueId";
	public static final String FRAUDREMARK_REMARKS = "remarks";
	public static final String FRAUDREMARK_TIME = "time";
	public static final String FRAUDREMARK_EVENTTIME = "eventTime";
	public static final String FRAUDREMARK_DATE = "date";
	public static final String FRAUDREMARK_EVENTDATE = "eventDate";
	public static final String FRAUDREMARK_INSIGHTVALUES = "insightValues";
	public static final String FRAUDREMARK_UPDATEBY = "updateBy";
	public static final String FRAUDREMARK_CREATEDBY = "createdBy";
	public static final String FRAUDREMARK_UPDATETS = "updateTs";
	public static final String FRAUDREMARK_KEYATTRIBUTES = "keyAttributes";
	public static final String FRAUDREMARK_INTERACTIONS = "interactions";
	public static final String FRAUDREMARK_INSIGHTCATEGORY = "insightCategory";
	public static final String FRAUDREMARK_INSIGHTNAME = "insightName";
	public static final String FRAUDREMARK_FRAUDINTAKE = "fraud_intake";
	public static final String FRAUDREMARK_TTL = "ttl";
	public static final String FRAUDREMARK_MTN = "mtn";
	public static final String FRAUDREMARK_ACCTNO = "acctNo";
	public static final String FRAUDREMARK_ACCTNUM = "acctNum";
	public static final String FRAUDREMARK_CURRENTVALUES = "currentvalues";
	public static final String FRAUDREMARK_REQUESTTYPE = "requestType";
	public static final String FRAUDREMARK_STREAMS = "streams";
	public static final String CHANNEL = "SourceFraudRemark";

	public static final String FRAUDREMARK_TTL_VALUE = "604800";
	public static final String FRAUDREMARK_MTN_VALUE = "9999999999";
	public static final String JOBNAME = "fraud_remark";

}
