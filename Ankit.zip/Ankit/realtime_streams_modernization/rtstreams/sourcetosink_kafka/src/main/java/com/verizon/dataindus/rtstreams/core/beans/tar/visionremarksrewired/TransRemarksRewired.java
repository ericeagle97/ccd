package com.verizon.dataindus.rtstreams.core.beans.tar.visionremarksrewired;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class TransRemarksRewired implements Serializable, Cloneable {

	@SerializedName("L1")
	@Nullable
	String l1;

	@SerializedName("L2")
	@Nullable
	String l2;

	@SerializedName("L3")
	@Nullable
	String l3;

	@SerializedName("mtn")
	@Nullable
	String mtn;

	@SerializedName("ACCOUNT_NO")
	@Nullable
	String acctNo;

	@SerializedName("CUST_ID")
	@Nullable
	String custIdNo;

	@SerializedName("REMARKS")
	@Nullable
	String remarks;
	@SerializedName("region")
	@Nullable
	String region;

	@SerializedName("remarkType")
	@Nullable
	String remarkType;

	@SerializedName("channel")
	@Nullable
	String channel;

	@SerializedName("REMARKS_DATE")
	@Nullable
	String remarksDate;

	@SerializedName("linkageId")
	@Nullable
	String linkageId;

	@SerializedName("orgData")
	@Nullable
	String orgData;

	public String getOrgData() {
		return orgData;
	}

	public void setOrgData(String orgData) {
		this.orgData = orgData;
	}

	public String getLinkageId() {
		return linkageId;
	}

	public void setLinkageId(String linkageId) {
		this.linkageId = linkageId;
	}

	public String getL1() {
		return l1;
	}

	public void setL1(String l1) {
		this.l1 = l1;
	}

	public String getL2() {
		return l2;
	}

	public void setL2(String l2) {
		this.l2 = l2;
	}

	public String getL3() {
		return l3;
	}

	public void setL3(String l3) {
		this.l3 = l3;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public String getCustIdNo() {
		return custIdNo;
	}

	public void setCustIdNo(String custIdNo) {
		this.custIdNo = custIdNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRemarkType() {
		return remarkType;
	}

	public void setRemarkType(String remarkType) {
		this.remarkType = remarkType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getRemarksDate() {
		return remarksDate;
	}

	public void setRemarksDate(String remarksDate) {
		this.remarksDate = remarksDate;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "TransRemarksRewired{" + "l1='" + l1 + '\'' + ", l2='" + l2 + '\'' + ", l3='" + l3 + '\'' + ", mtn='"
				+ mtn + '\'' + ", acctNo='" + acctNo + '\'' + ", custIdNo='" + custIdNo + '\'' + ", remarks='" + remarks
				+ '\'' + ", region='" + region + '\'' + ", remarkType='" + remarkType + '\'' + ", channel='" + channel
				+ '\'' + ", remarksDate='" + remarksDate + '\'' + '}';
	}
}