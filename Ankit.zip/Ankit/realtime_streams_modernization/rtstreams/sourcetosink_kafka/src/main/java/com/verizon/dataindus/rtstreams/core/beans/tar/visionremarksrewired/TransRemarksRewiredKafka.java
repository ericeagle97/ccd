package com.verizon.dataindus.rtstreams.core.beans.tar.visionremarksrewired;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY,
        getterVisibility = JsonAutoDetect.Visibility.NONE,
        setterVisibility = JsonAutoDetect.Visibility.NONE)
public class TransRemarksRewiredKafka implements Serializable, Cloneable {

    @JsonProperty("L1")
    @Nullable
    String l1 = "";

    @JsonProperty("L2")
    @Nullable
    String l2 = "";

    @JsonProperty("L3")
    @Nullable
    String l3 = "";

    @JsonProperty("mtn")
    @Nullable
    String mtn = "";

    @JsonProperty("ACCOUNT_NO")
    @Nullable
    String acctNo = "";

    @JsonProperty("CUST_ID")
    @Nullable
    String custIdNo = "";

    @JsonProperty("REMARKS")
    @Nullable
    String remarks = "";
    @JsonProperty("region")
    @Nullable
    String region = "";

    @JsonProperty("remarkType")
    @Nullable
    String remarkType = "";

    @JsonProperty("channel")
    @Nullable
    String channel = "";

    @JsonProperty("REMARKS_DATE")
    @Nullable
    String remarksDate = "";


    public String getL1() {
        return l1;
    }

    public void setL1(String l1) {
        this.l1 = l1;
    }

    public String getL2() {
        return l2;
    }

    public void setL2(String l2) {
        this.l2 = l2;
    }

    public String getL3() {
        return l3;
    }

    public void setL3(String l3) {
        this.l3 = l3;
    }

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getCustIdNo() {
        return custIdNo;
    }

    public void setCustIdNo(String custIdNo) {
        this.custIdNo = custIdNo;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getRemarkType() {
        return remarkType;
    }

    public void setRemarkType(String remarkType) {
        this.remarkType = remarkType;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getRemarksDate() {
        return remarksDate;
    }

    public void setRemarksDate(String remarksDate) {
        this.remarksDate = remarksDate;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return "TransRemarksRewired{" + "l1='" + l1 + '\'' + ", l2='" + l2 + '\'' + ", l3='" + l3 + '\'' + ", mtn='"
                + mtn + '\'' + ", acctNo='" + acctNo + '\'' + ", custIdNo='" + custIdNo + '\'' + ", remarks='" + remarks
                + '\'' + ", region='" + region + '\'' + ", remarkType='" + remarkType + '\'' + ", channel='" + channel
                + '\'' + ", remarksDate='" + remarksDate + '\'' + '}';
    }
}
