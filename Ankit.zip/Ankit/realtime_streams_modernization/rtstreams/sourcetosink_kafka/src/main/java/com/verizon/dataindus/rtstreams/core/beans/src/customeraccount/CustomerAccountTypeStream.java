package com.verizon.dataindus.rtstreams.core.beans.src.customeraccount;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;


@javax.annotation.Nullable
public class CustomerAccountTypeStream implements Serializable {
	
	@SerializedName("userSession")
	@Nullable
	String userSession;
	
	@SerializedName("custId")
	@Nullable
	String custId;
	
	@SerializedName("accountId")
	@Nullable
	String accountId;
	
	@SerializedName("mtn")
	@Nullable
	String mtn;
	
	@SerializedName("businessUnit")
	@Nullable
	String businessUnit;

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	@SerializedName("start_time")
	@Nullable
	String start_time;
	
	public String getUserSession() {
		return userSession;
	}

	public void setUserSession(String userSession) {
		this.userSession = userSession;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

}
