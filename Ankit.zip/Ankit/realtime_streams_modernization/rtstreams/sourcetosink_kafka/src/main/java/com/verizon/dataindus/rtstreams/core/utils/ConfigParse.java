package com.verizon.dataindus.rtstreams.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.yaml.snakeyaml.Yaml;

//import com.verizon.dataindus.rtstreams.core.utils.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.Properties;
import com.verizon.dataindus.rtstreams.core.constants.Properties.className;

/*
 *Config Parse class will parse the job specific yaml file from the config path and generates HashMap & returns the same HashMap. 
 */
public class ConfigParse 
{
	/*Variable to store config path*/
	public static String configPath="";
	
	/*HashMap variable to store job specific config parameters from the config file*/
	public static  Map<String, Object> parameters= new HashMap<String, Object>();
	
	public Map<String, Object> configParse(String job_name)   
	{
		/*Creating object for custom exception class*/
		InputStream yamlInputStream = null;

		try 
		{
			/*Reads the job specific config file*/
			yamlInputStream = new FileInputStream(new File(configPath+job_name+".yaml"));
		} 
		catch (Exception e) 
		{
			/* Throws an generic exception*/
			e.printStackTrace(System.out);
		}
		
		/*configYaml object to read yaml data*/
		Yaml configYaml = new Yaml();
		
		/*Stores yaml configues as HashMap variable*/
		parameters = configYaml.load(yamlInputStream);
		return parameters;
	}

}


