package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class utmType implements Serializable {

	public String getUtm_campaign() {
		return utm_campaign;
	}

	public void setUtm_campaign(String utm_campaign) {
		this.utm_campaign = utm_campaign;
	}

	public String getUtm_medium() {
		return utm_medium;
	}

	public void setUtm_medium(String utm_medium) {
		this.utm_medium = utm_medium;
	}

	public String getUtm_source() {
		return utm_source;
	}

	public void setUtm_source(String utm_source) {
		this.utm_source = utm_source;
	}

	public String getUtm_content() {
		return utm_content;
	}

	public void setUtm_content(String utm_content) {
		this.utm_content = utm_content;
	}

	@SerializedName("utm_campaign")
	@JsonProperty("utm_campaign")
	@JsonAlias({"utm_campaign"})
	@Nullable
	private String utm_campaign;
	
	@SerializedName("utm_medium")
	@JsonProperty("utm_medium")
	@JsonAlias({"utm_medium"})
	@Nullable
	private String utm_medium;
	
	@SerializedName("utm_source")
	@JsonProperty("utm_source")
	@JsonAlias({"utm_source"})
	@Nullable
	private String utm_source;
	
	@SerializedName("utm_content")
	@JsonProperty("utm_content")
	@JsonAlias({"utm_content"})
	@Nullable
	private String utm_content;

}
