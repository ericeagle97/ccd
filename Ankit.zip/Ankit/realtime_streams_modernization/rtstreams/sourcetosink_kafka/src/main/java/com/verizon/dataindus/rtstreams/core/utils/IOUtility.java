package com.verizon.dataindus.rtstreams.core.utils;

import org.apache.beam.repackaged.core.org.apache.commons.lang3.StringUtils;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.joda.time.Duration;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

public class IOUtility {

	public static void applyWindowAndWriteToGCS(PCollection<String> data,int windowInSec, String filePath, 
			String fileName,int numShards) {
		//String fileFormat = String.format("GCS fileSink - (%s)", StringUtils.substringAfter(filePath, "/"));
		
		String fileFormat = String.format("GCS fileSink - %s(%s)", StringUtils.substringAfterLast(filePath.substring(0,filePath.lastIndexOf("/")),"/"), fileName);
		data.apply(Window.<String>into(FixedWindows.of(Duration
				.standardSeconds(windowInSec)))
				.withAllowedLateness(Duration.standardHours(5))
				.discardingFiredPanes())
		.apply(fileFormat, WriteToGcs.writeToGCS(filePath,
				fileName,numShards));
	}

	public static void deadLetterOptionalSink (String deadletterOption, PCollection<String> invalidData,
			String pubsubTopic, int windowInSec, String filePath, String fileName,int numShards) {
		// Dead letters for Invalid Records 
		if((Constants.GCS).equalsIgnoreCase(deadletterOption)) 
		{
			// Dead letter GCS Sink
			applyWindowAndWriteToGCS(invalidData, Integer.valueOf(windowInSec),
					filePath,fileName,Integer.valueOf(numShards));
		}
		else if ((Constants.PUBSUB).equalsIgnoreCase(deadletterOption))
		{
			// Dead letter Pub Sub Topic
			invalidData.apply(String.format("Pubsub topicSink - %1$s",StringUtils.substringAfterLast(pubsubTopic, "/")), PubsubIO.writeStrings().to(pubsubTopic));
		}
	}

}
