package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class CustomerInfo implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("registrationStatus")
   String registrationStatus;

   @Nullable
	@SerializedName("registrationRequired")
   String registrationRequired;

   @Nullable
	@SerializedName("entitlementStatusCode")
   String entitlementStatusCode;

   @Nullable
	@SerializedName("customerId")
   String customerId;

   @Nullable
	@SerializedName("accountNumber")
   String accountNumber;

   @Nullable
	@SerializedName("cartCreator")
   String cartCreator;

   @Nullable
	@SerializedName("isNotified")
   String isNotified;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setRegistrationStatus(String registrationStatus) {
        this.registrationStatus = registrationStatus;
    }
    public String getRegistrationStatus() {
        return registrationStatus;
    }
    
    public void setRegistrationRequired(String registrationRequired) {
        this.registrationRequired = registrationRequired;
    }
    public String getRegistrationRequired() {
        return registrationRequired;
    }
    
    public void setEntitlementStatusCode(String entitlementStatusCode) {
        this.entitlementStatusCode = entitlementStatusCode;
    }
    public String getEntitlementStatusCode() {
        return entitlementStatusCode;
    }
    
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getCustomerId() {
        return customerId;
    }
    
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public void setCartCreator(String cartCreator) {
        this.cartCreator = cartCreator;
    }
    public String getCartCreator() {
        return cartCreator;
    }
    
    public void setIsNotified(String isNotified) {
        this.isNotified = isNotified;
    }
    public String getIsNotified() {
        return isNotified;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
}