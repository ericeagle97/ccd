package com.verizon.dataindus.rtstreams.core.constants.vlm;

public class VlmConstants {

	public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String GMT = " GMT";
	public static final String REGISTRANTID = "registrantId";
	public static final String MDN = "mdn";
	public static final String ACCOUNTNO = "accountNo";
	public static final String REASONCODE = "reasonCode";
	public static final String VLMCODE = "vlmCode";
	public static final String POSLOCCODE = "posLocCode";
	public static final String LOCATIONNAME = "locationName";
	public static final String TIMEZONE = "timeZone";
	public static final String APPOINTMENTDATE = "appointmentDate";
	public static final String STARTTIME = "startTime";
	public static final String STATUS = "status";
	public static final String ENDTIME = "endTime";
	public static final String STRSTREAMSTIMESTAMP = "streamsTimestamp";
	public static final String REQUESTTYPE = "SOI_InsertCustomerInsights";

}
