package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class PaymentInfo implements Serializable {

   @Nullable
	@SerializedName("paymentCardList")
   List<PaymentCardList> paymentCardList;


    public void setPaymentCardList(List<PaymentCardList> paymentCardList) {
        this.paymentCardList = paymentCardList;
    }
    public List<PaymentCardList> getPaymentCardList() {
        return paymentCardList;
    }
    
}