package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class LayeroneOutputType implements Serializable {


    // rstring modelName, rstring clientId, rstring acctNo, rstring aiProcessorLogID, rstring modelVersion, rstring mtn, rstring event_dt, ServiceRequestType serviceRequest, ServiceResponseType serviceResponse, rstring custId, rstring totalResponseTime, rstring clientTransactionId;
    @Nullable
    @SerializedName("modelName")
    String modelName;

    @Nullable
    @SerializedName("clientId")
    String clientId;

    @Nullable
    @SerializedName("acctNo")
    String acctNo;

    @Nullable
    @SerializedName("aiProcessorLogID")
    String aiProcessorLogID;

    @Nullable
    @SerializedName("modelVersion")
    String modelVersion;

    @Nullable
    @SerializedName("mtn")
    String mtn;

    @Nullable
    @SerializedName("event_dt")
    String event_dt;

    @Nullable
    @SerializedName("serviceRequest")
    ServiceRequestType serviceRequest;

    @Nullable
    @SerializedName("serviceResponse")
    ServiceResponseType  serviceResponse;

    @Nullable
    @SerializedName("custId")
    String custId;

    @Nullable
    @SerializedName("totalResponseTime")
    String totalResponseTime;

    @Nullable
    @SerializedName("clientTransactionId")
    String clientTransactionId;

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getAiProcessorLogID() {
        return aiProcessorLogID;
    }

    public void setAiProcessorLogID(String aiProcessorLogID) {
        this.aiProcessorLogID = aiProcessorLogID;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public void setModelVersion(String modelVersion) {
        this.modelVersion = modelVersion;
    }

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getEvent_dt() {
        return event_dt;
    }

    public void setEvent_dt(String event_dt) {
        this.event_dt = event_dt;
    }

    public ServiceRequestType getServiceRequest() {
        return serviceRequest;
    }

    public void setServiceRequest(ServiceRequestType serviceRequest) {
        this.serviceRequest = serviceRequest;
    }

    public ServiceResponseType getServiceResponse() {
        return serviceResponse;
    }

    public void setServiceResponse(ServiceResponseType serviceResponse) {
        this.serviceResponse = serviceResponse;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getTotalResponseTime() {
        return totalResponseTime;
    }

    public void setTotalResponseTime(String totalResponseTime) {
        this.totalResponseTime = totalResponseTime;
    }

    public String getClientTransactionId() {
        return clientTransactionId;
    }

    public void setClientTransactionId(String clientTransactionId) {
        this.clientTransactionId = clientTransactionId;
    }
}