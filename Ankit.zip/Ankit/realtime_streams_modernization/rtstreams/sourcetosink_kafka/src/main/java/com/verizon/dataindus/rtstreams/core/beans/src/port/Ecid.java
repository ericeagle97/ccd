package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class Ecid implements Serializable{

	   @Override
	public String toString() {
		return "Ecid [id=" + id + "]";
	}
	@SerializedName("id")
	   String id;


	    public void setId(String id) {
	        this.id = id;
	    }
	    public String getId() {
	        return id;
	    }
	    
	}
