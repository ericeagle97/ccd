package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class MobileInfoAttributes implements Serializable{
	
	
	@Nullable
	@SerializedName("accessRoles")
	AccessRoles accessRoles;

	public AccessRoles getAccessRoles() {
		return accessRoles;
	}

	public void setAccessRoles(AccessRoles accessRoles) {
		this.accessRoles = accessRoles;
	}
	
		
	
}