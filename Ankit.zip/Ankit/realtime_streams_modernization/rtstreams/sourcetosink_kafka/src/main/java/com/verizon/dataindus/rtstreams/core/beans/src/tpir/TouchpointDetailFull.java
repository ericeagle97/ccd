package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@XmlRootElement(name = "touchpointDetail")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class TouchpointDetailFull implements Serializable{
	
	@SerializedName("channelId")
	@Nullable 
	@XmlElement(name = "channelId")
	public String channelId; 

	@SerializedName("activityDate")
	@Nullable 
	@XmlElement(name = "activityDate")
	public String activityDate; 

	@SerializedName("activitySummary")
	@Nullable @XmlElement(name = "activitySummary")
	public String activitySummary; 

	@SerializedName("activityDetail")
	@Nullable 
	@XmlElement(name = "activityDetail")
	public String activityDetail; 

	@SerializedName("status")
	@Nullable 
	@XmlElement(name = "status")
	public String status; 

	@SerializedName("selfServe")
	@Nullable 
	@XmlElement(name = "selfServe")
	public String selfServe; 

	@SerializedName("mtn")
	@Nullable 
	@XmlElement(name = "mtn")
	public String mtn; 

	@SerializedName("outageID")
	@Nullable 
	@XmlElement(name = "outageID")
	public String outageID; 

	@SerializedName("outageState")
	@Nullable 
	@XmlElement(name = "outageState")
	public String outageState; 

	@SerializedName("requestID")
	@Nullable 
	@XmlElement(name = "requestID")
	public String requestID; 

	@SerializedName("timestamp")
	@Nullable 
	@XmlElement(name = "timestamp")
	public String timestamp; 

	@SerializedName("congestedHours")
	@Nullable 
	@XmlElement(name = "congestedHours")
	public String congestedHours; 

	@SerializedName("accountNumber")
	@Nullable 
	@XmlElement(name = "accountNumber")
	public String accountNumber; 

	@SerializedName("statusCode")
	@Nullable 
	@XmlElement(name = "statusCode")
	public String statusCode; 

	@SerializedName("statusMessage")
	@Nullable 
	@XmlElement(name = "statusMessage")
	public String statusMessage; 

	@SerializedName("subChannel")
	@Nullable 
	@XmlElement(name = "subChannel")
	public String subChannel; 

	@SerializedName("additionalInfo")
	@Nullable 
	@XmlElement(name = "additionalInfo")
	public String additionalInfo; 

	@SerializedName("agentUserName")
	@Nullable 
	@XmlElement(name = "agentUserName")
	public String agentUserName; 

	@SerializedName("accountTenure")
	@Nullable 
	@XmlElement(name = "accountTenure")
	public String accountTenure; 

	@SerializedName("callCenterDesc")
	@Nullable 
	@XmlElement(name = "callCenterDesc")
	public String callCenterDesc; 

	@SerializedName("callDisputeInd")
	@Nullable 
	@XmlElement(name = "callDisputeInd")
	public String callDisputeInd; 

	@SerializedName("callReason")
	@Nullable 
	@XmlElement(name = "callReason")
	public String callReason; 

	@SerializedName("cartID")
	@Nullable 
	@XmlElement(name = "cartID")
	public String cartID; 

	@SerializedName("cbr")
	@Nullable 
	@XmlElement(name = "cbr")
	public String cbr; 

	@SerializedName("departmentDesc")
	@Nullable 
	@XmlElement(name = "departmentDesc")
	public String departmentDesc; 

	@SerializedName("destinationDept")
	@Nullable 
	@XmlElement(name = "destinationDept")
	public String destinationDept; 

	@SerializedName("repName")
	@Nullable 
	@XmlElement(name = "repName")
	public String repName; 

	@SerializedName("errorMsg")
	@Nullable 
	@XmlElement(name = "errorMsg")
	public String errorMsg; 

	@SerializedName("failReason")
	@Nullable 
	@XmlElement(name = "failReason")
	public String failReason; 

	@SerializedName("finalStatus")
	@Nullable 
	@XmlElement(name = "finalStatus")
	public String finalStatus; 

	@SerializedName("lastName")
	@Nullable 
	@XmlElement(name = "lastName")
	public String lastName; 

	@SerializedName("lob")
	@Nullable 
	@XmlElement(name = "lob")
	public String lob; 

	@SerializedName("pageName")
	@Nullable 
	@XmlElement(name = "pageName")
	public String pageName; 

	@SerializedName("purchaseFlow")
	@Nullable 
	@XmlElement(name = "purchaseFlow")
	public String purchaseFlow; 

	@SerializedName("remedyFlag")
	@Nullable 
	@XmlElement(name = "remedyFlag")
	public String remedyFlag; 

	@SerializedName("revenue")
	@Nullable 
	@XmlElement(name = "revenue")
	public String revenue; 

	@SerializedName("toolkit")
	@Nullable 
	@XmlElement(name = "toolkit")
	public String toolkit; 

	@SerializedName("transferPoint")
	@Nullable 
	@XmlElement(name = "transferPoint")
	public String transferPoint; 

	@SerializedName("treatmentFlag")
	@Nullable 
	@XmlElement(name = "treatmentFlag")
	public String treatmentFlag; 

	@SerializedName("tsrNextStep")
	@Nullable 
	@XmlElement(name = "tsrNextStep")
	public String tsrNextStep; 

	@SerializedName("tsrSymptom")
	@Nullable 
	@XmlElement(name = "tsrSymptom")
	public String tsrSymptom; 

	@SerializedName("typeOfBilling")
	@Nullable 
	@XmlElement(name = "typeOfBilling")
	public String typeOfBilling; 

	@SerializedName("userRole")
	@Nullable 
	@XmlElement(name = "userRole")
	public String userRole; 

	@SerializedName("workState")
	@Nullable 
	@XmlElement(name = "workState")
	public String workState; 

	@SerializedName("speechTag")
	@Nullable 
	@XmlElement(name = "speechTag")
	public String speechTag; 

	@SerializedName("intent")
	@Nullable 
	@XmlElement(name = "intent")
	public String intent; 

	@SerializedName("accessoryID")
	@Nullable 
	@XmlElement(name = "accessoryID")
	public String accessoryID; 

	@SerializedName("agentStoreID")
	@Nullable 
	@XmlElement(name = "agentStoreID")
	public String agentStoreID; 

	@SerializedName("chatDate")
	@Nullable 
	@XmlElement(name = "chatDate")
	public String chatDate; 

	@SerializedName("chatIntend")
	@Nullable 
	@XmlElement(name = "chatIntend")
	public String chatIntend; 

	@SerializedName("chatSkill")
	@Nullable 
	@XmlElement(name = "chatSkill")
	public String chatSkill; 

	@SerializedName("currentPricePlanID")
	@Nullable 
	@XmlElement(name = "currentPricePlanID")
	public String currentPricePlanID; 

	@SerializedName("currentSplFeatureOfferID")
	@Nullable 
	@XmlElement(name = "currentSplFeatureOfferID")
	public String currentSplFeatureOfferID; 

	@SerializedName("dateType")
	@Nullable 
	@XmlElement(name = "dateType")
	public String dateType; 

	@SerializedName("deviceID")
	@Nullable 
	@XmlElement(name = "deviceID")
	public String deviceID; 

	@SerializedName("dialOutReturnCode")
	@Nullable 
	@XmlElement(name = "dialOutReturnCode")
	public String dialOutReturnCode; 

	@SerializedName("dnis")
	@Nullable 
	@XmlElement(name = "dnis")
	public String dnis; 

	@SerializedName("ecpdID")
	@Nullable @XmlElement(name = "ecpdID")
	public String ecpdID; 

	@SerializedName("employeeId")
	@Nullable 
	@XmlElement(name = "employeeId")
	public String employeeId; 

	@SerializedName("errorCode")
	@Nullable 
	@XmlElement(name = "errorCode")
	public String errorCode; 

	@SerializedName("esnmeID")
	@Nullable 
	@XmlElement(name = "esnmeID")
	public String esnmeID; 

	@SerializedName("exitCode")
	@Nullable 
	@XmlElement(name = "exitCode")
	public String exitCode; 

	@SerializedName("failCode")
	@Nullable 
	@XmlElement(name = "failCode")
	public String failCode; 

	@SerializedName("featureID")
	@Nullable 
	@XmlElement(name = "featureID")
	public String featureID; 

	@SerializedName("firstName")
	@Nullable 
	@XmlElement(name = "firstName")
	public String firstName; 

	@SerializedName("globalID")
	@Nullable 
	@XmlElement(name = "globalID")
	public String globalID; 

	@SerializedName("invoiceID")
	@Nullable 
	@XmlElement(name = "invoiceID")
	public String invoiceID; 

	@SerializedName("level")
	@Nullable 
	@XmlElement(name = "level")
	public String level; 

	@SerializedName("mtnContractExpDate")
	@Nullable 
	@XmlElement(name = "mtnContractExpDate")
	public String mtnContractExpDate; 

	@SerializedName("newPricePlanID")
	@Nullable 
	@XmlElement(name = "newPricePlanID")
	public String newPricePlanID; 

	@SerializedName("amount")
	@Nullable 
	@XmlElement(name = "amount")
	public String amount; 

	@SerializedName("newSplFeatureOfferID")
	@Nullable 
	@XmlElement(name = "newSplFeatureOfferID")
	public String newSplFeatureOfferID; 

	@SerializedName("nps")
	@Nullable 
	@XmlElement(name = "nps")
	public String nps; 

	@SerializedName("nrbTicketNumber")
	@Nullable 
	@XmlElement(name = "nrbTicketNumber")
	public String nrbTicketNumber; 

	@SerializedName("numberOfLines")
	@Nullable 
	@XmlElement(name = "numberOfLines")
	public String numberOfLines; 

	@SerializedName("orderID")
	@Nullable 
	@XmlElement(name = "orderID")
	public String orderID; 

	@SerializedName("orderNumber")
	@Nullable 
	@XmlElement(name = "orderNumber")
	public String orderNumber; 

	@SerializedName("pastDueAmt")
	@Nullable 
	@XmlElement(name = "pastDueAmt")
	public String pastDueAmt; 

	@SerializedName("paymentDetail")
	@Nullable 
	@XmlElement(name = "paymentDetail")
	public String paymentDetail; 

	@SerializedName("paymentType")
	@Nullable 
	@XmlElement(name = "paymentType")
	public String paymentType; 

	@SerializedName("phoneNum")
	@Nullable 
	@XmlElement(name = "phoneNum")
	public String phoneNum; 

	@SerializedName("planID")
	@Nullable 
	@XmlElement(name = "planID")
	public String planID; 

	@SerializedName("postalCode")
	@Nullable 
	@XmlElement(name = "postalCode")
	public String postalCode; 

	@SerializedName("realTimeID")
	@Nullable 
	@XmlElement(name = "realTimeID")
	public String realTimeID; 

	@SerializedName("releaseOrder")
	@Nullable 
	@XmlElement(name = "releaseOrder")
	public String releaseOrder; 

	@SerializedName("repId")
	@Nullable 
	@XmlElement(name = "repId")
	public String repId; 

	@SerializedName("sessionID")
	@Nullable 
	@XmlElement(name = "sessionID")
	public String sessionID; 

	@SerializedName("simID")
	@Nullable 
	@XmlElement(name = "simID")
	public String simID; 

	@SerializedName("timeStamp")
	@Nullable 
	@XmlElement(name = "timeStamp")
	public String timeStamp; 

	@SerializedName("totalAllowance")
	@Nullable 
	@XmlElement(name = "totalAllowance")
	public String totalAllowance; 

	@SerializedName("totalRemaining")
	@Nullable 
	@XmlElement(name = "totalRemaining")
	public String totalRemaining; 

	@SerializedName("tsrCreatedDate")
	@Nullable 
	@XmlElement(name = "tsrCreatedDate")
	public String tsrCreatedDate; 

	@SerializedName("tsrID")
	@Nullable 
	@XmlElement(name = "tsrID")
	public String tsrID; 

	@SerializedName("tsrSymptomID")
	@Nullable 
	@XmlElement(name = "tsrSymptomID")
	public String tsrSymptomID; 

	@SerializedName("userID")
	@Nullable 
	@XmlElement(name = "userID")
	public String userID; 

	@SerializedName("cbr1")
	@Nullable 
	@XmlElement(name = "cbr1")
	public String cbr1; 

	@SerializedName("cbr1Type")
	@Nullable 
	@XmlElement(name = "cbr1Type")
	public String cbr1Type; 

	@SerializedName("cbr2")
	@Nullable 
	@XmlElement(name = "cbr2")
	public String cbr2; 

	@SerializedName("cbr2Type")
	@Nullable 
	@XmlElement(name = "cbr2Type")
	public String cbr2Type; 

	@SerializedName("agentStoreName")
	@Nullable 
	@XmlElement(name = "agentStoreName")
	public String agentStoreName; 

	@SerializedName("custCANum")
	@Nullable 
	@XmlElement(name = "custCANum")
	public String custCANum; 

	@SerializedName("customerAppVersion")
	@Nullable 
	@XmlElement(name = "customerAppVersion")
	public String customerAppVersion; 

	@SerializedName("lastLogin")
	@Nullable 
	@XmlElement(name = "lastLogin")
	public String lastLogin; 

	@SerializedName("latestAppVersionInAppStore")
	@Nullable 
	@XmlElement(name = "latestAppVersionInAppStore")
	public String latestAppVersionInAppStore; 
    
	public String getchannelId() {
		return channelId;
	}

	public void setchannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getactivityDate() {
		return activityDate;
	}

	public void setactivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getactivitySummary() {
		return activitySummary;
	}

	public void setactivitySummary(String activitySummary) {
		this.activitySummary = activitySummary;
	}

	public String getactivityDetail() {
		return activityDetail;
	}

	public void setactivityDetail(String activityDetail) {
		this.activityDetail = activityDetail;
	}

	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}

	public String getselfServe() {
		return selfServe;
	}

	public void setselfServe(String selfServe) {
		this.selfServe = selfServe;
	}

	public String getmtn() {
		return mtn;
	}

	public void setmtn(String mtn) {
		this.mtn = mtn;
	}

	public String getoutageID() {
		return outageID;
	}

	public void setoutageID(String outageID) {
		this.outageID = outageID;
	}

	public String getoutageState() {
		return outageState;
	}

	public void setoutageState(String outageState) {
		this.outageState = outageState;
	}

	public String getrequestID() {
		return requestID;
	}

	public void setrequestID(String requestID) {
		this.requestID = requestID;
	}

	public String gettimestamp() {
		return timestamp;
	}

	public void settimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getcongestedHours() {
		return congestedHours;
	}

	public void setcongestedHours(String congestedHours) {
		this.congestedHours = congestedHours;
	}

	public String getaccountNumber() {
		return accountNumber;
	}

	public void setaccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getstatusCode() {
		return statusCode;
	}

	public void setstatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getstatusMessage() {
		return statusMessage;
	}

	public void setstatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getsubChannel() {
		return subChannel;
	}

	public void setsubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public String getadditionalInfo() {
		return additionalInfo;
	}

	public void setadditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getagentUserName() {
		return agentUserName;
	}

	public void setagentUserName(String agentUserName) {
		this.agentUserName = agentUserName;
	}

	public String getaccountTenure() {
		return accountTenure;
	}

	public void setaccountTenure(String accountTenure) {
		this.accountTenure = accountTenure;
	}

	public String getcallCenterDesc() {
		return callCenterDesc;
	}

	public void setcallCenterDesc(String callCenterDesc) {
		this.callCenterDesc = callCenterDesc;
	}

	public String getcallDisputeInd() {
		return callDisputeInd;
	}

	public void setcallDisputeInd(String callDisputeInd) {
		this.callDisputeInd = callDisputeInd;
	}

	public String getcallReason() {
		return callReason;
	}

	public void setcallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getcartID() {
		return cartID;
	}

	public void setcartID(String cartID) {
		this.cartID = cartID;
	}

	public String getcbr() {
		return cbr;
	}

	public void setcbr(String cbr) {
		this.cbr = cbr;
	}

	public String getdepartmentDesc() {
		return departmentDesc;
	}

	public void setdepartmentDesc(String departmentDesc) {
		this.departmentDesc = departmentDesc;
	}

	public String getdestinationDept() {
		return destinationDept;
	}

	public void setdestinationDept(String destinationDept) {
		this.destinationDept = destinationDept;
	}

	public String getrepName() {
		return repName;
	}

	public void setrepName(String repName) {
		this.repName = repName;
	}

	public String geterrorMsg() {
		return errorMsg;
	}

	public void seterrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getfailReason() {
		return failReason;
	}

	public void setfailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getfinalStatus() {
		return finalStatus;
	}

	public void setfinalStatus(String finalStatus) {
		this.finalStatus = finalStatus;
	}

	public String getlastName() {
		return lastName;
	}

	public void setlastName(String lastName) {
		this.lastName = lastName;
	}

	public String getlob() {
		return lob;
	}

	public void setlob(String lob) {
		this.lob = lob;
	}

	public String getpageName() {
		return pageName;
	}

	public void setpageName(String pageName) {
		this.pageName = pageName;
	}

	public String getpurchaseFlow() {
		return purchaseFlow;
	}

	public void setpurchaseFlow(String purchaseFlow) {
		this.purchaseFlow = purchaseFlow;
	}

	public String getremedyFlag() {
		return remedyFlag;
	}

	public void setremedyFlag(String remedyFlag) {
		this.remedyFlag = remedyFlag;
	}

	public String getrevenue() {
		return revenue;
	}

	public void setrevenue(String revenue) {
		this.revenue = revenue;
	}

	public String gettoolkit() {
		return toolkit;
	}

	public void settoolkit(String toolkit) {
		this.toolkit = toolkit;
	}

	public String gettransferPoint() {
		return transferPoint;
	}

	public void settransferPoint(String transferPoint) {
		this.transferPoint = transferPoint;
	}

	public String gettreatmentFlag() {
		return treatmentFlag;
	}

	public void settreatmentFlag(String treatmentFlag) {
		this.treatmentFlag = treatmentFlag;
	}

	public String gettsrNextStep() {
		return tsrNextStep;
	}

	public void settsrNextStep(String tsrNextStep) {
		this.tsrNextStep = tsrNextStep;
	}

	public String gettsrSymptom() {
		return tsrSymptom;
	}

	public void settsrSymptom(String tsrSymptom) {
		this.tsrSymptom = tsrSymptom;
	}

	public String gettypeOfBilling() {
		return typeOfBilling;
	}

	public void settypeOfBilling(String typeOfBilling) {
		this.typeOfBilling = typeOfBilling;
	}

	public String getuserRole() {
		return userRole;
	}

	public void setuserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getworkState() {
		return workState;
	}

	public void setworkState(String workState) {
		this.workState = workState;
	}

	public String getspeechTag() {
		return speechTag;
	}

	public void setspeechTag(String speechTag) {
		this.speechTag = speechTag;
	}

	public String getintent() {
		return intent;
	}

	public void setintent(String intent) {
		this.intent = intent;
	}

	public String getaccessoryID() {
		return accessoryID;
	}

	public void setaccessoryID(String accessoryID) {
		this.accessoryID = accessoryID;
	}

	public String getagentStoreID() {
		return agentStoreID;
	}

	public void setagentStoreID(String agentStoreID) {
		this.agentStoreID = agentStoreID;
	}

	public String getchatDate() {
		return chatDate;
	}

	public void setchatDate(String chatDate) {
		this.chatDate = chatDate;
	}

	public String getchatIntend() {
		return chatIntend;
	}

	public void setchatIntend(String chatIntend) {
		this.chatIntend = chatIntend;
	}

	public String getchatSkill() {
		return chatSkill;
	}

	public void setchatSkill(String chatSkill) {
		this.chatSkill = chatSkill;
	}

	public String getcurrentPricePlanID() {
		return currentPricePlanID;
	}

	public void setcurrentPricePlanID(String currentPricePlanID) {
		this.currentPricePlanID = currentPricePlanID;
	}

	public String getcurrentSplFeatureOfferID() {
		return currentSplFeatureOfferID;
	}

	public void setcurrentSplFeatureOfferID(String currentSplFeatureOfferID) {
		this.currentSplFeatureOfferID = currentSplFeatureOfferID;
	}

	public String getdateType() {
		return dateType;
	}

	public void setdateType(String dateType) {
		this.dateType = dateType;
	}

	public String getdeviceID() {
		return deviceID;
	}

	public void setdeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getdialOutReturnCode() {
		return dialOutReturnCode;
	}

	public void setdialOutReturnCode(String dialOutReturnCode) {
		this.dialOutReturnCode = dialOutReturnCode;
	}

	public String getdnis() {
		return dnis;
	}

	public void setdnis(String dnis) {
		this.dnis = dnis;
	}

	public String getecpdID() {
		return ecpdID;
	}

	public void setecpdID(String ecpdID) {
		this.ecpdID = ecpdID;
	}

	public String getemployeeId() {
		return employeeId;
	}

	public void setemployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String geterrorCode() {
		return errorCode;
	}

	public void seterrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getesnmeID() {
		return esnmeID;
	}

	public void setesnmeID(String esnmeID) {
		this.esnmeID = esnmeID;
	}

	public String getexitCode() {
		return exitCode;
	}

	public void setexitCode(String exitCode) {
		this.exitCode = exitCode;
	}

	public String getfailCode() {
		return failCode;
	}

	public void setfailCode(String failCode) {
		this.failCode = failCode;
	}

	public String getfeatureID() {
		return featureID;
	}

	public void setfeatureID(String featureID) {
		this.featureID = featureID;
	}

	public String getfirstName() {
		return firstName;
	}

	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getglobalID() {
		return globalID;
	}

	public void setglobalID(String globalID) {
		this.globalID = globalID;
	}

	public String getinvoiceID() {
		return invoiceID;
	}

	public void setinvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}

	public String getlevel() {
		return level;
	}

	public void setlevel(String level) {
		this.level = level;
	}

	public String getmtnContractExpDate() {
		return mtnContractExpDate;
	}

	public void setmtnContractExpDate(String mtnContractExpDate) {
		this.mtnContractExpDate = mtnContractExpDate;
	}

	public String getnewPricePlanID() {
		return newPricePlanID;
	}

	public void setnewPricePlanID(String newPricePlanID) {
		this.newPricePlanID = newPricePlanID;
	}

	public String getamount() {
		return amount;
	}

	public void setamount(String amount) {
		this.amount = amount;
	}

	public String getnewSplFeatureOfferID() {
		return newSplFeatureOfferID;
	}

	public void setnewSplFeatureOfferID(String newSplFeatureOfferID) {
		this.newSplFeatureOfferID = newSplFeatureOfferID;
	}

	public String getnps() {
		return nps;
	}

	public void setnps(String nps) {
		this.nps = nps;
	}

	public String getnrbTicketNumber() {
		return nrbTicketNumber;
	}

	public void setnrbTicketNumber(String nrbTicketNumber) {
		this.nrbTicketNumber = nrbTicketNumber;
	}

	public String getnumberOfLines() {
		return numberOfLines;
	}

	public void setnumberOfLines(String numberOfLines) {
		this.numberOfLines = numberOfLines;
	}

	public String getorderID() {
		return orderID;
	}

	public void setorderID(String orderID) {
		this.orderID = orderID;
	}

	public String getorderNumber() {
		return orderNumber;
	}

	public void setorderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getpastDueAmt() {
		return pastDueAmt;
	}

	public void setpastDueAmt(String pastDueAmt) {
		this.pastDueAmt = pastDueAmt;
	}

	public String getpaymentDetail() {
		return paymentDetail;
	}

	public void setpaymentDetail(String paymentDetail) {
		this.paymentDetail = paymentDetail;
	}

	public String getpaymentType() {
		return paymentType;
	}

	public void setpaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getphoneNum() {
		return phoneNum;
	}

	public void setphoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getplanID() {
		return planID;
	}

	public void setplanID(String planID) {
		this.planID = planID;
	}

	public String getpostalCode() {
		return postalCode;
	}

	public void setpostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getrealTimeID() {
		return realTimeID;
	}

	public void setrealTimeID(String realTimeID) {
		this.realTimeID = realTimeID;
	}

	public String getreleaseOrder() {
		return releaseOrder;
	}

	public void setreleaseOrder(String releaseOrder) {
		this.releaseOrder = releaseOrder;
	}

	public String getrepId() {
		return repId;
	}

	public void setrepId(String repId) {
		this.repId = repId;
	}

	public String getsessionID() {
		return sessionID;
	}

	public void setsessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public String getsimID() {
		return simID;
	}

	public void setsimID(String simID) {
		this.simID = simID;
	}

	public String gettimeStamp() {
		return timeStamp;
	}

	public void settimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String gettotalAllowance() {
		return totalAllowance;
	}

	public void settotalAllowance(String totalAllowance) {
		this.totalAllowance = totalAllowance;
	}

	public String gettotalRemaining() {
		return totalRemaining;
	}

	public void settotalRemaining(String totalRemaining) {
		this.totalRemaining = totalRemaining;
	}

	public String gettsrCreatedDate() {
		return tsrCreatedDate;
	}

	public void settsrCreatedDate(String tsrCreatedDate) {
		this.tsrCreatedDate = tsrCreatedDate;
	}

	public String gettsrID() {
		return tsrID;
	}

	public void settsrID(String tsrID) {
		this.tsrID = tsrID;
	}

	public String gettsrSymptomID() {
		return tsrSymptomID;
	}

	public void settsrSymptomID(String tsrSymptomID) {
		this.tsrSymptomID = tsrSymptomID;
	}

	public String getuserID() {
		return userID;
	}

	public void setuserID(String userID) {
		this.userID = userID;
	}

	public String getcbr1() {
		return cbr1;
	}

	public void setcbr1(String cbr1) {
		this.cbr1 = cbr1;
	}

	public String getcbr1Type() {
		return cbr1Type;
	}

	public void setcbr1Type(String cbr1Type) {
		this.cbr1Type = cbr1Type;
	}

	public String getcbr2() {
		return cbr2;
	}

	public void setcbr2(String cbr2) {
		this.cbr2 = cbr2;
	}

	public String getcbr2Type() {
		return cbr2Type;
	}

	public void setcbr2Type(String cbr2Type) {
		this.cbr2Type = cbr2Type;
	}

	public String getagentStoreName() {
		return agentStoreName;
	}

	public void setagentStoreName(String agentStoreName) {
		this.agentStoreName = agentStoreName;
	}

	public String getcustCANum() {
		return custCANum;
	}

	public void setcustCANum(String custCANum) {
		this.custCANum = custCANum;
	}

	public String getcustomerAppVersion() {
		return customerAppVersion;
	}

	public void setcustomerAppVersion(String customerAppVersion) {
		this.customerAppVersion = customerAppVersion;
	}

	public String getlastLogin() {
		return lastLogin;
	}

	public void setlastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getlatestAppVersionInAppStore() {
		return latestAppVersionInAppStore;
	}

	public void setlatestAppVersionInAppStore(String latestAppVersionInAppStore) {
		this.latestAppVersionInAppStore = latestAppVersionInAppStore;
	}

	@Override
	public String toString() {
		
		return "touchpointDetail [channelId = " + channelId + " , activityDate = " + activityDate + " , activitySummary = " + activitySummary + " , activityDetail = " + activityDetail + " , status = " + status + " , selfServe = " + selfServe + " , mtn = " + mtn + " , outageID = " + outageID + " , outageState = " + outageState + " , requestID = " + requestID + " , timestamp = " + timestamp + " , congestedHours = " + congestedHours + " , accountNumber = " + accountNumber + " , statusCode = " + statusCode + " , statusMessage = " + statusMessage + " , subChannel = " + subChannel + " , additionalInfo = " + additionalInfo + " , agentUserName = " + agentUserName + " , accountTenure = " + accountTenure + " , callCenterDesc = " + callCenterDesc + " , callDisputeInd = " + callDisputeInd + " , callReason = " + callReason + " , cartID = " + cartID + " , cbr = " + cbr + " , departmentDesc = " + departmentDesc + " , destinationDept = " + destinationDept + " , repName = " + repName + " , errorMsg = " + errorMsg + " , failReason = " + failReason + " , finalStatus = " + finalStatus + " , lastName = " + lastName + " , lob = " + lob + " , pageName = " + pageName + " , purchaseFlow = " + purchaseFlow + " , remedyFlag = " + remedyFlag + " , revenue = " + revenue + " , toolkit = " + toolkit + " , transferPoint = " + transferPoint + " , treatmentFlag = " + treatmentFlag + " , tsrNextStep = " + tsrNextStep + " , tsrSymptom = " + tsrSymptom + " , typeOfBilling = " + typeOfBilling + " , userRole = " + userRole + " , workState = " + workState + " , speechTag = " + speechTag + " , intent = " + intent + " , accessoryID = " + accessoryID + " , agentStoreID = " + agentStoreID + " , chatDate = " + chatDate + " , chatIntend = " + chatIntend + " , chatSkill = " + chatSkill + " , currentPricePlanID = " + currentPricePlanID + " , currentSplFeatureOfferID = " + currentSplFeatureOfferID + " , dateType = " + dateType + " , deviceID = " + deviceID + " , dialOutReturnCode = " + dialOutReturnCode + " , dnis = " + dnis + " , ecpdID = " + ecpdID + " , employeeId = " + employeeId + " , errorCode = " + errorCode + " , esnmeID = " + esnmeID + " , exitCode = " + exitCode + " , failCode = " + failCode + " , featureID = " + featureID + " , firstName = " + firstName + " , globalID = " + globalID + " , invoiceID = " + invoiceID + " , level = " + level + " , mtnContractExpDate = " + mtnContractExpDate + " , newPricePlanID = " + newPricePlanID + " , amount = " + amount + " , newSplFeatureOfferID = " + newSplFeatureOfferID + " , nps = " + nps + " , nrbTicketNumber = " + nrbTicketNumber + " , numberOfLines = " + numberOfLines + " , orderID = " + orderID + " , orderNumber = " + orderNumber + " , pastDueAmt = " + pastDueAmt + " , paymentDetail = " + paymentDetail + " , paymentType = " + paymentType + " , phoneNum = " + phoneNum + " , planID = " + planID + " , postalCode = " + postalCode + " , realTimeID = " + realTimeID + " , releaseOrder = " + releaseOrder + " , repId = " + repId + " , sessionID = " + sessionID + " , simID = " + simID + " , timeStamp = " + timeStamp + " , totalAllowance = " + totalAllowance + " , totalRemaining = " + totalRemaining + " , tsrCreatedDate = " + tsrCreatedDate + " , tsrID = " + tsrID + " , tsrSymptomID = " + tsrSymptomID + " , userID = " + userID + " , cbr1 = " + cbr1 + " , cbr1Type = " + cbr1Type + " , cbr2 = " + cbr2 + " , cbr2Type = " + cbr2Type + " , agentStoreName = " + agentStoreName + " , custCANum = " + custCANum + " , customerAppVersion = " + customerAppVersion + " , lastLogin = " + lastLogin + " , latestAppVersionInAppStore = " + latestAppVersionInAppStore + " ]";
	}

}
