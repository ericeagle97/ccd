package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.mmg;

import java.io.EOFException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.beans.CassandraKeyBean;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.IVR_Disconnect_insightstype;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.InsightValuesType;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.MainCassandraAggType;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.MainCassandraInsightType;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.keyAttributesType;
import com.verizon.dataindus.rtstreams.core.beans.tar.mmg.keyAttributesType1;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.mmg.Constants;
import com.verizon.dataindus.rtstreams.core.utils.impls.PreProcessingClass;

import redis.clients.jedis.Jedis;

public class Sourcemmg extends DoFn<String, String> {

	private final Counter IVR_DisconnectStreaminvalidCounter = Metrics.counter(Constants.SOURCEMMG,
			Constants.MMGSMARTCLICK_COUNTER); // "Sourcemmg-IVR_DisconnectStream", "Invaliddata");
	private final Counter IVR_DisconnectStreamvalidCounter = Metrics.counter(Constants.SOURCEMMG,
			Constants.MMGSMARTCLICK_INVALID_COUNTER); // "Sourcemmg-IVR_DisconnectStream", "Validdata");

	private final Counter IVR_PlanChangePredStreaminvalidCounter = Metrics.counter(Constants.SOURCEMMG,
			Constants.MMG_SMS_COUNTER);
	private final Counter IVR_PlanChangePredStreamvalidCounter = Metrics.counter(Constants.SOURCEMMG,
			Constants.MMG_SMS_INVALID_COUNTER);

	public static final TupleTag<String> CustomerInsights = new TupleTag<String>() { // MainCassandraInsightType
	};

	public static final TupleTag<String> AggrProductInsights = new TupleTag<String>() { // MainCassandraAggType
	};
	public static final TupleTag<String> deadletter = new TupleTag<String>() {
	};
	ObjectMapper objectMapper = new ObjectMapper();
	private Jedis redisClientDoFnObject;
	private String projectId;
	private Map<String, String> lookupData;

	private String keystorePassword;
	private byte[] jksBytes;
	private ByteString secretPayload;
	private boolean errorLog;
	boolean redisError = false;

	public Sourcemmg(String keystorePassword, byte[] jksBytes, ByteString secretPayload, boolean errorLog) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;
		this.errorLog = errorLog;
	}

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword);

	}

	@ProcessElement
	public void processElement(ProcessContext c) throws IOException, ParseException {
		
		String inputData = c.element();

		IVR_Disconnect_insightstype ivrDisconnectString = null;
		
		Gson gson = new Gson();

		try {
		
			try {
				
				ObjectMapper objectMapper = new ObjectMapper();
	            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	            objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
	            objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
	            objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);

	            //convert json string to object
	            ivrDisconnectString = objectMapper
	                    .readValue(inputData, IVR_Disconnect_insightstype.class);

				 //ivrDisconnectString = gson.fromJson(inputData, IVR_Disconnect_insightstype.class);
				
			} catch (Exception e) {
				c.output(deadletter, c.element());
				e.printStackTrace(System.out);
			}
			
			if (ivrDisconnectString.getClient().contains("CJCM") && ivrDisconnectString.getEvent().contains("SmartLink_Click")
					&& !CommonUtility.isNullEmptyOrBlank(ivrDisconnectString.getCampaign().getTrackingId())) {

				MainCassandraAggType main = new MainCassandraAggType();
				main.setRequestType("SOI_InsertAggrProductInsights");

				keyAttributesType keyattr = new keyAttributesType();
				keyattr.setRequestedBy("mmg");
				keyattr.setUpdateBy("stream");
				keyattr.setAggrCategory("mmg_smartclick");
				keyattr.setAggrValues(gson.toJson(ivrDisconnectString));
				keyattr.setAggrName("rt");
				
				
				
				// Updating pattern per BAU - 11/6/2024
				/*
				 * DateTimeFormatter format =
				 * DateTimeFormatter.ofPattern("yyyy-mm-dd HH:mm:ss O"); ZonedDateTime gmtTime =
				 * ZonedDateTime.now(ZoneId.of("GMT"));
				 * 
				 * keyattr.setUpdateTs(format.format(gmtTime));
				 */
				keyattr.setUpdateTs(CommonUtility.getGMTDateTime("yyyy-MM-dd HH:mm:ss 'GMT'"));
				
				keyattr.setAggrProdId(ivrDisconnectString.getTransactionId());
				
				
				main.setKeyAttributes(keyattr);

				if (keyattr.getAggrValues() != "") {
					// Updating per Cassandra Insertion pattern - 11/6/2024
					//c.output(AggrProductInsights, gson.toJson(main));
					c.output(AggrProductInsights, gson.toJson(keyattr));
					IVR_DisconnectStreamvalidCounter.inc();
				} else {
					c.output(deadletter, c.element());
					IVR_DisconnectStreaminvalidCounter.inc();
				}
			}

			// IVR_PlanChangePredStream

			String ivrstr = ivrDisconnectString.getSmartLinkUrl();

			if (ivrstr.contains("m.vzw.com/m/GTStartSave") || (ivrstr.contains("m.vzw.com/m/GTStartSave")
					|| ivrstr.contains("m.vzw.com/m/StartUnldSame") || ivrstr.contains("m.vzw.com/m/StartUnldSave")
					|| ivrstr.contains("m.vzw.com/m/StartUnldSp") || ivrstr.contains("m.vzw.com/Met2DoMoreSame")
					|| ivrstr.contains("m.vzw.com/Met2DoMoreSave") || ivrstr.contains("m.vzw.com/Met2DoMoreSp")
					|| ivrstr.contains("m.vzw.com/Unl2DoMoreSa") || ivrstr.contains("m.vzw.com/Unl2DoMoreSp")
					|| ivrstr.contains("m.vzw.com/UnlPlayDSM") || ivrstr.contains("m.vzw.com/UnlPlayDSV")
					|| ivrstr.contains("m.vzw.com/UnlPlayDSP") || ivrstr.contains("m.vzw.com/UnlGetDSP")
					|| ivrstr.contains("m.vzw.com/met2playsp") || ivrstr.contains("m.vzw.com/UnlPlay5SP")
					|| ivrstr.contains("m.vzw.com/UnPlayNWSM") || ivrstr.contains("m.vzw.com/UnPlayNWSP"))) {
				

				InsightValuesType insight = new InsightValuesType();

				insight.setEvent(ivrDisconnectString.getEvent());
				insight.setSmartLinkUrl(ivrDisconnectString.getSmartLinkUrl());
				insight.setStatus(ivrDisconnectString.getStatus());
				insight.setTrackingId(ivrDisconnectString.getCampaign().getTrackingId());

				MainCassandraInsightType mainInsight = new MainCassandraInsightType();

				mainInsight.setRequestType("SOI_InsertCustomerInsights");

				keyAttributesType1 keyattr1 = new keyAttributesType1();

				keyattr1.setUpdateBy("streams");
				keyattr1.setInsightValues(gson.toJson(insight).toString());
				keyattr1.setInsightCategory("interactions");
				keyattr1.setMtn(ivrDisconnectString.getExternalUserId());
				keyattr1.setAcctNo("");
				keyattr1.setCustId("");
				keyattr1.setInsightName("marketingsms");

				// Updating pattern per BAU - 11/6/2024
				//DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss O");
				//ZonedDateTime gmtTime = ZonedDateTime.now(ZoneId.of("GMT"));
				//keyattr1.setUpdateTs(format.format(gmtTime)); 
				keyattr1.setUpdateTs(CommonUtility.getGMTDateTime("yyyy-MM-dd HH:mm:ss 'GMT'"));

				mainInsight.setKeyAttributes1(keyattr1);

				String mtn = keyattr1.getMtn();
				String accountNo = keyattr1.getAcctNo();
				String custId = keyattr1.getCustId();

				CassandraKeyBean kBean = new CassandraKeyBean(mtn, custId, accountNo);

				if (CommonUtility.isNullEmptyOrBlank(custId)) {
					
					kBean = new PreProcessingClass().getCassandraKeyIdentifierFromRedis(kBean, redisClientDoFnObject);

					mtn = kBean.getMtn();
					accountNo = kBean.getAccountNo();
					custId = kBean.getCustomerId();

					if (!CommonUtility.isNullEmptyOrBlank(accountNo) && !CommonUtility.isNullEmptyOrBlank(custId) && !CommonUtility.isNullEmptyOrBlank(mtn) && accountNo.matches("[0-9]+")
							&& custId.matches("[0-9]+") && mtn.matches("[0-9]+")) {
						
						
						keyattr1.setMtn("9999999999");
						keyattr1.setCustId(custId);
						keyattr1.setAcctNo(accountNo);
						
						IVR_PlanChangePredStreamvalidCounter.inc();
						
						// Updating per Cassandra Insertion pattern - 11/6/2024
						//c.output(CustomerInsights, gson.toJson(mainInsight));
						
						c.output(CustomerInsights, gson.toJson(keyattr1));
					} else {
						IVR_PlanChangePredStreaminvalidCounter.inc();
						c.output(deadletter, c.element());
					}
				}
			}
		} catch (Exception e) {
			IVR_PlanChangePredStreaminvalidCounter.inc();
			c.output(deadletter, c.element());
			
		}
	}

	@Teardown
	public void teardown() {
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
	}
}
