package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class ScannedThreatLog implements Serializable {
	private static final long serialVersionUID = 1L;
	@SerializedName("headers")
	@Nullable
	public String time;
	@SerializedName("threatCount")
	@Nullable
	public String threatCount;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getThreatCount() {
		return threatCount;
	}

	public void setThreatCount(String threatCount) {
		this.threatCount = threatCount;
	}

	@Override
	public String toString() {
		return "ScannedThreatLog [time=" + time + ", threatCount=" + threatCount + "]";
	}

	public ScannedThreatLog(String time, String threatCount) {
		super();
		this.time = time;
		this.threatCount = threatCount;
	}

	public ScannedThreatLog() {
		super();
		// TODO Auto-generated constructor stub
	}

}
