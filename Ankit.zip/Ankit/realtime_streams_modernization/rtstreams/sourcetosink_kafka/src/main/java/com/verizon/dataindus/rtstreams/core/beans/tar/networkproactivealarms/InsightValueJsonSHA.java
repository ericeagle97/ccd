package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class InsightValueJsonSHA implements Serializable {
    @SerializedName("alarm_type")
    @Nullable
    String alarm_type;

    @SerializedName("alarm_mtn")
    @Nullable
    String alarm_mtn;

    @SerializedName("alarm_category")
    @Nullable
    String alarm_category;

    @SerializedName("eventTime")
    @Nullable
    String eventTime;

    @Nullable
    public String getAlarm_type() {
        return alarm_type;
    }

    public void setAlarm_type(@Nullable String alarm_type) {
        this.alarm_type = alarm_type;
    }

    @Nullable
    public String getAlarm_mtn() {
        return alarm_mtn;
    }

    public void setAlarm_mtn(@Nullable String alarm_mtn) {
        this.alarm_mtn = alarm_mtn;
    }

    @Nullable
    public String getAlarm_category() {
        return alarm_category;
    }

    public void setAlarm_category(@Nullable String alarm_category) {
        this.alarm_category = alarm_category;
    }

    @Nullable
    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(@Nullable String eventTime) {
        this.eventTime = eventTime;
    }

    @Override
    public String toString() {
        return "InsightValueJsonSHA{" +
                "alarm_type='" + alarm_type + '\'' +
                ", alarm_mtn='" + alarm_mtn + '\'' +
                ", alarm_category='" + alarm_category + '\'' +
                ", eventTime='" + eventTime + '\'' +
                '}';
    }
}
