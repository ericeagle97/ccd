package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;

import com.google.gson.annotations.SerializedName;

   
public class CellularLTE {

   @SerializedName("rssi")
   int rssi;

   @SerializedName("rsrp")
   int rsrp;

   @SerializedName("rsrq")
   int rsrq;

   @SerializedName("sinr")
   int sinr;

   @SerializedName("pci")
   int pci;


    public void setRssi(int rssi) {
        this.rssi = rssi;
    }
    public int getRssi() {
        return rssi;
    }
    
    public void setRsrp(int rsrp) {
        this.rsrp = rsrp;
    }
    public int getRsrp() {
        return rsrp;
    }
    
    public void setRsrq(int rsrq) {
        this.rsrq = rsrq;
    }
    public int getRsrq() {
        return rsrq;
    }
    
    public void setSinr(int sinr) {
        this.sinr = sinr;
    }
    public int getSinr() {
        return sinr;
    }
    
    public void setPci(int pci) {
        this.pci = pci;
    }
    public int getPci() {
        return pci;
    }
    
}