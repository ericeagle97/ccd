package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


//@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class Service implements Serializable {

	@Nullable
	@SerializedName("pxObjClass")
	String pxObjClass;

	@Nullable
	@SerializedName("Status")
	@JsonProperty("Status")
	String Status;

	@Nullable
	@SerializedName("addressInfo")
	AddressInfo addressInfo;

	@Nullable
	@SerializedName("SelectedMTN")
	@JsonProperty("SelectedMTN")
	String SelectedMTN;

	@Nullable
	@SerializedName("orderNumber")
	String orderNumber;

	@Nullable
	@SerializedName("clientId")
	String clientId;

	@Nullable
	@SerializedName("Type")
	@JsonProperty("Type")
	String Type;

	@Nullable
	@SerializedName("contextInfo")
	ContextInfo contextInfo;

	@Nullable
	@SerializedName("mtnPlanDetails")
	List<MtnPlanDetails> mtnPlanDetails;

	@Nullable
	@SerializedName("activationStatus")
	String activationStatus;

	@Nullable
	@SerializedName("NewMTN")
	@JsonProperty("NewMTN")
	String NewMTN;

	@Nullable
	@SerializedName("CaseID")
	@JsonProperty("CaseID")
	String CaseID;

	@Nullable
	@SerializedName("associateCaseId")
	String associateCaseId;

	@Nullable
	@SerializedName("AssociatedCaseType")
	@JsonProperty("AssociatedCaseType")
	String AssociatedCaseType;

	@Nullable
	@SerializedName("TicketDetails")
	@JsonProperty("TicketDetails")
	TicketDetails TicketDetails;

	@Nullable
	@SerializedName("errorMessages")
	ErrorMessages errorMessages;

	@Nullable
	@SerializedName("remarks")
	List<Remarks> remarks;

	@Nullable
	@SerializedName("intent")
	String intent;

	@Nullable
	@SerializedName("symptomID")
	String symptomID;

	@Nullable
	@SerializedName("symptom")
	String symptom;

	@Nullable
	@SerializedName("subSymptom")
	String subSymptom;

	@Nullable
	@SerializedName("subSymptomID")
	String subSymptomID;

	@Nullable
	@SerializedName("effectiveDate")
	String effectiveDate;

	@Nullable
	@SerializedName("UpdateDateTime")
	@JsonProperty("UpdateDateTime")
	String UpdateDateTime;

	@Nullable
	@SerializedName("SessionID")
	@JsonProperty("SessionID")
	String SessionID;

	@Nullable
	@SerializedName("userId")
	String userId;

	@Nullable
	@SerializedName("parentCaseID")
	String parentCaseID;

	@Nullable
	@SerializedName("AccountNumber")
	@JsonProperty("AccountNumber")
	String AccountNumber;

	@Nullable
	@SerializedName("pxUpdateDateTime")
	String pxUpdateDateTime;

	@Nullable
	@SerializedName("DeviceCategory")
	@JsonProperty("DeviceCategory")
	String DeviceCategory;

	@Nullable
	@SerializedName("pxCreateDateTime")
	String pxCreateDateTime;

	@Nullable
	@SerializedName("DeviceModel")
	@JsonProperty("DeviceModel")
	String DeviceModel;

	@Nullable
	@SerializedName("pxInsName")
	String pxInsName;

	@Nullable
	@SerializedName("pzInsKey")
	String pzInsKey;

	@Nullable
	@SerializedName("InternalAssignmentHandle")
	@JsonProperty("InternalAssignmentHandle")
	String InternalAssignmentHandle;

	@Nullable
	@SerializedName("HTTPStatusCode")
	@JsonProperty("HTTPStatusCode")
	String HTTPStatusCode;

	@Nullable
	@SerializedName("portStatus")
	String portStatus;

	@Nullable
	@SerializedName("CurrentStageSubscript")
	@JsonProperty("CurrentStageSubscript")
	String CurrentStageSubscript;

	@Nullable
	@SerializedName("portHasCompleted")
	String portHasCompleted;

	@Nullable
	@SerializedName("CaseFilterDescription")
	@JsonProperty("CaseFilterDescription")
	String CaseFilterDescription;

	@Nullable
	@SerializedName("InitialInteraction")
	@JsonProperty("InitialInteraction")
	String InitialInteraction;

	@Nullable
	@SerializedName("StatusWorkOld")
	@JsonProperty("StatusWorkOld")
	String StatusWorkOld;

	@Nullable
	@SerializedName("WorkPartiesRule")
	@JsonProperty("WorkPartiesRule")
	String WorkPartiesRule;

	@Nullable
	@SerializedName("lastAction")
	String lastAction;

	@Nullable
	@SerializedName("CurrentStage")
	@JsonProperty("CurrentStage")
	String CurrentStage;

	@Nullable
	@SerializedName("intentId")
	String intentId;

	@Nullable
	@SerializedName("UpdateCounter")
	@JsonProperty("UpdateCounter")
	String UpdateCounter;

	@Nullable
	@SerializedName("DeviceIdType")
	@JsonProperty("DeviceIdType")
	String DeviceIdType;

	@Nullable
	@SerializedName("SubscriptionInfo")
	@JsonProperty("SubscriptionInfo")
	SubscriptionInfo SubscriptionInfo;

	@Nullable
	@SerializedName("EntitlementInfo")
	@JsonProperty("EntitlementInfo")
	EntitlementInfo EntitlementInfo;

	@Nullable
	@SerializedName("ClientType")
	@JsonProperty("ClientType")
	String ClientType;

	@Nullable
	@SerializedName("NotificationCount")
	@JsonProperty("NotificationCount")
	String NotificationCount;

	@Nullable
	@SerializedName("ProductCaseID")
	@JsonProperty("ProductCaseID")
	String ProductCaseID;

	@Nullable
	@SerializedName("AddressIntent")
	@JsonProperty("AddressIntent")
	String AddressIntent;

	@Nullable
	@SerializedName("NotificationDate")
	@JsonProperty("NotificationDate")
	String NotificationDate;

	@Nullable
	@SerializedName("ProductRegistered")
	@JsonProperty("ProductRegistered")
	String ProductRegistered;

	@Nullable
	@SerializedName("PPCaseID")
	@JsonProperty("PPCaseID")
	String PPCaseID;

	@Nullable
	@SerializedName("master_url")
	String masterUrl;

	@Nullable
	@SerializedName("PaymentIntent")
	@JsonProperty("PaymentIntent")
	String PaymentIntent;

	@Nullable
	@SerializedName("originating_client_id")
	String originatingClientId;

	@Nullable
	@SerializedName("ServiceName")
	@JsonProperty("ServiceName")
	String ServiceName;

	@Nullable
	@SerializedName("bp_id")
	@JsonProperty("bp_id")
	String bpId;

	@Nullable
	@SerializedName("pyLabel")
	String pyLabel;

	@Nullable
	@SerializedName("CancelEntitlementDate")
	@JsonProperty("CancelEntitlementDate")
	String CancelEntitlementDate;

	@Nullable
	@SerializedName("BangoEntitled")
	@JsonProperty("BangoEntitled")
	String BangoEntitled;

	@Nullable
	@SerializedName("pyStatusWork")
	String pyStatusWork;

	@Nullable
	@SerializedName("BangoSubscribed")
	@JsonProperty("BangoSubscribed")
	String BangoSubscribed;

	@Nullable
	@SerializedName("PaymentMethodUpdated")
	@JsonProperty("PaymentMethodUpdated")
	String PaymentMethodUpdated;

	@Nullable
	@SerializedName("OfferID")
	@JsonProperty("OfferID")
	String OfferID;

	@Nullable
	@SerializedName("MON")
	@JsonProperty("MON")
	String MON ;

	@Nullable
	@SerializedName("locationCode")
	String locationCode;

	@Nullable
	@SerializedName("promoType")
	String promoType;

	@Nullable
	@SerializedName("StatusMessage")
	@JsonProperty("StatusMessage")
	String StatusMessage;

	@Nullable
	@SerializedName("posRetryMessage")
	String posRetryMessage;

	@Nullable
	@SerializedName("RetryStatus")
	@JsonProperty("RetryStatus")
	String RetryStatus;

	@Nullable
	@SerializedName("RetryCount")
	@JsonProperty("RetryCount")
	String RetryCount;

	@Nullable
	@SerializedName("PosRetryCount")
	@JsonProperty("PosRetryCount")
	String PosRetryCount;

	@Nullable
	@SerializedName("PromoDesc")
	@JsonProperty("PromoDesc")
	String PromoDesc;

	@Nullable
	@SerializedName("PromoAction")
	@JsonProperty("PromoAction")
	String PromoAction;

	@Nullable
	@SerializedName("RuleId")
	@JsonProperty("RuleId")
	String RuleId;

	@Nullable
	@SerializedName("RuleName")
	@JsonProperty("RuleName")
	String RuleName;

	@Nullable
	@SerializedName("PromoBatchDate")
	@JsonProperty("PromoBatchDate")
	String PromoBatchDate;

	@Nullable
	@SerializedName("IsPromoMailTriggerd")
	@JsonProperty("IsPromoMailTriggerd")
	String IsPromoMailTriggerd;

	@Nullable
	@SerializedName("cartId")
	String cartId;

	@Nullable
	@SerializedName("CallReason")
	@JsonProperty("CallReason")
	String CallReason;

	@Nullable
	@SerializedName("loggedInMTN")
	String loggedInMTN;

	@Nullable
	@SerializedName("queueName")
	String queueName;

	@Nullable
	@SerializedName("isOrderNumberExpected")
	String isOrderNumberExpected;

	@Nullable
	@SerializedName("CustomerType")
	@JsonProperty("CustomerType")
	String CustomerType;

	@Nullable
	@SerializedName("emailAddress")
	String emailAddress;

	@Nullable
	@SerializedName("firstName")
	String firstName;

	@Nullable
	@SerializedName("middleName")
	String middleName;

	@Nullable
	@SerializedName("lastName")
	String lastName;

	@Nullable
	@SerializedName("addressLine1")
	String addressLine1;

	@Nullable
	@SerializedName("addressLine2")
	String addressLine2;

	@Nullable
	@SerializedName("addressLine3")
	String addressLine3;

	@Nullable
	@SerializedName("city")
	String city;

	@Nullable
	@SerializedName("state")
	String state;

	@Nullable
	@SerializedName("zipCode")
	String zipCode;

	@Nullable
	@SerializedName("responseCode")
	String responseCode;

	@Nullable
	@SerializedName("currentPlanType")
	String currentPlanType;

	@Nullable
	@SerializedName("transactionType")
	String transactionType;

	@Nullable
	@SerializedName("childMileStone")
	String childMileStone;

	@Nullable
	@SerializedName("journeyKey")
	String journeyKey;

	@Nullable
	@SerializedName("parentMilestone")
	String parentMilestone;

	@Nullable
	@SerializedName("resolvedTimestamp")
	String resolvedTimestamp;

	@Nullable
	@SerializedName("USER_ID")
	@JsonProperty("USER_ID")
	String USERID;

	@Nullable
	@SerializedName("followUpCallDateTime")
	String followUpCallDateTime;

	@Nullable
	@SerializedName("device")
	String device;

	@Nullable
	@SerializedName("committedSLADateTime")
	String committedSLADateTime;

	@Nullable
	@SerializedName("supervisorId")
	String supervisorId;

	@Nullable
	@SerializedName("lockedBy")
	String lockedBy;

	@Nullable
	@SerializedName("outOfSLATime")
	String outOfSLATime;

	@Nullable
	@SerializedName("resolutionSLADateTime")
	String resolutionSLADateTime;

	@Nullable
	@SerializedName("withInSLA")
	String withInSLA;

	@Nullable
	@SerializedName("escalationLevel")
	String escalationLevel;

	@Nullable
	@SerializedName("nextEscalationDateTime")
	String nextEscalationDateTime;

	@Nullable
	@SerializedName("latitude")
	String latitude;

	@Nullable
	@SerializedName("longitude")
	String longitude;

	@Nullable
	@SerializedName("ChannelList")
	@JsonProperty("ChannelList")
	ChannelList ChannelList;

	@Nullable
	@SerializedName("project_lob")
	@JsonProperty("project_lob")
	String projectLob;


	@Nullable
	@SerializedName("emailChangeInfo")
	List<EmailChangeInfo> emailChangeInfo;

	@Nullable
	@SerializedName("addressChangeInfo")
	List<AddressChangeInfo> addressChangeInfo;

	@Nullable
	@SerializedName("nameChangeInfo")
	List<NameChangeInfo> nameChangeInfo;

	@Nullable
	@SerializedName("IsBalancePastDue")
	@JsonProperty("IsBalancePastDue")
	String IsBalancePastDue;

	@Nullable
	@SerializedName("preOrder")
	String preOrder;

	@Nullable
	@SerializedName("fiveGUpSell")
	String fiveGUpSell;

	@Nullable
	@SerializedName("IconicDateTimeStart")
	@JsonProperty("IconicDateTimeStart")
	String IconicDateTimeStart;

	@Nullable
	@SerializedName("CartStatus")
	@JsonProperty("CartStatus")
	String CartStatus;

	@Nullable
	@SerializedName("PendingOrderFlag")
	String PendingOrderFlag;

	@Nullable
	@SerializedName("MtnLevelPendingOrder")
	@JsonProperty("MtnLevelPendingOrder")
	String MtnLevelPendingOrder;

	@Nullable
	@SerializedName("byodEsim")
	String byodEsim;

	@Nullable
	@SerializedName("planQualifiedForPromotion")
	String planQualifiedForPromotion;

	@Nullable
	@SerializedName("OrderSubmitStatus")
	@JsonProperty("OrderSubmitStatus")
	String OrderSubmitStatus;

	@Nullable
	@SerializedName("AcctLevelPendingOrder")
	@JsonProperty("AcctLevelPendingOrder")
	String AcctLevelPendingOrder;

	@Nullable
	@SerializedName("CJCMEmailOrchestration")
	@JsonProperty("CJCMEmailOrchestration")
	String CJCMEmailOrchestration;

	@Nullable
	@SerializedName("hasNumberShare")
	@JsonProperty("hasNumberShare")
	String hasNumberShare;

	@Nullable
	@SerializedName("digitalOrderId")
	String digitalOrderId;

	@Nullable
	@SerializedName("retaildepletionType")
	String retaildepletionType;

	@Nullable
	@SerializedName("ChildCaseID")
	@JsonProperty("ChildCaseID")
	String ChildCaseID;

	@Nullable
	@SerializedName("IsPOJORequired")
	@JsonProperty("IsPOJORequired")
	String IsPOJORequired;

	@Nullable
	@SerializedName("totalDueToday")
	String totalDueToday;

	@Nullable
	@SerializedName("submittedPerkDetails")
	List<SubmittedPerkDetails> submittedPerkDetails;

	@Nullable
	@SerializedName("futureDatedPerkRemovedDetails")
	List<FutureDatedPerkRemovedDetails> futureDatedPerkRemovedDetails;

	@Nullable
	@SerializedName("customerProfile")
	CustomerProfile customerProfile;

	@Nullable
	@SerializedName("customerProfileForNSE")
	CustomerProfileForNSE customerProfileForNSE;

	@Nullable
	@SerializedName("prepaidindicator")
	String prepaidindicator;

	@Nullable
	@SerializedName("scrtyDeAmt")
	String scrtyDeAmt;

	@Nullable
	@SerializedName("ecpdProfile")
	EcpdProfile ecpdProfile;

	@Nullable
	@SerializedName("custInformation")
	CustInformation custInformation;

	@Nullable
	@SerializedName("e911_addr_ind")
	String e911_addr_ind;

	@Nullable
	@SerializedName("bolt5G")
	String bolt5G;

	@Nullable
	@SerializedName("retailispuFlow")
	String retailispuFlow;

	@Nullable
	@SerializedName("lineActivityType")
	String lineActivityType;

	@Nullable
	@SerializedName("pxSaveDateTime")
	String pxSaveDateTime;

	@Nullable
	@SerializedName("networkBandWidthType")
	String networkBandWidthType;

	@Nullable
	@SerializedName("customerTypeCode")
	String customerTypeCode;

	@Nullable
	@SerializedName("hasMixAndMatchPlan")
	String hasMixAndMatchPlan;

	@Nullable
	@SerializedName("hasSharePlan")
	String hasSharePlan;

	@Nullable
	@SerializedName("devicePlan_Compatible")
	String devicePlan_Compatible;

	@Nullable
	@SerializedName("isPreQualifiedNBX")
	String isPreQualifiedNBX;
	//Adding attributes for 24.08ER
	@Nullable
	@SerializedName("paymentDate")
	String paymentDate;

	@Nullable
	@SerializedName("leadOwner")
	String leadOwner;
	
	@Nullable
	@SerializedName("contactMethod")
	String contactMethod;
	
	@Nullable
	@SerializedName("leadType")
	String leadType;
	
	@Nullable
	@SerializedName("storeId")
	String storeId;
	
	@Nullable
	@SerializedName("CustomertTypeCode")
	@JsonProperty("CustomertTypeCode")
	String CustomertTypeCode;
	
	@Nullable
	@SerializedName("unsecuredPTP")
	String unsecuredPTP;
	
	@Nullable
	@SerializedName("fullAuthFailed")
	String fullAuthFailed;
	
	@Nullable
	@SerializedName("digitalCustomerType")
	String digitalCustomerType;
	
	@Nullable
	@SerializedName("devicePlanCompatible")
	String devicePlanCompatible;
	
	@Nullable
	@SerializedName("byodESimPhone")
	String byodESimPhone;
	
	@Nullable
	@SerializedName("BuyoutTradeinOrder")
	@JsonProperty("BuyoutTradeinOrder")
	String BuyoutTradeinOrder;
	
	@Nullable
	@SerializedName("backOrder")
	String backOrder;
	
	@Nullable
	@SerializedName("appleWatchFlag")
	String appleWatchFlag;
	
	@Nullable
	@SerializedName("handsetEligibilityDate")
	String handsetEligibilityDate;
	
	@Nullable
	@SerializedName("FourG")
	@JsonProperty("FourG")
	String FourG;
	
	@Nullable
	@SerializedName("formFactor")
	String formFactor;
	
	@Nullable
	@SerializedName("FIOScustomer")
	@JsonProperty("FIOScustomer")
	String FIOScustomer;
	
	@Nullable
	@SerializedName("F4G")
	@JsonProperty("F4G")
	String F4G;
	
	@Nullable
	@SerializedName("EquipmentMfgName")
	@JsonProperty("EquipmentMfgName")
	String EquipmentMfgName;
	
	@Nullable
	@SerializedName("EquipmentDeviceCategory")
	@JsonProperty("EquipmentDeviceCategory")
	String EquipmentDeviceCategory;
	
	@Nullable
	@SerializedName("DeviceRepair")
	@JsonProperty("DeviceRepair")
	String DeviceRepair;
	
	@Nullable
	@SerializedName("DeviceId")
	@JsonProperty("DeviceId")
	String DeviceId;
	
	@Nullable
	@SerializedName("DeviceFeature")
	@JsonProperty("DeviceFeature")
	String DeviceFeature;
	
	@Nullable
	@SerializedName("DeviceFamily")
	@JsonProperty("DeviceFamily")
	String DeviceFamily;
	
	@Nullable
	@SerializedName("DeviceActivationDate")
	@JsonProperty("DeviceActivationDate")
	String DeviceActivationDate;
	
	@Nullable
	@SerializedName("callStandardCompatibility")
	String callStandardCompatibility;
	
	@Nullable
	@SerializedName("callId")
	String callId;
	
	@Nullable
	@SerializedName("planDescription")
	String planDescription;
	
	@Nullable
	@SerializedName("planId")
	String planId;
	
	@Nullable
	@SerializedName("isCaseNotesUtilized")
	String isCaseNotesUtilized;
	
	@Nullable
	@SerializedName("DeviceSkuId")
	@JsonProperty("DeviceSkuId")
	String DeviceSkuId;
	
	@Nullable
	@SerializedName("submitTradeInOrder")
	String submitTradeInOrder;
	
	@Nullable
	@SerializedName("DeviceType")
	@JsonProperty("DeviceType")
	String DeviceType;
	
	@Nullable
	@SerializedName("TransactionType")
	@JsonProperty("TransactionType")
	String TransactionType;
	
	@Nullable
	@SerializedName("Description")
	@JsonProperty("Description")
	String Description;

	@Nullable
	@SerializedName("context")
	Context context;
	
	@Nullable
	@SerializedName("Isbyod")
	@JsonProperty("Isbyod")
	String Isbyod;
	
	@Nullable
	@SerializedName("Isportin")
	@JsonProperty("Isportin")
	String Isportin;
	
	@Nullable
	@SerializedName("originalOrderNumber")
	String originalOrderNumber;
	
	@Nullable
	@SerializedName("originalLocationCode")
	String originalLocationCode;
	

	public List<EmailChangeInfo> getEmailChangeInfo() {
		return emailChangeInfo;
	}
	public void setEmailChangeInfo(List<EmailChangeInfo> emailChangeInfo) {
		this.emailChangeInfo = emailChangeInfo;
	}
	public List<AddressChangeInfo> getAddressChangeInfo() {
		return addressChangeInfo;
	}
	public void setAddressChangeInfo(List<AddressChangeInfo> addressChangeInfo) {
		this.addressChangeInfo = addressChangeInfo;
	}
	public List<NameChangeInfo> getNameChangeInfo() {
		return nameChangeInfo;
	}
	public void setNameChangeInfo(List<NameChangeInfo> nameChangeInfo) {
		this.nameChangeInfo = nameChangeInfo;
	}
	public void setPxObjClass(String pxObjClass) {
		this.pxObjClass = pxObjClass;
	}
	public String getPxObjClass() {
		return pxObjClass;
	}

	public void setStatus(String Status) {
		this.Status = Status;
	}
	public String getStatus() {
		return Status;
	}

	public void setAddressInfo(AddressInfo addressInfo) {
		this.addressInfo = addressInfo;
	}
	public AddressInfo getAddressInfo() {
		return addressInfo;
	}

	public void setSelectedMTN(String SelectedMTN) {
		this.SelectedMTN = SelectedMTN;
	}
	public String getSelectedMTN() {
		return SelectedMTN;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderNumber() {
		return orderNumber;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientId() {
		return clientId;
	}

	public void setType(String Type) {
		this.Type = Type;
	}
	public String getType() {
		return Type;
	}

	public void setContextInfo(ContextInfo contextInfo) {
		this.contextInfo = contextInfo;
	}
	public ContextInfo getContextInfo() {
		return contextInfo;
	}

	public void setMtnPlanDetails(List<MtnPlanDetails> mtnPlanDetails) {
		this.mtnPlanDetails = mtnPlanDetails;
	}
	public List<MtnPlanDetails> getMtnPlanDetails() {
		return mtnPlanDetails;
	}

	public void setActivationStatus(String activationStatus) {
		this.activationStatus = activationStatus;
	}
	public String getActivationStatus() {
		return activationStatus;
	}

	public void setNewMTN(String NewMTN) {
		this.NewMTN = NewMTN;
	}
	public String getNewMTN() {
		return NewMTN;
	}

	public void setCaseID(String CaseID) {
		this.CaseID = CaseID;
	}
	public String getCaseID() {
		return CaseID;
	}

	public void setAssociateCaseId(String associateCaseId) {
		this.associateCaseId = associateCaseId;
	}
	public String getAssociateCaseId() {
		return associateCaseId;
	}

	public void setAssociatedCaseType(String AssociatedCaseType) {
		this.AssociatedCaseType = AssociatedCaseType;
	}
	public String getAssociatedCaseType() {
		return AssociatedCaseType;
	}

	public void setTicketDetails(TicketDetails TicketDetails) {
		this.TicketDetails = TicketDetails;
	}
	public TicketDetails getTicketDetails() {
		return TicketDetails;
	}

	public void setErrorMessages(ErrorMessages errorMessages) {
		this.errorMessages = errorMessages;
	}
	public ErrorMessages getErrorMessages() {
		return errorMessages;
	}

	public void setRemarks(List<Remarks> remarks) {
		this.remarks = remarks;
	}
	public List<Remarks> getRemarks() {
		return remarks;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}
	public String getIntent() {
		return intent;
	}

	public void setSymptomID(String symptomID) {
		this.symptomID = symptomID;
	}
	public String getSymptomID() {
		return symptomID;
	}

	public void setSymptom(String symptom) {
		this.symptom = symptom;
	}
	public String getSymptom() {
		return symptom;
	}

	public void setSubSymptom(String subSymptom) {
		this.subSymptom = subSymptom;
	}
	public String getSubSymptom() {
		return subSymptom;
	}

	public void setSubSymptomID(String subSymptomID) {
		this.subSymptomID = subSymptomID;
	}
	public String getSubSymptomID() {
		return subSymptomID;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setUpdateDateTime(String UpdateDateTime) {
		this.UpdateDateTime = UpdateDateTime;
	}
	public String getUpdateDateTime() {
		return UpdateDateTime;
	}

	public void setSessionID(String SessionID) {
		this.SessionID = SessionID;
	}
	public String getSessionID() {
		return SessionID;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserId() {
		return userId;
	}

	public void setParentCaseID(String parentCaseID) {
		this.parentCaseID = parentCaseID;
	}
	public String getParentCaseID() {
		return parentCaseID;
	}

	public void setAccountNumber(String AccountNumber) {
		this.AccountNumber = AccountNumber;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}

	public void setPxUpdateDateTime(String pxUpdateDateTime) {
		this.pxUpdateDateTime = pxUpdateDateTime;
	}
	public String getPxUpdateDateTime() {
		return pxUpdateDateTime;
	}

	public void setDeviceCategory(String DeviceCategory) {
		this.DeviceCategory = DeviceCategory;
	}
	public String getDeviceCategory() {
		return DeviceCategory;
	}

	public void setPxCreateDateTime(String pxCreateDateTime) {
		this.pxCreateDateTime = pxCreateDateTime;
	}
	public String getPxCreateDateTime() {
		return pxCreateDateTime;
	}

	public void setDeviceModel(String DeviceModel) {
		this.DeviceModel = DeviceModel;
	}
	public String getDeviceModel() {
		return DeviceModel;
	}

	public void setPxInsName(String pxInsName) {
		this.pxInsName = pxInsName;
	}
	public String getPxInsName() {
		return pxInsName;
	}

	public void setPzInsKey(String pzInsKey) {
		this.pzInsKey = pzInsKey;
	}
	public String getPzInsKey() {
		return pzInsKey;
	}

	public void setInternalAssignmentHandle(String InternalAssignmentHandle) {
		this.InternalAssignmentHandle = InternalAssignmentHandle;
	}
	public String getInternalAssignmentHandle() {
		return InternalAssignmentHandle;
	}

	public void setHTTPStatusCode(String HTTPStatusCode) {
		this.HTTPStatusCode = HTTPStatusCode;
	}
	public String getHTTPStatusCode() {
		return HTTPStatusCode;
	}

	public void setPortStatus(String portStatus) {
		this.portStatus = portStatus;
	}
	public String getPortStatus() {
		return portStatus;
	}

	public void setCurrentStageSubscript(String CurrentStageSubscript) {
		this.CurrentStageSubscript = CurrentStageSubscript;
	}
	public String getCurrentStageSubscript() {
		return CurrentStageSubscript;
	}

	public void setPortHasCompleted(String portHasCompleted) {
		this.portHasCompleted = portHasCompleted;
	}
	public String getPortHasCompleted() {
		return portHasCompleted;
	}

	public void setCaseFilterDescription(String CaseFilterDescription) {
		this.CaseFilterDescription = CaseFilterDescription;
	}
	public String getCaseFilterDescription() {
		return CaseFilterDescription;
	}

	public void setInitialInteraction(String InitialInteraction) {
		this.InitialInteraction = InitialInteraction;
	}
	public String getInitialInteraction() {
		return InitialInteraction;
	}

	public void setStatusWorkOld(String StatusWorkOld) {
		this.StatusWorkOld = StatusWorkOld;
	}
	public String getStatusWorkOld() {
		return StatusWorkOld;
	}

	public void setWorkPartiesRule(String WorkPartiesRule) {
		this.WorkPartiesRule = WorkPartiesRule;
	}
	public String getWorkPartiesRule() {
		return WorkPartiesRule;
	}

	public void setLastAction(String lastAction) {
		this.lastAction = lastAction;
	}
	public String getLastAction() {
		return lastAction;
	}

	public void setCurrentStage(String CurrentStage) {
		this.CurrentStage = CurrentStage;
	}
	public String getCurrentStage() {
		return CurrentStage;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}
	public String getIntentId() {
		return intentId;
	}

	public void setUpdateCounter(String UpdateCounter) {
		this.UpdateCounter = UpdateCounter;
	}
	public String getUpdateCounter() {
		return UpdateCounter;
	}

	public void setDeviceIdType(String DeviceIdType) {
		this.DeviceIdType = DeviceIdType;
	}
	public String getDeviceIdType() {
		return DeviceIdType;
	}

	public void setSubscriptionInfo(SubscriptionInfo SubscriptionInfo) {
		this.SubscriptionInfo = SubscriptionInfo;
	}
	public SubscriptionInfo getSubscriptionInfo() {
		return SubscriptionInfo;
	}

	public void setEntitlementInfo(EntitlementInfo EntitlementInfo) {
		this.EntitlementInfo = EntitlementInfo;
	}
	public EntitlementInfo getEntitlementInfo() {
		return EntitlementInfo;
	}

	public void setClientType(String ClientType) {
		this.ClientType = ClientType;
	}
	public String getClientType() {
		return ClientType;
	}

	public void setNotificationCount(String NotificationCount) {
		this.NotificationCount = NotificationCount;
	}
	public String getNotificationCount() {
		return NotificationCount;
	}

	public void setProductCaseID(String ProductCaseID) {
		this.ProductCaseID = ProductCaseID;
	}
	public String getProductCaseID() {
		return ProductCaseID;
	}

	public void setAddressIntent(String AddressIntent) {
		this.AddressIntent = AddressIntent;
	}
	public String getAddressIntent() {
		return AddressIntent;
	}

	public void setNotificationDate(String NotificationDate) {
		this.NotificationDate = NotificationDate;
	}
	public String getNotificationDate() {
		return NotificationDate;
	}

	public void setProductRegistered(String ProductRegistered) {
		this.ProductRegistered = ProductRegistered;
	}
	public String getProductRegistered() {
		return ProductRegistered;
	}

	public void setPPCaseID(String PPCaseID) {
		this.PPCaseID = PPCaseID;
	}
	public String getPPCaseID() {
		return PPCaseID;
	}

	public void setMasterUrl(String masterUrl) {
		this.masterUrl = masterUrl;
	}
	public String getMasterUrl() {
		return masterUrl;
	}

	public void setPaymentIntent(String PaymentIntent) {
		this.PaymentIntent = PaymentIntent;
	}
	public String getPaymentIntent() {
		return PaymentIntent;
	}

	public void setOriginatingClientId(String originatingClientId) {
		this.originatingClientId = originatingClientId;
	}
	public String getOriginatingClientId() {
		return originatingClientId;
	}

	public void setServiceName(String ServiceName) {
		this.ServiceName = ServiceName;
	}
	public String getServiceName() {
		return ServiceName;
	}

	public void setBpId(String bpId) {
		this.bpId = bpId;
	}
	public String getBpId() {
		return bpId;
	}

	public void setPyLabel(String pyLabel) {
		this.pyLabel = pyLabel;
	}
	public String getPyLabel() {
		return pyLabel;
	}

	public void setCancelEntitlementDate(String CancelEntitlementDate) {
		this.CancelEntitlementDate = CancelEntitlementDate;
	}
	public String getCancelEntitlementDate() {
		return CancelEntitlementDate;
	}

	public void setBangoEntitled(String BangoEntitled) {
		this.BangoEntitled = BangoEntitled;
	}
	public String getBangoEntitled() {
		return BangoEntitled;
	}

	public void setPyStatusWork(String pyStatusWork) {
		this.pyStatusWork = pyStatusWork;
	}
	public String getPyStatusWork() {
		return pyStatusWork;
	}

	public void setBangoSubscribed(String BangoSubscribed) {
		this.BangoSubscribed = BangoSubscribed;
	}
	public String getBangoSubscribed() {
		return BangoSubscribed;
	}

	public void setPaymentMethodUpdated(String PaymentMethodUpdated) {
		this.PaymentMethodUpdated = PaymentMethodUpdated;
	}
	public String getPaymentMethodUpdated() {
		return PaymentMethodUpdated;
	}

	public void setOfferID(String OfferID) {
		this.OfferID = OfferID;
	}
	public String getOfferID() {
		return OfferID;
	}

	public void setMON (String MON ) {
		this.MON  = MON ;
	}
	public String getMON () {
		return MON ;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getLocationCode() {
		return locationCode;
	}

	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	public String getPromoType() {
		return promoType;
	}

	public void setStatusMessage(String StatusMessage) {
		this.StatusMessage = StatusMessage;
	}
	public String getStatusMessage() {
		return StatusMessage;
	}

	public void setPosRetryMessage(String posRetryMessage) {
		this.posRetryMessage = posRetryMessage;
	}
	public String getPosRetryMessage() {
		return posRetryMessage;
	}

	public void setRetryStatus(String RetryStatus) {
		this.RetryStatus = RetryStatus;
	}
	public String getRetryStatus() {
		return RetryStatus;
	}

	public void setRetryCount(String RetryCount) {
		this.RetryCount = RetryCount;
	}
	public String getRetryCount() {
		return RetryCount;
	}

	public void setPosRetryCount(String PosRetryCount) {
		this.PosRetryCount = PosRetryCount;
	}
	public String getPosRetryCount() {
		return PosRetryCount;
	}

	public void setPromoDesc(String PromoDesc) {
		this.PromoDesc = PromoDesc;
	}
	public String getPromoDesc() {
		return PromoDesc;
	}

	public void setPromoAction(String PromoAction) {
		this.PromoAction = PromoAction;
	}
	public String getPromoAction() {
		return PromoAction;
	}

	public void setRuleId(String RuleId) {
		this.RuleId = RuleId;
	}
	public String getRuleId() {
		return RuleId;
	}

	public void setRuleName(String RuleName) {
		this.RuleName = RuleName;
	}
	public String getRuleName() {
		return RuleName;
	}

	public void setPromoBatchDate(String PromoBatchDate) {
		this.PromoBatchDate = PromoBatchDate;
	}
	public String getPromoBatchDate() {
		return PromoBatchDate;
	}

	public void setIsPromoMailTriggerd(String IsPromoMailTriggerd) {
		this.IsPromoMailTriggerd = IsPromoMailTriggerd;
	}
	public String getIsPromoMailTriggerd() {
		return IsPromoMailTriggerd;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getCartId() {
		return cartId;
	}

	public void setCallReason(String CallReason) {
		this.CallReason = CallReason;
	}
	public String getCallReason() {
		return CallReason;
	}

	public void setLoggedInMTN(String loggedInMTN) {
		this.loggedInMTN = loggedInMTN;
	}
	public String getLoggedInMTN() {
		return loggedInMTN;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getQueueName() {
		return queueName;
	}

	public void setIsOrderNumberExpected(String isOrderNumberExpected) {
		this.isOrderNumberExpected = isOrderNumberExpected;
	}
	public String getIsOrderNumberExpected() {
		return isOrderNumberExpected;
	}

	public void setCustomerType(String CustomerType) {
		this.CustomerType = CustomerType;
	}
	public String getCustomerType() {
		return CustomerType;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getMiddleName() {
		return middleName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getAddressLine3() {
		return addressLine3;
	}

	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}

	public void setState(String state) {
		this.state = state;
	}
	public String getState() {
		return state;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getZipCode() {
		return zipCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseCode() {
		return responseCode;
	}

	public void setCurrentPlanType(String currentPlanType) {
		this.currentPlanType = currentPlanType;
	}
	public String getCurrentPlanType() {
		return currentPlanType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionType() {
		return transactionType;
	}

	public void setChildMileStone(String childMileStone) {
		this.childMileStone = childMileStone;
	}
	public String getChildMileStone() {
		return childMileStone;
	}

	public void setJourneyKey(String journeyKey) {
		this.journeyKey = journeyKey;
	}
	public String getJourneyKey() {
		return journeyKey;
	}

	public void setParentMilestone(String parentMilestone) {
		this.parentMilestone = parentMilestone;
	}
	public String getParentMilestone() {
		return parentMilestone;
	}

	public void setResolvedTimestamp(String resolvedTimestamp) {
		this.resolvedTimestamp = resolvedTimestamp;
	}
	public String getResolvedTimestamp() {
		return resolvedTimestamp;
	}

	public void setUSERID(String USERID) {
		this.USERID = USERID;
	}
	public String getUSERID() {
		return USERID;
	}

	public void setFollowUpCallDateTime(String followUpCallDateTime) {
		this.followUpCallDateTime = followUpCallDateTime;
	}
	public String getFollowUpCallDateTime() {
		return followUpCallDateTime;
	}

	public void setDevice(String device) {
		this.device = device;
	}
	public String getDevice() {
		return device;
	}

	public void setCommittedSLADateTime(String committedSLADateTime) {
		this.committedSLADateTime = committedSLADateTime;
	}
	public String getCommittedSLADateTime() {
		return committedSLADateTime;
	}

	public void setSupervisorId(String supervisorId) {
		this.supervisorId = supervisorId;
	}
	public String getSupervisorId() {
		return supervisorId;
	}

	public void setLockedBy(String lockedBy) {
		this.lockedBy = lockedBy;
	}
	public String getLockedBy() {
		return lockedBy;
	}

	public void setOutOfSLATime(String outOfSLATime) {
		this.outOfSLATime = outOfSLATime;
	}
	public String getOutOfSLATime() {
		return outOfSLATime;
	}

	public void setResolutionSLADateTime(String resolutionSLADateTime) {
		this.resolutionSLADateTime = resolutionSLADateTime;
	}
	public String getResolutionSLADateTime() {
		return resolutionSLADateTime;
	}

	public void setWithInSLA(String withInSLA) {
		this.withInSLA = withInSLA;
	}
	public String getWithInSLA() {
		return withInSLA;
	}

	public void setEscalationLevel(String escalationLevel) {
		this.escalationLevel = escalationLevel;
	}
	public String getEscalationLevel() {
		return escalationLevel;
	}

	public void setNextEscalationDateTime(String nextEscalationDateTime) {
		this.nextEscalationDateTime = nextEscalationDateTime;
	}
	public String getNextEscalationDateTime() {
		return nextEscalationDateTime;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLatitude() {
		return latitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLongitude() {
		return longitude;
	}

	public void setChannelList(ChannelList ChannelList) {
		this.ChannelList = ChannelList;
	}
	public ChannelList getChannelList() {
		return ChannelList;
	}

	public void setProjectLob(String projectLob) {
		this.projectLob = projectLob;
	}
	public String getProjectLob() {
		return projectLob;
	}
	public String getIsBalancePastDue() {
		return IsBalancePastDue;
	}
	public void setIsBalancePastDue(String isBalancePastDue) {
		IsBalancePastDue = isBalancePastDue;
	}
	public String getPreOrder() {
		return preOrder;
	}
	public void setPreOrder(String preOrder) {
		this.preOrder = preOrder;
	}
	public String getFiveGUpSell() {
		return fiveGUpSell;
	}
	public void setFiveGUpSell(String fiveGUpSell) {
		this.fiveGUpSell = fiveGUpSell;
	}
	public String getIconicDateTimeStart() {
		return IconicDateTimeStart;
	}
	public void setIconicDateTimeStart(String iconicDateTimeStart) {
		IconicDateTimeStart = iconicDateTimeStart;
	}
	public String getCartStatus() {
		return CartStatus;
	}
	public void setCartStatus(String cartStatus) {
		CartStatus = cartStatus;
	}
	public String getPendingOrderFlag() {
		return PendingOrderFlag;
	}
	public void setPendingOrderFlag(String pendingOrderFlag) {
		PendingOrderFlag = pendingOrderFlag;
	}
	public String getMtnLevelPendingOrder() {
		return MtnLevelPendingOrder;
	}
	public void setMtnLevelPendingOrder(String mtnLevelPendingOrder) {
		MtnLevelPendingOrder = mtnLevelPendingOrder;
	}
	public String getByodEsim() {
		return byodEsim;
	}
	public void setByodEsim(String byodEsim) {
		this.byodEsim = byodEsim;
	}
	public String getPlanQualifiedForPromotion() {
		return planQualifiedForPromotion;
	}
	public void setPlanQualifiedForPromotion(String planQualifiedForPromotion) {
		this.planQualifiedForPromotion = planQualifiedForPromotion;
	}
	public String getOrderSubmitStatus() {
		return OrderSubmitStatus;
	}
	public void setOrderSubmitStatus(String orderSubmitStatus) {
		OrderSubmitStatus = orderSubmitStatus;
	}
	public String getAcctLevelPendingOrder() {
		return AcctLevelPendingOrder;
	}
	public void setAcctLevelPendingOrder(String acctLevelPendingOrder) {
		AcctLevelPendingOrder = acctLevelPendingOrder;
	}
	public String getCJCMEmailOrchestration() {
		return CJCMEmailOrchestration;
	}
	public void setCJCMEmailOrchestration(String cJCMEmailOrchestration) {
		CJCMEmailOrchestration = cJCMEmailOrchestration;
	}
	public String getHasNumberShare() {
		return hasNumberShare;
	}
	public void setHasNumberShare(String hasNumberShare) {
		this.hasNumberShare = hasNumberShare;
	}
	public String getDigitalOrderId() {
		return digitalOrderId;
	}
	public void setDigitalOrderId(String digitalOrderId) {
		this.digitalOrderId = digitalOrderId;
	}
	public String getRetaildepletionType() {
		return retaildepletionType;
	}
	public void setRetaildepletionType(String retaildepletionType) {
		this.retaildepletionType = retaildepletionType;
	}
	public String getChildCaseID() {
		return ChildCaseID;
	}
	public void setChildCaseID(String childCaseID) {
		ChildCaseID = childCaseID;
	}
	public String getIsPOJORequired() {
		return IsPOJORequired;
	}
	public void setIsPOJORequired(String isPOJORequired) {
		IsPOJORequired = isPOJORequired;
	}
	public String getTotalDueToday() {
		return totalDueToday;
	}
	public void setTotalDueToday(String totalDueToday) {
		this.totalDueToday = totalDueToday;
	}
	public List<SubmittedPerkDetails> getSubmittedPerkDetails() {
		return submittedPerkDetails;
	}
	public void setSubmittedPerkDetails(List<SubmittedPerkDetails> submittedPerkDetails) {
		this.submittedPerkDetails = submittedPerkDetails;
	}
	public List<FutureDatedPerkRemovedDetails> getFutureDatedPerkRemovedDetails() {
		return futureDatedPerkRemovedDetails;
	}
	public void setFutureDatedPerkRemovedDetails(List<FutureDatedPerkRemovedDetails> futureDatedPerkRemovedDetails) {
		this.futureDatedPerkRemovedDetails = futureDatedPerkRemovedDetails;
	}
	public CustomerProfile getCustomerProfile() {
		return customerProfile;
	}
	public void setCustomerProfile(CustomerProfile customerProfile) {
		this.customerProfile = customerProfile;
	}
	public CustomerProfileForNSE getCustomerProfileForNSE() {
		return customerProfileForNSE;
	}
	public void setCustomerProfileForNSE(CustomerProfileForNSE customerProfileForNSE) {
		this.customerProfileForNSE = customerProfileForNSE;
	}
	public String getPrepaidindicator() {
		return prepaidindicator;
	}
	public void setPrepaidindicator(String prepaidindicator) {
		this.prepaidindicator = prepaidindicator;
	}
	public String getScrtyDeAmt() {
		return scrtyDeAmt;
	}
	public void setScrtyDeAmt(String scrtyDeAmt) {
		this.scrtyDeAmt = scrtyDeAmt;
	}
	public EcpdProfile getEcpdProfile() {
		return ecpdProfile;
	}
	public void setEcpdProfile(EcpdProfile ecpdProfile) {
		this.ecpdProfile = ecpdProfile;
	}
	public CustInformation getCustInformation() {
		return custInformation;
	}
	public void setCustInformation(CustInformation custInformation) {
		this.custInformation = custInformation;
	}
	public String getE911_addr_ind() {
		return e911_addr_ind;
	}
	public void setE911_addr_ind(String e911_addr_ind) {
		this.e911_addr_ind = e911_addr_ind;
	}
	public String getBolt5G() {
		return bolt5G;
	}
	public void setBolt5G(String bolt5g) {
		bolt5G = bolt5g;
	}
	public String getRetailispuFlow() {
		return retailispuFlow;
	}
	public void setRetailispuFlow(String retailispuFlow) {
		this.retailispuFlow = retailispuFlow;
	}
	public String getLineActivityType() {
		return lineActivityType;
	}
	public void setLineActivityType(String lineActivityType) {
		this.lineActivityType = lineActivityType;
	}
	public String getPxSaveDateTime() {
		return pxSaveDateTime;
	}
	public void setPxSaveDateTime(String pxSaveDateTime) {
		this.pxSaveDateTime = pxSaveDateTime;
	}
	public String getNetworkBandWidthType() {
		return networkBandWidthType;
	}
	public void setNetworkBandWidthType(String networkBandWidthType) {
		this.networkBandWidthType = networkBandWidthType;
	}
	public String getCustomerTypeCode() {
		return customerTypeCode;
	}
	public void setCustomerTypeCode(String customerTypeCode) {
		this.customerTypeCode = customerTypeCode;
	}
	public String getHasMixAndMatchPlan() {
		return hasMixAndMatchPlan;
	}
	public void setHasMixAndMatchPlan(String hasMixAndMatchPlan) {
		this.hasMixAndMatchPlan = hasMixAndMatchPlan;
	}
	public String getHasSharePlan() {
		return hasSharePlan;
	}
	public void setHasSharePlan(String hasSharePlan) {
		this.hasSharePlan = hasSharePlan;
	}
	public String getDevicePlan_Compatible() {
		return devicePlan_Compatible;
	}
	public void setDevicePlan_Compatible(String devicePlan_Compatible) {
		this.devicePlan_Compatible = devicePlan_Compatible;
	}
	public String getIsPreQualifiedNBX() {
		return isPreQualifiedNBX;
	}
	public void setIsPreQualifiedNBX(String isPreQualifiedNBX) {
		this.isPreQualifiedNBX = isPreQualifiedNBX;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getLeadOwner() {
		return leadOwner;
	}

	public void setLeadOwner(String leadOwner) {
		this.leadOwner = leadOwner;
	}

	public String getContactMethod() {
		return contactMethod;
	}

	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}

	public String getLeadType() {
		return leadType;
	}

	public void setLeadType(String leadType) {
		this.leadType = leadType;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getCustomertTypeCode() {
		return CustomertTypeCode;
	}

	public void setCustomertTypeCode(String customertTypeCode) {
		CustomertTypeCode = customertTypeCode;
	}

	public String getUnsecuredPTP() {
		return unsecuredPTP;
	}

	public void setUnsecuredPTP(String unsecuredPTP) {
		this.unsecuredPTP = unsecuredPTP;
	}

	public String getFullAuthFailed() {
		return fullAuthFailed;
	}

	public void setFullAuthFailed(String fullAuthFailed) {
		this.fullAuthFailed = fullAuthFailed;
	}

	public String getDigitalCustomerType() {
		return digitalCustomerType;
	}

	public void setDigitalCustomerType(String digitalCustomerType) {
		this.digitalCustomerType = digitalCustomerType;
	}

	public String getDevicePlanCompatible() {
		return devicePlanCompatible;
	}

	public void setDevicePlanCompatible(String devicePlanCompatible) {
		this.devicePlanCompatible = devicePlanCompatible;
	}

	public String getByodESimPhone() {
		return byodESimPhone;
	}

	public void setByodESimPhone(String byodESimPhone) {
		this.byodESimPhone = byodESimPhone;
	}

	public String getBuyoutTradeinOrder() {
		return BuyoutTradeinOrder;
	}

	public void setBuyoutTradeinOrder(String buyoutTradeinOrder) {
		BuyoutTradeinOrder = buyoutTradeinOrder;
	}

	public String getBackOrder() {
		return backOrder;
	}

	public void setBackOrder(String backOrder) {
		this.backOrder = backOrder;
	}

	public String getAppleWatchFlag() {
		return appleWatchFlag;
	}

	public void setAppleWatchFlag(String appleWatchFlag) {
		this.appleWatchFlag = appleWatchFlag;
	}

	public String getHandsetEligibilityDate() {
		return handsetEligibilityDate;
	}

	public void setHandsetEligibilityDate(String handsetEligibilityDate) {
		this.handsetEligibilityDate = handsetEligibilityDate;
	}

	public String getFourG() {
		return FourG;
	}

	public void setFourG(String fourG) {
		FourG = fourG;
	}

	public String getFormFactor() {
		return formFactor;
	}

	public void setFormFactor(String formFactor) {
		this.formFactor = formFactor;
	}

	public String getFIOScustomer() {
		return FIOScustomer;
	}

	public void setFIOScustomer(String FIOScustomer) {
		this.FIOScustomer = FIOScustomer;
	}

	public String getF4G() {
		return F4G;
	}

	public void setF4G(String f4G) {
		F4G = f4G;
	}

	public String getEquipmentMfgName() {
		return EquipmentMfgName;
	}

	public void setEquipmentMfgName(String equipmentMfgName) {
		EquipmentMfgName = equipmentMfgName;
	}

	public String getEquipmentDeviceCategory() {
		return EquipmentDeviceCategory;
	}

	public void setEquipmentDeviceCategory(String equipmentDeviceCategory) {
		EquipmentDeviceCategory = equipmentDeviceCategory;
	}

	public String getDeviceRepair() {
		return DeviceRepair;
	}

	public void setDeviceRepair(String deviceRepair) {
		DeviceRepair = deviceRepair;
	}

	public String getDeviceId() {
		return DeviceId;
	}

	public void setDeviceId(String deviceId) {
		DeviceId = deviceId;
	}

	public String getDeviceFeature() {
		return DeviceFeature;
	}

	public void setDeviceFeature(String deviceFeature) {
		DeviceFeature = deviceFeature;
	}

	public String getDeviceFamily() {
		return DeviceFamily;
	}

	public void setDeviceFamily(String deviceFamily) {
		DeviceFamily = deviceFamily;
	}

	public String getDeviceActivationDate() {
		return DeviceActivationDate;
	}

	public void setDeviceActivationDate(String deviceActivationDate) {
		DeviceActivationDate = deviceActivationDate;
	}

	public String getCallStandardCompatibility() {
		return callStandardCompatibility;
	}

	public void setCallStandardCompatibility(String callStandardCompatibility) {
		this.callStandardCompatibility = callStandardCompatibility;
	}

	public String getCallId() {
		return callId;
	}

	public void setCallId(String callId) {
		this.callId = callId;
	}

	public String getPlanDescription() {
		return planDescription;
	}

	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getIsCaseNotesUtilized() {
		return isCaseNotesUtilized;
	}

	public void setIsCaseNotesUtilized(String isCaseNotesUtilized) {
		this.isCaseNotesUtilized = isCaseNotesUtilized;
	}

	public String getDeviceSkuId() {
		return DeviceSkuId;
	}

	public void setDeviceSkuId(String deviceSkuId) {
		DeviceSkuId = deviceSkuId;
	}

	public String getSubmitTradeInOrder() {
		return submitTradeInOrder;
	}

	public void setSubmitTradeInOrder(String submitTradeInOrder) {
		this.submitTradeInOrder = submitTradeInOrder;
	}

	public String getDeviceType() {
		return DeviceType;
	}

	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}
	public String getTransactionTypeUpper() {
		return TransactionType;
	}

	public void setTransactionTypeUpper(String TransactionType) {
		this.TransactionType = TransactionType;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Context getContext() {
		return context;
	}
	public void setContext(Context context) {
		this.context = context;
	}
	public String getIsbyod() {
		return Isbyod;
	}
	public void setIsbyod(String isbyod) {
		Isbyod = isbyod;
	}
	public String getIsportin() {
		return Isportin;
	}
	public void setIsportin(String isportin) {
		Isportin = isportin;
	}
	public String getOriginalOrderNumber() {
		return originalOrderNumber;
	}
	public void setOriginalOrderNumber(String originalOrderNumber) {
		this.originalOrderNumber = originalOrderNumber;
	}
	public String getOriginalLocationCode() {
		return originalLocationCode;
	}
	public void setOriginalLocationCode(String originalLocationCode) {
		this.originalLocationCode = originalLocationCode;
	}
	
	
	
	
}
