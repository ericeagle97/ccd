package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Body implements Serializable{
	
	 @SerializedName("label")
	 @Nullable
	   String label;

	   @SerializedName("deeplink")
	   @Nullable
	   String deeplink;

	   @SerializedName("dismiss")
	   @Nullable
	   boolean dismiss;

	   @SerializedName("action")
	   @Nullable
	   String action;


	    public void setLabel(String label) {
	        this.label = label;
	    }
	    public String getLabel() {
	        return label;
	    }
	    
	    public void setDeeplink(String deeplink) {
	        this.deeplink = deeplink;
	    }
	    public String getDeeplink() {
	        return deeplink;
	    }
	    
	    public void setDismiss(boolean dismiss) {
	        this.dismiss = dismiss;
	    }
	    public boolean getDismiss() {
	        return dismiss;
	    }
	    
	    public void setAction(String action) {
	        this.action = action;
	    }
	    public String getAction() {
	        return action;
	    }
	    
	}
