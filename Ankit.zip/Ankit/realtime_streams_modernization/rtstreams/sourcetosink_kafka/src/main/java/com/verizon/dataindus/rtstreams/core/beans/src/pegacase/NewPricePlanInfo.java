package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class NewPricePlanInfo implements Serializable {
	
	@Nullable
	@SerializedName("pricePlanDesc")
	String pricePlanDesc;
	
	@Nullable
	@SerializedName("pricePlanCode")
	String pricePlanCode;

	public String getPricePlanDesc() {
		return pricePlanDesc;
	}

	public void setPricePlanDesc(String pricePlanDesc) {
		this.pricePlanDesc = pricePlanDesc;
	}

	public String getPricePlanCode() {
		return pricePlanCode;
	}

	public void setPricePlanCode(String pricePlanCode) {
		this.pricePlanCode = pricePlanCode;
	}
	
}
