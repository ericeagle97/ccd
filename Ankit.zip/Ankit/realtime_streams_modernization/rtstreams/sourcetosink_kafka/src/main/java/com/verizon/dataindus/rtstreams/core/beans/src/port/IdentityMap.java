package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

public class IdentityMap implements Serializable {

	@Nullable
	@SerializedName("custlinehash")
	List<Custlinehash> custlinehash;

	@Nullable
	@SerializedName("ecid")
	List<Ecid> ecid;

	@Nullable
	@SerializedName("mtnaccounthash")
	List<Mtnaccounthash> mtnaccounthash;

	public void setCustlinehash(List<Custlinehash> custlinehash) {
		this.custlinehash = custlinehash;
	}

	public List<Custlinehash> getCustlinehash() {
		return custlinehash;
	}

	public void setEcid(List<Ecid> ecid) {
		this.ecid = ecid;
	}

	public List<Ecid> getEcid() {
		return ecid;
	}

	public void setMtnaccounthash(List<Mtnaccounthash> mtnaccounthash) {
		this.mtnaccounthash = mtnaccounthash;
	}

	public List<Mtnaccounthash> getMtnaccounthash() {
		return mtnaccounthash;
	}

	@Override
	public String toString() {
		return "IdentityMap [custlinehash=" + custlinehash + ", ecid=" + ecid + ", mtnaccounthash=" + mtnaccounthash
				+ "]";
	}

}
