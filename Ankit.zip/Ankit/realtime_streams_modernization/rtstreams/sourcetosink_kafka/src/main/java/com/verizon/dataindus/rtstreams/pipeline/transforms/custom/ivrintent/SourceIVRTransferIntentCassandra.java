package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ivrintent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.dataindus.rtstreams.core.beans.src.ivrintent.transferivrintent;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.ivrtransferintent.IvrTransferIntentConstant;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class SourceIVRTransferIntentCassandra extends DoFn<String, String> {

	public static final TupleTag<String> IVRTransferCustomerInsights = new TupleTag<String>() { // MainCassandraInsightType
	};
	
	public static final TupleTag<String> IVRTransferRaw= new TupleTag<String>() { // MainCassandraInsightType
	};
	
	public static final TupleTag<String> deadletter = new TupleTag<String>() {
	};

	ObjectMapper objectMapper = new ObjectMapper();
	
	private final Counter inputDataCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			"total_input_records");

	private final Counter processedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_VALID);

	private final Counter unprocessedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_INVALID);

	@ProcessElement
	public void processElement(ProcessContext c) {
		String sourceData = c.element();
		
		inputDataCounter.inc();
		
		transferivrintent transferivrintentInput = null;
		try {
			
			DateTimeFormatter format_starttime = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss:SSS O");
			ZonedDateTime gmtTime_starttime = ZonedDateTime.now(ZoneId.of("GMT"));
			
			
			
			transferivrintentInput = objectMapper.readValue(sourceData, transferivrintent.class);
			
			Map<String, String> rawinputMap_BQ = new HashMap<String, String>();
			
			rawinputMap_BQ.put("RawData",sourceData.toString());
			rawinputMap_BQ.put("mtn",transferivrintentInput.getMtn());
			rawinputMap_BQ.put("ivrcallid",transferivrintentInput.getCallId());
			
			
			c.output(IVRTransferRaw, new JSONObject(rawinputMap_BQ).toString().replace("\\\\",""));
			
			String finalvalue = transferivrintentInput.getMtn() + "," + transferivrintentInput.getCall_timestamp() + ","
					+ transferivrintentInput.getCall_category_stated_intent() + ","
					+ transferivrintentInput.getCall_time_of_day() + "," + transferivrintentInput.getCall_day_of_week()
					+ "," + transferivrintentInput.getCall_is_save_call() + ","
					+ transferivrintentInput.getCall_ivr_hq_route_value() + ","
					+ transferivrintentInput.getCall_ivr_account_type() + ","
					+ transferivrintentInput.getCall_ivr_device_id() + ","
					+ transferivrintentInput.getCall_ivr_cust_value() + ","
					+ transferivrintentInput.getCall_ivr_special_handling() + ","
					+ transferivrintentInput.getCall_ivr_lang() + "," + transferivrintentInput.getCall_ivr_wallet()
					+ "," + transferivrintentInput.getCall_ivr_cacs_level() + ","
					+ transferivrintentInput.getCall_ivr_fb_npp_tsr_seg_cplx() + ","
					+ transferivrintentInput.getCall_ivr_onstar_qes() + ","
					+ transferivrintentInput.getCall_ivr_customer_intent() + ","
					+ transferivrintentInput.getCall_ivr_onebill() + ","
					+ transferivrintentInput.getCall_ivr_high_risk_loe() + ","
					+ transferivrintentInput.getCall_ivr_work_state() + "," + transferivrintentInput.getCall_ivr_assoc()
					+ "," + transferivrintentInput.getCall_ivr_device_category() + ","
					+ transferivrintentInput.getCall_ivr_hrp() + ","
					+ transferivrintentInput.getCall_ivr_solution_teams() + ","
					+ transferivrintentInput.getCall_speech_tag();
			

			Map<String, String> cassandraMap = new HashMap<String, String>();

			cassandraMap.put(IvrTransferIntentConstant.IVRIntent_UPDATEBY, "dataflow");
			cassandraMap.put(IvrTransferIntentConstant.IVRIntent_INSIGHTCATEGORY, "agentaipair");
			cassandraMap.put(IvrTransferIntentConstant.IVRIntent_INSIGHTNAME, "callprofile");
			cassandraMap.put(IvrTransferIntentConstant.IVRIntent_INSIGHTVALUES, finalvalue);
			cassandraMap.put(IvrTransferIntentConstant.IVRIntent_Id, transferivrintentInput.getMtn());

			DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss O");
			ZonedDateTime gmtTime = ZonedDateTime.now(ZoneId.of("GMT"));

			cassandraMap.put("updateTs", format.format(gmtTime));
			cassandraMap.put("KafkaInputRaw", sourceData.toString());
			cassandraMap.put("StartTime", format_starttime.format(gmtTime_starttime));
			cassandraMap.put("IVREventSentTime", transferivrintentInput.getEventts());
			cassandraMap.put("mtn", transferivrintentInput.getMtn());
			

			processedCounter.inc();

			c.output(IVRTransferCustomerInsights, new JSONObject(cassandraMap).toString());
			
			
			
			
			
			
		} catch (Exception e) {

			unprocessedCounter.inc();
			c.output(deadletter, c.element());
			e.printStackTrace(System.out);
		}

	}

}
