package com.verizon.dataindus.rtstreams.core.beans.tar.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class ThreatHistoryCount implements Serializable {
	private static final long serialVersionUID = 1L;
	/*
	 * type threatHistoryCountType = rstring date, int32 threatHistoryCountDarkWeb,
	 * int32 threatHistoryCountWifi, int32 threatHistoryCountSystemThreat, int32
	 * threatHistoryCountTotal;
	 */
	@SerializedName("date")
	@Nullable
	public String date;
	@SerializedName("threatHistoryCountDarkWeb")
	@Nullable
	public int threatHistoryCountDarkWeb;
	@SerializedName("threatHistoryCountWifi")
	@Nullable
	public int threatHistoryCountWifi;
	@SerializedName("threatHistoryCountSystemThreat")
	@Nullable
	public int threatHistoryCountSystemThreat;
	@SerializedName("threatHistoryCountTotal")
	@Nullable
	public int threatHistoryCountTotal;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getThreatHistoryCountDarkWeb() {
		return threatHistoryCountDarkWeb;
	}

	public void setThreatHistoryCountDarkWeb(int threatHistoryCountDarkWeb) {
		this.threatHistoryCountDarkWeb = threatHistoryCountDarkWeb;
	}

	public int getThreatHistoryCountWifi() {
		return threatHistoryCountWifi;
	}

	public void setThreatHistoryCountWifi(int threatHistoryCountWifi) {
		this.threatHistoryCountWifi = threatHistoryCountWifi;
	}

	public int getThreatHistoryCountSystemThreat() {
		return threatHistoryCountSystemThreat;
	}

	public void setThreatHistoryCountSystemThreat(int threatHistoryCountSystemThreat) {
		this.threatHistoryCountSystemThreat = threatHistoryCountSystemThreat;
	}

	public int getThreatHistoryCountTotal() {
		return threatHistoryCountTotal;
	}

	public void setThreatHistoryCountTotal(int threatHistoryCountTotal) {
		this.threatHistoryCountTotal = threatHistoryCountTotal;
	}

	@Override
	public String toString() {
		return "ThreatHistoryCount [date=" + date + ", threatHistoryCountDarkWeb=" + threatHistoryCountDarkWeb
				+ ", threatHistoryCountWifi=" + threatHistoryCountWifi + ", threatHistoryCountSystemThreat="
				+ threatHistoryCountSystemThreat + ", threatHistoryCountTotal=" + threatHistoryCountTotal + "]";
	}

	public ThreatHistoryCount(String date, int threatHistoryCountDarkWeb,
			int threatHistoryCountSystemThreat, int threatHistoryCountTotal, int threatHistoryCountWifi) {
		super();
		this.date = date;
		this.threatHistoryCountDarkWeb = threatHistoryCountDarkWeb;
		this.threatHistoryCountWifi = threatHistoryCountWifi;
		this.threatHistoryCountSystemThreat = threatHistoryCountSystemThreat;
		this.threatHistoryCountTotal = threatHistoryCountTotal;
	}

	public ThreatHistoryCount() {
		super();
	}

}
