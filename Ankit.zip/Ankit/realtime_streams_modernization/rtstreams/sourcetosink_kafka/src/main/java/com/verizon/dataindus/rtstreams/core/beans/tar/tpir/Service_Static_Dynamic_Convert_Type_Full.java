package com.verizon.dataindus.rtstreams.core.beans.tar.tpir;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
import java.util.List;


@javax.annotation.Nullable

public class Service_Static_Dynamic_Convert_Type_Full implements Serializable {

	@SerializedName("serviceName")
	@Nullable
	public String serviceName;

	@SerializedName("subserviceName")
	@Nullable
	public String subserviceName;

	@SerializedName("requestID")
	@Nullable
	public String requestID;

	@SerializedName("clientName")
	@Nullable
	public String clientName;

	@SerializedName("generatedID")
	@Nullable
	public String generatedID;

	@SerializedName("version")
	@Nullable
	public String version;

	@SerializedName("accessoryID")
	@Nullable
	public String accessoryID;

	@SerializedName("accountNumber")
	@Nullable
	public String accountNumber;

	@SerializedName("accountTenure")
	@Nullable
	public String accountTenure;

	@SerializedName("activityDate")
	@Nullable
	public String activityDate;

	@SerializedName("activityDetail")
	@Nullable
	public String activityDetail;

	@SerializedName("activitySummary")
	@Nullable
	public String activitySummary;

	@SerializedName("additionalInfo")
	@Nullable
	public String additionalInfo;

	@SerializedName("agentStoreID")
	@Nullable
	public String agentStoreID;

	@SerializedName("agentUserName")
	@Nullable
	public String agentUserName;

	@SerializedName("amount")
	@Nullable
	public String amount;

	@SerializedName("callCenterDesc")
	@Nullable
	public String callCenterDesc;

	@SerializedName("callDisputeInd")
	@Nullable
	public String callDisputeInd;

	@SerializedName("callReason")
	@Nullable
	public String callReason;

	@SerializedName("cartID")
	@Nullable
	public String cartID;

	@SerializedName("channelId")
	@Nullable
	public String channelId;

	@SerializedName("chatDate")
	@Nullable
	public String chatDate;

	@SerializedName("chatIntend")
	@Nullable
	public String chatIntend;

	@SerializedName("chatSkill")
	@Nullable
	public String chatSkill;

	@SerializedName("currentPricePlanID")
	@Nullable
	public String currentPricePlanID;

	@SerializedName("currentSplFeatureOfferID")
	@Nullable
	public String currentSplFeatureOfferID;

	@SerializedName("dateType")
	@Nullable
	public String dateType;

	@SerializedName("departmentDesc")
	@Nullable
	public String departmentDesc;

	@SerializedName("destinationDept")
	@Nullable
	public String destinationDept;

	@SerializedName("deviceID")
	@Nullable
	public String deviceID;

	@SerializedName("dialOutReturnCode")
	@Nullable
	public String dialOutReturnCode;

	@SerializedName("dnis")
	@Nullable
	public String dnis;

	@SerializedName("ecpdID")
	@Nullable
	public String ecpdID;

	@SerializedName("employeeId")
	@Nullable
	public String employeeId;

	@SerializedName("errorCode")
	@Nullable
	public String errorCode;

	@SerializedName("errorMsg")
	@Nullable
	public String errorMsg;

	@SerializedName("esnmeID")
	@Nullable
	public String esnmeID;

	@SerializedName("exitCode")
	@Nullable
	public String exitCode;

	@SerializedName("failCode")
	@Nullable
	public String failCode;

	@SerializedName("failReason")
	@Nullable
	public String failReason;

	@SerializedName("featureID")
	@Nullable
	public String featureID;

	@SerializedName("finalStatus")
	@Nullable
	public String finalStatus;

	@SerializedName("firstName")
	@Nullable
	public String firstName;

	@SerializedName("globalID")
	@Nullable
	public String globalID;

	@SerializedName("intent")
	@Nullable
	public String intent;

	@SerializedName("invoiceID")
	@Nullable
	public String invoiceID;

	@SerializedName("lastName")
	@Nullable
	public String lastName;

	@SerializedName("level")
	@Nullable
	public String level;

	@SerializedName("lob")
	@Nullable
	public String lob;

	@SerializedName("mtn")
	@Nullable
	public String mtn;

	@SerializedName("mtnContractExpDate")
	@Nullable
	public String mtnContractExpDate;

	@SerializedName("newPricePlanID")
	@Nullable
	public String newPricePlanID;

	@SerializedName("newSplFeatureOfferID")
	@Nullable
	public String newSplFeatureOfferID;

	@SerializedName("nps")
	@Nullable
	public String nps;

	@SerializedName("nrbTicketNumber")
	@Nullable
	public String nrbTicketNumber;

	@SerializedName("numberOfLines")
	@Nullable
	public String numberOfLines;

	@SerializedName("orderID")
	@Nullable
	public String orderID;

	@SerializedName("orderNumber")
	@Nullable
	public String orderNumber;

	@SerializedName("pageName")
	@Nullable
	public String pageName;

	@SerializedName("pastDueAmt")
	@Nullable
	public String pastDueAmt;

	@SerializedName("paymentDetail")
	@Nullable
	public String paymentDetail;

	@SerializedName("paymentType")
	@Nullable
	public String paymentType;

	@SerializedName("phoneNum")
	@Nullable
	public String phoneNum;

	@SerializedName("planID")
	@Nullable
	public String planID;

	@SerializedName("postalCode")
	@Nullable
	public String postalCode;

	@SerializedName("purchaseFlow")
	@Nullable
	public String purchaseFlow;

	@SerializedName("realTimeID")
	@Nullable
	public String realTimeID;

	@SerializedName("releaseOrder")
	@Nullable
	public String releaseOrder;

	@SerializedName("remedyFlag")
	@Nullable
	public String remedyFlag;

	@SerializedName("repId")
	@Nullable
	public String repId;

	@SerializedName("repName")
	@Nullable
	public String repName;

	@SerializedName("revenue")
	@Nullable
	public String revenue;

	@SerializedName("selfServe")
	@Nullable
	public String selfServe;

	@SerializedName("sessionID")
	@Nullable
	public String sessionID;

	@SerializedName("simID")
	@Nullable
	public String simID;

	@SerializedName("status")
	@Nullable
	public String status;

	@SerializedName("statusCode")
	@Nullable
	public String statusCode;

	@SerializedName("statusMessage")
	@Nullable
	public String statusMessage;

	@SerializedName("subChannel")
	@Nullable
	public String subChannel;

	@SerializedName("timeStamp")
	@Nullable
	public String timeStamp;

	@SerializedName("toolkit")
	@Nullable
	public String toolkit;

	@SerializedName("totalAllowance")
	@Nullable
	public String totalAllowance;

	@SerializedName("totalRemaining")
	@Nullable
	public String totalRemaining;

	@SerializedName("transferPoint")
	@Nullable
	public String transferPoint;

	@SerializedName("treatmentFlag")
	@Nullable
	public String treatmentFlag;

	@SerializedName("tsrCreatedDate")
	@Nullable
	public String tsrCreatedDate;

	@SerializedName("tsrID")
	@Nullable
	public String tsrID;

	@SerializedName("tsrNextStep")
	@Nullable
	public String tsrNextStep;

	@SerializedName("tsrSymptom")
	@Nullable
	public String tsrSymptom;

	@SerializedName("tsrSymptomID")
	@Nullable
	public String tsrSymptomID;

	@SerializedName("typeOfBilling")
	@Nullable
	public String typeOfBilling;

	@SerializedName("userID")
	@Nullable
	public String userID;

	@SerializedName("userRole")
	@Nullable
	public String userRole;

	@SerializedName("workState")
	@Nullable
	public String workState;

	@SerializedName("cbr1")
	@Nullable
	public String cbr1;

	@SerializedName("cbr1Type")
	@Nullable
	public String cbr1Type;

	@SerializedName("cbr2")
	@Nullable
	public String cbr2;

	@SerializedName("cbr2Type")
	@Nullable
	public String cbr2Type;

	@SerializedName("speechTag")
	@Nullable
	public String speechTag;

	@SerializedName("account_number")
	@Nullable
	public String account_number;

	@SerializedName("cust_id")
	@Nullable
	public String cust_id;

	@SerializedName("transdatetime")
	@Nullable
	public String transdatetime;

	@SerializedName("agentStoreName")
	@Nullable
	public String agentStoreName;

	@SerializedName("cbr")
	@Nullable
	public String cbr;

	@SerializedName("congestedHours")
	@Nullable
	public String congestedHours;

	@SerializedName("custCANum")
	@Nullable
	public String custCANum;

	@SerializedName("customerAppVersion")
	@Nullable
	public String customerAppVersion;

	@SerializedName("lastLogin")
	@Nullable
	public String lastLogin;

	@SerializedName("latestAppVersionInAppStore")
	@Nullable
	public String latestAppVersionInAppStore;

	@SerializedName("outageID")
	@Nullable
	public String outageID;

	@SerializedName("outageState")
	@Nullable
	public String outageState;

	@SerializedName("linkageID")
	@Nullable
	String linkageID;

	@SerializedName("time_details")
	@Nullable
	List<TimeDetails> timeDetails;

	public List<TimeDetails> getTimeDetails() {
		return timeDetails;
	}

	public void setTimeDetails(List<TimeDetails> timeDetails) {
		this.timeDetails = timeDetails;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getSubserviceName() {
		return subserviceName;
	}

	public void setSubserviceName(String subserviceName) {
		this.subserviceName = subserviceName;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getGeneratedID() {
		return generatedID;
	}

	public void setGeneratedID(String generatedID) {
		this.generatedID = generatedID;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAccessoryID() {
		return accessoryID;
	}

	public void setAccessoryID(String accessoryID) {
		this.accessoryID = accessoryID;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountTenure() {
		return accountTenure;
	}

	public void setAccountTenure(String accountTenure) {
		this.accountTenure = accountTenure;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getActivityDetail() {
		return activityDetail;
	}

	public void setActivityDetail(String activityDetail) {
		this.activityDetail = activityDetail;
	}

	public String getActivitySummary() {
		return activitySummary;
	}

	public void setActivitySummary(String activitySummary) {
		this.activitySummary = activitySummary;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getAgentStoreID() {
		return agentStoreID;
	}

	public void setAgentStoreID(String agentStoreID) {
		this.agentStoreID = agentStoreID;
	}

	public String getAgentUserName() {
		return agentUserName;
	}

	public void setAgentUserName(String agentUserName) {
		this.agentUserName = agentUserName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCallCenterDesc() {
		return callCenterDesc;
	}

	public void setCallCenterDesc(String callCenterDesc) {
		this.callCenterDesc = callCenterDesc;
	}

	public String getCallDisputeInd() {
		return callDisputeInd;
	}

	public void setCallDisputeInd(String callDisputeInd) {
		this.callDisputeInd = callDisputeInd;
	}

	public String getCallReason() {
		return callReason;
	}

	public void setCallReason(String callReason) {
		this.callReason = callReason;
	}

	public String getCartID() {
		return cartID;
	}

	public void setCartID(String cartID) {
		this.cartID = cartID;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getChatDate() {
		return chatDate;
	}

	public void setChatDate(String chatDate) {
		this.chatDate = chatDate;
	}

	public String getChatIntend() {
		return chatIntend;
	}

	public void setChatIntend(String chatIntend) {
		this.chatIntend = chatIntend;
	}

	public String getChatSkill() {
		return chatSkill;
	}

	public void setChatSkill(String chatSkill) {
		this.chatSkill = chatSkill;
	}

	public String getCurrentPricePlanID() {
		return currentPricePlanID;
	}

	public void setCurrentPricePlanID(String currentPricePlanID) {
		this.currentPricePlanID = currentPricePlanID;
	}

	public String getCurrentSplFeatureOfferID() {
		return currentSplFeatureOfferID;
	}

	public void setCurrentSplFeatureOfferID(String currentSplFeatureOfferID) {
		this.currentSplFeatureOfferID = currentSplFeatureOfferID;
	}

	public String getDateType() {
		return dateType;
	}

	public void setDateType(String dateType) {
		this.dateType = dateType;
	}

	public String getDepartmentDesc() {
		return departmentDesc;
	}

	public void setDepartmentDesc(String departmentDesc) {
		this.departmentDesc = departmentDesc;
	}

	public String getDestinationDept() {
		return destinationDept;
	}

	public void setDestinationDept(String destinationDept) {
		this.destinationDept = destinationDept;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getDialOutReturnCode() {
		return dialOutReturnCode;
	}

	public void setDialOutReturnCode(String dialOutReturnCode) {
		this.dialOutReturnCode = dialOutReturnCode;
	}

	public String getDnis() {
		return dnis;
	}

	public void setDnis(String dnis) {
		this.dnis = dnis;
	}

	public String getEcpdID() {
		return ecpdID;
	}

	public void setEcpdID(String ecpdID) {
		this.ecpdID = ecpdID;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getEsnmeID() {
		return esnmeID;
	}

	public void setEsnmeID(String esnmeID) {
		this.esnmeID = esnmeID;
	}

	public String getExitCode() {
		return exitCode;
	}

	public void setExitCode(String exitCode) {
		this.exitCode = exitCode;
	}

	public String getFailCode() {
		return failCode;
	}

	public void setFailCode(String failCode) {
		this.failCode = failCode;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getFeatureID() {
		return featureID;
	}

	public void setFeatureID(String featureID) {
		this.featureID = featureID;
	}

	public String getFinalStatus() {
		return finalStatus;
	}

	public void setFinalStatus(String finalStatus) {
		this.finalStatus = finalStatus;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGlobalID() {
		return globalID;
	}

	public void setGlobalID(String globalID) {
		this.globalID = globalID;
	}

	public String getIntent() {
		return intent;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}

	public String getInvoiceID() {
		return invoiceID;
	}

	public void setInvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getMtnContractExpDate() {
		return mtnContractExpDate;
	}

	public void setMtnContractExpDate(String mtnContractExpDate) {
		this.mtnContractExpDate = mtnContractExpDate;
	}

	public String getNewPricePlanID() {
		return newPricePlanID;
	}

	public void setNewPricePlanID(String newPricePlanID) {
		this.newPricePlanID = newPricePlanID;
	}

	public String getNewSplFeatureOfferID() {
		return newSplFeatureOfferID;
	}

	public void setNewSplFeatureOfferID(String newSplFeatureOfferID) {
		this.newSplFeatureOfferID = newSplFeatureOfferID;
	}

	public String getNps() {
		return nps;
	}

	public void setNps(String nps) {
		this.nps = nps;
	}

	public String getNrbTicketNumber() {
		return nrbTicketNumber;
	}

	public void setNrbTicketNumber(String nrbTicketNumber) {
		this.nrbTicketNumber = nrbTicketNumber;
	}

	public String getNumberOfLines() {
		return numberOfLines;
	}

	public void setNumberOfLines(String numberOfLines) {
		this.numberOfLines = numberOfLines;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getPastDueAmt() {
		return pastDueAmt;
	}

	public void setPastDueAmt(String pastDueAmt) {
		this.pastDueAmt = pastDueAmt;
	}

	public String getPaymentDetail() {
		return paymentDetail;
	}

	public void setPaymentDetail(String paymentDetail) {
		this.paymentDetail = paymentDetail;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getPlanID() {
		return planID;
	}

	public void setPlanID(String planID) {
		this.planID = planID;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPurchaseFlow() {
		return purchaseFlow;
	}

	public void setPurchaseFlow(String purchaseFlow) {
		this.purchaseFlow = purchaseFlow;
	}

	public String getRealTimeID() {
		return realTimeID;
	}

	public void setRealTimeID(String realTimeID) {
		this.realTimeID = realTimeID;
	}

	public String getReleaseOrder() {
		return releaseOrder;
	}

	public void setReleaseOrder(String releaseOrder) {
		this.releaseOrder = releaseOrder;
	}

	public String getRemedyFlag() {
		return remedyFlag;
	}

	public void setRemedyFlag(String remedyFlag) {
		this.remedyFlag = remedyFlag;
	}

	public String getRepId() {
		return repId;
	}

	public void setRepId(String repId) {
		this.repId = repId;
	}

	public String getRepName() {
		return repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getRevenue() {
		return revenue;
	}

	public void setRevenue(String revenue) {
		this.revenue = revenue;
	}

	public String getSelfServe() {
		return selfServe;
	}

	public void setSelfServe(String selfServe) {
		this.selfServe = selfServe;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public String getSimID() {
		return simID;
	}

	public void setSimID(String simID) {
		this.simID = simID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getSubChannel() {
		return subChannel;
	}

	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getToolkit() {
		return toolkit;
	}

	public void setToolkit(String toolkit) {
		this.toolkit = toolkit;
	}

	public String getTotalAllowance() {
		return totalAllowance;
	}

	public void setTotalAllowance(String totalAllowance) {
		this.totalAllowance = totalAllowance;
	}

	public String getTotalRemaining() {
		return totalRemaining;
	}

	public void setTotalRemaining(String totalRemaining) {
		this.totalRemaining = totalRemaining;
	}

	public String getTransferPoint() {
		return transferPoint;
	}

	public void setTransferPoint(String transferPoint) {
		this.transferPoint = transferPoint;
	}

	public String getTreatmentFlag() {
		return treatmentFlag;
	}

	public void setTreatmentFlag(String treatmentFlag) {
		this.treatmentFlag = treatmentFlag;
	}

	public String getTsrCreatedDate() {
		return tsrCreatedDate;
	}

	public void setTsrCreatedDate(String tsrCreatedDate) {
		this.tsrCreatedDate = tsrCreatedDate;
	}

	public String getTsrID() {
		return tsrID;
	}

	public void setTsrID(String tsrID) {
		this.tsrID = tsrID;
	}

	public String getTsrNextStep() {
		return tsrNextStep;
	}

	public void setTsrNextStep(String tsrNextStep) {
		this.tsrNextStep = tsrNextStep;
	}

	public String getTsrSymptom() {
		return tsrSymptom;
	}

	public void setTsrSymptom(String tsrSymptom) {
		this.tsrSymptom = tsrSymptom;
	}

	public String getTsrSymptomID() {
		return tsrSymptomID;
	}

	public void setTsrSymptomID(String tsrSymptomID) {
		this.tsrSymptomID = tsrSymptomID;
	}

	public String getTypeOfBilling() {
		return typeOfBilling;
	}

	public void setTypeOfBilling(String typeOfBilling) {
		this.typeOfBilling = typeOfBilling;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getWorkState() {
		return workState;
	}

	public void setWorkState(String workState) {
		this.workState = workState;
	}

	public String getCbr1() {
		return cbr1;
	}

	public void setCbr1(String cbr1) {
		this.cbr1 = cbr1;
	}

	public String getCbr1Type() {
		return cbr1Type;
	}

	public void setCbr1Type(String cbr1Type) {
		this.cbr1Type = cbr1Type;
	}

	public String getCbr2() {
		return cbr2;
	}

	public void setCbr2(String cbr2) {
		this.cbr2 = cbr2;
	}

	public String getCbr2Type() {
		return cbr2Type;
	}

	public void setCbr2Type(String cbr2Type) {
		this.cbr2Type = cbr2Type;
	}

	public String getSpeechTag() {
		return speechTag;
	}

	public void setSpeechTag(String speechTag) {
		this.speechTag = speechTag;
	}

	public String getAccount_number() {
		return account_number;
	}

	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public String getTransdatetime() {
		return transdatetime;
	}

	public void setTransdatetime(String transdatetime) {
		this.transdatetime = transdatetime;
	}

	public String getAgentStoreName() {
		return agentStoreName;
	}

	public void setAgentStoreName(String agentStoreName) {
		this.agentStoreName = agentStoreName;
	}

	public String getCbr() {
		return cbr;
	}

	public void setCbr(String cbr) {
		this.cbr = cbr;
	}

	public String getCongestedHours() {
		return congestedHours;
	}

	public void setCongestedHours(String congestedHours) {
		this.congestedHours = congestedHours;
	}

	public String getCustCANum() {
		return custCANum;
	}

	public void setCustCANum(String custCANum) {
		this.custCANum = custCANum;
	}

	public String getCustomerAppVersion() {
		return customerAppVersion;
	}

	public void setCustomerAppVersion(String customerAppVersion) {
		this.customerAppVersion = customerAppVersion;
	}

	public String getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}

	public String getLatestAppVersionInAppStore() {
		return latestAppVersionInAppStore;
	}

	public void setLatestAppVersionInAppStore(String latestAppVersionInAppStore) {
		this.latestAppVersionInAppStore = latestAppVersionInAppStore;
	}

	public String getOutageID() {
		return outageID;
	}

	public void setOutageID(String outageID) {
		this.outageID = outageID;
	}

	public String getOutageState() {
		return outageState;
	}

	public void setOutageState(String outageState) {
		this.outageState = outageState;
	}

	public String getLinkageID() {
		return linkageID;
	}

	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	}

	@Override
	public String toString() {
		return "Service_Static_Dynamic_Convert_Type_Full [serviceName=" + serviceName + ", subserviceName="
				+ subserviceName + ", requestID=" + requestID + ", clientName=" + clientName + ", generatedID="
				+ generatedID + ", version=" + version + ", accessoryID=" + accessoryID + ", accountNumber="
				+ accountNumber + ", accountTenure=" + accountTenure + ", activityDate=" + activityDate
				+ ", activityDetail=" + activityDetail + ", activitySummary=" + activitySummary + ", additionalInfo="
				+ additionalInfo + ", agentStoreID=" + agentStoreID + ", agentUserName=" + agentUserName + ", amount="
				+ amount + ", callCenterDesc=" + callCenterDesc + ", callDisputeInd=" + callDisputeInd + ", callReason="
				+ callReason + ", cartID=" + cartID + ", channelId=" + channelId + ", chatDate=" + chatDate
				+ ", chatIntend=" + chatIntend + ", chatSkill=" + chatSkill + ", currentPricePlanID="
				+ currentPricePlanID + ", currentSplFeatureOfferID=" + currentSplFeatureOfferID + ", dateType="
				+ dateType + ", departmentDesc=" + departmentDesc + ", destinationDept=" + destinationDept
				+ ", deviceID=" + deviceID + ", dialOutReturnCode=" + dialOutReturnCode + ", dnis=" + dnis + ", ecpdID="
				+ ecpdID + ", employeeId=" + employeeId + ", errorCode=" + errorCode + ", errorMsg=" + errorMsg
				+ ", esnmeID=" + esnmeID + ", exitCode=" + exitCode + ", failCode=" + failCode + ", failReason="
				+ failReason + ", featureID=" + featureID + ", finalStatus=" + finalStatus + ", firstName=" + firstName
				+ ", globalID=" + globalID + ", intent=" + intent + ", invoiceID=" + invoiceID + ", lastName="
				+ lastName + ", level=" + level + ", lob=" + lob + ", mtn=" + mtn + ", mtnContractExpDate="
				+ mtnContractExpDate + ", newPricePlanID=" + newPricePlanID + ", newSplFeatureOfferID="
				+ newSplFeatureOfferID + ", nps=" + nps + ", nrbTicketNumber=" + nrbTicketNumber + ", numberOfLines="
				+ numberOfLines + ", orderID=" + orderID + ", orderNumber=" + orderNumber + ", pageName=" + pageName
				+ ", pastDueAmt=" + pastDueAmt + ", paymentDetail=" + paymentDetail + ", paymentType=" + paymentType
				+ ", phoneNum=" + phoneNum + ", planID=" + planID + ", postalCode=" + postalCode + ", purchaseFlow="
				+ purchaseFlow + ", realTimeID=" + realTimeID + ", releaseOrder=" + releaseOrder + ", remedyFlag="
				+ remedyFlag + ", repId=" + repId + ", repName=" + repName + ", revenue=" + revenue + ", selfServe="
				+ selfServe + ", sessionID=" + sessionID + ", simID=" + simID + ", status=" + status + ", statusCode="
				+ statusCode + ", statusMessage=" + statusMessage + ", subChannel=" + subChannel + ", timeStamp="
				+ timeStamp + ", toolkit=" + toolkit + ", totalAllowance=" + totalAllowance + ", totalRemaining="
				+ totalRemaining + ", transferPoint=" + transferPoint + ", treatmentFlag=" + treatmentFlag
				+ ", tsrCreatedDate=" + tsrCreatedDate + ", tsrID=" + tsrID + ", tsrNextStep=" + tsrNextStep
				+ ", tsrSymptom=" + tsrSymptom + ", tsrSymptomID=" + tsrSymptomID + ", typeOfBilling=" + typeOfBilling
				+ ", userID=" + userID + ", userRole=" + userRole + ", workState=" + workState + ", cbr1=" + cbr1
				+ ", cbr1Type=" + cbr1Type + ", cbr2=" + cbr2 + ", cbr2Type=" + cbr2Type + ", speechTag=" + speechTag
				+ ", account_number=" + account_number + ", cust_id=" + cust_id + ", transdatetime=" + transdatetime
				+ ", agentStoreName=" + agentStoreName + ", cbr=" + cbr + ", congestedHours=" + congestedHours
				+ ", custCANum=" + custCANum + ", customerAppVersion=" + customerAppVersion + ", lastLogin=" + lastLogin
				+ ", latestAppVersionInAppStore=" + latestAppVersionInAppStore + ", outageID=" + outageID
				+ ", outageState=" + outageState + ", linkageID=" + linkageID + "]";
	}


}
