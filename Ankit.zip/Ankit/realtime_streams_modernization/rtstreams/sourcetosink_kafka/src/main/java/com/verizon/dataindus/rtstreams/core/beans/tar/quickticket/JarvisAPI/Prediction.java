package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable 
public class Prediction implements Serializable {

   @SerializedName("message")
   String message;

   @SerializedName("statusCode")
   int statusCode;


    public void setMessage(String message) {
        this.message = message;
    }
    public String getMessage() {
        return message;
    }
    
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
    public int getStatusCode() {
        return statusCode;
    }
    
}