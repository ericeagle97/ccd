package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.tar.reconnect.CassandraStream;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class AllDataFlattened implements Serializable {
    @SerializedName("CtiOutputPojo")
    @Nullable
    CtiOutputPojo CtiOutputPojo;
    @SerializedName("IvrCallPath")
    @Nullable
    IvrCallPath IvrCallPath;

    @SerializedName("CassandraStream")
    @Nullable
    CassandraStream cassandraStream;

    public CassandraStream getCassandraStream() {
        return cassandraStream;
    }

    public void setCassandraStream(CassandraStream cassandraStream) {
        this.cassandraStream = cassandraStream;
    }

    public com.verizon.dataindus.rtstreams.core.beans.src.reconnect.CtiOutputPojo getCtiOutputPojo() {
        return CtiOutputPojo;
    }

    public void setCtiOutputPojo(com.verizon.dataindus.rtstreams.core.beans.src.reconnect.CtiOutputPojo ctiOutputPojo) {
        CtiOutputPojo = ctiOutputPojo;
    }

    public com.verizon.dataindus.rtstreams.core.beans.src.reconnect.IvrCallPath getIvrCallPath() {
        return IvrCallPath;
    }

    public void setIvrCallPath(com.verizon.dataindus.rtstreams.core.beans.src.reconnect.IvrCallPath ivrCallPath) {
        IvrCallPath = ivrCallPath;
    }


    @Override
    public String toString() {
        return "AllDataFlattened{" +
                "CtiOutputPojo=" + CtiOutputPojo +
                ", IvrCallPath=" + IvrCallPath +
                ", cassandraStream=" + cassandraStream +
                '}';
    }
}
