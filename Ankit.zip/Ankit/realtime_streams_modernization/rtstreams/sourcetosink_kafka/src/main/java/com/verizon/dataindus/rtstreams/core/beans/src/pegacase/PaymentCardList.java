package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class PaymentCardList implements Serializable {

   @Nullable
	@SerializedName("zipCode")
   String zipCode;

   @Nullable
	@SerializedName("requestType")
   String requestType;

   @Nullable
	@SerializedName("nickName")
   String nickName;

   @Nullable
	@SerializedName("expiryMonth")
   String expiryMonth;

   @Nullable
	@SerializedName("expiryYear")
   String expiryYear;

   @Nullable
	@SerializedName("paymentMethodType")
   String paymentMethodType;

   @Nullable
	@SerializedName("cardNumber")
   String cardNumber;

   @Nullable
	@SerializedName("lob")
   String lob;

   @Nullable
	@SerializedName("cid")
   String cid;


    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    public String getZipCode() {
        return zipCode;
    }
    
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    public String getRequestType() {
        return requestType;
    }
    
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    public String getNickName() {
        return nickName;
    }
    
    public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
    }
    public String getExpiryMonth() {
        return expiryMonth;
    }
    
    public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
    }
    public String getExpiryYear() {
        return expiryYear;
    }
    
    public void setPaymentMethodType(String paymentMethodType) {
        this.paymentMethodType = paymentMethodType;
    }
    public String getPaymentMethodType() {
        return paymentMethodType;
    }
    
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
    public String getCardNumber() {
        return cardNumber;
    }
    
    public void setLob(String lob) {
        this.lob = lob;
    }
    public String getLob() {
        return lob;
    }
    
    public void setCid(String cid) {
        this.cid = cid;
    }
    public String getCid() {
        return cid;
    }
    
}