package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.QTIgniteAPI;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class QTIgniteApiScoreType implements Serializable {

	   @SerializedName("vzwdbCreateTimestamp")
	   String vzwdbCreateTimestamp;

	   @SerializedName("issueDesc")
	   String issueDesc;

	   @SerializedName("symptoms")
	   String symptoms;

	   @SerializedName("ordLocCode")
	   String ordLocCode;

	   @SerializedName("childCount")
	   String childCount;

	   @SerializedName("channelId")
	   String channelId;

	   @SerializedName("transactionID")
	   String transactionID;

	   @SerializedName("timeTaken")
	   String timeTaken;

	   @SerializedName("score")
	   String score;

	   @SerializedName("temp")
	   String temp;

	   @SerializedName("operation")
	   String operation;

	   @SerializedName("refnumber")
	   String refnumber;

	   @SerializedName("comments")
	   String comments;

	   @SerializedName("jiraid")
	   String jiraid;

	   @SerializedName("issuestatus")
	   String issuestatus;

	   @SerializedName("source")
	   String source;

	   @SerializedName("priority")
	   String priority;

	   @SerializedName("mtn")
	   String mtn;

	   @SerializedName("accountid")
	   String accountid;

	   @SerializedName("tickettype")
	   String tickettype;

	   @SerializedName("request")
	   String request;

	   @SerializedName("starttime")
	   String starttime;

	   @SerializedName("endtime")
	   String endtime;


	    public void setVzwdbCreateTimestamp(String vzwdbCreateTimestamp) {
	        this.vzwdbCreateTimestamp = vzwdbCreateTimestamp;
	    }
	    public String getVzwdbCreateTimestamp() {
	        return vzwdbCreateTimestamp;
	    }
	    
	    public void setIssueDesc(String issueDesc) {
	        this.issueDesc = issueDesc;
	    }
	    public String getIssueDesc() {
	        return issueDesc;
	    }
	    
	    public void setSymptoms(String symptoms) {
	        this.symptoms = symptoms;
	    }
	    public String getSymptoms() {
	        return symptoms;
	    }
	    
	    public void setOrdLocCode(String ordLocCode) {
	        this.ordLocCode = ordLocCode;
	    }
	    public String getOrdLocCode() {
	        return ordLocCode;
	    }
	    
	    public void setChildCount(String childCount) {
	        this.childCount = childCount;
	    }
	    public String getChildCount() {
	        return childCount;
	    }
	    
	    public void setChannelId(String channelId) {
	        this.channelId = channelId;
	    }
	    public String getChannelId() {
	        return channelId;
	    }
	    
	    public void setTransactionID(String transactionID) {
	        this.transactionID = transactionID;
	    }
	    public String getTransactionID() {
	        return transactionID;
	    }
	    
	    public void setTimeTaken(String timeTaken) {
	        this.timeTaken = timeTaken;
	    }
	    public String getTimeTaken() {
	        return timeTaken;
	    }
	    
	    public void setScore(String score) {
	        this.score = score;
	    }
	    public String getScore() {
	        return score;
	    }
	    
	    public void setTemp(String temp) {
	        this.temp = temp;
	    }
	    public String getTemp() {
	        return temp;
	    }
	    
	    public void setOperation(String operation) {
	        this.operation = operation;
	    }
	    public String getOperation() {
	        return operation;
	    }
	    
	    public void setRefnumber(String refnumber) {
	        this.refnumber = refnumber;
	    }
	    public String getRefnumber() {
	        return refnumber;
	    }
	    
	    public void setComments(String comments) {
	        this.comments = comments;
	    }
	    public String getComments() {
	        return comments;
	    }
	    
	    public void setJiraid(String jiraid) {
	        this.jiraid = jiraid;
	    }
	    public String getJiraid() {
	        return jiraid;
	    }
	    
	    public void setIssuestatus(String issuestatus) {
	        this.issuestatus = issuestatus;
	    }
	    public String getIssuestatus() {
	        return issuestatus;
	    }
	    
	    public void setSource(String source) {
	        this.source = source;
	    }
	    public String getSource() {
	        return source;
	    }
	    
	    public void setPriority(String priority) {
	        this.priority = priority;
	    }
	    public String getPriority() {
	        return priority;
	    }
	    
	    public void setMtn(String mtn) {
	        this.mtn = mtn;
	    }
	    public String getMtn() {
	        return mtn;
	    }
	    
	    public void setAccountid(String accountid) {
	        this.accountid = accountid;
	    }
	    public String getAccountid() {
	        return accountid;
	    }
	    
	    public void setTickettype(String tickettype) {
	        this.tickettype = tickettype;
	    }
	    public String getTickettype() {
	        return tickettype;
	    }
	    
	    public void setRequest(String request) {
	        this.request = request;
	    }
	    public String getRequest() {
	        return request;
	    }
	    
	    public void setStarttime(String starttime) {
	        this.starttime = starttime;
	    }
	    public String getStarttime() {
	        return starttime;
	    }
	    
	    public void setEndtime(String endtime) {
	        this.endtime = endtime;
	    }
	    public String getEndtime() {
	        return endtime;
	    }
	    
	}