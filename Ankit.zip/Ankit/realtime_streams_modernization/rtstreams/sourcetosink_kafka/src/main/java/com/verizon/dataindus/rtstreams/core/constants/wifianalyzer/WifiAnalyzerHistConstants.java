package com.verizon.dataindus.rtstreams.core.constants.wifianalyzer;

public class WifiAnalyzerHistConstants {

       
    public static final String SESSION_Id = "sessionId";
    public static final String INSIGHT_VALUES = "insightValues";
    public static final String INSIGHT_CATEGORY = "insightCategory";
   
    
    public static final String INSIGHT_NAME = "insightName";
   
    public static final String EPP = "epp";
   
   
    public static final String KEY_ATTRIBUTES = "keyAttributes";
    public static final String USER_ID = "userID";
    public static final String SESSION_ID = "sessionID";
    public static final String USECASE_ID = "usecaseID";
    public static final String VIS_HASHED_ACCOUNT_NO = "visHashedAccountNumber";
    public static final String VIS_HASED_MDN = "visHashedMdn";
    public static final Object CUSTOMER ="customer" ;
    public static final Object KEY_RING_TABLE = "keyring";
    public static final String GENERIC_SCORE = "GenericScore";
    public static final String MTN ="mtn" ;
    public static final String CUST_ID = "cust_id";
    public static final String ACCT_NO = "acct_no";
    public static final String SESSION_INSIGHTS = "SessionInsights";
   
    public static final String OUTCOME = "outcome";
    public static final String CFD = "cfd";
    public static final String SCORES = "scores";

    
    public static final String AGGR_PRODID = "aggrProdId";
    public static final String AGGR_NAME = "aggrName";
    public static final String AGGR_VALUES = "aggrValues";
    public static final String AGGR_CATEGORY = "aggrCategory";
    public static final String UPDATE_BY = "updateBy";
    public static final String LOWER_STREAMS = "streams";
    public static final String STREAMS = "Streams";
    public static final String REQUESTED_BY = "requestedBy";
    public static final String TTL_VALUE = "15780000";
    public static final String TTL = "ttl";
    public static final String TIME = "time";
    public static final String MDN ="mdn" ;
    public static final String WIFIANLYZER_RAW ="wifianlyzer_raw" ;
    public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String TIME_ZONE = " GMT";
    public static final String UPDATE_TS = "updateTs";
   
    
    
    public static final String HEAT_MAP_POINTS = "heatmapPoints";
    public static final String TIMEZONE = "timezone";
    public static final String FLOOR = "floor";
    public static final String TEST_NAME = "testName";
    public static final String TEST_DEVICE = "testDevice";
    public static final String MODEL = "model";
    public static final String WIFI = "wifi";
    public static final String BANDWIDTH_CHANNEL = "bandwidthChannel";
    public static final String RESULT = "result";
    public static final String STRONG = "Strong";
    public static final String WEAK = "Weak";
    public static final String AVERAGE = "Average";
    public static final String WIFIANLYZER_HIST ="wifianlyzer_hist" ;
    public static final String RT = "rt";
    public static final String WIFIRSSI = "wifiRSSI";
    public static final String OS = "OS";
    public static final String RESULTS = "results";
    public static final String WIFI_TEST_HISTORY = "wifiTestHistory";
   
    public static final String AGGR_PRODUCT_INSIGHTS =  "AggrProductInsights";
    public static final String CASSANDRA_REQUEST_TYPE_AGGR_PRODUCT_INSIGHTS = "SOI_AggrProductInsights";
    public static final String CASSANDRA_REQUEST_TYPE_AGGR_PRODUCT_INSIGHTS_TTL = "SOI_InsertAggrProductInsights_ttl";
    
    public static final String REQUEST_TYPE = "requestType";
    
    
    
   
}
