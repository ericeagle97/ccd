package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class CPE5gHomeAlertType implements Serializable{

    @SerializedName("mdn_5g")
    @Nullable
    String mdn_5g;

    @SerializedName("imei")
    @Nullable
    String imei;

    @SerializedName("user_type")
    @Nullable
    double user_type;

    @SerializedName("local_time")
    @Nullable
    String local_time;

    @SerializedName("memory_free")
    @Nullable
    double memory_free;

    @SerializedName("timestamp_1stwatch")
    @Nullable
    String timestamp_1stwatch;

    @SerializedName("timestamp_3rdwatch")
    @Nullable
    String timestamp_3rdwatch;

    @SerializedName("latest_powercycle")
    @Nullable
    String latest_powercycle;

    @SerializedName("filtered_temperature")
    @Nullable
    double filtered_temperature;

    @SerializedName("idu_filtered_temperature")
    @Nullable
    double idu_filtered_temperature;

    @SerializedName("filtered_cqi")
    @Nullable
    String filtered_cqi;

    @SerializedName("filtered_brsrp")
    @Nullable
    String filtered_brsrp;

    @SerializedName("filtered_5gsnr")
    @Nullable
    String filtered_5gsnr;

    @SerializedName("pct_wan_down_7day")
    @Nullable
    String pct_wan_down_7day;

    @SerializedName("on_5g_pct")
    @Nullable
    String on_5g_pct;

    @SerializedName("off_5g_pct")
    @Nullable
    String off_5g_pct;

    @SerializedName("reboot_recommendation")
    @Nullable
    String reboot_recommendation;

    @SerializedName("report_time")
    @Nullable
    String report_time;

    @SerializedName("trans_dt")
    @Nullable
    String trans_dt;

    @SerializedName("active_user")
    @Nullable
    String active_user;

    @SerializedName("alarm_category")
    @Nullable
    String alarm_category;

    @SerializedName("alarm_type")
    @Nullable
    String alarm_type;

    @SerializedName("firmware_ver")
    @Nullable
    String firmware_ver;

    @SerializedName("install_status")
    @Nullable
    String install_status;

    @SerializedName("model_name")
    @Nullable
    String model_name;

    @SerializedName("reboot_order")
    @Nullable
    String reboot_order;

    @SerializedName("site_market")
    @Nullable
    String site_market;

    @SerializedName("time_zone")
    @Nullable
    String time_zone;

    @SerializedName("num_reboot_7days")
    @Nullable
    double num_reboot_7days;

    @SerializedName("alert_id")
    @Nullable
    long alert_id;

    @SerializedName("id")
    @Nullable
    long id;

    @SerializedName("linkageId")
    @Nullable
    String linkageId;

    @Nullable
    public String getMdn_5g() {
        return mdn_5g;
    }

    public void setMdn_5g(@Nullable String mdn_5g) {
        this.mdn_5g = mdn_5g;
    }

    @Nullable
    public String getImei() {
        return imei;
    }

    public void setImei(@Nullable String imei) {
        this.imei = imei;
    }

    public double getUser_type() {
        return user_type;
    }

    public void setUser_type(double user_type) {
        this.user_type = user_type;
    }

    @Nullable
    public String getLocal_time() {
        return local_time;
    }

    public void setLocal_time(@Nullable String local_time) {
        this.local_time = local_time;
    }

    public double getMemory_free() {
        return memory_free;
    }

    public void setMemory_free(double memory_free) {
        this.memory_free = memory_free;
    }

    @Nullable
    public String getTimestamp_1stwatch() {
        return timestamp_1stwatch;
    }

    public void setTimestamp_1stwatch(@Nullable String timestamp_1stwatch) {
        this.timestamp_1stwatch = timestamp_1stwatch;
    }

    @Nullable
    public String getTimestamp_3rdwatch() {
        return timestamp_3rdwatch;
    }

    public void setTimestamp_3rdwatch(@Nullable String timestamp_3rdwatch) {
        this.timestamp_3rdwatch = timestamp_3rdwatch;
    }

    @Nullable
    public String getLatest_powercycle() {
        return latest_powercycle;
    }

    public void setLatest_powercycle(@Nullable String latest_powercycle) {
        this.latest_powercycle = latest_powercycle;
    }

    public double getFiltered_temperature() {
        return filtered_temperature;
    }

    public void setFiltered_temperature(double filtered_temperature) {
        this.filtered_temperature = filtered_temperature;
    }

    public double getIdu_filtered_temperature() {
        return idu_filtered_temperature;
    }

    public void setIdu_filtered_temperature(double idu_filtered_temperature) {
        this.idu_filtered_temperature = idu_filtered_temperature;
    }

    @Nullable
    public String getFiltered_cqi() {
        return filtered_cqi;
    }

    public void setFiltered_cqi(@Nullable String filtered_cqi) {
        this.filtered_cqi = filtered_cqi;
    }

    @Nullable
    public String getFiltered_brsrp() {
        return filtered_brsrp;
    }

    public void setFiltered_brsrp(@Nullable String filtered_brsrp) {
        this.filtered_brsrp = filtered_brsrp;
    }

    @Nullable
    public String getFiltered_5gsnr() {
        return filtered_5gsnr;
    }

    public void setFiltered_5gsnr(@Nullable String filtered_5gsnr) {
        this.filtered_5gsnr = filtered_5gsnr;
    }

    @Nullable
    public String getPct_wan_down_7day() {
        return pct_wan_down_7day;
    }

    public void setPct_wan_down_7day(@Nullable String pct_wan_down_7day) {
        this.pct_wan_down_7day = pct_wan_down_7day;
    }

    @Nullable
    public String getOn_5g_pct() {
        return on_5g_pct;
    }

    public void setOn_5g_pct(@Nullable String on_5g_pct) {
        this.on_5g_pct = on_5g_pct;
    }

    @Nullable
    public String getOff_5g_pct() {
        return off_5g_pct;
    }

    public void setOff_5g_pct(@Nullable String off_5g_pct) {
        this.off_5g_pct = off_5g_pct;
    }

    @Nullable
    public String getReboot_recommendation() {
        return reboot_recommendation;
    }

    public void setReboot_recommendation(@Nullable String reboot_recommendation) {
        this.reboot_recommendation = reboot_recommendation;
    }

    @Nullable
    public String getReport_time() {
        return report_time;
    }

    public void setReport_time(@Nullable String report_time) {
        this.report_time = report_time;
    }

    @Nullable
    public String getTrans_dt() {
        return trans_dt;
    }

    public void setTrans_dt(@Nullable String trans_dt) {
        this.trans_dt = trans_dt;
    }

    @Nullable
    public String getActive_user() {
        return active_user;
    }

    public void setActive_user(@Nullable String active_user) {
        this.active_user = active_user;
    }

    @Nullable
    public String getAlarm_category() {
        return alarm_category;
    }

    public void setAlarm_category(@Nullable String alarm_category) {
        this.alarm_category = alarm_category;
    }

    @Nullable
    public String getAlarm_type() {
        return alarm_type;
    }

    public void setAlarm_type(@Nullable String alarm_type) {
        this.alarm_type = alarm_type;
    }

    @Nullable
    public String getFirmware_ver() {
        return firmware_ver;
    }

    public void setFirmware_ver(@Nullable String firmware_ver) {
        this.firmware_ver = firmware_ver;
    }

    @Nullable
    public String getInstall_status() {
        return install_status;
    }

    public void setInstall_status(@Nullable String install_status) {
        this.install_status = install_status;
    }

    @Nullable
    public String getModel_name() {
        return model_name;
    }

    public void setModel_name(@Nullable String model_name) {
        this.model_name = model_name;
    }

    @Nullable
    public String getReboot_order() {
        return reboot_order;
    }

    public void setReboot_order(@Nullable String reboot_order) {
        this.reboot_order = reboot_order;
    }

    @Nullable
    public String getSite_market() {
        return site_market;
    }

    public void setSite_market(@Nullable String site_market) {
        this.site_market = site_market;
    }

    @Nullable
    public String getTime_zone() {
        return time_zone;
    }

    public void setTime_zone(@Nullable String time_zone) {
        this.time_zone = time_zone;
    }

    public double getNum_reboot_7days() {
        return num_reboot_7days;
    }

    public void setNum_reboot_7days(double num_reboot_7days) {
        this.num_reboot_7days = num_reboot_7days;
    }

    public long getAlert_id() {
        return alert_id;
    }

    public void setAlert_id(long alert_id) {
        this.alert_id = alert_id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    @Override
    public String toString() {
        return "CPE5gHomeAlertType{" +
                "mdn_5g='" + mdn_5g + '\'' +
                ", imei='" + imei + '\'' +
                ", user_type=" + user_type +
                ", local_time='" + local_time + '\'' +
                ", memory_free=" + memory_free +
                ", timestamp_1stwatch='" + timestamp_1stwatch + '\'' +
                ", timestamp_3rdwatch='" + timestamp_3rdwatch + '\'' +
                ", latest_powercycle='" + latest_powercycle + '\'' +
                ", filtered_temperature=" + filtered_temperature +
                ", idu_filtered_temperature=" + idu_filtered_temperature +
                ", filtered_cqi='" + filtered_cqi + '\'' +
                ", filtered_brsrp='" + filtered_brsrp + '\'' +
                ", filtered_5gsnr='" + filtered_5gsnr + '\'' +
                ", pct_wan_down_7day='" + pct_wan_down_7day + '\'' +
                ", on_5g_pct='" + on_5g_pct + '\'' +
                ", off_5g_pct='" + off_5g_pct + '\'' +
                ", reboot_recommendation='" + reboot_recommendation + '\'' +
                ", report_time='" + report_time + '\'' +
                ", trans_dt='" + trans_dt + '\'' +
                ", active_user='" + active_user + '\'' +
                ", alarm_category='" + alarm_category + '\'' +
                ", alarm_type='" + alarm_type + '\'' +
                ", firmware_ver='" + firmware_ver + '\'' +
                ", install_status='" + install_status + '\'' +
                ", model_name='" + model_name + '\'' +
                ", reboot_order='" + reboot_order + '\'' +
                ", site_market='" + site_market + '\'' +
                ", time_zone='" + time_zone + '\'' +
                ", num_reboot_7days=" + num_reboot_7days +
                ", alert_id=" + alert_id +
                ", id=" + id +
                ", linkageId=" + linkageId +
                '}';
    }
}
