package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class CustomerInsightsType implements Serializable {

	public String getCust_id_no() {
		return cust_id_no;
	}

	public void setCust_id_no(String cust_id_no) {
		this.cust_id_no = cust_id_no;
	}

	public String getAcct_no() {
		return acct_no;
	}

	public void setAcct_no(String acct_no) {
		this.acct_no = acct_no;
	}

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getInsight_category() {
		return insight_category;
	}

	public void setInsight_category(String insight_category) {
		this.insight_category = insight_category;
	}

	public String getInsight_name() {
		return insight_name;
	}

	public void setInsight_name(String insight_name) {
		this.insight_name = insight_name;
	}

	public String getInsight_values() {
		return insight_values;
	}

	public void setInsight_values(String insight_values) {
		this.insight_values = insight_values;
	}

	@SerializedName("cust_id_no")
	@Nullable
	private String cust_id_no;

	@SerializedName("acct_no")
	@Nullable
	private String acct_no;

	@SerializedName("mtn")
	@Nullable
	private String mtn;

	@SerializedName("insight_category")
	@Nullable
	private String insight_category;

	@SerializedName("insight_name")
	@Nullable
	private String insight_name;

	@SerializedName("insight_values")
	@Nullable
	private String insight_values;
}
