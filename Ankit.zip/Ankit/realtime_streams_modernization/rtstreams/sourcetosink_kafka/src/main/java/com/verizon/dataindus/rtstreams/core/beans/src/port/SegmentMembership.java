package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class SegmentMembership implements Serializable{

	   @Override
	public String toString() {
		return "SegmentMembership [ups=" + ups + "]";
	}
	@SerializedName("ups")
	   Ups ups;


	    public void setUps(Ups ups) {
	        this.ups = ups;
	    }
	    public Ups getUps() {
	        return ups;
	    }
	    
	}
