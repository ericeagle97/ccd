package com.verizon.dataindus.rtstreams.core.constants.ivrtransferintent;

public class IvrTransferIntentConstant {
	public static final String IVRIntent_CUSTTYPE = "custType";
	public static final String IVRIntent_CUSTID = "custId";
	public static final String IVRIntent_ISSUEID = "issueId";
	public static final String IVRIntent_TIME = "time";
	public static final String IVRIntent_clientApp = "clientApp";
	public static final String IVRIntent_EVENTTIME = "eventTime";
	public static final String IVRIntent_DATE = "date";
	public static final String IVRIntent_EVENTDATE = "eventDate";
	public static final String IVRIntent_INSIGHTVALUES = "insightValues";
	public static final String IVRIntent_UPDATEBY = "updateBy";
	public static final String IVRIntent_CREATEDBY = "createdBy";
	public static final String IVRIntent_UPDATETS = "updateTs";
	public static final String IVRIntent_KEYATTRIBUTES = "keyAttributes";
	public static final String IVRIntent_INTERACTIONS = "interactions";
	public static final String IVRIntent_INSIGHTCATEGORY = "insightCategory";
	public static final String IVRIntent_INSIGHTNAME = "insightName";
	public static final String IVRIntent_TTL = "ttl";
	public static final String IVRIntent_Id = "id";
	public static final String IVRIntent_ACCTNO = "acctNo";
	public static final String IVRIntent_ACCTNUM = "acctNum";
	public static final String IVRIntent_REQUESTTYPE = "requestType";
	public static final String IVRIntent_STREAMS = "streams";
	public static final String CHANNEL = "SourceIVRIntent";

}
