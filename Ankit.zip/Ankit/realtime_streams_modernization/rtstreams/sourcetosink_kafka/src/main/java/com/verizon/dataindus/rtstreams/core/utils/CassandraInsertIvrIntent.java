package com.verizon.dataindus.rtstreams.core.utils;


import com.verizon.dataindus.rtstreams.core.beans.src.ivrintent.cassandratobq;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.lib.IVRIntentCassandraInsertion;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.text.ParseException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class CassandraInsertIvrIntent extends DoFn<String, String> implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertIvrIntent.class);
    private String httpRequest;
    private String requestType;

    public static final TupleTag<String> deadLetterQueue = new TupleTag<String>() {
	};
	public static final TupleTag<String> responseSuccess = new TupleTag<String>() {
	};
	
	public static final TupleTag<String> bqoutput_timemapping = new TupleTag<String>() {
	};
	
    final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_FEATURES+"_"+ Constants.METRICS_COUNTER_SUCCESS);
	final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_FEATURES+"_"+ Constants.METRICS_COUNTER_FAILURE);
	final Counter failureApiCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_API+"_"+ Constants.METRICS_COUNTER_FAILURE);
    static HttpClient client;
    @Setup
    public void setup(){
        client = HttpClient.newHttpClient();
    }

    @Teardown
    public void teardown(){
        if(client != null){
            client=null;
        }
    }

    public CassandraInsertIvrIntent(String httpRequest, String requestType) {
        // TODO Auto-generated constructor stub
        this.httpRequest = httpRequest;
        this.requestType = requestType;
    }


    @ProcessElement
    public void processElement(ProcessContext c) throws ParseException, IOException, InterruptedException {
        flush(c.element().toString(), c);
    }


    private void flush(String record, ProcessContext c) {
        try {
            HashMap<String, Object> batchDataReq = new HashMap<String, Object>();
            JSONObject inpRecord=new JSONObject(record);
            String dfStarttime=inpRecord.getString("StartTime");
            String kafkaInputRaw=inpRecord.getString("KafkaInputRaw");
            String ivrSentTime=inpRecord.getString("IVREventSentTime");
            
            String mtn=inpRecord.getString("mtn");
            
            inpRecord.remove("StartTime");
            inpRecord.remove("KafkaInputRaw");
            inpRecord.remove("IVREventSentTime");
            inpRecord.remove("mtn");
            batchDataReq.put("requestType", requestType);
            batchDataReq.put("keyAttributes", new JSONObject(inpRecord));
            /** object of cassandra insertion library */
            IVRIntentCassandraInsertion insertData = new IVRIntentCassandraInsertion();
            long StartTime = System.currentTimeMillis();
            /** send metadata and data of http request to  cassandra insertion library and stores the response to 'response' variable */
            HttpResponse<String> response = insertData.ivrIntentCassandraInsertion(client, httpRequest,
                    new JSONObject(batchDataReq).toString());
            
            
            long EndTime = System.currentTimeMillis();
            long TimeTaken = EndTime - StartTime;
            
            DateTimeFormatter format_endtime = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss:SSS O");
			ZonedDateTime gmtTime_endtime = ZonedDateTime.now(ZoneId.of("GMT"));
            
			cassandratobq outputRecord=new cassandratobq();
			
			Map<String,Object> cassandrainputMap_BQ = new HashMap<String, Object>();
			
			cassandrainputMap_BQ.put("DfStarttime",dfStarttime.toString());
			cassandrainputMap_BQ.put("IVRSentTime",ivrSentTime.toString());
			cassandrainputMap_BQ.put("KafkaInputRaw",kafkaInputRaw.toString());
			cassandrainputMap_BQ.put("DFEndTime",format_endtime.format(gmtTime_endtime));
			cassandrainputMap_BQ.put("mtn",mtn);
			cassandrainputMap_BQ.put("statusCode",response.statusCode());
			cassandrainputMap_BQ.put("cassandraReq",(inpRecord).toString());
			
			
			c.output(bqoutput_timemapping,new JSONObject(cassandrainputMap_BQ).toString().replace("\\\\",""));
            
            
            //LOG.info(" response=" + response.statusCode() + " StartTime=" + StartTime + " EndTime=" + EndTime + " TimeTaken=" + TimeTaken);
            if(response != null && response.statusCode() == 200 &&
                    response.body().toString().matches(Constants.REGEX_PNO_SUCCESS)) {
				successCounter.inc();
				
				c.output(responseSuccess,batchDataReq+","+response);			
			} 
			else if (response == null || ! (response.body().toString().matches(Constants.REGEX_PNO_SUCCESS))) {
				failureCounter.inc();
				
				c.output(deadLetterQueue, new JSONObject(batchDataReq).toString());
			}
			else {
				failureCounter.inc();
				c.output(deadLetterQueue, new JSONObject(batchDataReq).toString());
			}
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            failureApiCounter.inc();
            LOG.error(sw.toString());
        }

    }
}