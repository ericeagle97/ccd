package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class SHAMainType implements Serializable {
    @SerializedName("requestType")
    @Nullable
    String requestType;

    @SerializedName("keyAttributes")
    @Nullable
    KeyAttributesTypeRemoveAlarm keyAttributes;

    @Nullable
    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(@Nullable String requestType) {
        this.requestType = requestType;
    }

    @Nullable
    public KeyAttributesTypeRemoveAlarm getKeyAttributes() {
        return keyAttributes;
    }

    public void setKeyAttributes(@Nullable KeyAttributesTypeRemoveAlarm keyAttributes) {
        this.keyAttributes = keyAttributes;
    }

    @Override
    public String toString() {
        return "SHAMainType{" +
                "requestType='" + requestType + '\'' +
                ", keyAttributes=" + keyAttributes +
                '}';
    }
}
