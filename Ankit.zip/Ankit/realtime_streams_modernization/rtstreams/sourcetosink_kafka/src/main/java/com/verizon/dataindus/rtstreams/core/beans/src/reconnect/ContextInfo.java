package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class ContextInfo implements Serializable {

   @SerializedName("athenaSessionID")
   @Nullable
   String athenaSessionID;

   @SerializedName("callReason")
   @Nullable
   String callReason;

   @SerializedName("processStep")
   @Nullable
   String processStep;


    public void setAthenaSessionID(String athenaSessionID) {
        this.athenaSessionID = athenaSessionID;
    }
    public String getAthenaSessionID() {
        return athenaSessionID;
    }
    
    public void setCallReason(String callReason) {
        this.callReason = callReason;
    }
    public String getCallReason() {
        return callReason;
    }
    
    public void setProcessStep(String processStep) {
        this.processStep = processStep;
    }
    public String getProcessStep() {
        return processStep;
    }

    @Override
    public String toString() {
        return "ContextInfo{" +
                "athenaSessionID='" + athenaSessionID + '\'' +
                ", callReason='" + callReason + '\'' +
                ", processStep='" + processStep + '\'' +
                '}';
    }
}