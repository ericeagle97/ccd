package com.verizon.dataindus.rtstreams.core.common;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import com.google.cloud.storage.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.verizon.dataindus.rtstreams.core.constants.Properties;
import com.verizon.dataindus.rtstreams.core.constants.Constants;

import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;

public class CommonUtility {

	public static Map<String,JSONObject> getKafkaIOReadConfigurations(
			String project,
			String kafkaIOReadConfigBucket,
			String kafkaIOReadConfigFile,
			String kafkaIOReadSource,
			ExceptionsUtils objCustomExceptions) {

		String fileContent = "";
		try{
			Storage storage = StorageOptions.newBuilder()
					.setProjectId(project)
					.build()
					.getService();

			Blob blob = storage.get(BlobId.of(kafkaIOReadConfigBucket, kafkaIOReadConfigFile));
			fileContent = new String(blob.getContent());
		}
		catch(StorageException storageException){
			objCustomExceptions.storageException(Properties.CLASS_COMMONUTILITY,
					storageException);
			return null;
		}

		try{
			JSONObject jsonConfig = new JSONObject(fileContent)
					.getJSONObject(Constants.CONFIG_KEYWORD_SOURCES)
					.getJSONObject(kafkaIOReadSource);

			JSONArray topicArray = jsonConfig.getJSONArray(Constants.CONFIG_KEYWORD_TOPICS);
			Map<String,JSONObject> kafkaIOReadTopicConfigMap = new HashMap<>();

			populateConfigMap(topicArray, kafkaIOReadTopicConfigMap);

			return kafkaIOReadTopicConfigMap;
		}
		catch(JSONException jsonException){
			objCustomExceptions.jsonException(Properties.CLASS_COMMONUTILITY,jsonException);
			return null;
		}
	}

	public static void populateConfigMap(JSONArray jsonArray, Map<String,JSONObject> map){
		for(int i = 0; i < jsonArray.length(); i++) {
			JSONObject innerObj = jsonArray.getJSONObject(i);
			Iterator<String> keys = innerObj.keys();

			while(keys.hasNext()) {
				String key = keys.next();
				map.put(key, innerObj.getJSONObject(key));
			}
		}
	}

	public static String getGMTDateTime(String pattern) {
		// Format the date and time as a string
		Instant instantTime = Instant.now();
		ZoneId zone = ZoneId.of("GMT");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
		String dateTime = instantTime.atZone(zone).format(formatter);
		return dateTime;

	}
	public static String getMilliTime() {
		Clock clock = Clock.systemDefaultZone();
		Instant instant = clock.instant();
		String milliTs = String.valueOf(instant.toEpochMilli());				
		return milliTs;
	}

	public static String getNanoGMTTime () {
		Instant instantTime = Instant.now();
		ZoneId zone = ZoneId.of("GMT");
		long nano = instantTime.atZone(zone).getNano();
		String dateTime = getGMTDateTime("yyyy-MM-dd HH:mm:ss");
		String nanotime = dateTime+":"+nano +" GMT";
		return nanotime;	
	}

	public static TimeDetails addJobTimestamp(String inout, TimeDetails obj) {

		if("IN".equals(inout)) {
			obj.setInTime(getGMTDateTime("yyyy-MM-dd HH:mm:ss:SSS 'GMT'"));
		}
		else if ("OUT".equals(inout)) {
			obj.setOutTime(getGMTDateTime("yyyy-MM-dd HH:mm:ss:SSS 'GMT'"));
		}
		return obj;

	}

	public static String genLinkageID(String mtn, String channel) {

		Integer uniqueId = 1;
		String indexNo = "0";
		String dateTime = getGMTDateTime("yyyy-MM-dd HHmmss.SSSSSS");
		String currentDay = dateTime.split(" ")[0];
		String currentTime = dateTime.split(" ")[1].split("\\.")[0];

		String currentTimeMs = dateTime.split("\\.")[1];

		String linkageID = "";
		//+getChannel()
		uniqueId = 1;
		//linkageID = mtn+"_"+channel+"_"+currentDay+"_"+currentTime+indexNo+String.valueOf(uniqueId);
		linkageID = mtn + "_" + channel + "_" + currentDay + "_" + currentTime + currentTimeMs + indexNo + String.valueOf(uniqueId);
		return linkageID;
	}

	public static Boolean isNullEmptyOrBlank (String field) {
		if (field == null //|| field.isBlank()
				|| field.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public static Object getEmptyIfNull (Object obj) {
		if (null == obj) {
			return "";
		} else {
			return obj;
		}
	}

	public static String getEmptyStrIfNull(String obj) {
		if ((obj == null) || obj.contentEquals("null")) {
			return "";
		} else {
			return obj;
		}
	}
	
	public static int getDefaultIntIfNull (String obj) {
		if (obj == null) {
			return (int) 0;
		} else {
			return Integer.valueOf(obj);
		}
	}
	
	public static String leftAppendString(String inputString,String filler, int index) {
		int diff = index - inputString.length();
		String temp = inputString;
		int i = 0;
		while (i < diff)
		{
			temp = filler + temp;
			++i;
		}
		return temp;
	}

	public static long getDefaultLongIfNull (String obj) {
		if (obj == null) {
			return (int) 0;
		} else {
			return Long.valueOf(obj);
		}
	}

}
