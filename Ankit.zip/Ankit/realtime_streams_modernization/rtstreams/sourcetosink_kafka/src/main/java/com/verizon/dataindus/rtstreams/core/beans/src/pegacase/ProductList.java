package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class ProductList implements Serializable {

   @Nullable
	@SerializedName("productOfferingId")
   String productOfferingId;

   @Nullable
	@SerializedName("productOfferingPricingID")
   String productOfferingPricingID;

   @Nullable
	@SerializedName("paymentCardList")
   List<PaymentCardList> paymentCardList;

   @Nullable
	@SerializedName("action")
   String action;

   @Nullable
	@SerializedName("productKey")
   String productKey;

   @Nullable
	@SerializedName("promotionId")
   String promotionId;

   @Nullable
	@SerializedName("OfferType")
   @JsonProperty("OfferType")
   String OfferType;

   @Nullable
	@SerializedName("merchantAccountKey")
   String merchantAccountKey;


    public void setProductOfferingId(String productOfferingId) {
        this.productOfferingId = productOfferingId;
    }
    public String getProductOfferingId() {
        return productOfferingId;
    }
    
    public void setProductOfferingPricingID(String productOfferingPricingID) {
        this.productOfferingPricingID = productOfferingPricingID;
    }
    public String getProductOfferingPricingID() {
        return productOfferingPricingID;
    }
    
    public void setPaymentCardList(List<PaymentCardList> paymentCardList) {
        this.paymentCardList = paymentCardList;
    }
    public List<PaymentCardList> getPaymentCardList() {
        return paymentCardList;
    }
    
    public void setAction(String action) {
        this.action = action;
    }
    public String getAction() {
        return action;
    }
    
    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }
    public String getProductKey() {
        return productKey;
    }
    
    public void setPromotionId(String promotionId) {
        this.promotionId = promotionId;
    }
    public String getPromotionId() {
        return promotionId;
    }
    
    public void setOfferType(String OfferType) {
        this.OfferType = OfferType;
    }
    public String getOfferType() {
        return OfferType;
    }
    
    public void setMerchantAccountKey(String merchantAccountKey) {
        this.merchantAccountKey = merchantAccountKey;
    }
    public String getMerchantAccountKey() {
        return merchantAccountKey;
    }
    
}