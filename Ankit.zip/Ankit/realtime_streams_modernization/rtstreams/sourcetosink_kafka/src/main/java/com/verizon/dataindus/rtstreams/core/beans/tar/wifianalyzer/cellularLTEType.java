package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;
import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

@javax.annotation.Nullable
public class cellularLTEType implements Serializable {

	@SerializedName("rssi")
	@Nullable
	private long rssi;

	@SerializedName("rsrq")
	@Nullable
	private long rsrq;

	@SerializedName("pci")
	@Nullable
	private long pci;

	@SerializedName("rsrp")
	@Nullable
	private long rsrp;

	@SerializedName("sinr")
	@Nullable
	private long sinr;

	public long getRssi() {
		return rssi;
	}

	public void setRssi(long rssi) {
		this.rssi = rssi;
	}

	public long getRsrq() {
		return rsrq;
	}

	public void setRsrq(long rsrq) {
		this.rsrq = rsrq;
	}

	public long getPci() {
		return pci;
	}

	public void setPci(long pci) {
		this.pci = pci;
	}

	public long getRsrp() {
		return rsrp;
	}

	public void setRsrp(long rsrp) {
		this.rsrp = rsrp;
	}

	public long getSinr() {
		return sinr;
	}

	public void setSinr(long sinr) {
		this.sinr = sinr;
	}

	@Override
	public String toString() {
		return "CellularLTEType [rssi=" + rssi + ", rsrq=" + rsrq + ", pci=" + pci + ", rsrp=" + rsrp + ", sinr=" + sinr
				+ "]";
	}

}