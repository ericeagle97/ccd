package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class sourceportJSONType implements Serializable{
	
	@Override
	public String toString() {
		return "sourceportJSONType [messages=" + messages + "]";
	}
	@SerializedName("messages")
	   List<Messages> messages;
	
	//tupletime and linkageID


	    public void setMessages(List<Messages> messages) {
	        this.messages = messages;
	    }
	    public List<Messages> getMessages() {
	        return messages;
	    }
	    
}