package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class OutcomeType implements Serializable {


    //rstring score,rstring OTF, rstring EPP, rstring outcomeTimeStamp, rstring info;

   @SerializedName("score")
   @Nullable
   String score;

   @SerializedName("OTF")
   @Nullable
   String OTF;

   @SerializedName("EPP")
   @Nullable
   String EPP;

    @SerializedName("outcomeTimeStamp")
    @Nullable
    String outcomeTimeStamp;

    @SerializedName("info")
    @Nullable
    String info;

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getOTF() {
        return OTF;
    }

    public void setOTF(String OTF) {
        this.OTF = OTF;
    }

    public String getEPP() {
        return EPP;
    }

    public void setEPP(String EPP) {
        this.EPP = EPP;
    }

    public String getOutcomeTimeStamp() {
        return outcomeTimeStamp;
    }

    public void setOutcomeTimeStamp(String outcomeTimeStamp) {
        this.outcomeTimeStamp = outcomeTimeStamp;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "OutcomeType{" +
                "score='" + score + '\'' +
                ", OTF='" + OTF + '\'' +
                ", EPP='" + EPP + '\'' +
                ", outcomeTimeStamp='" + outcomeTimeStamp + '\'' +
                ", info='" + info + '\'' +
                '}';
    }
}