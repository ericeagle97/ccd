package com.verizon.dataindus.rtstreams.lib.readers;

import com.google.common.collect.ImmutableMap;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.factory.ConsumerFactoryFn;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.values.PCollection;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.populateConfigMap;
import static com.verizon.dataindus.rtstreams.core.constants.Constants.*;

/*
 * Connection to Kafka Server using parameters assigned in configuration file
 * and returning PCollections
 */
public class KafkaReader
{
	public List<PCollection<String>> readSource(Pipeline pipeline,
										  String topic,
										  String regions,
										  Map<String,JSONObject> kafkaIOReadTopicWiseConfigMap)
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();

		// Get the configuration as a JSONObject for the provided topic
		JSONObject topicWiseConfig = kafkaIOReadTopicWiseConfigMap.get(topic);

		// Get region-wise(east/west) configuration for the topic
		JSONArray regionArray = topicWiseConfig.getJSONArray(CONFIG_KEYWORD_REGIONS);
		Map<String,JSONObject> regionWiseServerGroup = new HashMap<>();

		// Populate the map regionWiseServerGroup using a helper function
		populateConfigMap(regionArray, regionWiseServerGroup);

		// Create a map of all kafka properties for the topic to be supplied in KafkaIO.read()
		Map<String,Object> kafkaIOReadPropertiesMap = new HashMap<>();
		JSONObject kafkaProperties = topicWiseConfig.getJSONObject(CONFIG_KEYWORD_KAFKA_PROPERTIES);
		for(String key: kafkaProperties.keySet())
			kafkaIOReadPropertiesMap.put(key, kafkaProperties.get(key));

		List<PCollection<String>> kafkaIoReads = new ArrayList<>();
		
		

		// Execute KafkaIO.read() for each region provided as a runtime parameter
		for(String region:regions.split(",")){
			try {
				if(regionWiseServerGroup.get(region).has(CONFIG_KEYWORD_SASL_JAAS))
				{
					kafkaIoReads.add(pipeline
							.apply(String.format("Read from %s topic - (%s)", topic, region),
								KafkaIO.<String, String>read()
								.withBootstrapServers((String) regionWiseServerGroup.get(region)
										.get(CONFIG_KEYWORD_BOOTSTRAP_SERVER))
								.withTopics(Collections.singletonList(topic))
								.withKeyDeserializer(StringDeserializer.class)
								.withValueDeserializer(StringDeserializer.class)
								.withConsumerConfigUpdates(ImmutableMap.of(CONFIG_KEYWORD_GROUP_ID,
										regionWiseServerGroup.get(region).get(CONFIG_KEYWORD_GROUP_ID)))
								.withConsumerConfigUpdates(ImmutableMap.of(CONFIG_KEYWORD_SASL_JAAS,
										regionWiseServerGroup.get(region).get(CONFIG_KEYWORD_SASL_JAAS)))
								.withConsumerConfigUpdates(kafkaIOReadPropertiesMap)
								.withConsumerFactoryFn(new ConsumerFactoryFn(
										topicWiseConfig.getString(CONFIG_KEYWORD_TRUSTSTORE_BUCKET),
										topicWiseConfig.getString(CONFIG_KEYWORD_TRUSTSTORE_FILE)))
								.withoutMetadata())
							.apply("Retrieve Kafka record values",Values.create()));
					
				}
				
				else
				{
					kafkaIoReads.add(pipeline
							.apply(String.format("Read from %s topic - (%s)", topic, region),
								KafkaIO.<String, String>read()
								.withBootstrapServers((String) regionWiseServerGroup.get(region)
										.get(CONFIG_KEYWORD_BOOTSTRAP_SERVER))
								.withTopics(Collections.singletonList(topic))
								.withKeyDeserializer(StringDeserializer.class)
								.withValueDeserializer(StringDeserializer.class)
								.withConsumerConfigUpdates(ImmutableMap.of(CONFIG_KEYWORD_GROUP_ID,
										regionWiseServerGroup.get(region).get(CONFIG_KEYWORD_GROUP_ID)))
								.withConsumerConfigUpdates(kafkaIOReadPropertiesMap)
								.withConsumerFactoryFn(new ConsumerFactoryFn(
										topicWiseConfig.getString(CONFIG_KEYWORD_TRUSTSTORE_BUCKET),
										topicWiseConfig.getString(CONFIG_KEYWORD_TRUSTSTORE_FILE)))
								.withoutMetadata())
							.apply("Retrieve Kafka record values",Values.create()));
					
				}
			}
			catch(KafkaException kafkaException){
				objCustomExceptions.kafkaException("KafkaReader",kafkaException);				
			}
			catch(Exception e){
				objCustomExceptions.errorPipeline("KafkaReader",e);
				return null;
			}
		}
		return kafkaIoReads;
	}
}
