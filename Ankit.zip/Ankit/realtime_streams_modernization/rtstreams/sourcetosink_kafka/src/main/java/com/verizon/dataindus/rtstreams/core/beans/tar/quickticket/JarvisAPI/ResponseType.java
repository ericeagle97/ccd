package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class ResponseType implements Serializable {

   @SerializedName("serviceHeader")
   ServiceHeader serviceHeader;

   @SerializedName("serviceResponse")
   ServiceResponse serviceResponse;

   @SerializedName("status")
   Status status;


    public void setServiceHeader(ServiceHeader serviceHeader) {
        this.serviceHeader = serviceHeader;
    }
    public ServiceHeader getServiceHeader() {
        return serviceHeader;
    }
    
    public void setServiceResponse(ServiceResponse serviceResponse) {
        this.serviceResponse = serviceResponse;
    }
    public ServiceResponse getServiceResponse() {
        return serviceResponse;
    }
    
    public void setStatus(Status status) {
        this.status = status;
    }
    public Status getStatus() {
        return status;
    }
    
}