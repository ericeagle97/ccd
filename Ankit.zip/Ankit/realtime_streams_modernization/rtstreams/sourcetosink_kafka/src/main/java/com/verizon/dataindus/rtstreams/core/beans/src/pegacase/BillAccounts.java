package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class BillAccounts implements Serializable{
	
	
	@Nullable
	@SerializedName("disconnected")
	String disconnected;
	
	@Nullable
	@SerializedName("establishedDate")
	String establishedDate;
	
	@Nullable
	@SerializedName("contactInfo")
	ContactInfo contactInfo;
	
	@Nullable
	@SerializedName("accountAttributes")
	AccountAttributes accountAttributes;
	
	@Nullable
	@SerializedName("billAccountNo")
	String billAccountNo;
	
	@Nullable
	@SerializedName("mtns")
	List<Mtns> mtns;

	public String getDisconnected() {
		return disconnected;
	}

	public void setDisconnected(String disconnected) {
		this.disconnected = disconnected;
	}

	public String getEstablishedDate() {
		return establishedDate;
	}

	public void setEstablishedDate(String establishedDate) {
		this.establishedDate = establishedDate;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public AccountAttributes getAccountAttributes() {
		return accountAttributes;
	}

	public void setAccountAttributes(AccountAttributes accountAttributes) {
		this.accountAttributes = accountAttributes;
	}

	public String getBillAccountNo() {
		return billAccountNo;
	}

	public void setBillAccountNo(String billAccountNo) {
		this.billAccountNo = billAccountNo;
	}

	public List<Mtns> getMtns() {
		return mtns;
	}

	public void setMtns(List<Mtns> mtns) {
		this.mtns = mtns;
	}
	
	
	
}