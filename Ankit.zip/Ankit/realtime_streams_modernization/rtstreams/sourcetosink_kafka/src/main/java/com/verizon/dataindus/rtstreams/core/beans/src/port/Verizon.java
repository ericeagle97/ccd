package com.verizon.dataindus.rtstreams.core.beans.src.port;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

public class Verizon implements Serializable {

	@Override
	public String toString() {
		return "Verizon [crmCustHash=" + crmCustHash + ", crmCustLineHash=" + crmCustLineHash + ", custId=" + custId
				+ ", mtn=" + mtn + "]";
	}

	
	@Nullable
	@SerializedName("crmCustHash")
	String crmCustHash;

	@Nullable
	@SerializedName("crmCustLineHash")
	String crmCustLineHash;

	@Nullable
	@SerializedName("custId")
	String custId;

	@Nullable
	@SerializedName("mtn")
	String mtn;

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public void setCrmCustHash(String crmCustHash) {
		this.crmCustHash = crmCustHash;
	}

	public String getCrmCustHash() {
		return crmCustHash;
	}

	public void setCrmCustLineHash(String crmCustLineHash) {
		this.crmCustLineHash = crmCustLineHash;
	}

	public String getCrmCustLineHash() {
		return crmCustLineHash;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustId() {
		return custId;
	}

}