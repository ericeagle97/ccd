package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class Alert5gHome1MinType implements Serializable {
    @SerializedName("report_time")
    @Nullable
    String report_time;

    @SerializedName("imei")
    @Nullable
    String imei;

    @SerializedName("alarm_type")
    @Nullable
    String alarm_type;

    @SerializedName("latest_heartbeat_received")
    @Nullable
    String latest_heartbeat_received;

    @SerializedName("ts")
    @Nullable
    long ts;

    @SerializedName("brsrp")
    @Nullable
    int brsrp;

    @SerializedName("rsrp_4g")
    @Nullable
    int rsrp_4g;

    @SerializedName("mdn_5g")
    @Nullable
    String mdn_5g;

    @SerializedName("alarm_category")
    @Nullable
    String alarm_category;

    @SerializedName("software_ver")
    @Nullable
    String software_ver;

    @SerializedName("recommend_solution")
    @Nullable
    String recommend_solution;

    @SerializedName("firmware_ver")
    @Nullable
    String firmware_ver;

    @SerializedName("temperature")
    @Nullable
    String temperature;

    @SerializedName("date")
    @Nullable
    String date;

    @SerializedName("city")
    @Nullable
    String city;

    @SerializedName("state")
    @Nullable
    String state;

    @SerializedName("zip_code5")
    @Nullable
    String zip_code5;

    @SerializedName("vmb")
    @Nullable
    int vmb;

    @SerializedName("id")
    @Nullable
    long id;

    @SerializedName("rca")
    @Nullable
    String rca;

    @SerializedName("imsi")
    @Nullable
    String imsi;

    @SerializedName("alert_id")
    @Nullable
    long alert_id;

    @SerializedName("account_type")
    @Nullable
    String account_type;

    @SerializedName("account_status")
    @Nullable
    String account_status;

    @SerializedName("priority")
    @Nullable
    int priority;

    @SerializedName("linkageId")
    @Nullable
    String linkageId;

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Nullable
    public String getReport_time() {
        return report_time;
    }

    public void setReport_time(@Nullable String report_time) {
        this.report_time = report_time;
    }

    @Nullable
    public String getImei() {
        return imei;
    }

    public void setImei(@Nullable String imei) {
        this.imei = imei;
    }

    @Nullable
    public String getAlarm_type() {
        return alarm_type;
    }

    public void setAlarm_type(@Nullable String alarm_type) {
        this.alarm_type = alarm_type;
    }

    @Nullable
    public String getLatest_heartbeat_received() {
        return latest_heartbeat_received;
    }

    public void setLatest_heartbeat_received(@Nullable String latest_heartbeat_received) {
        this.latest_heartbeat_received = latest_heartbeat_received;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public int getBrsrp() {
        return brsrp;
    }

    public void setBrsrp(int brsrp) {
        this.brsrp = brsrp;
    }

    public int getRsrp_4g() {
        return rsrp_4g;
    }

    public void setRsrp_4g(int rsrp_4g) {
        this.rsrp_4g = rsrp_4g;
    }

    @Nullable
    public String getMdn_5g() {
        return mdn_5g;
    }

    public void setMdn_5g(@Nullable String mdn_5g) {
        this.mdn_5g = mdn_5g;
    }

    @Nullable
    public String getAlarm_category() {
        return alarm_category;
    }

    public void setAlarm_category(@Nullable String alarm_category) {
        this.alarm_category = alarm_category;
    }

    @Nullable
    public String getSoftware_ver() {
        return software_ver;
    }

    public void setSoftware_ver(@Nullable String software_ver) {
        this.software_ver = software_ver;
    }

    @Nullable
    public String getRecommend_solution() {
        return recommend_solution;
    }

    public void setRecommend_solution(@Nullable String recommend_solution) {
        this.recommend_solution = recommend_solution;
    }

    @Nullable
    public String getFirmware_ver() {
        return firmware_ver;
    }

    public void setFirmware_ver(@Nullable String firmware_ver) {
        this.firmware_ver = firmware_ver;
    }

    @Nullable
    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(@Nullable String temperature) {
        this.temperature = temperature;
    }

    @Nullable
    public String getDate() {
        return date;
    }

    public void setDate(@Nullable String date) {
        this.date = date;
    }

    @Nullable
    public String getCity() {
        return city;
    }

    public void setCity(@Nullable String city) {
        this.city = city;
    }

    @Nullable
    public String getState() {
        return state;
    }

    public void setState(@Nullable String state) {
        this.state = state;
    }

    @Nullable
    public String getZip_code5() {
        return zip_code5;
    }

    public void setZip_code5(@Nullable String zip_code5) {
        this.zip_code5 = zip_code5;
    }

    public int getVmb() {
        return vmb;
    }

    public void setVmb(int vmb) {
        this.vmb = vmb;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Nullable
    public String getRca() {
        return rca;
    }

    public void setRca(@Nullable String rca) {
        this.rca = rca;
    }

    @Nullable
    public String getImsi() {
        return imsi;
    }

    public void setImsi(@Nullable String imsi) {
        this.imsi = imsi;
    }

    public long getAlert_id() {
        return alert_id;
    }

    public void setAlert_id(long alert_id) {
        this.alert_id = alert_id;
    }

    @Nullable
    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(@Nullable String account_type) {
        this.account_type = account_type;
    }

    @Nullable
    public String getAccount_status() {
        return account_status;
    }

    public void setAccount_status(@Nullable String account_status) {
        this.account_status = account_status;
    }

    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    @Override
    public String toString() {
        return "Alert5gHome1MinType{" +
                "report_time='" + report_time + '\'' +
                ", imei='" + imei + '\'' +
                ", alarm_type='" + alarm_type + '\'' +
                ", latest_heartbeat_received='" + latest_heartbeat_received + '\'' +
                ", ts=" + ts +
                ", brsrp=" + brsrp +
                ", rsrp_4g=" + rsrp_4g +
                ", mdn_5g='" + mdn_5g + '\'' +
                ", alarm_category='" + alarm_category + '\'' +
                ", software_ver='" + software_ver + '\'' +
                ", recommend_solution='" + recommend_solution + '\'' +
                ", firmware_ver='" + firmware_ver + '\'' +
                ", temperature='" + temperature + '\'' +
                ", date='" + date + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip_code5='" + zip_code5 + '\'' +
                ", vmb=" + vmb +
                ", id=" + id +
                ", rca='" + rca + '\'' +
                ", imsi='" + imsi + '\'' +
                ", alert_id=" + alert_id +
                ", account_type='" + account_type + '\'' +
                ", account_status='" + account_status + '\'' +
                ", priority=" + priority +
                ", linkageId=" + linkageId +
                '}';
    }
}
