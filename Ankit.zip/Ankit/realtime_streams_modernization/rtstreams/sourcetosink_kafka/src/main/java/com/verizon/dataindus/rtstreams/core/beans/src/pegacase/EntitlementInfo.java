package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class EntitlementInfo implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("Status")
   @JsonProperty("Status")
   String Status;

   @Nullable
	@SerializedName("dateExpiry")
   String dateExpiry;

   @Nullable
	@SerializedName("entitlementId")
   String entitlementId;

   @Nullable
	@SerializedName("customerInfo")
   CustomerInfo customerInfo;

   @Nullable
	@SerializedName("productKey")
   String productKey;

   @Nullable
	@SerializedName("merchantAccountKey")
   String merchantAccountKey;

   @Nullable
	@SerializedName("responseCode")
   String responseCode;

   @Nullable
	@SerializedName("entitlementDisplayName")
   String entitlementDisplayName;

   @Nullable
	@SerializedName("offerKey")
   String offerKey;

   @Nullable
	@SerializedName("dateCreated")
   String dateCreated;

   @Nullable
	@SerializedName("dateEnded")
   String dateEnded;

   @Nullable
	@SerializedName("entitlementUrl")
   String entitlementUrl;

   @Nullable
	@SerializedName("dateActivated")
   String dateActivated;

   @Nullable
	@SerializedName("dateFailed")
   String dateFailed;

   @Nullable
	@SerializedName("responseMessage")
   String responseMessage;

   @Nullable
	@SerializedName("Play_Enroll_Date")
   @JsonProperty("Play_Enroll_Date")
   String PlayEnrollDate;

   @Nullable
	@SerializedName("isOnPromoOrTrial")
   String isOnPromoOrTrial;

   @Nullable
	@SerializedName("active")
   String active;

   @Nullable
	@SerializedName("status")
   @JsonProperty("status")
   String status;

   @Nullable
	@SerializedName("paymentInfo")
   PaymentInfo paymentInfo;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setStatus(String Status) {
        this.Status = Status;
    }
    public String getStatus() {
        return Status;
    }
    
    public void setDateExpiry(String dateExpiry) {
        this.dateExpiry = dateExpiry;
    }
    public String getDateExpiry() {
        return dateExpiry;
    }
    
    public void setEntitlementId(String entitlementId) {
        this.entitlementId = entitlementId;
    }
    public String getEntitlementId() {
        return entitlementId;
    }
    
    public void setCustomerInfo(CustomerInfo customerInfo) {
        this.customerInfo = customerInfo;
    }
    public CustomerInfo getCustomerInfo() {
        return customerInfo;
    }
    
    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }
    public String getProductKey() {
        return productKey;
    }
    
    public void setMerchantAccountKey(String merchantAccountKey) {
        this.merchantAccountKey = merchantAccountKey;
    }
    public String getMerchantAccountKey() {
        return merchantAccountKey;
    }
    
    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }
    public String getResponseCode() {
        return responseCode;
    }
    
    public void setEntitlementDisplayName(String entitlementDisplayName) {
        this.entitlementDisplayName = entitlementDisplayName;
    }
    public String getEntitlementDisplayName() {
        return entitlementDisplayName;
    }
    
    public void setOfferKey(String offerKey) {
        this.offerKey = offerKey;
    }
    public String getOfferKey() {
        return offerKey;
    }
    
    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }
    public String getDateCreated() {
        return dateCreated;
    }
    
    public void setDateEnded(String dateEnded) {
        this.dateEnded = dateEnded;
    }
    public String getDateEnded() {
        return dateEnded;
    }
    
    public void setEntitlementUrl(String entitlementUrl) {
        this.entitlementUrl = entitlementUrl;
    }
    public String getEntitlementUrl() {
        return entitlementUrl;
    }
    
    public void setDateActivated(String dateActivated) {
        this.dateActivated = dateActivated;
    }
    public String getDateActivated() {
        return dateActivated;
    }
    
    public void setDateFailed(String dateFailed) {
        this.dateFailed = dateFailed;
    }
    public String getDateFailed() {
        return dateFailed;
    }
    
    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
    public String getResponseMessage() {
        return responseMessage;
    }
    
    public void setPlayEnrollDate(String PlayEnrollDate) {
        this.PlayEnrollDate = PlayEnrollDate;
    }
    public String getPlayEnrollDate() {
        return PlayEnrollDate;
    }
    
    public void setIsOnPromoOrTrial(String isOnPromoOrTrial) {
        this.isOnPromoOrTrial = isOnPromoOrTrial;
    }
    public String getIsOnPromoOrTrial() {
        return isOnPromoOrTrial;
    }
    
    public void setActive(String active) {
        this.active = active;
    }
    public String getActive() {
        return active;
    }
    
    public void setStatus1(String status) {
        this.status = status;
    }
    public String getStatus1() {
        return status;
    }
    
    public void setPaymentInfo(PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }
    public PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
}