package com.verizon.dataindus.rtstreams.core.beans.tar.networklocationviolation;

import java.util.ArrayList;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import com.verizon.dataindus.rtstreams.core.beans.src.networklocationviolation.Addresstype;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.NONE, setterVisibility = Visibility.NONE)
public class KafkaNotificationType {
	
	@Nullable
	@JsonProperty("EVENT_CATEGORY")
	@JsonAlias({ "EVENT_CATEGORY" })
	@SerializedName("EVENT_CATEGORY")
	String EVENT_CATEGORY = "";

	@Nullable
	@JsonProperty("EVENT_TYPE")
	@JsonAlias({ "EVENT_TYPE" })
	@SerializedName("EVENT_TYPE")
	String EVENT_TYPE = "";
	
	@Nullable
	@JsonProperty("PUBLISH_TIMESTAMP_UTC")
	@JsonAlias({ "PUBLISH_TIMESTAMP_UTC" })
	@SerializedName("PUBLISH_TIMESTAMP_UTC")
	String PUBLISH_TIMESTAMP_UTC = "";
	
	@Nullable
	@JsonProperty("PUBLISHED_BY")
	@JsonAlias({ "PUBLISHED_BY" })
	@SerializedName("PUBLISHED_BY")
	String PUBLISHED_BY = "";
	
	@Nullable
	@JsonProperty("MTNImpacted")
	@JsonAlias({ "MTNImpacted" })
	@SerializedName("MTNImpacted")
	String MTNImpacted = "";
	
	@Nullable
	@JsonProperty("CUST_ID")
	@JsonAlias({ "CUST_ID" })
	@SerializedName("CUST_ID")
	String CUST_ID = "";
	
	@Nullable
	@JsonProperty("ACCT_NUM")
	@JsonAlias({ "ACCT_NUM" })
	@SerializedName("ACCT_NUM")
	String ACCT_NUM = "";
	
	@Nullable
	@JsonProperty("CUST_LINE_SEQ_ID")
	@JsonAlias({ "CUST_LINE_SEQ_ID" })
	@SerializedName("CUST_LINE_SEQ_ID")
	String CUST_LINE_SEQ_ID = "";
	
	@Nullable
	@JsonProperty("CURRENT_STATUS")
	@JsonAlias({ "CURRENT_STATUS" })
	@SerializedName("CURRENT_STATUS")
	String CURRENT_STATUS = "";
	
	@Nullable
	@JsonProperty("PREVIOUS_STATUS")
	@JsonAlias({ "PREVIOUS_STATUS" })
	@SerializedName("PREVIOUS_STATUS")
	String PREVIOUS_STATUS = "";
	
	@Nullable
	@JsonProperty("STATUS_CHANGE_TIMESTAMP_UTC")
	@JsonAlias({ "STATUS_CHANGE_TIMESTAMP_UTC" })
	@SerializedName("STATUS_CHANGE_TIMESTAMP_UTC")
	String STATUS_CHANGE_TIMESTAMP_UTC = "";
	
	@Nullable
	@JsonProperty("VERIFICATION_METHOD")
	@JsonAlias({ "VERIFICATION_METHOD" })
	@SerializedName("VERIFICATION_METHOD")
	String VERIFICATION_METHOD = "";
	
	@Nullable
	@JsonProperty("VERIFICATION_TRIGGER")
	@JsonAlias({ "VERIFICATION_TRIGGER" })
	@SerializedName("VERIFICATION_TRIGGER")
	String VERIFICATION_TRIGGER = "";
	
	@Nullable
	@JsonProperty("VERIFICATION_ADDRESS")
	@JsonAlias({ "VERIFICATION_ADDRESS" })
	@SerializedName("VERIFICATION_ADDRESS")
	String VERIFICATION_ADDRESS = "";
	
	@Nullable
	@JsonProperty("PRIMARY_ADDRESS")
	@JsonAlias({ "PRIMARY_ADDRESS" })
	@SerializedName("PRIMARY_ADDRESS")
	Addresstype PRIMARY_ADDRESS = new Addresstype();
	
	@Nullable
	@JsonProperty("SECONDARY_ADDRESS")
	@JsonAlias({ "SECONDARY_ADDRESS" })
	@SerializedName("SECONDARY_ADDRESS")
	Addresstype SECONDARY_ADDRESS = new Addresstype();
	
	@SerializedName("linkageID")
	@JsonProperty("linkageID")
	@JsonAlias({ "linkageID" })
	@Nullable
	String linkageID = "";
	
	@SerializedName("tupleTimestamp")
	@JsonProperty("tupleTimestamp")
	@JsonAlias({ "tupleTimestamp" })
	@Nullable
	List<TimeDetails> tupleTimestamp = new ArrayList<>();

	public String getEVENT_CATEGORY() {
		return EVENT_CATEGORY;
	}

	public void setEVENT_CATEGORY(String eVENT_CATEGORY) {
		EVENT_CATEGORY = eVENT_CATEGORY;
	}

	public String getEVENT_TYPE() {
		return EVENT_TYPE;
	}

	public void setEVENT_TYPE(String eVENT_TYPE) {
		EVENT_TYPE = eVENT_TYPE;
	}

	public String getPUBLISH_TIMESTAMP_UTC() {
		return PUBLISH_TIMESTAMP_UTC;
	}

	public void setPUBLISH_TIMESTAMP_UTC(String pUBLISH_TIMESTAMP_UTC) {
		PUBLISH_TIMESTAMP_UTC = pUBLISH_TIMESTAMP_UTC;
	}

	public String getPUBLISHED_BY() {
		return PUBLISHED_BY;
	}

	public void setPUBLISHED_BY(String pUBLISHED_BY) {
		PUBLISHED_BY = pUBLISHED_BY;
	}

	public String getMTNImpacted() {
		return MTNImpacted;
	}

	public void setMTNImpacted(String mTNImpacted) {
		MTNImpacted = mTNImpacted;
	}

	public String getCUST_ID() {
		return CUST_ID;
	}

	public void setCUST_ID(String cUST_ID) {
		CUST_ID = cUST_ID;
	}

	public String getACCT_NUM() {
		return ACCT_NUM;
	}

	public void setACCT_NUM(String aCCT_NUM) {
		ACCT_NUM = aCCT_NUM;
	}

	public String getCUST_LINE_SEQ_ID() {
		return CUST_LINE_SEQ_ID;
	}

	public void setCUST_LINE_SEQ_ID(String cUST_LINE_SEQ_ID) {
		CUST_LINE_SEQ_ID = cUST_LINE_SEQ_ID;
	}

	public String getCURRENT_STATUS() {
		return CURRENT_STATUS;
	}

	public void setCURRENT_STATUS(String cURRENT_STATUS) {
		CURRENT_STATUS = cURRENT_STATUS;
	}

	public String getPREVIOUS_STATUS() {
		return PREVIOUS_STATUS;
	}

	public void setPREVIOUS_STATUS(String pREVIOUS_STATUS) {
		PREVIOUS_STATUS = pREVIOUS_STATUS;
	}

	public String getSTATUS_CHANGE_TIMESTAMP_UTC() {
		return STATUS_CHANGE_TIMESTAMP_UTC;
	}

	public void setSTATUS_CHANGE_TIMESTAMP_UTC(String sTATUS_CHANGE_TIMESTAMP_UTC) {
		STATUS_CHANGE_TIMESTAMP_UTC = sTATUS_CHANGE_TIMESTAMP_UTC;
	}

	public String getVERIFICATION_METHOD() {
		return VERIFICATION_METHOD;
	}

	public void setVERIFICATION_METHOD(String vERIFICATION_METHOD) {
		VERIFICATION_METHOD = vERIFICATION_METHOD;
	}

	public String getVERIFICATION_TRIGGER() {
		return VERIFICATION_TRIGGER;
	}

	public void setVERIFICATION_TRIGGER(String vERIFICATION_TRIGGER) {
		VERIFICATION_TRIGGER = vERIFICATION_TRIGGER;
	}

	public String getVERIFICATION_ADDRESS() {
		return VERIFICATION_ADDRESS;
	}

	public void setVERIFICATION_ADDRESS(String vERIFICATION_ADDRESS) {
		VERIFICATION_ADDRESS = vERIFICATION_ADDRESS;
	}

	public Addresstype getPRIMARY_ADDRESS() {
		return PRIMARY_ADDRESS;
	}

	public void setPRIMARY_ADDRESS(Addresstype pRIMARY_ADDRESS) {
		PRIMARY_ADDRESS = pRIMARY_ADDRESS;
	}

	public Addresstype getSECONDARY_ADDRESS() {
		return SECONDARY_ADDRESS;
	}

	public void setSECONDARY_ADDRESS(Addresstype sECONDARY_ADDRESS) {
		SECONDARY_ADDRESS = sECONDARY_ADDRESS;
	}

	public String getLinkageID() {
		return linkageID;
	}

	public void setLinkageID(String linkageID) {
		this.linkageID = linkageID;
	}

	public List<TimeDetails> getTupleTimestamp() {
		return tupleTimestamp;
	}

	public void setTupleTimestamp(List<TimeDetails> tupleTimestamp) {
		this.tupleTimestamp = tupleTimestamp;
	}

	@Override
	public String toString() {
		return "KafkaNotificationType [EVENT_CATEGORY=" + EVENT_CATEGORY + ", EVENT_TYPE=" + EVENT_TYPE
				+ ", PUBLISH_TIMESTAMP_UTC=" + PUBLISH_TIMESTAMP_UTC + ", PUBLISHED_BY=" + PUBLISHED_BY
				+ ", MTNImpacted=" + MTNImpacted + ", CUST_ID=" + CUST_ID + ", ACCT_NUM=" + ACCT_NUM
				+ ", CUST_LINE_SEQ_ID=" + CUST_LINE_SEQ_ID + ", CURRENT_STATUS=" + CURRENT_STATUS + ", PREVIOUS_STATUS="
				+ PREVIOUS_STATUS + ", STATUS_CHANGE_TIMESTAMP_UTC=" + STATUS_CHANGE_TIMESTAMP_UTC
				+ ", VERIFICATION_METHOD=" + VERIFICATION_METHOD + ", VERIFICATION_TRIGGER=" + VERIFICATION_TRIGGER
				+ ", VERIFICATION_ADDRESS=" + VERIFICATION_ADDRESS + ", PRIMARY_ADDRESS=" + PRIMARY_ADDRESS
				+ ", SECONDARY_ADDRESS=" + SECONDARY_ADDRESS + ", linkageID=" + linkageID + ", tupleTimestamp="
				+ tupleTimestamp + "]";
	}


	
}
