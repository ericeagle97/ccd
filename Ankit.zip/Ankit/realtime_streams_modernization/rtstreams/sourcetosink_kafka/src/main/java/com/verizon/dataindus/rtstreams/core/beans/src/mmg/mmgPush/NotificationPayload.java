package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@javax.annotation.Nullable
public class NotificationPayload implements Serializable{
	
	
	 @SerializedName("application")
	 @Nullable
	   String application;

	   @SerializedName("client")
	   @Nullable
	   String client;

	   @SerializedName("type")
	   @Nullable
	   String type;

	   @SerializedName("userId")
	   @Nullable
	   String userId;

	   @SerializedName("deviceInstanceId")
	   @Nullable
	   String deviceInstanceId;

	   @SerializedName("transactionId")
	   @Nullable
	   String transactionId;

	   @SerializedName("sentDate")
	   @Nullable
	   String sentDate;

	   @SerializedName("content")
	   @Nullable
	   Content content;


	    public void setApplication(String application) {
	        this.application = application;
	    }
	    public String getApplication() {
	        return application;
	    }
	    
	    public void setClient(String client) {
	        this.client = client;
	    }
	    public String getClient() {
	        return client;
	    }
	    
	    public void setType(String type) {
	        this.type = type;
	    }
	    public String getType() {
	        return type;
	    }
	    
	    public void setUserId(String userId) {
	        this.userId = userId;
	    }
	    public String getUserId() {
	        return userId;
	    }
	    
	    public void setDeviceInstanceId(String deviceInstanceId) {
	        this.deviceInstanceId = deviceInstanceId;
	    }
	    public String getDeviceInstanceId() {
	        return deviceInstanceId;
	    }
	    
	    public void setTransactionId(String transactionId) {
	        this.transactionId = transactionId;
	    }
	    public String getTransactionId() {
	        return transactionId;
	    }
	    
	    public void setSentDate(String sentDate) {
	        this.sentDate = sentDate;
	    }
	    public String getSentDate() {
	        return sentDate;
	    }
	    
	    public void setContent(Content content) {
	        this.content = content;
	    }
	    public Content getContent() {
	        return content;
	    }
		@Override
		public String toString() {
			return "NotificationPayload [application=" + application + ", client=" + client + ", type=" + type
					+ ", userId=" + userId + ", deviceInstanceId=" + deviceInstanceId + ", transactionId="
					+ transactionId + ", sentDate=" + sentDate + ", content=" + content + "]";
		}
	    
	    
	    
	}
