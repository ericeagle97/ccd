package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class RtModelReq implements Serializable {

   @SerializedName("insightCategory")
   String insightCategory;

   @SerializedName("insightName")
   String insightName;

   @SerializedName("features")
   Features features;


    public void setInsightCategory(String insightCategory) {
        this.insightCategory = insightCategory;
    }
    public String getInsightCategory() {
        return insightCategory;
    }
    
    public void setInsightName(String insightName) {
        this.insightName = insightName;
    }
    public String getInsightName() {
        return insightName;
    }
    
    public void setFeatures(Features features) {
        this.features = features;
    }
    public Features getFeatures() {
        return features;
    }
    
	public RtModelReq(String insightCategory, String insightName, Features features) {
		super();
		this.insightCategory = insightCategory;
		this.insightName = insightName;
		this.features = features;
	}
	
	public RtModelReq() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}