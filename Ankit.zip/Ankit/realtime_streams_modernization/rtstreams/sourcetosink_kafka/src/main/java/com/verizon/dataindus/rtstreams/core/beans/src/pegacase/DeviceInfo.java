package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class DeviceInfo implements Serializable{
	
	@Nullable
	@SerializedName("deviceType")
	DeviceType deviceType;
		
	@Nullable
	@SerializedName("deviceIdType")
	String deviceIdType;
	
	@Nullable
	@SerializedName("deviceActivationDate")
	String deviceActivationDate;
	
	@Nullable
	@SerializedName("category")
	Category category;
	
	@Nullable
	@SerializedName("displayName")
	String displayName;
	
	@Nullable
	@SerializedName("deviceSku")
	String deviceSku;
	
	@Nullable
	@SerializedName("imei")
	String imei;

	@Nullable
	@SerializedName("deviceId")
	String deviceId;
	
	public DeviceType getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(DeviceType deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceIdType() {
		return deviceIdType;
	}

	public void setDeviceIdType(String deviceIdType) {
		this.deviceIdType = deviceIdType;
	}

	public String getDeviceActivationDate() {
		return deviceActivationDate;
	}

	public void setDeviceActivationDate(String deviceActivationDate) {
		this.deviceActivationDate = deviceActivationDate;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDeviceSku() {
		return deviceSku;
	}

	public void setDeviceSku(String deviceSku) {
		this.deviceSku = deviceSku;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
	
	
}