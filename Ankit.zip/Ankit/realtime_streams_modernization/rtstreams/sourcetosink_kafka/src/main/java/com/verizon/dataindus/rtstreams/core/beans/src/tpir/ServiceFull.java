package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@XmlRootElement(name = "service")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class ServiceFull implements Serializable{
	
	@SerializedName("serviceBody")
    @Nullable
    @XmlElement(name = "serviceBody")
	public serviceBodyFull serviceBody;
	
	@SerializedName("serviceHeader")
	@Nullable
    @XmlElement(name = "serviceHeader")
	public ServiceHeaderFull serviceHeader;
	
	@SerializedName("linkageId")
	@Nullable
    @XmlElement(name = "linkageId")
	public String linkageId;

	public serviceBodyFull getServiceBody() {
		return serviceBody;
	}

	public void setServiceBody(serviceBodyFull serviceBody) {
		this.serviceBody = serviceBody;
	}

	public ServiceHeaderFull getServiceHeader() {
		return serviceHeader;
	}

	public void setServiceHeader(ServiceHeaderFull serviceHeader) {
		this.serviceHeader = serviceHeader;
	}

	public String getLinkageId() {
		return linkageId;
	}

	public void setLinkageId(String linkageId) {
		this.linkageId = linkageId;
	}

	@Override
	public String toString() {
		return "service [serviceBody=" + serviceBody + ", serviceHeader=" + serviceHeader + ", linkageId=" + linkageId
				+ "]";
	}
	
}

