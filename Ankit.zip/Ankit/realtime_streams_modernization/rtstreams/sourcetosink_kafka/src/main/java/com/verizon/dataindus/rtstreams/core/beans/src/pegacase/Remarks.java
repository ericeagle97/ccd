package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class Remarks implements Serializable {

   @Nullable
	@SerializedName("actor")
   String actor;

   @Nullable
	@SerializedName("dateTimeOfRemark")
   String dateTimeOfRemark;

   @Nullable
	@SerializedName("sourceOfRemark")
   String sourceOfRemark;

   @Nullable
	@SerializedName("remark")
   String remark;

   @Nullable
	@SerializedName("remarkType")
   String remarkType;

   @Nullable
	@SerializedName("recentUpdate")
   String recentUpdate;


    public void setActor(String actor) {
        this.actor = actor;
    }
    public String getActor() {
        return actor;
    }
    
    public void setDateTimeOfRemark(String dateTimeOfRemark) {
        this.dateTimeOfRemark = dateTimeOfRemark;
    }
    public String getDateTimeOfRemark() {
        return dateTimeOfRemark;
    }
    
    public void setSourceOfRemark(String sourceOfRemark) {
        this.sourceOfRemark = sourceOfRemark;
    }
    public String getSourceOfRemark() {
        return sourceOfRemark;
    }
    
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public String getRemark() {
        return remark;
    }
    
    public void setRemarkType(String remarkType) {
        this.remarkType = remarkType;
    }
    public String getRemarkType() {
        return remarkType;
    }
    
    public void setRecentUpdate(String recentUpdate) {
        this.recentUpdate = recentUpdate;
    }
    public String getRecentUpdate() {
        return recentUpdate;
    }
    
}