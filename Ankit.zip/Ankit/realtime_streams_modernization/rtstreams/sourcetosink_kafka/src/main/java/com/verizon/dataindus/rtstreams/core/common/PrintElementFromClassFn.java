package com.verizon.dataindus.rtstreams.core.common;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class PrintElementFromClassFn extends DoFn<Object,String>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(PrintElementFromClassFn.class);

	@ProcessElement
	public void processElement(ProcessContext processContext){
		LOG.info("Printing :" + processContext.element().toString());
		processContext.output(String.valueOf(processContext.element().toString()).toString());

	}
}

