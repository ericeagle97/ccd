package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;
import java.util.List;


   

@javax.annotation.Nullable
public class ContextInfo implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("processAction")
   String processAction;

   @Nullable
	@SerializedName("processStep")
   String processStep;

   @Nullable
	@SerializedName("EventType")
   @JsonProperty("EventType")
   String EventType;

   @Nullable
	@SerializedName("OrderDetails")
   @JsonProperty("OrderDetails")
   OrderDetailsType  OrderDetails;

   @Nullable
	@SerializedName("channel")
   String channel;

   @Nullable
	@SerializedName("callReason")
   String callReason;

   @Nullable
	@SerializedName("intent")
   String intent;

   @Nullable
	@SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;

   @Nullable
	@SerializedName("isPromoOffer")
  String isPromoOffer;
   
   @Nullable
	@SerializedName("isSbdOffer")
  String isSbdOffer;
   
   @Nullable
	@SerializedName("journeyType")
 String journeyType;
   
   @Nullable
	@SerializedName("deviceList")
	List<DeviceList> deviceList;
   
   

    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setProcessAction(String processAction) {
        this.processAction = processAction;
    }
    public String getProcessAction() {
        return processAction;
    }
    
    public void setProcessStep(String processStep) {
        this.processStep = processStep;
    }
    public String getProcessStep() {
        return processStep;
    }
    
    public void setEventType(String EventType) {
        this.EventType = EventType;
    }
    public String getEventType() {
        return EventType;
    }
    
    public void setOrderDetails (OrderDetailsType OrderDetails ) {
        this.OrderDetails  = OrderDetails ;
    }
    public OrderDetailsType getOrderDetails () {
        return OrderDetails ;
    }
    
    public void setChannel(String channel) {
        this.channel = channel;
    }
    public String getChannel() {
        return channel;
    }
    
    public void setCallReason(String callReason) {
        this.callReason = callReason;
    }
    public String getCallReason() {
        return callReason;
    }
    
    public void setIntent(String intent) {
        this.intent = intent;
    }
    public String getIntent() {
        return intent;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
	public String getIsPromoOffer() {
		return isPromoOffer;
	}
	public void setIsPromoOffer(String isPromoOffer) {
		this.isPromoOffer = isPromoOffer;
	}
	public String getIsSbdOffer() {
		return isSbdOffer;
	}
	public void setIsSbdOffer(String isSbdOffer) {
		this.isSbdOffer = isSbdOffer;
	}
	public String getJourneyType() {
		return journeyType;
	}
	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}
	public List<DeviceList> getDeviceList() {
		return deviceList;
	}
	public void setDeviceList(List<DeviceList> deviceList) {
		this.deviceList = deviceList;
	}
	
    
}
