package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Data implements Serializable {
	
	

	@Override
	public String toString() {
		return "Data [authToken=" + authToken + ", state=" + state + ", uom=" + uom + ", rawText=" + rawText
				+ ", version=" + version + "]";
	}

	@SerializedName("authToken")
	@Nullable
	String authToken;

	@SerializedName("state")
	@Nullable
	String state;

	@SerializedName("uom")
	@Nullable
	String uom;

	@SerializedName("rawText")
	@Nullable
	String rawText;

	@SerializedName("version")
	@Nullable
	String version;

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getUom() {
		return uom;
	}

	public void setRawText(String rawText) {
		this.rawText = rawText;
	}

	public String getRawText() {
		return rawText;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getVersion() {
		return version;
	}

}
