package com.verizon.dataindus.rtstreams.core.beans.tar.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable   
public class Result implements Serializable {

   @SerializedName("prediction")
   Prediction prediction;


    public void setPrediction(Prediction prediction) {
        this.prediction = prediction;
    }
    public Prediction getPrediction() {
        return prediction;
    }
    
}