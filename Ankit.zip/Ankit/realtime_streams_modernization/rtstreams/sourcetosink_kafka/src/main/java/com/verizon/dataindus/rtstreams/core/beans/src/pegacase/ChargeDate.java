package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class ChargeDate implements Serializable {

   @Nullable
	@SerializedName("date")
   String date;

   @Nullable
	@SerializedName("timestamp")
   String timestamp;


    public void setDate(String date) {
        this.date = date;
    }
    public String getDate() {
        return date;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    public String getTimestamp() {
        return timestamp;
    }
    
}