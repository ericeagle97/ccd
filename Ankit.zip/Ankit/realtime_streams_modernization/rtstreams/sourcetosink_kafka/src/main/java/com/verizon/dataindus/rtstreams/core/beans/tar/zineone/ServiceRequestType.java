package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class ServiceRequestType implements Serializable {


    // rstring insight_category,rstring insight_name,rstring sessionID;

    @SerializedName("insight_category")
    @Nullable
    String insight_category;

    @SerializedName("insight_name")
    @Nullable
    String insight_name;

    @SerializedName("sessionID")
    @Nullable
    String sessionID;

    public String getInsight_category() {
        return insight_category;
    }

    public void setInsight_category(String insight_category) {
        this.insight_category = insight_category;
    }

    public String getInsight_name() {
        return insight_name;
    }

    public void setInsight_name(String insight_name) {
        this.insight_name = insight_name;
    }

    public String getSessionID() {
        return sessionID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }
}