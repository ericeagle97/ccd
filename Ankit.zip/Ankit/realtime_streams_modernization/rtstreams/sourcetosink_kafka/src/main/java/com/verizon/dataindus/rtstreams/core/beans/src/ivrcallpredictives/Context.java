package com.verizon.dataindus.rtstreams.core.beans.src.ivrcallpredictives;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class Context implements Serializable {

   @SerializedName("resultsListSize")
   @Nullable
   String resultsListSize;

   @SerializedName("contextInfo")
   @Nullable
   ContextInfo contextInfo;

   @SerializedName("dnsInfo")
   @Nullable
   DnsInfo dnsInfo;

   @SerializedName("responseList")
   @Nullable
   ResponseList responseList;


    public void setResultsListSize(String resultsListSize) {
        this.resultsListSize = resultsListSize;
    }
    public String getResultsListSize() {
        return resultsListSize;
    }
    
    public void setContextInfo(ContextInfo contextInfo) {
        this.contextInfo = contextInfo;
    }
    public ContextInfo getContextInfo() {
        return contextInfo;
    }
    
    public void setDnsInfo(DnsInfo dnsInfo) {
        this.dnsInfo = dnsInfo;
    }
    public DnsInfo getDnsInfo() {
        return dnsInfo;
    }
    
    public void setResponseList(ResponseList responseList) {
        this.responseList = responseList;
    }
    public ResponseList getResponseList() {
        return responseList;
    }

    @Override
    public String toString() {
        return "Context{" +
                "resultsListSize='" + resultsListSize + '\'' +
                ", contextInfo=" + contextInfo +
                ", dnsInfo=" + dnsInfo +
                ", responseList=" + responseList +
                '}';
    }
}