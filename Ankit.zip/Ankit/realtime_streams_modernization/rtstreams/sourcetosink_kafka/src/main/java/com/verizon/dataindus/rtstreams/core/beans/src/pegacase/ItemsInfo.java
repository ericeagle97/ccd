package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class ItemsInfo implements Serializable{
	
	@Nullable
	@SerializedName("cartItems")
	CartItems cartItems;
	
	@Nullable
	@SerializedName("localNumberPortability")
	LocalNumberPortability localNumberPortability;
	
	@Nullable
	@SerializedName("manufacturer")
	String manufacturer;
	
	@Nullable
	@SerializedName("sorDeviceCategory")
	String sorDeviceCategory;

	public CartItems getCartItems() {
		return cartItems;
	}

	public void setCartItems(CartItems cartItems) {
		this.cartItems = cartItems;
	}

	public LocalNumberPortability getLocalNumberPortability() {
		return localNumberPortability;
	}

	public void setLocalNumberPortability(LocalNumberPortability localNumberPortability) {
		this.localNumberPortability = localNumberPortability;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getSorDeviceCategory() {
		return sorDeviceCategory;
	}

	public void setSorDeviceCategory(String sorDeviceCategory) {
		this.sorDeviceCategory = sorDeviceCategory;
	}
	
	

}
