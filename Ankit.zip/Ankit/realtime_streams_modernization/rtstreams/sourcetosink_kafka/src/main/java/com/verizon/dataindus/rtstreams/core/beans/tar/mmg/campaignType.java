package com.verizon.dataindus.rtstreams.core.beans.tar.mmg;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class campaignType implements Serializable {

	@SerializedName("expectedTransaction")
	@Nullable
	private String expectedTransaction;
	@SerializedName("name")
	@Nullable
	private String name;
	@SerializedName("source")
	@Nullable
	private String source;
	@SerializedName("trackingId")
	@Nullable
	private String trackingId;
	@SerializedName("group")
	@Nullable
	private String group;

	public String getExpectedTransaction() {
		return expectedTransaction;
	}

	public void setExpectedTransaction(String expectedTransaction) {
		this.expectedTransaction = expectedTransaction;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	@Override
	public String toString() {
		return "campaignType [expectedTransaction=" + expectedTransaction + ", name=" + name + ", source=" + source
				+ ", trackingId=" + trackingId + ", group=" + group + "]";
	}

}
