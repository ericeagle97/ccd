package com.verizon.dataindus.rtstreams.core.utils;

/** A Java class extending Ptransform, expects string input pcollection and yields string output pcollection,
 * Class calls the RedisFlagUtility to do a lookup.
 * Example usage:
 PCollection<String> lines = ... ;
 PCollection<String>  tableRowCollection  = lines.apply(new ParallelWriteGCS(keystorePassword, jksBytes,secretPayload, minuteInterval,timeSeconds, redisFlagValue, redisFlagKey))

 Type parameters:
 <InputT> –  String - Main data
 <OutputT> – String - input data as it is **/

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.lib.RedisFlagLookup;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

public class ParallelWriteGCS extends PTransform<PCollection<String>, PCollection<String>> {
    private StreamsJobRunner.KafkaIngestionOptions options;

    /**
     * Type - String, use - projectId for redis connection**/
    String projectId;

    /**
     * Type - String, use - holds keystore password for redis connection
     **/
    String keystorePassword;

    /**
     * Type - byte array, use - holds jks bytes for redis connection
     **/
    byte[] jksBytes;

    /**
     * Type - byte string, use - holds secret payload for redis connection
     **/
    ByteString secretPayload;

    /**
     * Type -  string, use - holds config data, minutes for redis flag check **/
    int minuteInterval;

    /**
     * Type -  string, use - holds config data, seconds for redis flag check **/
    int timeSeconds;

    /**
     * Type -  string, use - holds config data, value for redis lookup **/
    String redisFlagValue;

    /**
     * Type -  string, use - holds config data, key for redis lookup **/
    String redisFlagKey;

    int gcsWindowDuration;
    String gcsFilePath;
    String gcsFileName;
    int gcsNoShards;
    String gcsOrPubsub;
    String pubsubOutputTopic;



    public ParallelWriteGCS(StreamsJobRunner.KafkaIngestionOptions options) {
        this.options = options;
        this.projectId = options.getProjectId();
        SecretInterface objSecret= new SecretInterfaceClass();
        this.keystorePassword = ((ByteString) objSecret.SecretGCP(projectId, options.getKeystorePassword(), "latest")).toStringUtf8();
        this.jksBytes = ((ByteString) objSecret.SecretGCP(projectId, options.getKeystoreFile(), "latest")).toByteArray();
        this.secretPayload = (ByteString) objSecret.SecretGCP(projectId, options.getSecretCredentials(), "latest");
        this.minuteInterval = options.getMinuteIntervalRedisFlagCheck(); // new
        this.timeSeconds = options.getTimeSecondsRedisFlagCheck(); // new
        this.redisFlagValue =options.getRedisFlagValue(); // new
        this.redisFlagKey = options.getRedisFlagKey(); // new
        this.gcsWindowDuration = options.getWindowDuration();
        this.gcsFilePath = options.getPath();
        this.gcsFileName = options.getFileName();
        this.gcsNoShards = options.getNumShards();
        this.gcsOrPubsub = options.getGcsOrPubsubParallelWrite(); //new
        this.pubsubOutputTopic = options.getPubSubTopic();

    }

    @Override
    public PCollection<String> expand(PCollection<String> input) {
        /**
         * call a pardo function, to check for redis flag **/
        PCollection<String> gcsRowCollection = input
                .apply("Redis flag check", ParDo.of(new RedisFlagLookup(keystorePassword, jksBytes, secretPayload, minuteInterval,
                        timeSeconds, redisFlagValue, redisFlagKey)));
        /**
         * Utility call to write data to gcs (change the code as Write utility is prepared) **/
        IOUtility.deadLetterOptionalSink(gcsOrPubsub,
                gcsRowCollection,
                pubsubOutputTopic+"-parallel",
                gcsWindowDuration, // changed
                gcsFilePath+"parallel/",
                gcsFileName+"-parallel",
                gcsNoShards);
        return input;
    }
}
