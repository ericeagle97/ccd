package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class AlertFWAExtenderType implements Serializable {
    @SerializedName("model")
    @Nullable
    String model;

    @SerializedName("model_name")
    @Nullable
    String model_name;

    @SerializedName("ap_withnosta")
    @Nullable
    String ap_withnosta;

    @SerializedName("circuit_id")
    @Nullable
    String circuit_id;

    @SerializedName("circuitid_change")
    @Nullable
    String circuitid_change;

    @SerializedName("consective_days")
    @Nullable
    String consective_days;

    @SerializedName("ext_less_five")
    @Nullable
    String ext_less_five;

    @SerializedName("ext_sn_conn")
    @Nullable
    String ext_sn_conn;

    @SerializedName("fiveg_bw")
    @Nullable
    String fiveg_bw;

    @SerializedName("new_extender")
    @Nullable
    String new_extender;

    @SerializedName("nopoor_days")
    @Nullable
    String nopoor_days;

    @SerializedName("nopoor_sta30")
    @Nullable
    String nopoor_sta30;

    @SerializedName("num_days")
    @Nullable
    String num_days;

    @SerializedName("poor_sta")
    @Nullable
    String poor_sta;

    @SerializedName("poor_sta_pct")
    @Nullable
    String poor_sta_pct;

    @SerializedName("primary_ssid")
    @Nullable
    String primary_ssid;

    @SerializedName("rec_ind")
    @Nullable
    String rec_ind;

    @SerializedName("rec_ind_phyrate")
    @Nullable
    String rec_ind_phyrate;

    @SerializedName("rec_ind_rssi")
    @Nullable
    String rec_ind_rssi;

    @SerializedName("sn")
    @Nullable
    String sn;

    @SerializedName("mtn")
    @Nullable
    String mtn;

    @SerializedName("son")
    @Nullable
    String son;

    @SerializedName("too_close_ext")
    @Nullable
    String too_close_ext;

    @SerializedName("report_time")
    @Nullable
    String report_time;

    @SerializedName("alarm_category")
    @Nullable
    String alarm_category;

    @SerializedName("alarm_type")
    @Nullable
    String alarm_type;

    @SerializedName("too_close_ext2")
    @Nullable
    String too_close_ext2;

    @SerializedName("vision_id")
    @Nullable
    String vision_id;

    @SerializedName("whw_days")
    @Nullable
    String whw_days;

    @SerializedName("wifi_peform")
    @Nullable
    String wifi_peform;

    @SerializedName("linkageId")
    @Nullable
    String linkageId;


    @Nullable
    public String getModel() {
        return model;
    }

    public void setModel(@Nullable String model) {
        this.model = model;
    }

    @Nullable
    public String getModel_name() {
        return model_name;
    }

    public void setModel_name(@Nullable String model_name) {
        this.model_name = model_name;
    }

    @Nullable
    public String getAp_withnosta() {
        return ap_withnosta;
    }

    public void setAp_withnosta(@Nullable String ap_withnosta) {
        this.ap_withnosta = ap_withnosta;
    }

    @Nullable
    public String getCircuit_id() {
        return circuit_id;
    }

    public void setCircuit_id(@Nullable String circuit_id) {
        this.circuit_id = circuit_id;
    }

    @Nullable
    public String getCircuitid_change() {
        return circuitid_change;
    }

    public void setCircuitid_change(@Nullable String circuitid_change) {
        this.circuitid_change = circuitid_change;
    }

    @Nullable
    public String getConsective_days() {
        return consective_days;
    }

    public void setConsective_days(@Nullable String consective_days) {
        this.consective_days = consective_days;
    }

    @Nullable
    public String getExt_less_five() {
        return ext_less_five;
    }

    public void setExt_less_five(@Nullable String ext_less_five) {
        this.ext_less_five = ext_less_five;
    }

    @Nullable
    public String getExt_sn_conn() {
        return ext_sn_conn;
    }

    public void setExt_sn_conn(@Nullable String ext_sn_conn) {
        this.ext_sn_conn = ext_sn_conn;
    }

    @Nullable
    public String getFiveg_bw() {
        return fiveg_bw;
    }

    public void setFiveg_bw(@Nullable String fiveg_bw) {
        this.fiveg_bw = fiveg_bw;
    }

    @Nullable
    public String getNew_extender() {
        return new_extender;
    }

    public void setNew_extender(@Nullable String new_extender) {
        this.new_extender = new_extender;
    }

    @Nullable
    public String getNopoor_days() {
        return nopoor_days;
    }

    public void setNopoor_days(@Nullable String nopoor_days) {
        this.nopoor_days = nopoor_days;
    }

    @Nullable
    public String getNopoor_sta30() {
        return nopoor_sta30;
    }

    public void setNopoor_sta30(@Nullable String nopoor_sta30) {
        this.nopoor_sta30 = nopoor_sta30;
    }

    @Nullable
    public String getNum_days() {
        return num_days;
    }

    public void setNum_days(@Nullable String num_days) {
        this.num_days = num_days;
    }

    @Nullable
    public String getPoor_sta() {
        return poor_sta;
    }

    public void setPoor_sta(@Nullable String poor_sta) {
        this.poor_sta = poor_sta;
    }

    @Nullable
    public String getPoor_sta_pct() {
        return poor_sta_pct;
    }

    public void setPoor_sta_pct(@Nullable String poor_sta_pct) {
        this.poor_sta_pct = poor_sta_pct;
    }

    @Nullable
    public String getPrimary_ssid() {
        return primary_ssid;
    }

    public void setPrimary_ssid(@Nullable String primary_ssid) {
        this.primary_ssid = primary_ssid;
    }

    @Nullable
    public String getRec_ind() {
        return rec_ind;
    }

    public void setRec_ind(@Nullable String rec_ind) {
        this.rec_ind = rec_ind;
    }

    @Nullable
    public String getRec_ind_phyrate() {
        return rec_ind_phyrate;
    }

    public void setRec_ind_phyrate(@Nullable String rec_ind_phyrate) {
        this.rec_ind_phyrate = rec_ind_phyrate;
    }

    @Nullable
    public String getRec_ind_rssi() {
        return rec_ind_rssi;
    }

    public void setRec_ind_rssi(@Nullable String rec_ind_rssi) {
        this.rec_ind_rssi = rec_ind_rssi;
    }

    @Nullable
    public String getSn() {
        return sn;
    }

    public void setSn(@Nullable String sn) {
        this.sn = sn;
    }

    @Nullable
    public String getMtn() {
        return mtn;
    }

    public void setMtn(@Nullable String mtn) {
        this.mtn = mtn;
    }

    @Nullable
    public String getSon() {
        return son;
    }

    public void setSon(@Nullable String son) {
        this.son = son;
    }

    @Nullable
    public String getToo_close_ext() {
        return too_close_ext;
    }

    public void setToo_close_ext(@Nullable String too_close_ext) {
        this.too_close_ext = too_close_ext;
    }

    @Nullable
    public String getReport_time() {
        return report_time;
    }

    public void setReport_time(@Nullable String report_time) {
        this.report_time = report_time;
    }

    @Nullable
    public String getAlarm_category() {
        return alarm_category;
    }

    public void setAlarm_category(@Nullable String alarm_category) {
        this.alarm_category = alarm_category;
    }

    @Nullable
    public String getToo_close_ext2() {
        return too_close_ext2;
    }

    public void setToo_close_ext2(@Nullable String too_close_ext2) {
        this.too_close_ext2 = too_close_ext2;
    }

    @Nullable
    public String getVision_id() {
        return vision_id;
    }

    public void setVision_id(@Nullable String vision_id) {
        this.vision_id = vision_id;
    }

    @Nullable
    public String getWhw_days() {
        return whw_days;
    }

    public void setWhw_days(@Nullable String whw_days) {
        this.whw_days = whw_days;
    }

    @Nullable
    public String getWifi_peform() {
        return wifi_peform;
    }

    public void setWifi_peform(@Nullable String wifi_peform) {
        this.wifi_peform = wifi_peform;
    }

    public String getAlarm_type() {
        return alarm_type;
    }

    public void setAlarm_type(String alarm_type) {
        this.alarm_type = alarm_type;
    }


    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    @Override
    public String toString() {
        return "AlertFWAExtenderType{" +
                "model='" + model + '\'' +
                ", model_name='" + model_name + '\'' +
                ", ap_withnosta='" + ap_withnosta + '\'' +
                ", circuit_id='" + circuit_id + '\'' +
                ", circuitid_change='" + circuitid_change + '\'' +
                ", consective_days='" + consective_days + '\'' +
                ", ext_less_five='" + ext_less_five + '\'' +
                ", ext_sn_conn='" + ext_sn_conn + '\'' +
                ", fiveg_bw='" + fiveg_bw + '\'' +
                ", new_extender='" + new_extender + '\'' +
                ", nopoor_days='" + nopoor_days + '\'' +
                ", nopoor_sta30='" + nopoor_sta30 + '\'' +
                ", num_days='" + num_days + '\'' +
                ", poor_sta='" + poor_sta + '\'' +
                ", poor_sta_pct='" + poor_sta_pct + '\'' +
                ", primary_ssid='" + primary_ssid + '\'' +
                ", rec_ind='" + rec_ind + '\'' +
                ", rec_ind_phyrate='" + rec_ind_phyrate + '\'' +
                ", rec_ind_rssi='" + rec_ind_rssi + '\'' +
                ", sn='" + sn + '\'' +
                ", mtn='" + mtn + '\'' +
                ", son='" + son + '\'' +
                ", too_close_ext='" + too_close_ext + '\'' +
                ", report_time='" + report_time + '\'' +
                ", alarm_category='" + alarm_category + '\'' +
                ", alarm_type='" + alarm_type + '\'' +
                ", too_close_ext2='" + too_close_ext2 + '\'' +
                ", vision_id='" + vision_id + '\'' +
                ", whw_days='" + whw_days + '\'' +
                ", wifi_peform='" + wifi_peform + '\'' +
                ", linkageId='" + linkageId + '\'' +
                '}';
    }
}
