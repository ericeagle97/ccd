package com.verizon.dataindus.rtstreams.core.constants.mmg;


public class Constants {

	public static final String SOURCEMMG = "SourceMMG";

	public static final String MMGPushStream = "mmg_push_stream_processed_count";
	public static final String MMGClickStream = "mmg_click_stream_processed_count";
	public static final String UnprocessedClick = "mmg_click_stream_unprocessed_count";
	public static final String UnprocessedPush = "mmg_push_stream_unprocessed_count";
	
	
	public static final String MMGSMARTCLICK_COUNTER = "mmg_smartclick_valid_counter";
	public static final String MMGSMARTCLICK_INVALID_COUNTER = "mmg_smartclick_invalid_counter";
	
	public static final String MMG_SMS_COUNTER = "mmg_marketingsms_valid_counter";
	public static final String MMG_SMS_INVALID_COUNTER = "mmg_marketingsms_invalid_counter";
	

	
}
