package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
import java.util.List;

@javax.annotation.Nullable
public class TransIvrCallPredictivesPojo implements Serializable {

    @SerializedName("customerId")
    @Nullable
    String customerId;

    @SerializedName("accountNo")
    @Nullable
    String accountNo;

    @SerializedName("mtn")
    @Nullable
    String mtn;

    @SerializedName("insightCategory")
    @Nullable
    List<String> insightCategory;

    @SerializedName("insightName")
    @Nullable
    List<String> insightName;

    @SerializedName("clientTransactionId")
    @Nullable
    String clientTransactionId;

    @SerializedName("soiTransactionId")
    @Nullable
    String soiTransactionId;

    @SerializedName("clientName")
    @Nullable
    String clientName;

    //@SerializedName("insightValue")
    //InsightValue insightValue;

    @SerializedName("feedbackResponse")
    @Nullable
    FeedbackResponse feedbackResponse;


    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getCustomerId() {
        return customerId;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }
    public String getAccountNo() {
        return accountNo;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }
    public String getMtn() {
        return mtn;
    }

    public void setInsightCategory(List<String> insightCategory) {
        this.insightCategory = insightCategory;
    }
    public List<String> getInsightCategory() {
        return insightCategory;
    }

    public void setInsightName(List<String> insightName) {
        this.insightName = insightName;
    }
    public List<String> getInsightName() {
        return insightName;
    }

    public void setClientTransactionId(String clientTransactionId) {
        this.clientTransactionId = clientTransactionId;
    }
    public String getClientTransactionId() {
        return clientTransactionId;
    }

    public void setSoiTransactionId(String soiTransactionId) {
        this.soiTransactionId = soiTransactionId;
    }
    public String getSoiTransactionId() {
        return soiTransactionId;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
    public String getClientName() {
        return clientName;
    }

    /*public void setInsightValue(InsightValue insightValue) {
        this.insightValue = insightValue;
    }
    public InsightValue getInsightValue() {
        return insightValue;
    }*/

    public void setFeedbackResponse(FeedbackResponse feedbackResponse) {
        this.feedbackResponse = feedbackResponse;
    }
    public FeedbackResponse getFeedbackResponse() {
        return feedbackResponse;
    }

    @Override
    public String toString() {
        return "SourceIvrCallPredictivesPojo{" +
                "customerId='" + customerId + '\'' +
                ", accountNo='" + accountNo + '\'' +
                ", mtn='" + mtn + '\'' +
                ", insightCategory=" + insightCategory +
                ", insightName=" + insightName +
                ", clientTransactionId='" + clientTransactionId + '\'' +
                ", soiTransactionId='" + soiTransactionId + '\'' +
                ", clientName='" + clientName + '\'' +
                ", feedbackResponse=" + feedbackResponse +
                '}';
    }

}