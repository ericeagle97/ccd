package com.verizon.dataindus.rtstreams.core.beans.src.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class Response implements Serializable {

   @SerializedName("rank")
   @Nullable
   String rank;

   @SerializedName("propositionID")
   @Nullable
   String propositionID;

   @SerializedName("externalID")
   @Nullable
   String externalID;

   @SerializedName("dispositionOptionID")
   @Nullable
   String dispositionOptionID;

   @SerializedName("dispositionDesc")
   @Nullable
   String dispositionDesc;

   @SerializedName("propositionDesc")
   @Nullable
   String propositionDesc;


    public void setRank(String rank) {
        this.rank = rank;
    }
    public String getRank() {
        return rank;
    }
    
    public void setPropositionID(String propositionID) {
        this.propositionID = propositionID;
    }
    public String getPropositionID() {
        return propositionID;
    }
    
    public void setExternalID(String externalID) {
        this.externalID = externalID;
    }
    public String getExternalID() {
        return externalID;
    }
    
    public void setDispositionOptionID(String dispositionOptionID) {
        this.dispositionOptionID = dispositionOptionID;
    }
    public String getDispositionOptionID() {
        return dispositionOptionID;
    }
    
    public void setDispositionDesc(String dispositionDesc) {
        this.dispositionDesc = dispositionDesc;
    }
    public String getDispositionDesc() {
        return dispositionDesc;
    }
    
    public void setPropositionDesc(String propositionDesc) {
        this.propositionDesc = propositionDesc;
    }
    public String getPropositionDesc() {
        return propositionDesc;
    }

    @Override
    public String toString() {
        return "Response{" +
                "rank='" + rank + '\'' +
                ", propositionID='" + propositionID + '\'' +
                ", externalID='" + externalID + '\'' +
                ", dispositionOptionID='" + dispositionOptionID + '\'' +
                ", dispositionDesc='" + dispositionDesc + '\'' +
                ", propositionDesc='" + propositionDesc + '\'' +
                '}';
    }
}