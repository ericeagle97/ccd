package com.verizon.dataindus.rtstreams.core.beans.tar.wifianalyzer;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class WiFIAnalyzerInsightsType implements Serializable{
	
	@SerializedName("mtn")
	@Nullable
	private String mtn;
	
	@SerializedName("aggrCategory")
	@Nullable
	private String aggrCategory;
	
	@SerializedName("aggrName")
	@Nullable
	private String aggrName ;
	
	@SerializedName("aggrValues")
	@Nullable
	private MainType  aggrValues;

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getAggrCategory() {
		return aggrCategory;
	}

	public void setAggrCategory(String aggrCategory) {
		this.aggrCategory = aggrCategory;
	}

	public String getAggrName() {
		return aggrName;
	}

	public void setAggrName(String aggrName) {
		this.aggrName = aggrName;
	}

	public MainType getAggrValues() {
		return aggrValues;
	}

	public void setAggrValues(MainType aggrValues) {
		this.aggrValues = aggrValues;
	}

	@Override
	public String toString() {
		return "WiFIAnalyzerInsightsType [mtn=" + mtn + ", aggrCategory=" + aggrCategory + ", aggrName=" + aggrName
				+ ", aggrValues=" + aggrValues + "]";
	}
	
	
	
	
	
	

}
