package com.verizon.dataindus.rtstreams.core.beans.src.wifianalyzer;
import java.util.List;

import com.google.gson.annotations.SerializedName;

   
public class WiFiAnalyzerStream {

   @SerializedName("testName")
   String testName;

   @SerializedName("OS")
   String OS;

   @SerializedName("mdn")
   String mdn;

   @SerializedName("appVersionName")
   String appVersionName;

   @SerializedName("appVersionCode")
   int appVersionCode;

   @SerializedName("model")
   String model;

   @SerializedName("manufacturer")
   String manufacturer;

   @SerializedName("dataversion")
   int dataversion;

   @SerializedName("floor")
   String floor;

   @SerializedName("time")
   int time;

   @SerializedName("ssid")
   String ssid;

   @SerializedName("LTEcellId")
   int LTEcellId;

   @SerializedName("timezone")
   String timezone;

 
   @SerializedName("wifilinkSpeed")
   String wifilinkSpeed;

   @SerializedName("aggrName")
   String aggrName;

   @SerializedName("mapData")
   List<MapData> mapData;


    public void setTestName(String testName) {
        this.testName = testName;
    }
    public String getTestName() {
        return testName;
    }
    
    public void setOS(String OS) {
        this.OS = OS;
    }
    public String getOS() {
        return OS;
    }
    
    public void setMdn(String mdn) {
        this.mdn = mdn;
    }
    public String getMdn() {
        return mdn;
    }
    
    public void setAppVersionName(String appVersionName) {
        this.appVersionName = appVersionName;
    }
    public String getAppVersionName() {
        return appVersionName;
    }
    
    public void setAppVersionCode(int appVersionCode) {
        this.appVersionCode = appVersionCode;
    }
    public int getAppVersionCode() {
        return appVersionCode;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    public String getModel() {
        return model;
    }
    
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    public String getManufacturer() {
        return manufacturer;
    }
    
    public void setDataversion(int dataversion) {
        this.dataversion = dataversion;
    }
    public int getDataversion() {
        return dataversion;
    }
    
    public void setFloor(String floor) {
        this.floor = floor;
    }
    public String getFloor() {
        return floor;
    }
    
    public void setTime(int time) {
        this.time = time;
    }
    public int getTime() {
        return time;
    }
    
    public void setSsid(String ssid) {
        this.ssid = ssid;
    }
    public String getSsid() {
        return ssid;
    }
    
    public void setLTEcellId(int LTEcellId) {
        this.LTEcellId = LTEcellId;
    }
    public int getLTEcellId() {
        return LTEcellId;
    }
    
    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }
    public String getTimezone() {
        return timezone;
    }
    
    
    
    public void setWifilinkSpeed(String wifilinkSpeed) {
        this.wifilinkSpeed = wifilinkSpeed;
    }
    public String getWifilinkSpeed() {
        return wifilinkSpeed;
    }
    
    public void setAggrName(String aggrName) {
        this.aggrName = aggrName;
    }
    public String getAggrName() {
        return aggrName;
    }
    
    public void setMapData(List<MapData> mapData) {
        this.mapData = mapData;
    }
    public List<MapData> getMapData() {
        return mapData;
    }
    
}