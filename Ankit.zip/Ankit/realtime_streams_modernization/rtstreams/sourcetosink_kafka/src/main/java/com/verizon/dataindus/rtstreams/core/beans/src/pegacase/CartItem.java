package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;

@javax.annotation.Nullable
public class CartItem implements Serializable{
	
	@Nullable
	@SerializedName("productId")
	String productId;
	
	@Nullable
	@SerializedName("itemCode")
	String itemCode;
	
	@Nullable
	@SerializedName("sorDeviceCategory")
	String sorDeviceCategory;
	
	@Nullable
	@SerializedName("skuId")
	String skuId;
	
	@Nullable
	@SerializedName("manufacturer")
	String manufacturer;
	
	@Nullable
	@SerializedName("cartItemType")
	String cartItemType;
	
	@Nullable
	@SerializedName("description")
	String description;
	
	@Nullable
	@SerializedName("sorId")
	String sorId;
	
	@Nullable
	@SerializedName("simId")
	String simId;
	
	@Nullable
	@SerializedName("deviceId")
	String deviceId ;


	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getSorDeviceCategory() {
		return sorDeviceCategory;
	}

	public void setSorDeviceCategory(String sorDeviceCategory) {
		this.sorDeviceCategory = sorDeviceCategory;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getCartItemType() {
		return cartItemType;
	}

	public void setCartItemType(String cartItemType) {
		this.cartItemType = cartItemType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSorId() {
		return sorId;
	}

	public void setSorId(String sorId) {
		this.sorId = sorId;
	}

	public String getSimId() {
		return simId;
	}

	public void setSimId(String simId) {
		this.simId = simId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

		
}