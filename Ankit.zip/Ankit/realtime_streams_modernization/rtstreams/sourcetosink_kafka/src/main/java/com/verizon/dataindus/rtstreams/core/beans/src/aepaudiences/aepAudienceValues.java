package com.verizon.dataindus.rtstreams.core.beans.src.aepaudiences;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.List;

public class aepAudienceValues implements Serializable {
    @Nullable
    @SerializedName("audiences")
    List<String> audiences;

    public List<String> getAudiences() {
        return audiences;
    }
}
