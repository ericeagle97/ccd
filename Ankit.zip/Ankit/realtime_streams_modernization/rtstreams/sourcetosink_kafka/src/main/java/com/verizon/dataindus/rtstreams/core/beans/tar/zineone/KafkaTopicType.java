package com.verizon.dataindus.rtstreams.core.beans.tar.zineone;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
import java.util.List;

@javax.annotation.Nullable
public class KafkaTopicType implements Serializable {


    //rstring usecaseID,rstring sessionID,rstring userID,rstring timeStamp,rstring visHashedAccountNumber,rstring visHashedMdn,list<outcomeType> outcomeEPP,list<outcomeCFDType> outcomeCFD,rstring custId,rstring accntNum;

   @SerializedName("usecaseID")
   @Nullable
   String usecaseID;

   @SerializedName("sessionID")
   @Nullable
   String sessionID;

   @SerializedName("userID")
   @Nullable
   String userID;

    @SerializedName("timeStamp")
    @Nullable
    String timeStamp;

    @SerializedName("visHashedAccountNumber")
    @Nullable
    String visHashedAccountNumber;

    @SerializedName("visHashedMdn")
    @Nullable
    String visHashedMdn;

    @SerializedName("outcomeEPP")
    @Nullable
    List<OutcomeType> outcomeEPP;

    @SerializedName("outcomeCFD")
    @Nullable
    List<OutcomeCFDType> outcomeCFD;

    @SerializedName("custId")
    @Nullable
    String custId;

    @SerializedName("accntNum")
    @Nullable
    String accntNum;


    public String getUsecaseID() {
        return usecaseID;
    }

    public void setUsecaseID(String usecaseID) {
        this.usecaseID = usecaseID;
    }

    public String getSessionID() {
        return sessionID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getVisHashedAccountNumber() {
        return visHashedAccountNumber;
    }

    public void setVisHashedAccountNumber(String visHashedAccountNumber) {
        this.visHashedAccountNumber = visHashedAccountNumber;
    }

    public String getVisHashedMdn() {
        return visHashedMdn;
    }

    public void setVisHashedMdn(String visHashedMdn) {
        this.visHashedMdn = visHashedMdn;
    }

    public List<OutcomeType> getOutcomeEPP() {
        return outcomeEPP;
    }

    public void setOutcomeEPP(List<OutcomeType> outcomeEPP) {
        this.outcomeEPP = outcomeEPP;
    }

    public List<OutcomeCFDType> getOutcomeCFD() {
        return outcomeCFD;
    }

    public void setOutcomeCFD(List<OutcomeCFDType> outcomeCFD) {
        this.outcomeCFD = outcomeCFD;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getAccntNum() {
        return accntNum;
    }

    public void setAccntNum(String accntNum) {
        this.accntNum = accntNum;
    }


    @Override
    public String toString() {
        String outcomeEPPString = "";
        if(outcomeEPP!= null) {
            for (OutcomeType elem : outcomeEPP) {
                outcomeEPPString = outcomeEPPString + "," + elem.toString();
            }
        }
        String outcomeCFDString = "";
        if(outcomeCFD!= null) {
            for (OutcomeCFDType elem : outcomeCFD) {
                outcomeCFDString = outcomeCFDString + "," + elem.toString();
            }
        }
        return "KafkaTopicType{" +
                "usecaseID='" + usecaseID + '\'' +
                ", sessionID='" + sessionID + '\'' +
                ", userID='" + userID + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", visHashedAccountNumber='" + visHashedAccountNumber + '\'' +
                ", visHashedMdn='" + visHashedMdn + '\'' +
                ", outcomeEPP=" + outcomeEPPString + '\'' +
                ", outcomeCFD=" + outcomeCFDString + '\'' +
                ", custId='" + custId + '\'' +
                ", accntNum='" + accntNum + '\'' +
                '}';
    }
}