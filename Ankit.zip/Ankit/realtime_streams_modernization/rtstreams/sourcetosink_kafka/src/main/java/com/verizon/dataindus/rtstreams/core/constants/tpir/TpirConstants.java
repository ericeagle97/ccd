package com.verizon.dataindus.rtstreams.core.constants.tpir;

public class TpirConstants {
	
	public static final String TPIR = "tpir";
	public static final String TPIR_COUNTER_SUCCESS = "tpir successful_count";
	public static final String TPIR_COUNTER_FAILURE = "tpir failure_count";
	
	public static final String NETWORKTPIR = "network tpir";
	public static final String NETWORKTPIR_COUNTER_SUCCESS = "network tpir successful_count";
	public static final String NETWORKTPIR_COUNTER_FAILURE = "network tpir failure_count";
	
	public static final String TPIRSOURCE = "tpir source";
	public static final String TPIRSOURCE_COUNTER_SUCCESS = "tpir source successful_count";
	public static final String TPIRSOURCE_COUNTER_FAILURE = "tpir source failure_count";
	
	public static final String TPIRSOURCEFULL = "tpir source full";
	public static final String TPIRSOURCEFULL_COUNTER_SUCCESS = "tpir source full successful_count";
	public static final String TPIRSOURCEFULL_COUNTER_FAILURE = "tpir source full failure_count";

	public static final String CASSANDRAIVRSPEECHTAG = "cassandra speech tag";
	public static final String CASSANDRAIVRSPEECHTAG_COUNTER_SUCCESS = "cassandra speech tag successful_count";
	public static final String CASSANDRAIVRSPEECHTAG_COUNTER_FAILURE = "cassandra speech tag failure_count";
	
	public static final String SOI_TOUCHPOINT_TOPIC = "soi_touchpoint";
    public static final String SOI_JMSTPIR_TOPIC = "soi_jms_tpir";
    //public static final String SOI_JMSTPIR_TOPIC = "soi_zineone";
    
    public static final String CUSTINSIGHTS = "customer_insights";
    public static final String CUSTINSIGHTS_SUCCESS = "customer_insights_successful_count";
    public static final String CUSTINSIGHTS_FAILURE = "customer_insights_failure_count";
    public static final String EDW = "EDW_";
    

}
