package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.google.gson.annotations.SerializedName;

@XmlRootElement(name = "NetworkType")
@XmlAccessorType(XmlAccessType.FIELD)

@javax.annotation.Nullable
public class NetworkTypeFull implements Serializable{
	
	@SerializedName("serviceName")
	@Nullable
	@XmlElement(name = "serviceName")
	public String serviceName;

	@SerializedName("msubserviceNametn")
	@Nullable
	@XmlElement(name = "subserviceName")
	public String subserviceName;

	@SerializedName("requestID")
	@Nullable
	@XmlElement(name = "requestID")
	public String requestID;

	@SerializedName("clientName")
	@Nullable
	@XmlElement(name = "clientName")
	public String clientName;

	@SerializedName("generatedID")
	@Nullable
	@XmlElement(name = "generatedID")
	public String generatedID;

	@SerializedName("version")
	@Nullable
	@XmlElement(name = "version")
	public String version;

	@SerializedName("channelId")
	@Nullable
	@XmlElement(name = "channelId")
	public String channelId;

	@SerializedName("activitySummary")
	@Nullable
	@XmlElement(name = "activitySummary")
	public String activitySummary;

	@SerializedName("activityDetail")
	@Nullable
	@XmlElement(name = "activityDetail")
	public String activityDetail;

	@SerializedName("status")
	@Nullable
	@XmlElement(name = "status")
	public String status;

	@SerializedName("selfServe")
	@Nullable
	@XmlElement(name = "selfServe")
	public String selfServe;

	@SerializedName("accountNumber")
	@Nullable
	@XmlElement(name = "accountNumber")
	public String accountNumber;

	@SerializedName("mtnList")
	@Nullable
	@XmlElement(name = "mtnList")
	ArrayList<String> mtnList;

	@SerializedName("timeStamp")
	@Nullable
	@XmlElement(name = "timeStamp")
	public String timeStamp;

	@SerializedName("congestedHrs")
	@Nullable
	@XmlElement(name = "congestedHrs")
	public String congestedHrs;

	@SerializedName("outageID")
	@Nullable
	@XmlElement(name = "outageID")
	public String outageID;

	@SerializedName("outageState")
	@Nullable
	@XmlElement(name = "outageState")
	public String outageState;

	@SerializedName("activityDate")
	@Nullable
	@XmlElement(name = "activityDate")
	public String activityDate;

	@SerializedName("city")
	@Nullable
	@XmlElement(name = "city")
	public String city;

	@SerializedName("state")
	@Nullable
	@XmlElement(name = "state")
	public String state;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getSubserviceName() {
		return subserviceName;
	}

	public void setSubserviceName(String subserviceName) {
		this.subserviceName = subserviceName;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getGeneratedID() {
		return generatedID;
	}

	public void setGeneratedID(String generatedID) {
		this.generatedID = generatedID;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getActivitySummary() {
		return activitySummary;
	}

	public void setActivitySummary(String activitySummary) {
		this.activitySummary = activitySummary;
	}

	public String getActivityDetail() {
		return activityDetail;
	}

	public void setActivityDetail(String activityDetail) {
		this.activityDetail = activityDetail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSelfServe() {
		return selfServe;
	}

	public void setSelfServe(String selfServe) {
		this.selfServe = selfServe;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public ArrayList<String> getMtnList() {
		return mtnList;
	}

	public void setMtnList(ArrayList<String> mtnList) {
		this.mtnList = mtnList;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getCongestedHrs() {
		return congestedHrs;
	}

	public void setCongestedHrs(String congestedHrs) {
		this.congestedHrs = congestedHrs;
	}

	public String getOutageID() {
		return outageID;
	}

	public void setOutageID(String outageID) {
		this.outageID = outageID;
	}

	public String getOutageState() {
		return outageState;
	}

	public void setOutageState(String outageState) {
		this.outageState = outageState;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	@Override
	public String toString() {
		return "NetworkType [serviceName = " + serviceName + " , subserviceName = " + subserviceName + " , requestID = " + requestID + " , clientName = " + clientName + " , generatedID = " + generatedID + " , version = " + version + " , channelId = " + channelId + " , activitySummary = " + activitySummary + " , activityDetail = " + activityDetail + " , status = " + status + " , selfServe = " + selfServe + " , accountNumber = " + accountNumber + " , mtnList = " + mtnList + " , timeStamp = " + timeStamp + " , congestedHrs = " + congestedHrs + " , outageID = " + outageID + " , outageState = " + outageState + " , activityDate = " + activityDate + " , city = " + city + " , state = " + state + " ]";
				
	}
	

}

