package com.verizon.dataindus.rtstreams.core.beans.tar.networkwificalling;

import com.google.gson.annotations.SerializedName;
import com.verizon.dataindus.rtstreams.core.beans.TimeDetails;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
import java.util.List;

@javax.annotation.Nullable
public class CustomerInsightsType implements Serializable {

    // tuple<rstring cust_id_no,rstring acct_no,rstring mtn,rstring insight_category,rstring insight_name,rstring insight_values, list<time_details> tupleTimestamp, rstring linkageID>;
   @SerializedName("cust_id_no")
   @Nullable
   String cust_id_no;

   @SerializedName("acct_no")
   @Nullable
   String acct_no;

   @SerializedName("mtn")
   @Nullable
   String mtn;

   @SerializedName("insight_category")
   @Nullable
   String insight_category;

   @SerializedName("insight_name")
   @Nullable
   String insight_name;

   @SerializedName("insight_values")
   @Nullable
   String insight_values;

   @SerializedName("tupleTimestamp")
   @Nullable
   List<TimeDetails> tupleTimestamp;

    @SerializedName("linkageID")
    @Nullable
    String linkageID;

    public String getCust_id_no() {
        return cust_id_no;
    }

    public void setCust_id_no(String cust_id_no) {
        this.cust_id_no = cust_id_no;
    }

    public String getAcct_no() {
        return acct_no;
    }

    public void setAcct_no(String acct_no) {
        this.acct_no = acct_no;
    }

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getInsight_category() {
        return insight_category;
    }

    public void setInsight_category(String insight_category) {
        this.insight_category = insight_category;
    }

    public String getInsight_name() {
        return insight_name;
    }

    public void setInsight_name(String insight_name) {
        this.insight_name = insight_name;
    }

    public String getInsight_values() {
        return insight_values;
    }

    public void setInsight_values(String insight_values) {
        this.insight_values = insight_values;
    }

    public List<TimeDetails> getTupleTimestamp() {
        return tupleTimestamp;
    }

    public void setTupleTimestamp(List<TimeDetails> tupleTimestamp) {
        this.tupleTimestamp = tupleTimestamp;
    }

    public String getLinkageID() {
        return linkageID;
    }

    public void setLinkageID(String linkageID) {
        this.linkageID = linkageID;
    }


    @Override
    public String toString() {
        return "CustomerInsightsType{" +
                "cust_id_no='" + cust_id_no + '\'' +
                ", acct_no='" + acct_no + '\'' +
                ", mtn='" + mtn + '\'' +
                ", insight_category='" + insight_category + '\'' +
                ", insight_name='" + insight_name + '\'' +
                ", insight_values='" + insight_values + '\'' +
                ", tupleTimestamp=" + tupleTimestamp +
                ", linkageID='" + linkageID + '\'' +
                '}';
    }
}