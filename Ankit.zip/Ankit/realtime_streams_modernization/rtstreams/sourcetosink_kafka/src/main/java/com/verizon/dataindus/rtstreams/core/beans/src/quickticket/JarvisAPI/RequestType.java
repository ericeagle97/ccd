package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.JarvisAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class RequestType implements Serializable{

   @SerializedName("serviceHeader")
   ServiceHeader serviceHeader;

   @SerializedName("serviceRequest")
   ServiceRequest serviceRequest;


    public void setServiceHeader(ServiceHeader serviceHeader) {
        this.serviceHeader = serviceHeader;
    }
    public ServiceHeader getServiceHeader() {
        return serviceHeader;
    }
    
    public void setServiceRequest(ServiceRequest serviceRequest) {
        this.serviceRequest = serviceRequest;
    }
    public ServiceRequest getServiceRequest() {
        return serviceRequest;
    }
    
}