package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


@javax.annotation.Nullable
public class TicketDetails implements Serializable {

   @Nullable
	@SerializedName("zipCode")
   String zipCode;

   @Nullable
	@SerializedName("reason")
   String reason;

   @Nullable
	@SerializedName("contactPreference")
   String contactPreference;

   @Nullable
	@SerializedName("cartId")
   String cartId;

   @Nullable
	@SerializedName("isCustomerViewPermitted")
   String isCustomerViewPermitted;

   @Nullable
	@SerializedName("creditAppNum")
   String creditAppNum;

   @Nullable
	@SerializedName("fullName")
   String fullName;

   @Nullable
	@SerializedName("errorCode")
   String errorCode;

   @Nullable
	@SerializedName("ticketType")
   String ticketType;

   @Nullable
	@SerializedName("relatingTo")
   String relatingTo;

   @Nullable
	@SerializedName("orderDetails")
   OrderDetails orderDetails;
   
   @Nullable
   @SerializedName("followUpDetails")
   FollowUpDetails followUpDetails;

   @Nullable
   @SerializedName("secondaryContactPreference")
   String secondaryContactPreference;

   @Nullable
   @SerializedName("systemMessage")
   String systemMessage;

   @Nullable
	@SerializedName("additionalInfo")
   String additionalInfo;

   @Nullable
	@SerializedName("locationCode")
   String locationCode;


    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    public String getZipCode() {
        return zipCode;
    }
    
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getReason() {
        return reason;
    }
    
    public void setContactPreference(String contactPreference) {
        this.contactPreference = contactPreference;
    }
    public String getContactPreference() {
        return contactPreference;
    }
    
    public void setCartId(String cartId) {
        this.cartId = cartId;
    }
    public String getCartId() {
        return cartId;
    }
    
    public void setIsCustomerViewPermitted(String isCustomerViewPermitted) {
        this.isCustomerViewPermitted = isCustomerViewPermitted;
    }
    public String getIsCustomerViewPermitted() {
        return isCustomerViewPermitted;
    }
    
    public void setCreditAppNum(String creditAppNum) {
        this.creditAppNum = creditAppNum;
    }
    public String getCreditAppNum() {
        return creditAppNum;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getFullName() {
        return fullName;
    }
    
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorCode() {
        return errorCode;
    }
    
    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }
    public String getTicketType() {
        return ticketType;
    }
    
    public void setRelatingTo(String relatingTo) {
        this.relatingTo = relatingTo;
    }
    public String getRelatingTo() {
        return relatingTo;
    }
    
    public void setOrderDetails(OrderDetails orderDetails) {
        this.orderDetails = orderDetails;
    }
    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public void setFollowUpDetails(FollowUpDetails followUpDetails) {
        this.followUpDetails = followUpDetails;
    }
    public FollowUpDetails getFollowUpDetails() {
        return followUpDetails;
    }
    
    public void setSecondaryContactPreference(String secondaryContactPreference) {
        this.secondaryContactPreference = secondaryContactPreference;
    }
    public String getSecondaryContactPreference() {
        return secondaryContactPreference;
    }
    
    public void setSystemMessage(String systemMessage) {
        this.systemMessage = systemMessage;
    }
    public String getSystemMessage() {
        return systemMessage;
    }
    
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
    public String getAdditionalInfo() {
        return additionalInfo;
    }
    
    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }
    public String getLocationCode() {
        return locationCode;
    }
    
}