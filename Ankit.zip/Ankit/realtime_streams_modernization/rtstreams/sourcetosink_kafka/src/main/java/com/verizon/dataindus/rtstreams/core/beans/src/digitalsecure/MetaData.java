package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class MetaData implements Serializable {
	private static final long serialVersionUID = 1L;

	@SerializedName("timeZone")
	@Nullable
	public String timeZone;
	@SerializedName("sdk_int")
	@Nullable
	public String sdk_int;
	@SerializedName("make")
	@Nullable
	public String make;
	@SerializedName("model")
	@Nullable
	public String model;
	@SerializedName("buildTime")
	@Nullable
	public String buildTime;
	@SerializedName("osFirmware")
	@Nullable
	public String osFirmware;
	@SerializedName("mvmVersion")
	@Nullable
	public String mvmVersion;

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getSdk_int() {
		return sdk_int;
	}

	public void setSdk_int(String sdk_int) {
		this.sdk_int = sdk_int;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBuildTime() {
		return buildTime;
	}

	public void setBuildTime(String buildTime) {
		this.buildTime = buildTime;
	}

	public String getOsFirmware() {
		return osFirmware;
	}

	public void setOsFirmware(String osFirmware) {
		this.osFirmware = osFirmware;
	}

	public String getMvmVersion() {
		return mvmVersion;
	}

	public void setMvmVersion(String mvmVersion) {
		this.mvmVersion = mvmVersion;
	}

	@Override
	public String toString() {
		return "MetaData [timeZone=" + timeZone + ", sdk_int=" + sdk_int + ", make=" + make + ", model=" + model
				+ ", buildTime=" + buildTime + ", osFirmware=" + osFirmware + ", mvmVersion=" + mvmVersion + "]";
	}

}
