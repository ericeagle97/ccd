package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class ThreatHistoryLog implements Serializable {
	private static final long serialVersionUID = 1L;
	@SerializedName("detectedTime")
	@Nullable
	public String detectedTime;
	@SerializedName("resolvedTime")
	@Nullable
	public String resolvedTime;
	@SerializedName("type")
	@Nullable
	public String type;

	public String getDetectedTime() {
		return detectedTime;
	}

	public void setDetectedTime(String detectedTime) {
		this.detectedTime = detectedTime;
	}

	public String getResolvedTime() {
		return resolvedTime;
	}

	public void setResolvedTime(String resolvedTime) {
		this.resolvedTime = resolvedTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ThreatHistoryLog [detectedTime=" + detectedTime + ", resolvedTime=" + resolvedTime + ", type=" + type
				+ "]";
	}

	public ThreatHistoryLog() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ThreatHistoryLog(String detectedTime, String resolvedTime, String type) {
		super();
		this.detectedTime = detectedTime;
		this.resolvedTime = resolvedTime;
		this.type = type;
	}

}
