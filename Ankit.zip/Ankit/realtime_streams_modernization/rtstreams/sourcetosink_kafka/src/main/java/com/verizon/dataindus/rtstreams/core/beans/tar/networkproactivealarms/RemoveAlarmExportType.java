package com.verizon.dataindus.rtstreams.core.beans.tar.networkproactivealarms;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;

@javax.annotation.Nullable
public class RemoveAlarmExportType implements Serializable {
    @SerializedName("mtn")
    @Nullable
    String mtn;

    @SerializedName("insight_category")
    @Nullable
    String insight_category;

    @SerializedName("insight_name")
    @Nullable
    String insight_name;

    @SerializedName("insight_values")
    @Nullable
    InsightValueJsonSHA insight_values;

    @SerializedName("ttl")
    @Nullable
    String ttl;

    @Nullable
    public String getMtn() {
        return mtn;
    }

    public void setMtn(@Nullable String mtn) {
        this.mtn = mtn;
    }

    @Nullable
    public String getInsight_category() {
        return insight_category;
    }

    public void setInsight_category(@Nullable String insight_category) {
        this.insight_category = insight_category;
    }

    @Nullable
    public String getInsight_name() {
        return insight_name;
    }

    public void setInsight_name(@Nullable String insight_name) {
        this.insight_name = insight_name;
    }

    @Nullable
    public InsightValueJsonSHA getInsight_values() {
        return insight_values;
    }

    public void setInsight_values(@Nullable InsightValueJsonSHA insight_values) {
        this.insight_values = insight_values;
    }

    @Nullable
    public String getTtl() {
        return ttl;
    }

    public void setTtl(@Nullable String ttl) {
        this.ttl = ttl;
    }

    @Override
    public String toString() {
        return "RemoveAlarmExportType{" +
                "mtn='" + mtn + '\'' +
                ", insight_category='" + insight_category + '\'' +
                ", insight_name='" + insight_name + '\'' +
                ", insight_values=" + insight_values +
                ", ttl='" + ttl + '\'' +
                '}';
    }
}
