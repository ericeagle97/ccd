package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgClick;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class metadataType {

	public String getAMToken() {
		return AMToken;
	}

	public void setAMToken(String aMToken) {
		AMToken = aMToken;
	}

	public String getOauthURL() {
		return oauthURL;
	}

	public void setOauthURL(String oauthURL) {
		this.oauthURL = oauthURL;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getRawText() {
		return rawText;
	}

	public void setRawText(String rawText) {
		this.rawText = rawText;
	}

	public String getShortUrl() {
		return shortUrl;
	}

	public void setShortUrl(String shortUrl) {
		this.shortUrl = shortUrl;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@SerializedName("AMToken")
	@Nullable
	private String AMToken;
	@SerializedName("oauthURL")
	@Nullable
	private String oauthURL;
	@SerializedName("uom")
	@Nullable
	private String uom;
	@SerializedName("rawText")
	@Nullable
	private String rawText;
	@SerializedName("shortUrl")
	@Nullable
	private String shortUrl;
	@SerializedName("state")
	@Nullable
	private String state;
	@SerializedName("version")
	@Nullable
	private String version;
}
