package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class template_type implements Serializable{
	
	@SerializedName("id")
	@Nullable
	String id;
	 
	@SerializedName("name")
	@Nullable
	String name;
	 
	@SerializedName("description")
	@Nullable
	String description;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "template_type [id=" + id + ", name=" + name + ", description=" + description + "]";
	}
	
	
}
