package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class OrderDetails implements Serializable {

   @Nullable
	@SerializedName("orderType")
   String orderType;

   @Nullable
	@SerializedName("dotcomOrderNumber")
   String dotcomOrderNumber;

   @Nullable
	@SerializedName("errorDescription")
   String errorDescription;

   @Nullable
	@SerializedName("orderNum")
   String orderNum;


    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getOrderType() {
        return orderType;
    }
    
    public void setDotcomOrderNumber(String dotcomOrderNumber) {
        this.dotcomOrderNumber = dotcomOrderNumber;
    }
    public String getDotcomOrderNumber() {
        return dotcomOrderNumber;
    }
    
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    
    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }
    public String getOrderNum() {
        return orderNum;
    }
    
}