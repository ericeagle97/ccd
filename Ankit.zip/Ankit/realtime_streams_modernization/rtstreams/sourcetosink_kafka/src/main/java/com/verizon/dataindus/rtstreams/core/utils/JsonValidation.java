package com.verizon.dataindus.rtstreams.core.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verizon.dataindus.rtstreams.core.constants.Constants;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;

public class JsonValidation extends DoFn<String, String> {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static TupleTag<String> VALID_JSON_RECORDS = new TupleTag<String>(){};
    public static   TupleTag<String> INVALID_JSON_RECORDS = new TupleTag<String>(){};

    private final Counter validJsonCounter = Metrics.counter(Constants.METRICS_JSON_VALIDATION, Constants.METRICS_COUNTER_VALID);
    private final Counter invalidJsonCounter = Metrics.counter(Constants.METRICS_JSON_VALIDATION, Constants.METRICS_COUNTER_INVALID);

    @ProcessElement
    public void processElement(ProcessContext c)
    {
        /** Valid json will be in try block- ValidTag
         Invalid jsons will be moving to catch block - Failure Tag
         **/
       try
        {
            String line = c.element();
            JsonObject json = (JsonObject) new JsonParser().parse(line);

            validJsonCounter.inc();
            c.output(c.element());
        } catch (Exception e){
            invalidJsonCounter.inc();
            c.output(INVALID_JSON_RECORDS, c.element());
        }
    }
}
