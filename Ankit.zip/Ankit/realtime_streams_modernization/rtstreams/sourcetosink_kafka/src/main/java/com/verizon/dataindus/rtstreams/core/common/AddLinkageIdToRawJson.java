package com.verizon.dataindus.rtstreams.core.common;
import org.apache.beam.sdk.transforms.DoFn;
import org.json.JSONObject;
public class AddLinkageIdToRawJson extends DoFn<String, String> {
	
	private static final long serialVersionUID = 1L;
	private String id;
	private String source;
	
	public AddLinkageIdToRawJson(String id, String source){
		this.id = id;
		this.source = source;
	}
	
	@ProcessElement
	public void processElement(ProcessContext c )
	{
		String rawData = c.element();
		JSONObject rawJson = new JSONObject(rawData);  
		
		String LinkageId = CommonUtility.genLinkageID(this.id, this.source);
		rawJson.put("linkageId",LinkageId);
		c.output(rawJson.toString());
	}
}
