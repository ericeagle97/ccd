package com.verizon.dataindus.rtstreams.core.beans.tar.reconnect;

import com.google.gson.annotations.SerializedName;
import org.apache.avro.reflect.Nullable;

import java.io.Serializable;
@javax.annotation.Nullable
public class CassandraStream implements Serializable {
    @SerializedName("callid")
    @Nullable
    String callid;
    @SerializedName("Predictive_ID")
    @Nullable
    String Predictive_ID;
    @SerializedName("Predictive_Optin_Ind")
    @Nullable
    String Predictive_Optin_Ind;

    public String getCallid() {
        return callid;
    }

    public void setCallid(String callid) {
        this.callid = callid;
    }

    public String getPredictive_ID() {
        return Predictive_ID;
    }

    public void setPredictive_ID(String predictive_ID) {
        Predictive_ID = predictive_ID;
    }

    public String getPredictive_Optin_Ind() {
        return Predictive_Optin_Ind;
    }

    public void setPredictive_Optin_Ind(String predictive_Optin_Ind) {
        Predictive_Optin_Ind = predictive_Optin_Ind;
    }

    @Override
    public String toString() {
        return "CassandraStream{" +
                "callid='" + callid + '\'' +
                ", Predictive_ID='" + Predictive_ID + '\'' +
                ", Predictive_Optin_Ind='" + Predictive_Optin_Ind + '\'' +
                '}';
    }
}
