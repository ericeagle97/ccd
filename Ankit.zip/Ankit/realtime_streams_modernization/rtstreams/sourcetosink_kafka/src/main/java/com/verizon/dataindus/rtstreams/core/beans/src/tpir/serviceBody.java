package com.verizon.dataindus.rtstreams.core.beans.src.tpir;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;


@XmlRootElement(name = "serviceBody")
@XmlAccessorType(XmlAccessType.FIELD)
@javax.annotation.Nullable
public class serviceBody implements Serializable {
	
	@SerializedName("activityDetailList")
    @Nullable
    @XmlElement(name = "activityDetailList")
	public ActivityDetailList activityDetailList;
	
	@SerializedName("version")
	@Nullable
    @XmlElement(name = "version")
	public Integer version;

	public ActivityDetailList getActivityDetailList() {
		return activityDetailList;
	}

	public void setActivityDetailList(ActivityDetailList activityDetailList) {
		this.activityDetailList = activityDetailList;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "serviceBody [activityDetailList=" + activityDetailList + ", version=" + version + "]";
	}
    
   
}

