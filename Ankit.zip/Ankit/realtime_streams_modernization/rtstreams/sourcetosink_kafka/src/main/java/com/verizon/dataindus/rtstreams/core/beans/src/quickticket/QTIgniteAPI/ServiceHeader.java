package com.verizon.dataindus.rtstreams.core.beans.src.quickticket.QTIgniteAPI;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

   
public class ServiceHeader implements Serializable {
	
	   @SerializedName("clientId")
	   String clientId;
	
	   @SerializedName("clientTransactionId")
	   String clientTransactionId;
	
	   @SerializedName("transactionId")
	   String transactionId;
	
	   @SerializedName("channelName")
	   String channelName;
	
	   @SerializedName("priority")
	   String priority;
	
	   @SerializedName("mtn")
	   String mtn;
	
	   @SerializedName("accountId")
	   String accountId;
	
	
	    public void setClientId(String clientId) {
	        this.clientId = clientId;
	    }
	    public String getClientId() {
	        return clientId;
	    }
	    
	    public void setClientTransactionId(String clientTransactionId) {
	        this.clientTransactionId = clientTransactionId;
	    }
	    public String getClientTransactionId() {
	        return clientTransactionId;
	    }
	    
	    public void setTransactionId(String transactionId) {
	        this.transactionId = transactionId;
	    }
	    public String getTransactionId() {
	        return transactionId;
	    }
	    
	    public void setChannelName(String channelName) {
	        this.channelName = channelName;
	    }
	    public String getChannelName() {
	        return channelName;
	    }
	    
	    public void setPriority(String priority) {
	        this.priority = priority;
	    }
	    public String getPriority() {
	        return priority;
	    }
	    
	    public void setMtn(String mtn) {
	        this.mtn = mtn;
	    }
	    public String getMtn() {
	        return mtn;
	    }
	    
	    public void setAccountId(String accountId) {
	        this.accountId = accountId;
	    }
	    public String getAccountId() {
	        return accountId;
	    }
	    
}