package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


@javax.annotation.Nullable
public class ChannelList implements Serializable {

   @Nullable
   @SerializedName("CaseID")
   @JsonProperty("CaseID")
   String CaseID;

   @Nullable
   @SerializedName("CaseStatus")
   @JsonProperty("CaseStatus")
   String CaseStatus;

   @Nullable
   @SerializedName("ProcessStep")
   @JsonProperty("ProcessStep")
   String ProcessStep;

   @Nullable
   @SerializedName("ClientId")
   @JsonProperty("ClientId")
   String ClientId;

   @Nullable
   @SerializedName("USER_ID")
   @JsonProperty("USER_ID")
   String USERID;

   @Nullable
   @SerializedName("pxCreateDateTime")
   String pxCreateDateTime;

   @Nullable
   @SerializedName("pxUpdateDateTime")
   String pxUpdateDateTime;


    public void setCaseID(String CaseID) {
        this.CaseID = CaseID;
    }
    public String getCaseID() {
        return CaseID;
    }
    
    public void setCaseStatus(String CaseStatus) {
        this.CaseStatus = CaseStatus;
    }
    public String getCaseStatus() {
        return CaseStatus;
    }
    
    public void setProcessStep(String ProcessStep) {
        this.ProcessStep = ProcessStep;
    }
    public String getProcessStep() {
        return ProcessStep;
    }
    
    public void setClientId(String ClientId) {
        this.ClientId = ClientId;
    }
    public String getClientId() {
        return ClientId;
    }
    
    public void setUSERID(String USERID) {
        this.USERID = USERID;
    }
    public String getUSERID() {
        return USERID;
    }
    
    public void setPxCreateDateTime(String pxCreateDateTime) {
        this.pxCreateDateTime = pxCreateDateTime;
    }
    public String getPxCreateDateTime() {
        return pxCreateDateTime;
    }
    
    public void setPxUpdateDateTime(String pxUpdateDateTime) {
        this.pxUpdateDateTime = pxUpdateDateTime;
    }
    public String getPxUpdateDateTime() {
        return pxUpdateDateTime;
    }
    
}