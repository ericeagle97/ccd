package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class Upcoming implements Serializable {

   @Nullable
	@SerializedName("totalTax")
   String totalTax;

   @Nullable
	@SerializedName("chargeEndDate")
   ChargeEndDate chargeEndDate;

   @Nullable
	@SerializedName("totalMandatoryTax")
   String totalMandatoryTax;

   @Nullable
	@SerializedName("totalChargeAmt")
   String totalChargeAmt;

   @Nullable
	@SerializedName("taxSummaryByImposition")
   List<TaxSummaryByImposition> taxSummaryByImposition;

   @Nullable
	@SerializedName("totalNonMandatoryTax")
   String totalNonMandatoryTax;

   @Nullable
	@SerializedName("chargeDate")
   ChargeDate chargeDate;


    public void setTotalTax(String totalTax) {
        this.totalTax = totalTax;
    }
    public String getTotalTax() {
        return totalTax;
    }
    
    public void setChargeEndDate(ChargeEndDate chargeEndDate) {
        this.chargeEndDate = chargeEndDate;
    }
    public ChargeEndDate getChargeEndDate() {
        return chargeEndDate;
    }
    
    public void setTotalMandatoryTax(String totalMandatoryTax) {
        this.totalMandatoryTax = totalMandatoryTax;
    }
    public String getTotalMandatoryTax() {
        return totalMandatoryTax;
    }
    
    public void setTotalChargeAmt(String totalChargeAmt) {
        this.totalChargeAmt = totalChargeAmt;
    }
    public String getTotalChargeAmt() {
        return totalChargeAmt;
    }
    
    public void setTaxSummaryByImposition(List<TaxSummaryByImposition> taxSummaryByImposition) {
        this.taxSummaryByImposition = taxSummaryByImposition;
    }
    public List<TaxSummaryByImposition> getTaxSummaryByImposition() {
        return taxSummaryByImposition;
    }
    
    public void setTotalNonMandatoryTax(String totalNonMandatoryTax) {
        this.totalNonMandatoryTax = totalNonMandatoryTax;
    }
    public String getTotalNonMandatoryTax() {
        return totalNonMandatoryTax;
    }
    
    public void setChargeDate(ChargeDate chargeDate) {
        this.chargeDate = chargeDate;
    }
    public ChargeDate getChargeDate() {
        return chargeDate;
    }
    
}