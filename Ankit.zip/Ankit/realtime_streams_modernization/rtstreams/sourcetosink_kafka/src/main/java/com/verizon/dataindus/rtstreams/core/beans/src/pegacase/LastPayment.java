package com.verizon.dataindus.rtstreams.core.beans.src.pegacase;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.avro.reflect.Nullable;
import java.io.Serializable;


   

@javax.annotation.Nullable
public class LastPayment implements Serializable {

   @Nullable
	@SerializedName("pxObjClass")
   String pxObjClass;

   @Nullable
	@SerializedName("pxUdateDateTime")
   String pxUdateDateTime;


    public void setPxObjClass(String pxObjClass) {
        this.pxObjClass = pxObjClass;
    }
    public String getPxObjClass() {
        return pxObjClass;
    }
    
    public void setPxUdateDateTime(String pxUdateDateTime) {
        this.pxUdateDateTime = pxUdateDateTime;
    }
    public String getPxUdateDateTime() {
        return pxUdateDateTime;
    }
    
}