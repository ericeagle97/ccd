package com.verizon.dataindus.rtstreams.core.beans.src.digitalsecure;

import java.io.Serializable;
import java.util.List;

import org.apache.avro.reflect.Nullable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;

@JsonIgnoreProperties(ignoreUnknown = true)
@javax.annotation.Nullable
public class Headers implements Serializable {

	private static final long serialVersionUID = 1L;

	@SerializedName("client_id")
	@Nullable
	public List<String> client_id;
	@SerializedName("client_secret")
	@Nullable
	public List<String> client_secret;
	@SerializedName("grant_type")
	@Nullable
	public List<String> grant_type;

	public List<String> getClient_id() {
		return client_id;
	}

	public void setClient_id(List<String> client_id) {
		this.client_id = client_id;
	}

	public List<String> getClient_secret() {
		return client_secret;
	}

	public void setClient_secret(List<String> client_secret) {
		this.client_secret = client_secret;
	}

	public List<String> getGrant_type() {
		return grant_type;
	}

	public void setGrant_type(List<String> grant_type) {
		this.grant_type = grant_type;
	}

	@Override
	public String toString() {
		return "Headers [client_id=" + client_id + ", client_secret=" + client_secret + ", grant_type=" + grant_type
				+ "]";
	}

}
