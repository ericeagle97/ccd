package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ivrcallpredictives;

import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.ivrcallpredictives.IvrCallPredictivesConstants;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class TargetIvrCallPredictives  extends DoFn<String, String>
{
    private static final long serialVersionUID = 1L;
    /*GCP logger object to log messages to cloud logger*/
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(TargetIvrCallPredictives.class);


    //TupleTag, used to produce output being send to cassandra table to daily forecast data

    public static final TupleTag<String> PredictiveToCassandraCustInsights = new TupleTag<String>() {
    };

    //TupleTag, used to produce output being send to cassandra table to daily forecast data
    public static final TupleTag<String> PredictiveToCassandraCustMtnInsights = new TupleTag<String>() {
    };

    private static final Counter totalInput = Metrics.counter(Constants.METRICS_PREPROCESSING,
            "total_import_count");

    private static final Counter deadLetterCount = Metrics.counter(Constants.METRICS_PREPROCESSING,
            "invalid_count");

    private static final Counter validCountCustMTN = Metrics.counter(Constants.METRICS_PREPROCESSING,
            "valid_count_cust_mtn_insights");

    private static final Counter validCountCust = Metrics.counter(Constants.METRICS_PREPROCESSING,
            "valid_count_cust_insights");

    //TupleTag, used to produce output being send to dead letter queue
    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };

    public static String getEmptyIfNull(String obj) {
        if (null == obj) {
            return "";
        } else {
            return obj;
        }

    }

    @ProcessElement
    public void processElement(ProcessContext c)
    {
        try
        {
            String strSourceData= c.element();
            JSONObject jsonSourceData = new JSONObject(strSourceData);
            Map<String,Object> outputData = new HashMap<String,Object> ();
            Map<String,String> insightValues = new HashMap<String,String> ();

            /*
            if mtn, customer_id, and account_no are available , push them to the output stream PredictiveToCassandraTypeData
             */
            if (!jsonSourceData.get(IvrCallPredictivesConstants.CUSTOMER_ID).toString().trim().isEmpty()
                    && jsonSourceData.get(IvrCallPredictivesConstants.CUSTOMER_ID).toString()!= null
                    && !jsonSourceData.get(IvrCallPredictivesConstants.ACCOUNT_NO).toString().trim().isEmpty()
                    && jsonSourceData.get(IvrCallPredictivesConstants.ACCOUNT_NO).toString()!=null
                    && !jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString().trim().isEmpty()
                    && jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString()!=null)
            {
                String mtn = getEmptyIfNull(jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString().replace("\"",""));
                // generate linkage id
                CommonUtility objLinkageId = new CommonUtility();
                String linkageID = objLinkageId.genLinkageID(mtn, IvrCallPredictivesConstants.CHANNEL);
                outputData.put(IvrCallPredictivesConstants.CUST_ID,jsonSourceData.get(IvrCallPredictivesConstants.CUSTOMER_ID).toString().replace("\"",""));
                outputData.put(IvrCallPredictivesConstants.ACCT_NO,jsonSourceData.get(IvrCallPredictivesConstants.ACCOUNT_NO).toString().replace("\"",""));
                outputData.put(IvrCallPredictivesConstants.MTN,jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString().replace("\"",""));
                outputData.put(IvrCallPredictivesConstants.INSIGHT_CATEGORY,IvrCallPredictivesConstants.CALL);
                outputData.put(IvrCallPredictivesConstants.INSIGHT_NAME,IvrCallPredictivesConstants.PREDICTIVE);
                insightValues.put(IvrCallPredictivesConstants.INSIGHT_VALUES, jsonSourceData.get(IvrCallPredictivesConstants.FEEDBACK_RESPONSE).toString());
                outputData.put(IvrCallPredictivesConstants.INSIGHT_VALUES,insightValues.get(IvrCallPredictivesConstants.INSIGHT_VALUES));
                outputData.put(IvrCallPredictivesConstants.UPDATE_BY,IvrCallPredictivesConstants.STREAMS);
                SimpleDateFormat formatter = new SimpleDateFormat(IvrCallPredictivesConstants.SIMPLE_DATE_FORMAT);
                String updateTs = formatter.format(new Date()) + IvrCallPredictivesConstants.TIME_ZONE;
                outputData.put(IvrCallPredictivesConstants.UPDATE_TS,updateTs);
                outputData.put(IvrCallPredictivesConstants.LINKAGE_ID, linkageID);
                validCountCust.inc();
                c.output( PredictiveToCassandraCustInsights, new JSONObject(outputData).toString());
            }

            /*
            if only mtn is available (customer_id and/or account_no is null/empty), push them to the output stream PredictiveToCassandraType1Data
             */

            else if(!jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString().equals("") && jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString()!=null )
            {
                outputData.put(IvrCallPredictivesConstants.MTN,jsonSourceData.get(IvrCallPredictivesConstants.MTN).toString());
                outputData.put(IvrCallPredictivesConstants.INSIGHT_CATEGORY,IvrCallPredictivesConstants.CALL);
                outputData.put(IvrCallPredictivesConstants.INSIGHT_NAME,IvrCallPredictivesConstants.PREDICTIVE);
                insightValues.put(IvrCallPredictivesConstants.INSIGHT_VALUES, jsonSourceData.get(IvrCallPredictivesConstants.FEEDBACK_RESPONSE).toString());
                outputData.put(IvrCallPredictivesConstants.INSIGHT_VALUES,insightValues.get(IvrCallPredictivesConstants.INSIGHT_VALUES));
                outputData.put(IvrCallPredictivesConstants.UPDATE_BY,IvrCallPredictivesConstants.STREAMS);
                SimpleDateFormat formatter = new SimpleDateFormat(IvrCallPredictivesConstants.SIMPLE_DATE_FORMAT);
                String updateTs = formatter.format(new Date()) + IvrCallPredictivesConstants.TIME_ZONE;
                outputData.put(IvrCallPredictivesConstants.UPDATE_TS,updateTs);
                validCountCustMTN.inc();
                c.output(PredictiveToCassandraCustMtnInsights, new JSONObject(outputData).toString());
            }
        }
        catch (Exception e)
        {
            deadLetterCount.inc();
            c.output(deadLetter, c.element());
            if (ExceptionsUtils.errorLog) {
                e.printStackTrace(System.out);
            }

        }
    }
}
