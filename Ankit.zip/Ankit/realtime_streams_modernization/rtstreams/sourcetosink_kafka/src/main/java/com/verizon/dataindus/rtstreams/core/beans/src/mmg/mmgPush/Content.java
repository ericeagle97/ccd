package com.verizon.dataindus.rtstreams.core.beans.src.mmg.mmgPush;

import java.io.Serializable;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

@javax.annotation.Nullable
public class Content implements Serializable{
	
	
	
	@Override
	public String toString() {
		return "Content [title=" + title + ", text=" + text + ", body=" + body + ", data=" + data + "]";
	}
	@SerializedName("title")
	@Nullable
	String title;

	@SerializedName("text")
	@Nullable
	String text;

	@SerializedName("body")
	@Nullable
	Body body;

	@SerializedName("data")
	@Nullable
	Data data;


	    public void setTitle(String title) {
	        this.title = title;
	    }
	    public String getTitle() {
	        return title;
	    }
	    
	    public void setText(String text) {
	        this.text = text;
	    }
	    public String getText() {
	        return text;
	    }
	    
	    public void setBody(Body body) {
	        this.body = body;
	    }
	    public Body getBody() {
	        return body;
	    }
	    
	    public void setData(Data data) {
	        this.data = data;
	    }
	    public Data getData() {
	        return data;
	    }
	    
	}
