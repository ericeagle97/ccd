package com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed;


import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;


import org.apache.avro.reflect.Nullable;

public class ShippingInsightPojo implements Serializable{
	
	@SerializedName("mtn")
	@Nullable
	public String mtn;
	
	@SerializedName("status")
	@Nullable
	public String status;
	
	@SerializedName("activityDate")
	@Nullable
	public String activityDate;

	public String getMtn() {
		return mtn;
	}

	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

	
	
	

}
