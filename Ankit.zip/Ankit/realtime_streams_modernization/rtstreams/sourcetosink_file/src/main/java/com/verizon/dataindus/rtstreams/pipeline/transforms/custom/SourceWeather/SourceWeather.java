package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.SourceWeather;
/**
 * Apache beam pardo class, read zipcodes from the input file and create respective rest endpoint
 * to fetch hourly weather details from yahoo API, creates cassandra request as output
 */

import com.verizon.dataindus.rtstreams.core.constants.WeatherConstants;
import com.verizon.dataindus.rtstreams.core.utils.ReadConfigJsonUtil;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.Duration;
import java.util.Date;


public class SourceWeather extends DoFn<String, String> {

    /**
     * Variable to hold static rest yahoo-endpoint
     */
    private String restEndpoint;

    /**
     * Variable to hold token to connect to rest yahoo-endpoint
     */
    private String token;

    /**
     *TupleTag, used to produce output being send to cassandra table to current observation data
     */
    public static final TupleTag<String> currentObervationData = new TupleTag<String>() {
    };

    /**
     *TupleTag, used to produce output being send to cassandra table to daily forecast data
     */
    public static final TupleTag<String> dailyForecastData = new TupleTag<String>() {
    };
    
    public static final TupleTag<String> rawTag = new TupleTag<String>() {
    };

    /**
     *TupleTag, used to produce output being send to dead letter queue
     */
    public static final TupleTag<String> deadLetter = new TupleTag<String>() {
    };

    private final Counter inputCounter = Metrics.counter("source_weatherAPI", "InputZipCodeCount");
    private final Counter deadLetterCounter = Metrics.counter("source_weatherAPI", "DeadLetterCount");

    /**
     *Read restendpoint and auth token from config file, set as class variables
     */
    public SourceWeather(String restEndpoint, String token) {
        this.restEndpoint = restEndpoint;
        this.token = token;
    }


    @ProcessElement
    public void processElement(ProcessContext c) throws ParseException {
        /**
         *input - zip code
         */
        String zipCode = c.element();

        /**
         * create rest endpoint for a particular zip code by appending zipcode to static rest endpoint
         */
        String yahooEndpoint = restEndpoint + zipCode;

        ReadConfigJsonUtil util = new ReadConfigJsonUtil();
        try {
            inputCounter.inc();
            HttpRequest request = null;
            /** Creating http requests using input httpURL and header details read from properties file */

            /**
             * create http request with auth token in the header
             */
            request = HttpRequest.newBuilder()
                    .uri(URI.create(yahooEndpoint)).timeout(Duration.ofSeconds(1)).GET()
                    .headers(WeatherConstants.X_APIKEY, token)
                    .build();

            /**
             * hit the api and read http response
             */
            HttpResponse response = util.callRestApi(request);

            /**
             * If api call is successful with response http code as 200, process the response data to create output
             */
            if (response.statusCode() == 200) {
            	
            	c.output(rawTag, response.body().toString());
            	
                JSONObject responseJson = new JSONObject(response.body().toString());

                /**
                 * Extract current observation data from response
                 */
                JSONArray currentObservationData = responseJson.getJSONObject(WeatherConstants.CURRENT_OBSERVATIONS)
                        .getJSONArray(WeatherConstants.RESULT);
                for (int observationRecord = 0; observationRecord < currentObservationData.length(); observationRecord++) {                    /**
                     * create request body to be inserted to cassandra
                     */
                    c.output(currentObervationData, util.frameWeatherCassandraRequest(currentObservationData.getJSONObject(observationRecord),
                            zipCode, WeatherConstants.CURRENT_OBSERVATIONS));

                }

                /**
                 * Extract daily data from response
                 */
                JSONArray dailyForecastsObservationData = responseJson
                        .getJSONObject(WeatherConstants.DAILY_FORECASTS).getJSONArray(WeatherConstants.RESULT);
                for (int observationRecord = 0; observationRecord < dailyForecastsObservationData.length(); observationRecord++) {

                    JSONObject dailyRecord = dailyForecastsObservationData.getJSONObject(observationRecord);

                    /**
                     * Compare forecast datetime with provider last update date time, if difference is less than 24 hours
                     * data can be written to cassandra table
                     */
                    SimpleDateFormat formatDatePattern = new SimpleDateFormat(WeatherConstants.DATE_PATTERN);
                    Date forecastTime = formatDatePattern.parse(dailyRecord.getString(WeatherConstants.FORECAST_TIME));
                    Date providerLastUpdateTime = formatDatePattern.parse(dailyRecord.getString(WeatherConstants.PROVIDER_LAST_UPDATE_TIME));
                    long timeDifference = forecastTime.getTime() - providerLastUpdateTime.getTime();
                    if (timeDifference <= 86400000) {
                        /**
                         * create request body to be inserted to cassandra
                         */
                        c.output(dailyForecastData, util.frameWeatherCassandraRequest(dailyRecord,
                                zipCode, WeatherConstants.DAILY_FORECASTS));
                    }

                }

            } else {
                deadLetterCounter.inc();
                c.output(deadLetter, c.element());
            }

        } catch (NullPointerException ex) {
            deadLetterCounter.inc();
            c.output(deadLetter, c.element());
            ex.printStackTrace(System.out);
        } catch (DateTimeException ex) {
            deadLetterCounter.inc();
            c.output(deadLetter, c.element());
            ex.printStackTrace(System.out);
        } catch (IndexOutOfBoundsException ex) {
            deadLetterCounter.inc();
            c.output(deadLetter, c.element());
            ex.printStackTrace(System.out);
        } catch (Exception ex) {
            deadLetterCounter.inc();
            c.output(deadLetter, c.element());
            ex.printStackTrace(System.out);
        }
    }
}