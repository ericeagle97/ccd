package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.beam.sdk.schemas.transforms.Group;
import org.apache.beam.sdk.transforms.GroupIntoBatches;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.transforms.WithKeys;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.utils.IOUtility;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.sourceedw.SourceEDW;

public class SourceEDWTransform {

	public static void downstreamProcess(PCollection<String> validData, StreamsJobRunner.FileIOOptions options,
			List<Map<String, String>> inputFileList) {
	
		SecretInterface objSecret = new SecretInterfaceClass();

		/**
		 * Type - String, use - holds keystore password for redis connection
		 **/
		String keystorePassword = ((ByteString) objSecret.SecretGCP(options.getProjectId(),
				options.getKeystorePassword(), "latest")).toStringUtf8();

		/**
		 * Type - byte array, use - holds jks bytes for redis connection
		 **/
		byte[] jksBytes = ((ByteString) objSecret.SecretGCP(options.getProjectId(), options.getKeystoreFile(),
				"latest")).toByteArray();

		/**
		 * Type - byte string, use - holds secret payload for redis connection
		 **/
		ByteString secretPayload = (ByteString) objSecret.SecretGCP(options.getProjectId(),
				options.getSecretCredentials(), "latest");

		
		int keySize = options.getKeySize();
		int batchSize = options.getBatchSize();
		/**
		 * Fixed Window for Batching the Data
		 */
		/*
		 * PCollection<Iterable<String>> groupedData = validData.apply("Windowing",
		 * Window.into(FixedWindows.of(Duration.standardMinutes(options.
		 * getWindowDuration())))) .apply("Grouping", Group.globally());
		 */
		
		PCollection <KV<Integer,Iterable<String>>> groupedData = validData
				.apply("Assigning Random key", WithKeys.of(
						(SerializableFunction<String,Integer>) ignored -> new Random()
						.nextInt(keySize))
						.withKeyType(TypeDescriptors.integers()))
				.apply("Grouping into Batches",
						GroupIntoBatches.ofSize(batchSize));

		/*
		 * fetching invalid and valid Data
		 */
		PCollectionTuple validInvalidData = groupedData.apply("Parsing and Redis Sink", ParDo.of(
				new SourceEDW(keystorePassword, jksBytes, secretPayload))
				.withOutputTags(SourceEDW.validTag,
						TupleTagList.of(SourceEDW.deadLetter).and(SourceEDW.invalidTag)));
		
		IOUtility.deadLetterOptionalSink(Constants.PUBSUB,
				validData,
				options.getPubSubTopic() + "-bqraw",
				"",
				"",
				0);
		
		IOUtility.deadLetterOptionalSink(Constants.PUBSUB,
				validInvalidData.get(SourceEDW.validTag),
				options.getPubSubTopic() + "-bqoutput",
				"",
				"",
				0);

		PCollection<String> invalidData = validInvalidData.get(SourceEDW.invalidTag);
		PCollection<String> errorData = validInvalidData.get(SourceEDW.deadLetter);

		/*
		 * Deadletters
		 */
		IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(), invalidData, options.getPubSubTopic() + "-invalid",
				options.getPath() + "/invalid/", options.getFileName(), options.getNumShards());
		
		IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(), errorData, options.getPubSubTopic() + "-error",
				options.getPath() + "/deadletter/", options.getFileName(), options.getNumShards());

	}
}
