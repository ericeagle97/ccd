package com.verizon.dataindus.rtstreams.core.constants.surge;

public class SourceSurgeAcctEstDtConstants {
	
	public static final String MTN = "mtn";
	public static final String ACCTNUM = "acctNum";
	public static final String ACCTESTBDT = "ACCT_ESTB_DT";
	public static final String CUSTID = "custId";
	public static final String MTN_REGEX = "[0-9]+";
	public static final String ACCT_EST_DT = "accountEstDate";

}
