package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.bqtokafka;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;


public class ProcessRows extends DoFn<KV<Integer,Iterable<String>>,String> {

	public static int counter = 0; //Counter to equally distribute the data to Kafka regions

	public static final TupleTag<String> validTag_east = new TupleTag<String>() {
	};

	public static final TupleTag<String> validTag_west = new TupleTag<String>() {
	};

	private static final Counter KafkaInsertBQEast = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.BQ_KAFKA_DATA_PUSH + "_" + Constants.REGION_EAST);

	private static final Counter KafkaInsertBQWEST = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.BQ_KAFKA_DATA_PUSH + "_" + Constants.REGION_WEST);


	@ProcessElement
	public void processElement(ProcessContext c ) throws IOException, ParseException 
	{
		// Read and iterate over the data
		Iterable<String> rows = c.element().getValue();

		try
		{
			if (rows.iterator().hasNext()) {
				//Loop over the records/rows to generate the JSON data as String to Kafka
				for (String record : rows) {
					//Convert the String record to a JSON object and fetch the value as String
					JSONObject recordData = new JSONObject(record);
					String dataString;
					if(record.contains("el_reprocessing"))
						dataString = recordData.getJSONObject("data").toString();
					else
						dataString = recordData.getString("data");

					//Convert the String json to JSON to push to Kafka
					JSONObject cjcmJson = new JSONObject(dataString);

					/*
					 * If counter is 0, push to west region and assign 1 to push the next record to east region
					 * Otherwise to east and assign 0 to push the next record to west region.
					 * Also increment the data counters with the data volume pushed to respective regions.
					 */
					if (counter == 0) {
						c.output(validTag_west, cjcmJson.toString());
						counter = 1;
						KafkaInsertBQWEST.inc();
					} else {
						c.output(validTag_east, cjcmJson.toString());
						counter = 0;
						KafkaInsertBQEast.inc();
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace(System.out);//Catch the exceptions if any
		}

	}
}
