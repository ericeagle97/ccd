package com.verizon.dataindus.rtstreams.core.constants.el;

public class Constants {

	  	public static final String EL_NAMESPACE = "EL";
	    public static final String METRICS_COUNTER_SUCCESS = "inserted_record";
	    public static final String METRICS_COUNTER_FAILURE = "failed_record";
	    public static final String METRICS_COUNTER_IGNORE = "ignored_record";
	    public static final String TOTAL_RECORDS_COUNTER = "total_records_read";
}
