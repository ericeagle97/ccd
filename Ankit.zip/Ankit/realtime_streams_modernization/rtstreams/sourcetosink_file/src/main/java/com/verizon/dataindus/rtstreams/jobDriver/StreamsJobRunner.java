package com.verizon.dataindus.rtstreams.jobDriver;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.pipeline.ingestion.file.FileIOIngestion;

public class StreamsJobRunner {
	public static FileIOOptions options;

	/*
	 * Interface to add custom pipeline options to pipeline
	 */
	public static interface FileIOOptions extends PipelineOptions {
		// Get GCP Project ID
		@Default.String("vz-it-np-gh2v-dev-rtstdo-0")
		@Description("GCP Project ID")
		@Validation.Required
		String getProjectId();

		void setProjectId(String projectId);

		// Get FileIO read config bucket
		@Default.String("vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow_rts")
		@Description("FileIO read config bucket")
		@Validation.Required
		String getFileIOConfigBucket();

		void setFileIOConfigBucket(String FileIOReadConfigBucket);

		// Get FileIO read config file
		@Default.String("DataflowSources/surge_configuration.json")
		@Description("FileIO read config file")
		@Validation.Required
		String getFileIOConfigFile();

		void setFileIOConfigFile(String FileIOReadConfigFile);
		// Get regions

		@Default.String("Source-SurgeAcctEstDt")
		@Description("FileIO read config file")
		@Validation.Required
		String getFileIOSource();

		void setFileIOSource(String FileIOReadSource);

		@Default.Boolean(true)
		@Description("Enable or Disable custom Logging and exceptions")
		@Validation.Required
		boolean getErrorLog();

		void setErrorLog(boolean errorLog);

		// Parameters below are used only for writing dead letter records
		@Default.Integer(1)
		@Description("Number of shards for each windowing function ")
		int getNumShards();

		void setNumShards(int value);

		@Default.String("gcs")
		@Description("Dead Letter Output can be \"GCS\" or \"PubSub\" ")
		String getDeadLetterSink();

		void setDeadLetterSink(String value);

		@Default.String("gs://vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow_rts/DataflowSources/RTStreams/SourceSurge")
		@Description("Gcs path to store the data into runtime path")
		String getPath();

		void setPath(String value);

		@Default.Integer(30)
		@Description("WindowDuration in Seconds")
		// @Validation.Required
		int getWindowDuration();

		void setWindowDuration(int value);

		@Default.String("memorystore-cert")
		@Description("MemoryStore Keystore File")
		String getKeystoreFile();

		void setKeystoreFile(String value);

		@Default.String("memorystore-cert")
		@Description("memorystore-keystore-pass")
		String getKeystorePassword();

		void setKeystorePassword(String value);

		@Default.String("memorystore-secrets")
		@Description("MemoryStore GCP Secrets")
		String getSecretCredentials();

		void setSecretCredentials(String value);

		@Default.String("source-surge")
		@Description("FileName")
		String getFileName();

		void setFileName(String value);

		@Default.String("vz-it-np-gh2v-dev-rtstdo-0")
		@Description("GCS Bucket Name")
		String getGcsBucket();

		void setGcsBucket(String value);

		@Default.String("projects/vz-it-np-gh2v-dev-rtstdo-0/topics/test-surge-error")
		@Description("Output PubSub topic to publish messages")
		@Validation.Required
		String getPubSubTopic();

		void setPubSubTopic(String pubSubTopic);

		@Description("HttpRequest")
		// @Validation.Required
		String getHttpRequest();

		void setHttpRequest(String value);

		@Description("skipHeader")
		// @Validation.Required
		boolean getSkipHeader();

		void setSkipHeader(boolean skipHeader);

		// Parameter to enable pubsub write for prod parallel run
		@Description("Parameter to enable pubsub write for prod parallel run")
		@Default.Boolean(false)
		boolean getPubsubParallelWrite();

		void setPubsubParallelWrite(boolean pubsubParallelWrite);
		
		@Description("Output pubsub topic for cassandra insertion")
		@Default.String("projects/vz-it-np-gh2v-test-rtstdo-0/topics/tp-cee-file-weather-cassandra-insert")
		String getOutputPubsubTopic();
		
		void setOutputPubsubTopic(String value);

		@Description("Grouping KeySize")
		@Default.Integer(5)
		int getKeySize();
		void setKeySize(int keySize);
		
		@Description("Grouping BatchSize")
		@Default.Integer(10)
		int getBatchSize();
		void setBatchSize(int batchSize);

		@Description("KafkaIO read config bucket")
		@Validation.Required
		@Default.String("vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow_rts")
		String getKafkaIOReadConfigBucket();

		void setKafkaIOReadConfigBucket(String kafkaIOReadConfigBucket);

		// Get KafkaIO read config file
		@Description("KafkaIO read config file")
		@Validation.Required
		@Default.String("DataflowSources/ConfigFiles/bqkafka_configuration_reprocessing.json")
		String getKafkaIOReadConfigFile();

		void setKafkaIOReadConfigFile(String kafkaIOReadConfigFile);

		// Get regions
		@Description("KafkaIO Read regions (comma-separated)")
		@Validation.Required
		@Default.String("east")
		String getKafkaIOReadRegions();

		void setKafkaIOReadRegions(String kafkaIOReadRegions);

		// Get regions
		@Description("KafkaIO Read source (source job name)")
		@Validation.Required
		@Default.String("source-bq-kafka_reprocessing")
		String getKafkaIOReadSource();

		void setKafkaIOReadSource(String kafkaIOReadSource);

		/*
		 * Kafka topic to read messages
		 */
		@Description("Input Kafka Topic Names (comma-separated)")
		@Validation.Required
		@Default.String("soi_vmg_event_ledger")
		String getKafkaTopicNames();

		void setKafkaTopicNames(String kafkaTopicNames);
	}

	/*
	 * Main method gets arguments as custom pipeline options and triggers
	 * KafkaSource template
	 */
	public static void main(String args[]) {
		/* Creating object for custom exception class */
		ExceptionsUtils objCustomExceptions = new ExceptionsUtils();
		try {
			options = PipelineOptionsFactory.fromArgs(args).withValidation().as(FileIOOptions.class);
			objCustomExceptions.errorLog = options.getErrorLog();
			FileIOIngestion fileIo = new FileIOIngestion();
			fileIo.fileIOIngestion(options);
		} catch (Exception e) {
			e.printStackTrace();
			objCustomExceptions.errorPipeline("StreamsJobRunner", e);
		}
	}
}
