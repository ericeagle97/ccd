package com.verizon.dataindus.rtstreams.core.common;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PrintElementFn extends DoFn<Row,String>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory.getLogger(PrintElementFn.class);

	@ProcessElement
	public void processElement(ProcessContext processContext){
		
		LOG.info("fields : "+ processContext.element().toString());
		processContext.output(String.valueOf(processContext.element().toString()).toString());
		
	}
}

