package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed;

import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed.CCRACommonPojo;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;

public class activationTransform extends DoFn<String, String> 
{
	private static final Logger LOG = LoggerFactory.getLogger(CleanCCRAFeed.class);
	private static final long serialVersionUID = 1L;
	Boolean errorLog;
	private StaticValueProvider<TupleTag<String>> deadLetterTag;
	
	public static final TupleTag<String> valid = new TupleTag<String>() {
	};
	
	public static final TupleTag<String> invalid = new TupleTag<String>() {
	};
	
	@ProcessElement
	public void processElement(ProcessContext c) 
	{
		
		ExceptionsUtils exceptions=new ExceptionsUtils();

		try 
		{
			String strSourceData = c.element().toString();
			String cleanData = null;
			
			CCRACommonPojo ccracommompojo = new CCRACommonPojo();
			
			if(strSourceData.contains("|") || strSourceData.contains("[|]"))
			{
				ccracommompojo.setActivation(strSourceData);
				
				c.output(valid,ccracommompojo.toString());
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOG.error(e.getMessage());
		}
	}

}
