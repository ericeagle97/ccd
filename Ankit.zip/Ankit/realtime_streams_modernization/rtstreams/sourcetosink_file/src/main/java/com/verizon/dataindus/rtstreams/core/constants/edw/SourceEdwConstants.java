package com.verizon.dataindus.rtstreams.core.constants.edw;

public class SourceEdwConstants {
	/*
	 * source_edw constants
	 */
	public static final String EDW_REQUESTTYPE_VALUE = "SOI_InsertCustomerMtnInsights";
	public static final String SORID = "sorId";
	public static final String CUSTID = "custId";
	public static final String CUSTLINESEQID = "custLineSeqId";
	public static final String RPTMTH = "rptMth";
	public static final String MTN = "mtn";
	public static final String ACCTNUM = "acctNum";
	public static final String VOICELINEIND = "voiceLineInd";
	public static final String SCOREVALUE1 = "scoreValue1";
	public static final String SCOREDECILE1 = "scoreDecile1";
	public static final String SCORECENTILE1 = "scoreCentile1";
	public static final String SCOREVALUE2 = "scoreValue2";
	public static final String SCOREDECILE2 = "scoreDecile2";
	public static final String SCORECENTILE2 = "scoreCentile2";
	public static final String SCOREVALUE3 = "scoreValue3";
	public static final String SCOREDECILE3 = "scoreDecile3";
	public static final String SCORECENTILE3 = "scoreCentile3";
	public static final String UPDATETS = "updateTs";
	public static final String INSIGHTCATEGORY = "insightCategory";
	public static final String INSIGHTCATEGORY_VALUE = "account";
	public static final String UPDATEBY = "updateBy";
	public static final String UPDATEBY_VALUE = "stream";
	public static final String INSIGHTNAME = "insightName";
	public static final String INSIGHTNAME_VALUE = "mapping";
	public static final String INSIGHTVALUES = "insightValues";
	public static final String MTN_COUNTER_SUCCESS = "valid mtn count";
	public static final String EDW_ = "EDW_";
	public static final String MTN_COUNTER_FAILURE = "mtn Fail count";
	public static final String MTN_REGEX = "[0-9]+";

}
