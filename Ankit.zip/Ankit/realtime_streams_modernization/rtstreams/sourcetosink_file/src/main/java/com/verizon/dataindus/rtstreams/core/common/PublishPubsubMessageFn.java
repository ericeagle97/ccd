package com.verizon.dataindus.rtstreams.core.common;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.verizon.dataindus.rtstreams.core.constants.Constants;

public class PublishPubsubMessageFn extends DoFn<String,PubsubMessage>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger LOG = LoggerFactory.getLogger(PublishPubsubMessageFn.class);

	private String attrKey;
	private String attrValue;

	public PublishPubsubMessageFn(String attrKey, String attrValue){
		this.attrKey = attrKey;
		this.attrValue = attrValue;
	}

	public static final Counter publishedCounter = Metrics.counter("PubsubPublish",
			"published_count" );

	@ProcessElement
	public void processElement(ProcessContext pc){

		HashMap<String, String> attributes = new HashMap<String, String>();
		attributes.put(attrKey, attrValue);

		PubsubMessage message = new PubsubMessage(
				pc.element().getBytes(StandardCharsets.UTF_8), attributes);
		publishedCounter.inc();
		pc.output(message);
	}
}

