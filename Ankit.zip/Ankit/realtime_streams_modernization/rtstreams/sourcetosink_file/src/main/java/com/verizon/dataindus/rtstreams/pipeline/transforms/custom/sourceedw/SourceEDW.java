package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.sourceedw;

import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.edw.SourceEdwConstants;
import com.verizon.dataindus.rtstreams.core.utils.JedisUtility;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;

public class SourceEDW extends DoFn<KV<Integer, Iterable<String>>, String> implements Serializable {

	private static final long serialVersionUID = 1L;

	// variable for projectId
	String projectId;
	private String keystorePassword;
	private byte[] jksBytes;
	private ByteString secretPayload;

	boolean enableWriteResponse;

	// jedis connect
	private Jedis redisClientDoFnObject;

	// constructor
	public SourceEDW(String keystorePassword, byte[] jksBytes, ByteString secretPayload) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;

	}

	public SourceEDW() {
	}

	public SourceEDW(Boolean enableWriteResponse) {
		this.enableWriteResponse = enableWriteResponse;
	}

	// for logging
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(SourceEDW.class);

	// Counter for processed data
	private final Counter processedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_SUCCESS);

	// counter for unprocessed data
	private final Counter unprocessedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_FAILURE);

	// counter for error data
	private final Counter errorCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_ERROR);

	// dead letter tuple tag
	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	// dead letter tuple tag
	public static final TupleTag<String> invalidTag = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	// valid tag
	public static final TupleTag<String> validTag = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword, false);

	}

	public static String getEmptyIfNull(String obj) {
		if (null == obj) {
			return "";
		} else {
			return obj;
		}
	}

	@ProcessElement
	public void processElement(ProcessContext c) throws IOException {
		Iterable<String> str_val_for_key = c.element().getValue();
		flush(str_val_for_key, c);
	}

	@Teardown
	public void teardown() {
		redisClientDoFnObject.close();
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
	}

	private void flush(Iterable<String> buffered, ProcessContext c) {
		//Iterable<String> batchList = c.element();
		Iterable<String> batchList = buffered ;

		Map<String, String> mapData = new HashMap<String, String>();

		try {
			Pipeline jedisPipeline = redisClientDoFnObject.pipelined();
			String[] separatedList = null;

			if (batchList.iterator().hasNext()) {
				for (String lines : batchList) {
					separatedList = lines.split(",", -1);
					String mtn_status_ind = separatedList[4];

					if (!CommonUtility.isNullEmptyOrBlank(mtn_status_ind)) {

						mapData.put(SourceEdwConstants.CUSTID, getEmptyIfNull(separatedList[0]));
						mapData.put(SourceEdwConstants.MTN, getEmptyIfNull(separatedList[1]));
						mapData.put(SourceEdwConstants.ACCTNUM, getEmptyIfNull(separatedList[3]));

						String redisKey = SourceEdwConstants.EDW_ + mapData.get(SourceEdwConstants.MTN);
						String redisValue = mapData.get(SourceEdwConstants.CUSTID) + "-" + mapData.get(SourceEdwConstants.ACCTNUM);

						if (mapData.get(SourceEdwConstants.CUSTID) != null && mapData.get(SourceEdwConstants.ACCTNUM) != null
								&& mapData.get(SourceEdwConstants.MTN) != null
								&& mapData.get(SourceEdwConstants.ACCTNUM).matches(SourceEdwConstants.MTN_REGEX)
								&& mapData.get(SourceEdwConstants.CUSTID).matches(SourceEdwConstants.MTN_REGEX)
								&& mapData.get(SourceEdwConstants.MTN).matches(SourceEdwConstants.MTN_REGEX)
								&& mapData.get(SourceEdwConstants.MTN).length() == 10) {

							jedisPipeline.set(redisKey, redisValue);

							if (mtn_status_ind.equalsIgnoreCase("a") ||
									mtn_status_ind.equalsIgnoreCase("s")) {
							} else if (mtn_status_ind.equalsIgnoreCase("d") ||
									mtn_status_ind.equalsIgnoreCase("io") ||
									mtn_status_ind.equalsIgnoreCase("c") ||
									mtn_status_ind.equalsIgnoreCase("po")) {
								jedisPipeline.expire(redisKey, 259200L);
							}

							processedCounter.inc();
							c.output(validTag, mapData.toString());

						} else {
							unprocessedCounter.inc();
							c.output(invalidTag, lines.toString()); //invalid-deadletter
						}
					}

					List<Object> res = jedisPipeline.syncAndReturnAll();
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
			errorCounter.inc();
			c.output(deadLetter, c.element().toString()); //error-deadletter
		}
	}



}
