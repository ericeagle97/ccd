package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.sourcesurgeacctestdt;

import java.io.EOFException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.surge.SourceSurgeAcctEstDtConstants;
import com.verizon.dataindus.rtstreams.core.utils.JedisUtility;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;

public class SourceSurgeAcctEstDt extends DoFn<KV<Integer, Iterable<String>>, String> implements Serializable {

	private static final long serialVersionUID = 1L;

	// variable for projectId
	String projectId;
	private String keystorePassword;
	private byte[] jksBytes;
	private ByteString secretPayload;

	boolean enableWriteResponse;

	// jedis connect
	private Jedis redisClientDoFnObject;

	// constructor
	public SourceSurgeAcctEstDt(String keystorePassword, byte[] jksBytes, ByteString secretPayload) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;

	}

	public SourceSurgeAcctEstDt(Boolean enableWriteResponse) {
		this.enableWriteResponse = enableWriteResponse;
	}

	// for logging
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(SourceSurgeAcctEstDt.class);

	// Counter for processed data
	private final Counter processedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_SUCCESS);

	// counter for unprocessed data
	private final Counter unprocessedCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_FAILURE);

	// counter for error data
	private final Counter errorCounter = Metrics.counter(Constants.METRICS_PREPROCESSING,
			Constants.METRICS_COUNTER_ERROR);

	// dead letter tuple tag
	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	// dead letter tuple tag
	public static final TupleTag<String> invalidTag = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	// valid tag
	public static final TupleTag<String> withoutAcctManipulationTag = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	public static final TupleTag<String> withAcctManipulationTag = new TupleTag<String>() {
		private static final long serialVersionUID = 1L;
	};

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
	NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword, false);

	}

	public static String getEmptyIfNull(String obj) {
		if (null == obj) {
			return "";
		} else {
			return obj;
		}
	}

	@ProcessElement
	public void processElement(ProcessContext c) throws IOException {
		Iterable<String> str_val_for_key = c.element().getValue();
		flush(str_val_for_key, c);
	}

	@Teardown
	public void teardown() {
		redisClientDoFnObject.close();
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
	}

	private void flush(Iterable<String> buffered, ProcessContext c) {
		//Iterable<String> batchList = c.element(); 
		Iterable<String> batchList = buffered ;

		Map<String, String> mapData = new HashMap<String, String>();

		try {
			Pipeline jedisPipeline = redisClientDoFnObject.pipelined();   	
			String[] separatedList = null;
			Map<String, Response<Boolean>> redisResponse = new HashMap<>();
			List<String> redisKeysList = new ArrayList<>();

			if (batchList.iterator().hasNext()) 
			{
				for (String lines : batchList) 
				{

					separatedList = lines.split(",", -1);
					// CUST_ID, ACCT_NUM, ACCT_ESTB_DT 

					mapData.put(SourceSurgeAcctEstDtConstants.CUSTID, getEmptyIfNull(separatedList[0]));
					mapData.put(SourceSurgeAcctEstDtConstants.ACCTNUM, getEmptyIfNull(separatedList[1]));
					mapData.put(SourceSurgeAcctEstDtConstants.ACCTESTBDT, getEmptyIfNull(separatedList[2]));

					String redisKey = mapData.get(SourceSurgeAcctEstDtConstants.CUSTID) + "-" + CommonUtility.leftAppendString(mapData.get(SourceSurgeAcctEstDtConstants.ACCTNUM), "0", 5);
					List<String> dTokens = List.of(mapData.get(SourceSurgeAcctEstDtConstants.ACCTESTBDT).split("/"));
					if (dTokens.size() >= 3){
						String custOrigDt = dTokens.get(2) + "/" + dTokens.get(0) + "/" + dTokens.get(1);
					}

					if (mapData.get(SourceSurgeAcctEstDtConstants.CUSTID) != null && mapData.get(SourceSurgeAcctEstDtConstants.ACCTNUM) != null
							&& mapData.get(SourceSurgeAcctEstDtConstants.ACCTNUM).matches(SourceSurgeAcctEstDtConstants.MTN_REGEX)
							&& mapData.get(SourceSurgeAcctEstDtConstants.CUSTID).matches(SourceSurgeAcctEstDtConstants.MTN_REGEX))
					{

						SimpleDateFormat srcParser = new SimpleDateFormat("yyyy-MM-dd");
						SimpleDateFormat trasformDateFormat = new SimpleDateFormat("yyyy/MM/dd");

						Date date = srcParser.parse(mapData.get(SourceSurgeAcctEstDtConstants.ACCTESTBDT));
						String accountDate = trasformDateFormat.format(date);

						//long setCallStructureRes = //JedisUtility.jedisHSet(redisClientDoFnObject,redisKey,SourceSurgeAcctEstDtConstants.ACCT_EST_DT,accountDate.toString()); // date format - yyyymmdd 2024/01/28

						//System.out.println("rediskey before modification ---> "+redisKey);
						//System.out.println("SourceSurgeAcctEstDtConstants.ACCT_EST_DT before modification ---> "+SourceSurgeAcctEstDtConstants.ACCT_EST_DT);
						//System.out.println("accountDate before modification ---> "+accountDate);

						c.output(withoutAcctManipulationTag, mapData.toString());

						redisResponse.put(redisKey,jedisPipeline.hexists(redisKey, SourceSurgeAcctEstDtConstants.ACCT_EST_DT));
						mapData.put(SourceSurgeAcctEstDtConstants.ACCTNUM,
								CommonUtility.leftAppendString(mapData.get(SourceSurgeAcctEstDtConstants.ACCTNUM), "0", 5));
						mapData.put(SourceSurgeAcctEstDtConstants.CUSTID,
								CommonUtility.leftAppendString(mapData.get(SourceSurgeAcctEstDtConstants.CUSTID), "0", 10));


						//System.out.println("rediskey before modification ---> "+redisKey);
						//System.out.println("SourceSurgeAcctEstDtConstants.ACCT_EST_DT before modification ---> "+SourceSurgeAcctEstDtConstants.ACCT_EST_DT);
						//System.out.println("accountDate before modification ---> "+accountDate);

						String redisKeyNew = mapData.get(SourceSurgeAcctEstDtConstants.CUSTID) + "-" + mapData.get(SourceSurgeAcctEstDtConstants.ACCTNUM);

						jedisPipeline.hset(redisKeyNew,SourceSurgeAcctEstDtConstants.ACCT_EST_DT,accountDate);
						//jedisPipeline.expire(redisKey, 1296000L);

						processedCounter.inc();
						c.output(withAcctManipulationTag, mapData.toString());
						//c.output(validTag, mapData.toString());

					} else {
						unprocessedCounter.inc();
						c.output(invalidTag, lines.toString()); //invalid-deadletter
					}
				}

				List<Object> res = jedisPipeline.syncAndReturnAll();
				/* To be commented for cutover */
				for(Map.Entry<String, Response<Boolean>> entry : redisResponse.entrySet())
				{
					String key = entry.getKey();
					Boolean keyExists = entry.getValue().get();
					if(keyExists)
					{
						jedisPipeline.del(key);
					}

				}				
			}

		} catch (Exception e) {
			e.printStackTrace();
			errorCounter.inc();
			c.output(deadLetter, c.element().toString()); //error-deadletter
		}
	}



}
