package com.verizon.dataindus.rtstreams.pipeline.ingestion.file;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.core.lib.FileReader;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.transforms.Filter;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.verizon.dataindus.rtstreams.core.utils.ReadConfigJsonUtil.getFileReadConfigurations;

public class FileIOIngestion {

    public void fileIOIngestion(StreamsJobRunner.FileIOOptions options) {

        // Creates pipeline with custom pipeline options
        Pipeline pipeline = Pipeline.create(options);

        // Creating object for custom exception class
        ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

        // Create a map from config data. and list for multiple entries in config data
        List<Map<String,String>> inputFileList = getFileReadConfigurations(
                options.getProjectId(),
                options.getFileIOConfigBucket(),
                options.getFileIOConfigFile(),
                options.getFileIOSource(),
                objCustomExceptions);

        // List of PCollections created after TextIO.read()
        List<PCollection<String>> listFileIOReadPCollections = new ArrayList<>();

        try{
            if(!inputFileList.isEmpty())
                for(Map<String, String> inputData: inputFileList){
                    // Add all PCollections read to the list
                    PCollection<String> listCollectionsForAllFiles = new FileReader()
                            .readSource(pipeline,inputData.get("inputFilePath"));

                    if (options.getSkipHeader()) {
						PCollection<String> listCollectionsForAllFilesWithHeaders = listCollectionsForAllFiles
								.apply(Filter.by(element -> !element.toLowerCase()
										.contains("cust_id,mtn,cust_line_seq_id,acct_num,process_dt")));

						listFileIOReadPCollections.add(listCollectionsForAllFilesWithHeaders);
					} else {
						listFileIOReadPCollections.add(listCollectionsForAllFiles);

					}
                }

            // Flatten out all PCollections read
            PCollection<String> dataFromAllFiles =
                    PCollectionList.of(listFileIOReadPCollections)
                            .apply("Flatten", Flatten.pCollections());


            //JsonParsing and Source Transformations with PubSub write for downstream consumptions
            SourceTransformation processLauncher =new SourceTransformation();
            /*Calling SourceProcessLauncher for source transformations if any class*/
            processLauncher.sourceProcessLauncher(dataFromAllFiles,options, inputFileList);

            pipeline.run();
        } catch (Exception e) {
            e.printStackTrace();
            objCustomExceptions.errorPipeline("FileIngestion", e);
        }
    }
}
