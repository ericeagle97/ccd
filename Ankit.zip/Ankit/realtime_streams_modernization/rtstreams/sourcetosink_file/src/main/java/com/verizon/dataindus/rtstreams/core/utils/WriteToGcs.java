package com.verizon.dataindus.rtstreams.core.utils;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.beam.sdk.io.Compression;
import org.apache.beam.sdk.io.FileIO;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.joda.time.Duration;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.WriteChannel;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.common.collect.Lists;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.Constants;


public class WriteToGcs
{

	/** writeToGCS  & writeToPubSub methods will write invalid record to Gcs Bucket/Pub sub
     topic based on user input */
	public static TextIO.Write writeToGCS(String path ,String fileName ,int numShards )
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String currentDateTIme = sdf.format(new Date());
		return

				TextIO.write()
				/** numShards decides the parallel pipeline on same window */
				.withNumShards(numShards)
				.to(path + currentDateTIme + "/" + fileName)
				.withSuffix( ".txt")
				.withCompression(Compression.GZIP);
	}

	public static void writeStringToGCS(String bucketName, String fileName, String data) {
		/*Accessing the GCS bucket and writing to file*/
		GoogleCredentials credentialsNew;
		try {
			credentialsNew = GoogleCredentials.getApplicationDefault().createScoped(Lists.newArrayList(Constants.GCP_AUTH_CRED));

			Storage storage = StorageOptions.newBuilder().setCredentials(credentialsNew).build().getService();

			String fileNameWithTime = fileName+"_"+CommonUtility.getGMTDateTime("yyyyMMdd_HHmmss_SSS")+".txt";
			BlobId blobId = BlobId.of(bucketName, fileNameWithTime);
			byte[] content;
			content = data.getBytes(StandardCharsets.UTF_8);

			BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
			try (WriteChannel writer = storage.writer(blobInfo)) {
				try {
					writer.write(ByteBuffer.wrap(content, 0, content.length));
				} catch (Exception ex) {
					// handle exception
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}







