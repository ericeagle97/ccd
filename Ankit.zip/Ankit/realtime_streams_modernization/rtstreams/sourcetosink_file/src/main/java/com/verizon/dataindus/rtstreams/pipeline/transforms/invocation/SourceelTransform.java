package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.joda.time.Duration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.utils.IOUtility;
import com.verizon.dataindus.rtstreams.core.utils.WriteToGcs;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.el.SourceEL;

public class SourceelTransform {

	public static void downstreamProcess(PCollection<String> validData, StreamsJobRunner.FileIOOptions options,
			List<Map<String, String>> inputFileList) {

		try {
			// Creating object for secrets interface
			SecretInterface objSecret = new SecretInterfaceClass();

			String keystorePassword = ((ByteString) objSecret.SecretGCP(options.getProjectId(),
					options.getKeystorePassword(), "latest")).toStringUtf8();

			byte[] jksBytes = ((ByteString) objSecret.SecretGCP(options.getProjectId(), options.getKeystoreFile(),
					"latest")).toByteArray();

			ByteString secretPayload = (ByteString) objSecret.SecretGCP(options.getProjectId(),
					options.getSecretCredentials(), "latest");

			// create object mapper instance
			ObjectMapper om = new ObjectMapper();
			// configure ignore unknown properties
			om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			om.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
			om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
			om.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);

			PCollectionTuple inserteddata = validData.apply("Redis Insertion",
					ParDo.of(new SourceEL(keystorePassword, jksBytes, secretPayload))
							.withOutputTags(SourceEL.successRecords, TupleTagList.of(SourceEL.deadLetter)));

			PCollection<String> validrecords = inserteddata.get(SourceEL.successRecords);

			PCollection<String> deadLetterLogic = inserteddata.get(SourceEL.deadLetter);

			// Dead letters Sink for Invalid Records - GCS/PubSub
			IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(), deadLetterLogic,
					options.getPubSubTopic() + "-error", options.getPath(), options.getFileName(),
					options.getNumShards());

			validrecords
					.apply(Window
							.<String>into(FixedWindows
									.of(Duration.standardSeconds(Integer.valueOf(options.getWindowDuration()))))
							.withAllowedLateness(Duration.standardHours(5)).discardingFiredPanes())
					.apply(WriteToGcs.writeToGCS(options.getPath() + "export/", "RedisELData", options.getNumShards()));

			/**
			 * Write raw record to BQ tables for data validation
			 */

			validData.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-bqraw"));

			validrecords.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-bqoutput"));

		} catch (Exception ex) {
			ex.printStackTrace(System.out);
		}

	}

}
