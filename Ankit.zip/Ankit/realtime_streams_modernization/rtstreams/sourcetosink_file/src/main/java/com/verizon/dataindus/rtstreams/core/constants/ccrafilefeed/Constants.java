package com.verizon.dataindus.rtstreams.core.constants.ccrafilefeed;

public class Constants {
	
	public static final String ACTIVATIONINSIGHT = "activation insight";
	public static final String ACTIVATIONINSIGHT_COUNTER_TOTAL = "activation insight total_count";
	public static final String ACTIVATIONINSIGHT_COUNTER_SUCCESS = "activation insight successful_count";
	public static final String ACTIVATIONINSIGHT_COUNTER_FAILURE = "activation insight failure_count";
	
	public static final String SHIPPINGINSIGHT = "shipping insight";
	public static final String SHIPPINGINSIGHT_COUNTER_TOTAL = "shipping insight total_count";
	public static final String SHIPPINGINSIGHT_COUNTER_SUCCESS = "shipping insight successful_count";
	public static final String SHIPPINGINSIGHT_COUNTER_FAILURE = "shipping insight failure_count";
	
	public static final String CASSANDRANORMALIZATION = "cassandra normalization";
	public static final String CASSANDRANORMALIZATION_COUNTER_SUCCESS = "cassandra call successful_count";
	public static final String CASSANDRANORMALIZATION_COUNTER_FAILURE = "cassandra call failure_count";
	
	public static final String EDW = "EDW_";

	
	
}

