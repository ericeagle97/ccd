package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed;

import java.util.Arrays;
import java.util.List;

import java.util.HashMap;
import java.util.Map;

import java.sql.Timestamp;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;

import com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed.ActivationInsightPojo;
import com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed.ShippingInsightPojo;
import com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed.customerInsightsPojo;
import com.verizon.dataindus.rtstreams.core.constants.ccrafilefeed.Constants;



public class SourceCCRAFeed extends DoFn<String, String>
{

	private static final long serialVersionUID = 1L;

	public static final TupleTag<customerInsightsPojo> ActivationInsight = new TupleTag<customerInsightsPojo>() {

		private static final long serialVersionUID = 1L;
	};

	public static final TupleTag<customerInsightsPojo> ShippigInsight = new TupleTag<customerInsightsPojo>() {

		private static final long serialVersionUID = 1L;
	};

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
	};

	private final Counter activationinsight_total = Metrics.counter(Constants.ACTIVATIONINSIGHT, Constants.ACTIVATIONINSIGHT_COUNTER_TOTAL);
	private final Counter activationinsight_success = Metrics.counter(Constants.ACTIVATIONINSIGHT, Constants.ACTIVATIONINSIGHT_COUNTER_SUCCESS);
	
	private final Counter activationinsight_error = Metrics.counter(Constants.ACTIVATIONINSIGHT, Constants.ACTIVATIONINSIGHT_COUNTER_FAILURE);

	private final Counter shippinginsight_total = Metrics.counter(Constants.SHIPPINGINSIGHT, Constants.SHIPPINGINSIGHT_COUNTER_TOTAL);
	private final Counter shippinginsight_success = Metrics.counter(Constants.SHIPPINGINSIGHT, Constants.SHIPPINGINSIGHT_COUNTER_SUCCESS);
	private final Counter shippinginsight_error = Metrics.counter(Constants.SHIPPINGINSIGHT, Constants.SHIPPINGINSIGHT_COUNTER_FAILURE);



	@ProcessElement
	public void processElement(ProcessContext c )
	{
		String sourceData = c.element();
		String tempactivityDateTime = "";
		String activityDate = "";
		String tempactivityTimeExtract = "";
		String activityTime ="";
		String timeInMs = "";
		String timestampFormat = ".";
		String timeInMsFinal ="";
	
		if(sourceData.contains("|") || sourceData.contains("[|]"))
		{
			try
			{
				activationinsight_total.inc();

				ActivationInsightPojo activation_object = new ActivationInsightPojo();

				customerInsightsPojo customerInsights = new customerInsightsPojo();

				Map<String, Object> activation_value = new HashMap<String, Object>(); 

				String yes = "Y";
				String no = "";

				List<String> items = Arrays.asList(sourceData.split("[|]"));//convert the String to list for easy indexing

				String _checkSuccess = items.get(5);
				String _mtn = items.get(3);

				//Check for success in line
				if (_checkSuccess.contains("SUCCESS")){
					activation_object.setActivation(yes);	
				}
				else 
				{
					activation_object.setActivation(no);
				}

				tempactivityDateTime = items.get(8);
				List<String> datetime = Arrays.asList(tempactivityDateTime.split(" "));

				activityDate = datetime.get(0);
				tempactivityTimeExtract = datetime.get(1);

				List<String> tempactivityTime = Arrays.asList(tempactivityTimeExtract.split("[.]"));

				activityTime = tempactivityTime.get(0);

				//replace "/" with ""
				activityDate = activityDate.replace("/","");

				//replace ":" with ""
				activityTime = activityTime.replace(":","");

				activityDate = activityDate.substring(4,8)+activityDate.substring(0,2)+activityDate.substring(2,4);
				activation_object.setMtn(_mtn);

				java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());
				List<String> presentTime = Arrays.asList(timestamp.toString().split(" "));
				String requiredTime = presentTime.get(1);
				List<String> millisec = Arrays.asList(requiredTime.split("[.]"));
				String requiredTime2 = millisec.get(1);
				timeInMsFinal = activityDate+"T"+activityTime+"."+requiredTime2+" GMT";
				activation_object.setActivityDate(timeInMsFinal);

				customerInsights.setCust_id_no("");
				customerInsights.setAcct_no("");
				customerInsights.setMtn(activation_object.getMtn());
				customerInsights.setInsight_category("Ordering");
				customerInsights.setInsight_name("activationInfo");

				activation_value.put("activation",activation_object.getActivation());
				activation_value.put("activityDate",activation_object.getActivityDate());

				customerInsights.setInsight_values(new JSONObject(activation_value).toString());
				
				activationinsight_success.inc();
				c.output(ActivationInsight,customerInsights);

			}

			catch (Exception ex) {

				c.output(deadLetter,sourceData.toString());
				
				activationinsight_error.inc();
			}

		}

		
		else
		{
			try
			{
				shippinginsight_total.inc();
				ShippingInsightPojo shipping_object = new ShippingInsightPojo();

				customerInsightsPojo customerShippingInsightPojo = new customerInsightsPojo();

				Map<String, Object> shipping_value = new HashMap<String, Object>();

				String _status = sourceData.substring(61, 65);

				String _mtn = sourceData.substring(65, 75);

				String tempactivityDate = "";

				shipping_object.setStatus(_status);
				shipping_object.setMtn(_mtn);


				//System.out.println(shipping_object);
				if(_status.equals("SUCC")) {
					shipping_object.setStatus("Successful");
				}

				else if(_status.equals("FAIL")) {
					shipping_object.setStatus("Fail");
				}

				else if(_status.equals("SHIP")) {
					shipping_object.setStatus("Shipping");
				}

				else if(_status.equals("SENT")) {
					shipping_object.setStatus("Sent");
				}

				else if(_status.equals("CNCL")) {
					shipping_object.setStatus("Canceled");
				}

				else if(_status.equals("ACTV")) {
					shipping_object.setStatus("DELIVERED");
				}

				else if(_status.equals("IFDW")) {
					shipping_object.setMtn("");
				}

				tempactivityDate = sourceData.substring(153,161);

				if(tempactivityDate.equals("        "))
				{
					shipping_object.setMtn("");
				}
				else if(!tempactivityDate.equals("        ")) {
					java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());
					List<String> presentTime = Arrays.asList(timestamp.toString().split(" "));
					String requiredTime = presentTime.get(1);
					//System.out.println("requiredTime-->"+requiredTime);
					List<String> millisec = Arrays.asList(requiredTime.split("[.]"));
					activityTime = millisec.get(0);

					List<String> time = Arrays.asList(activityTime.split(":"));
					String _time_to_add = time.get(0)+time.get(1)+time.get(2);
					//System.out.println("_time_to_add--->"+_time_to_add);
					String requiredTime2 = millisec.get(1);
					timeInMsFinal = tempactivityDate+"T"+_time_to_add+"."+requiredTime2+" GMT";
					shipping_object.setActivityDate(timeInMsFinal);
				}

				customerShippingInsightPojo.setCust_id_no("");
				customerShippingInsightPojo.setAcct_no("");
				customerShippingInsightPojo.setMtn(shipping_object.getMtn());
				customerShippingInsightPojo.setInsight_category("Ordering");
				customerShippingInsightPojo.setInsight_name("shippingInfo");
				shipping_value.put("status",shipping_object.getStatus());
				shipping_value.put("activityDate",shipping_object.getActivityDate());
				customerShippingInsightPojo.setInsight_values(new JSONObject(shipping_value).toString());
				shippinginsight_success.inc();
				c.output(ShippigInsight,customerShippingInsightPojo);

			}

			catch (Exception ex) {
				c.output(deadLetter,sourceData.toString());
				shippinginsight_error.inc();

			}
			
		}
		
	}

}