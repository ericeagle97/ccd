package com.verizon.dataindus.rtstreams.core.utils;

import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.lib.CassandraInsertion;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.net.http.HttpResponse;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;

public class CassandraInsertRPC extends DoFn<KV<Integer, Iterable<String>>, String> implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(CassandraInsertRPC.class);
	private String httpRequest;
	private String requestType;

	public static final TupleTag<String> deadLetterQueue = new TupleTag<String>() {
	};
	public static final TupleTag<String> responseSuccess = new TupleTag<String>() {
	};

	final Counter successCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_EVENTS+"_"+ Constants.METRICS_COUNTER_SUCCESS);
	final Counter failureCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_EVENTS+"_"+ Constants.METRICS_COUNTER_FAILURE);

	final Counter failureApiCounter = Metrics.counter(Constants.METRICS_CASSANDRA_INSERTION,Constants.METRICS_CASSANDRA_API+"_"+ Constants.METRICS_COUNTER_FAILURE);

	public CassandraInsertRPC(String httpRequest, String requestType) {

		this.httpRequest = httpRequest;
		this.requestType = requestType;
	}


	@ProcessElement
	public void processElement(ProcessContext c) throws ParseException, IOException, InterruptedException {
		Iterable<String> str_val_for_key = c.element().getValue();
		flush(str_val_for_key, c);
	}


	private void flush(Iterable<String> buffered, ProcessContext c) {
		try {
			ArrayList<Object> mylist = new ArrayList<Object>();
			for (String s : buffered) {
				mylist.add(new JSONObject(s));
			}
			HashMap<String, Object> batchDataReq = new HashMap<String, Object>();
			batchDataReq.put("requestType", requestType);
			batchDataReq.put("listKeyAttributes", mylist);
			//System.out.println(batchDataReq.toString());

			int mylistSize = mylist.size();
			/** object of cassandra insertion library */
			CassandraInsertion insertData = new CassandraInsertion();
			long StartTime = System.currentTimeMillis();
			/** send metadata and data of http request to cassandra insertion library and stores the response to 'response' variable */
			HttpResponse<String> response = insertData.cassandraInsertion(httpRequest, new JSONObject(batchDataReq).toString());
			long EndTime = System.currentTimeMillis();
			long TimeTaken = EndTime - StartTime;
			//            LOG.info(" mylistSize=" + mylistSize + " response=" + response.statusCode() + " StartTime=" + StartTime + " EndTime=" + EndTime + " TimeTaken=" + TimeTaken);
			if (response != null && response.statusCode() == 200 && response.body().toString().matches(Constants.REGEX_PNO_SUCCESS)) {
				successCounter.inc();
				c.output(new JSONObject(batchDataReq).toString());
			}
			else {
				failureCounter.inc();
				c.output(deadLetterQueue, new JSONObject(batchDataReq).toString());
			}
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			LOG.error(sw.toString());

			failureApiCounter.inc();
		}

	}
}