package com.verizon.dataindus.rtstreams.exceptions;

public class GenericException extends Exception{
    public GenericException() { super(); }

    public GenericException(String message) { super(message); }
}
