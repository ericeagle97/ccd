package com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed;


import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.SerializedName;


import org.apache.avro.reflect.Nullable;

public class ActivationInsightPojo implements Serializable{
	
	@SerializedName("mtn")
	@Nullable
	public String mtn;
	
	@SerializedName("activation")
	@Nullable
	public String activation;
	
	
	@SerializedName("activityDate")
	@Nullable
	public String activityDate;


	public String getMtn() {
		return mtn;
	}


	public void setMtn(String mtn) {
		this.mtn = mtn;
	}


	public String getActivation() {
		return activation;
	}


	public void setActivation(String activation) {
		this.activation = activation;
	}


	public String getActivityDate() {
		return activityDate;
	}


	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}

}
