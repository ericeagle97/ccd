package com.verizon.dataindus.rtstreams.core.utils.interfaces;

public interface SecretInterface 
{
	/*Interface to get ProjectId, SecretId, Verison as input to fetch secrets from GCP Secret Manager*/
	Object SecretGCP(String projectId, String secretId, String versionId) ;
}
