package com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed;

import org.apache.avro.reflect.Nullable;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Map;

@javax.annotation.Nullable

public class CCRACommonPojo  implements Serializable {
	
	@Nullable
	@SerializedName("activation")
	String activation;
	
	@Nullable
	@SerializedName("shipping")
	String shipping;

	public String getActivation() {
		return activation;
	}

	public void setActivation(String activation) {
		this.activation = activation;
	}

	public String getShipping() {
		return shipping;
	}

	public void setShipping(String shipping) {
		this.shipping = shipping;
	}

}
