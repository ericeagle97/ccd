package com.verizon.dataindus.rtstreams.lib.writers;


import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import org.apache.beam.sdk.io.kafka.KafkaIO;
import org.apache.beam.sdk.values.PCollection;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.populateConfigMap;
import static com.verizon.dataindus.rtstreams.core.constants.Constants.*;

/*
 * Connection to Kafka Server using parameters assigned in configuration file
 * and returning PCollections
 */
public class KafkaWriter {
    public List<PCollection<String>> writeData(PCollection<String> eastData, PCollection<String> westData,
                                               String topic,
                                               Map<String, JSONObject> kafkaIOReadTopicWiseConfigMap) {
        /* Creating object for custom exception class*/
        ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

        // Get the configuration as a JSONObject for the provided topic
        JSONObject topicWiseConfig = kafkaIOReadTopicWiseConfigMap.get(topic);

        // Get region-wise(east/west) configuration for the topic
        JSONArray regionArray = topicWiseConfig.getJSONArray(CONFIG_KEYWORD_REGIONS);
        Map<String, JSONObject> regionWiseServerGroup = new HashMap<>();

        // Populate the map regionWiseServerGroup using a helper function
        populateConfigMap(regionArray, regionWiseServerGroup);

        // Create a map of all kafka properties for the topic to be supplied in KafkaIO.read()
        Map<String, Object> kafkaIOReadPropertiesMap = new HashMap<>();
        JSONObject kafkaProperties = topicWiseConfig.getJSONObject(CONFIG_KEYWORD_KAFKA_PROPERTIES);
        for (String key : kafkaProperties.keySet())
            kafkaIOReadPropertiesMap.put(key, kafkaProperties.get(key));

        List<PCollection<String>> kafkaIoReads = new ArrayList<>();

        // Execute KafkaIO.read() for each region provided as a runtime parameter
        for (String region : regionWiseServerGroup.keySet()) {
            try {
            	PCollection<String> data = null;
            	if(region.equalsIgnoreCase("west")) {
            		data = westData;
            	}else {
            		data = eastData;
            	}
                data.apply(String.format("Write to %s topic - (%s)", topic, region),
                                KafkaIO.<Void, String>write().withTopic(topic)
                                        .withBootstrapServers((String) regionWiseServerGroup.get(region)
                                                .get(CONFIG_KEYWORD_BOOTSTRAP_SERVER))
                                        .withProducerConfigUpdates(kafkaIOReadPropertiesMap)
                                        .withValueSerializer(StringSerializer.class)
                                        .values()
                        );

            } catch (KafkaException kafkaException) {
                objCustomExceptions.kafkaException("KafkaWriter", kafkaException);
            } catch (Exception e) {
                objCustomExceptions.errorPipeline("KafkkaWriter", e);
                return null;
            }
        }
        return kafkaIoReads;
    }
}
