package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.el;

import static com.verizon.dataindus.rtstreams.core.constants.el.Constants.EL_NAMESPACE;
import static com.verizon.dataindus.rtstreams.core.constants.el.Constants.METRICS_COUNTER_FAILURE;
import static com.verizon.dataindus.rtstreams.core.constants.el.Constants.METRICS_COUNTER_IGNORE;
import static com.verizon.dataindus.rtstreams.core.constants.el.Constants.METRICS_COUNTER_SUCCESS;
import static com.verizon.dataindus.rtstreams.core.constants.el.Constants.TOTAL_RECORDS_COUNTER;

import java.io.EOFException;
import java.io.IOException;
import java.net.http.HttpClient;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;

import redis.clients.jedis.Jedis;

public class SourceEL extends DoFn<String, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(SourceEL.class);

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
	};

	public static TupleTag<String> successRecords = new TupleTag<String>() {
	};

	/* Counters for observability */
	private final Counter successCounter = Metrics.counter(EL_NAMESPACE, METRICS_COUNTER_SUCCESS);
	private final Counter failedCounter = Metrics.counter(EL_NAMESPACE, METRICS_COUNTER_FAILURE);
	private final Counter ignoredCounter = Metrics.counter(EL_NAMESPACE, METRICS_COUNTER_IGNORE);
	private final Counter totalrecordsCounter = Metrics.counter(EL_NAMESPACE, TOTAL_RECORDS_COUNTER);

	static HttpClient client;

	// Type - Jedis, use - holds Redis connection
	private Jedis redisClientDoFnObject;

	// Type - String, use - holds keystore password for redis connection
	private String keystorePassword;

	// Type - byte array, use - holds jks bytes for redis connection
	private byte[] jksBytes;
	// Type - byte string, use - holds secret payload for redis connection
	private ByteString secretPayload;

	public SourceEL(String keystorePassword, byte[] jksBytes, ByteString secretPayload) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;

	}

	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword,false);

		client = HttpClient.newHttpClient();

	}

	@ProcessElement
	public void processElement(ProcessContext c) {
		/* Get each row in c.element of a CSV file */
		String strSourceData = c.element().toString();
		totalrecordsCounter.inc();

		try {

			if (!strSourceData.isEmpty() || strSourceData != null) {
				/* Split columns */
				String values[] = strSourceData.split(",", 2);

				// If CSV is empty
				if (values.length > 0) {

					String proposition_id = values[0].toString();

					/* Ignore Header row */
					if (values[1].toString().contains("proposition")) {

						ignoredCounter.inc();
					} else if ((!proposition_id.isEmpty()) || (!CommonUtility.isNullEmptyOrBlank(proposition_id))) {

						/* Check - proposition id should not be null */
						String strproposition_id = values[0].toString();

						/* create the Redis key using proposition id */
						String strRedisKey = strproposition_id;
						String strproposition_name = values[1].toString().replace("\"", "");

						/* Insert the key into Redis */
						redisClientDoFnObject.hset("proposition_name_mapping", strRedisKey, strproposition_name);

						successCounter.inc();
						String getRedisValue = redisClientDoFnObject.hget("proposition_name_mapping", strRedisKey);
						String output = strRedisKey + "\n" + getRedisValue;
						c.output(successRecords, output);

					} else {

						/* Ignored the row, If proposition id is null */
						ignoredCounter.inc();

					}
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block

			failedCounter.inc();
			c.output(deadLetter, c.element());
			LOG.error(e.getMessage());
		}
	}

	@Teardown
	public void teardown() {
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
		if (client != null) {
			client = null;
		}
	}
}
