package com.verizon.dataindus.rtstreams.core.constants;

public class Properties 
{
	public static final String CLASS_STREAMSJOBLAUNCHER= "JobLauncher";
	public static final String CLASS_STREAMSJOBRUNNER= "Runner";
	public static final String CLASS_ACCESSSECRETVERSION= "AccessSecretVersion";
	public static final String CLASS_COMMONUTILITY= "CommonUtility";
	public static final String CLASS_DATAFLOWOPTION= "DataFlowOption";
	public static final String CLASS_CONFIGPARSE= "ConfigParse";
	public static final String CLASS_SOURCETRANSFORMATION= "SourceTransformation";

}
