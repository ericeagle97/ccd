package com.verizon.dataindus.rtstreams.core.lib;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;

import org.apache.beam.sdk.values.PCollection;

public class FileReader {

    public PCollection<String> readSource(Pipeline pipeline,
                                                   String filePath
    )
    {
        // Read the data from the file line by line
        return pipeline.apply("Read data from files", TextIO.read().from(filePath));
    }
}
