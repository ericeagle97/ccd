package com.verizon.dataindus.rtstreams.core.utils;

import com.google.cloud.storage.*;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.core.constants.*;
import com.verizon.dataindus.rtstreams.core.constants.Properties;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class ReadConfigJsonUtil {

    public static List<Map<String, String>> getFileReadConfigurations(
            String project,
            String fileIOReadConfigBucket,
            String fileIOReadConfigFile,
            String fileIOReadSource,
            ExceptionsUtils objCustomExceptions) {

        String fileContent = "";
        try {
            Storage storage = StorageOptions.newBuilder()
                    .setProjectId(project)
                    .build()
                    .getService();

            Blob blob = storage.get(BlobId.of(fileIOReadConfigBucket, fileIOReadConfigFile));
            fileContent = new String(blob.getContent());
        } catch (StorageException storageException) {
            objCustomExceptions.storageException((Properties.CLASS_COMMONUTILITY),
                    storageException);
            return null;
        }

        try {
            JSONArray fileArray = new JSONObject(fileContent)
                    .getJSONObject(Constants.CONFIG_KEYWORD_SOURCES)
                    .getJSONArray(fileIOReadSource);

            List<Map<String, String>> fileList = new ArrayList<>();
            for (int jsonObj = 0; jsonObj < fileArray.length(); jsonObj++) {
                Map<String, String> fileDataConfigMap = new HashMap<>();
                JSONObject obj = fileArray.getJSONObject(jsonObj);
                JSONArray keys = obj.names();
                for (int index = 0; index < keys.length(); index++) {
                    String key = keys.getString(index);
                    String value = obj.getString(key);
                    fileDataConfigMap.put(key, value);
                }
                fileList.add(fileDataConfigMap);
            }

            return fileList;
        } catch (JSONException jsonException) {
            objCustomExceptions.jsonException((Properties.CLASS_COMMONUTILITY), jsonException);
            return null;
        }
    }

    public HttpResponse callRestApi(HttpRequest request) {
        /** httpResponse variable, used to store response from cassandra server */
        HttpResponse response = null;
        try {
            /** httpclient variable, cassandra connection */
            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(1)).build();

            /** httpRequest variable, holds http request sent to cassandra */
            response = client.sendAsync(request,HttpResponse.BodyHandlers.ofString()).get(900, TimeUnit.MILLISECONDS);

        } catch (InterruptedException e) {

            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);

            return null;
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return null;
        } finally {
            return response;
        }
    }

    public String frameWeatherCassandraRequest(JSONObject inputData, String zipCode, String daily) {
        JSONObject outputJson = new JSONObject();
        SimpleDateFormat datePattern = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss 'GMT'");
        datePattern.setTimeZone(TimeZone.getTimeZone("GMT"));
        JSONObject insightValues = new JSONObject();
        insightValues.put(WeatherConstants.PROVIDER_LAST_UPDATE_TIME, inputData.getString(WeatherConstants.PROVIDER_LAST_UPDATE_TIME));
        insightValues.put(WeatherConstants.CONDITION_CODE, inputData.getInt(WeatherConstants.CONDITION_CODE));
        insightValues.put(WeatherConstants.CONDITION_DESCRIPTION, inputData.getString(WeatherConstants.CONDITION_DESCRIPTION));

        if (daily.equalsIgnoreCase(WeatherConstants.DAILY_FORECASTS)){
            insightValues.put(WeatherConstants.FORECAST_TIME, inputData.getString(WeatherConstants.FORECAST_TIME));
            outputJson.put(WeatherConstants.AGGR_CATEGORY, WeatherConstants.WEATHERFORECAST);
        } else {
            insightValues.put(WeatherConstants.TEMPERATURE, inputData.getInt(WeatherConstants.TEMPERATURE));
            outputJson.put(WeatherConstants.AGGR_CATEGORY, WeatherConstants.WEATHER);
        }

        outputJson.put(WeatherConstants.AGGR_VALUES, insightValues.toString());

        outputJson.put(WeatherConstants.AGGR_NAME, WeatherConstants.RT);
        outputJson.put(WeatherConstants.REQUESTED_BY, WeatherConstants.STREAMS);
        outputJson.put(WeatherConstants.UPDATE_BY,WeatherConstants.STREAMS);
        outputJson.put(WeatherConstants.PROD_ID, zipCode);
        outputJson.put(WeatherConstants.UPDATE_TS, datePattern.format(new Date()));
        return outputJson.toString();

    }

    public static String getGMTDateTime(String pattern) {
        // Format the date and time as a string
        Instant instantTime = Instant.now();
        ZoneId zone = ZoneId.of("GMT");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        String dateTime = instantTime.atZone(zone).format(formatter);
        return dateTime;

    }

}
