package com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed;

import java.io.EOFException;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.Setup;
import org.apache.beam.sdk.values.TupleTag;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.beans.tar.ccrafilefeed.customerInsightsPojo;
import com.verizon.dataindus.rtstreams.core.common.CommonUtility;
import com.verizon.dataindus.rtstreams.core.constants.ccrafilefeed.Constants;
import com.verizon.dataindus.rtstreams.core.utils.RedisConnector;

import redis.clients.jedis.Jedis;

public class CassandraNormalizationStreamFn extends DoFn<customerInsightsPojo, String> {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(CassandraNormalizationStreamFn.class);

	private Jedis redisClientDoFnObject;
	private String projectId;

	private String keystorePassword;
	private byte[] jksBytes;
	private ByteString secretPayload;

	private boolean errorLog;
	boolean redisError = false;

	/**
	 * Sets the lookupData variable for with values from lookup file, and other
	 * variables required for redis connection
	 **/
	public CassandraNormalizationStreamFn(String keystorePassword, byte[] jksBytes, ByteString secretPayload) {
		this.keystorePassword = keystorePassword;
		this.jksBytes = jksBytes;
		this.secretPayload = secretPayload;

	}

//	@Setup
//	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, EOFException {
//		
//		
//		RedisConnector redis = new RedisConnector();
//		redisClientDoFnObject = redis.redisConnector(projectId);
//		
//	}
	@Setup
	public void setup() throws UnrecoverableKeyException, KeyManagementException, KeyStoreException,
			NoSuchAlgorithmException, CertificateException, IOException, EOFException {
		/** Intializing redis connection utility **/
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		/** setting up redis connection, using redis connection utility **/
		redisClientDoFnObject = redis.redisConnector(this.secretPayload.toStringUtf8(), jksBytes, keystorePassword,true);

	}

	public static final TupleTag<String> deadLetter = new TupleTag<String>() {
	};

	public static final TupleTag<String> Cassandradata = new TupleTag<String>() {
	};

	private final Counter cassandrainsertion_valid_record = Metrics.counter(Constants.CASSANDRANORMALIZATION,
			Constants.CASSANDRANORMALIZATION_COUNTER_SUCCESS);
	private final Counter cassandrainsertion_invalid_record = Metrics.counter(Constants.CASSANDRANORMALIZATION,
			Constants.CASSANDRANORMALIZATION_COUNTER_FAILURE);
	private final Counter redis_valid_record = Metrics.counter(Constants.CASSANDRANORMALIZATION,
			"redis successful record");
	private final Counter redis_invalid_record = Metrics.counter(Constants.CASSANDRANORMALIZATION,
			"redis unsuccessful record");

	@ProcessElement
	public void processElement(ProcessContext c) throws IOException, ParseException {

		customerInsightsPojo CustomerInsightsImport = c.element();

		Map<String, Object> customerInsightsSink = new HashMap<String, Object>();
		Map<String, Object> keyAttributes = new HashMap<String, Object>();
		boolean customerWrite = false;
		String accNumber = null;
		String cstId = null;
		String mtnNumber = CustomerInsightsImport.getMtn();
		try {
			if (CustomerInsightsImport.getAcct_no() != null) {
				accNumber = CustomerInsightsImport.getAcct_no();
			}

			if (CustomerInsightsImport.getCust_id_no() != null) {
				accNumber = CustomerInsightsImport.getCust_id_no();
			}

			if ((CommonUtility.isNullEmptyOrBlank(accNumber) || CommonUtility.isNullEmptyOrBlank(cstId))
					&& !CommonUtility.isNullEmptyOrBlank(mtnNumber)) {
				/*
				 * String commandStatus =
				 * redisClientDoFnObject.set("EDW_"+CustomerInsightsImport.getMtn().toString().
				 * trim(),"123456789-0002");
				 * 
				 * if (commandStatus.contains("OK")) {
				 * 
				 * System.out.println("Key inserted");
				 * 
				 * } else {
				 * 
				 * System.out.println("Key insertion is failed"); }
				 */

				String edwKey = Constants.EDW + CustomerInsightsImport.getMtn().toString().trim();
				String accountNoCustomerID = redisClientDoFnObject.get(edwKey);
				// String accountNoCustomerID = "123456789-00001";
				if (accountNoCustomerID != null && accountNoCustomerID.contains("-")) {
					String[] accountNoCsid = accountNoCustomerID.split("-");
					if (accountNoCsid[0].matches("[0-9]+") && accountNoCsid[1].matches("[0-9]+")) {

						keyAttributes.put("acctNo", CommonUtility.leftAppendString(accountNoCsid[1], "0", 5));
						keyAttributes.put("custId", accountNoCsid[0]);
					} else {
						redis_invalid_record.inc();
						c.output(deadLetter, c.element().toString());
						return;
					}
				}

				else {
					redis_invalid_record.inc();
					c.output(deadLetter, c.element().toString());
					return;
				}

			}
		}

		catch (Exception ex) {
			// cassandranormalization_total_error.inc();
			if (errorLog) {
				ex.printStackTrace(System.out);
			}
			c.output(deadLetter, new JSONObject(CustomerInsightsImport).toString());
			redisError = true;
		}

		keyAttributes.put("mtn", mtnNumber);
		keyAttributes.put("insightValues", CustomerInsightsImport.getInsight_values());
		keyAttributes.put("insightCategory", CustomerInsightsImport.getInsight_category());

		keyAttributes.put("updateBy", "streams");
		keyAttributes.put("insightName", CustomerInsightsImport.getInsight_name());
		keyAttributes.put("ttl", "604800");

		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date1 = new Date();
		String activitytime1 = formatter1.format(date1);
		String updateTs = activitytime1 + " GMT";

		keyAttributes.put("updateTs", updateTs);

		if (keyAttributes.get("acctNo") != null && keyAttributes.get("custId") != null
				&& keyAttributes.get("mtn") != null && keyAttributes.get("acctNo").toString().matches("[0-9]+")
				&& keyAttributes.get("custId").toString().matches("[0-9]+")
				&& keyAttributes.get("mtn").toString().matches("[0-9]+") && keyAttributes.get("insightCategory") != null
				&& keyAttributes.get("insightName") != null && keyAttributes.get("acctNo") != ""
				&& keyAttributes.get("custId") != "" && keyAttributes.get("mtn") != ""
				&& keyAttributes.get("insightCategory") != "" && keyAttributes.get("insightName") != "") {
			customerInsightsSink.put("keyAttributes", new JSONObject(keyAttributes).toString());
			cassandrainsertion_valid_record.inc();
			c.output(Cassandradata, new JSONObject(keyAttributes).toString());
		} else {
			c.output(deadLetter, new JSONObject(keyAttributes).toString());
			cassandrainsertion_invalid_record.inc();
		}

	}

	@Teardown
	public void teardown() {
		redisClientDoFnObject.close();
		com.verizon.dataindus.rtstreams.core.utils.RedisConnector redis = new com.verizon.dataindus.rtstreams.core.utils.RedisConnector();
		redis.tearDown();
	}

}