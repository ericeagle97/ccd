package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.ByteString;
import com.verizon.dataindus.rtstreams.core.common.PrintElementFromClassAsJsonFn;
import com.verizon.dataindus.rtstreams.core.common.PublishPubsubMessageFn;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.WeatherConstants;
import com.verizon.dataindus.rtstreams.core.utils.CassandraInsertRPCSingleRecord;
import com.verizon.dataindus.rtstreams.core.utils.IOUtility;
import com.verizon.dataindus.rtstreams.core.utils.WriteToGcs;
import com.verizon.dataindus.rtstreams.core.utils.impls.SecretInterfaceClass;
import com.verizon.dataindus.rtstreams.core.utils.interfaces.SecretInterface;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.SourceWeather.SourceWeather;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed.CassandraNormalizationStreamFn;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed.Counter;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed.SourceCCRAFeed;

public class SourceccrafilefeedTransform {

	public static void downstreamProcess(PCollection<String> validData, StreamsJobRunner.FileIOOptions options,
			List<Map<String, String>> inputFileList) {
		boolean errorLog = false;

		SecretInterface objSecret = new SecretInterfaceClass();

		/**
		 * Type - String, use - holds keystore password for redis connection
		 **/
		String keystorePassword = ((ByteString) objSecret.SecretGCP(options.getProjectId(),
				options.getKeystorePassword(), "latest")).toStringUtf8();

		/**
		 * Type - byte array, use - holds jks bytes for redis connection
		 **/
		byte[] jksBytes = ((ByteString) objSecret.SecretGCP(options.getProjectId(), options.getKeystoreFile(),
				"latest")).toByteArray();

		/**
		 * Type - byte string, use - holds secret payload for redis connection
		 **/
		ByteString secretPayload = (ByteString) objSecret.SecretGCP(options.getProjectId(),
				options.getSecretCredentials(), "latest");
		
		

		// create object mapper instance
		ObjectMapper om = new ObjectMapper();
		// configure ignore unknown properties
		om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		om.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
		om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		om.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);

		PCollectionTuple InsightsData = validData.apply("Preprocessing for activation insight and shipping insight ",
				ParDo.of(new SourceCCRAFeed()).withOutputTags(SourceCCRAFeed.deadLetter,
						TupleTagList.of(SourceCCRAFeed.ActivationInsight).and(SourceCCRAFeed.ShippigInsight)));

		PCollectionTuple ActivationInsight_CassandraNormalizationStream = InsightsData
				.get(SourceCCRAFeed.ActivationInsight)
				.apply(ParDo.of(new CassandraNormalizationStreamFn(keystorePassword, jksBytes, secretPayload))
						.withOutputTags(CassandraNormalizationStreamFn.deadLetter,
								TupleTagList.of(CassandraNormalizationStreamFn.Cassandradata)));

		PCollectionTuple ShippigInsight_CassandraNormalizationStream = InsightsData.get(SourceCCRAFeed.ShippigInsight)
				.apply(ParDo.of(new CassandraNormalizationStreamFn(keystorePassword, jksBytes, secretPayload))
						.withOutputTags(CassandraNormalizationStreamFn.deadLetter,
								TupleTagList.of(CassandraNormalizationStreamFn.Cassandradata)));

//		PCollection<String> CassandraNormalizationStream_ActivationInsight = ActivationInsight_CassandraNormalizationStream
//				.get(CassandraNormalizationStreamFn.Cassandradata)
//				.apply("ActivationInsight Cassandra Features Insert",
//						ParDo.of(new CassandraInsertRPCSingleRecord(options.getHttpRequest(),
//								"SOI_InsertCustomerInsights_ttl"))
//								.withOutputTags(CassandraInsertRPCSingleRecord.responseSuccess,
//										TupleTagList.of(CassandraInsertRPCSingleRecord.deadLetterQueue)))
//				.get(CassandraInsertRPCSingleRecord.deadLetterQueue);
//
//		PCollection<String> CassandraNormalizationStream_ShippigInsight = ShippigInsight_CassandraNormalizationStream
//				.get(CassandraNormalizationStreamFn.Cassandradata)
//				.apply("ShippigInsight Cassandra Features Insert",
//						ParDo.of(new CassandraInsertRPCSingleRecord(options.getHttpRequest(),
//								"SOI_InsertCustomerInsights_ttl"))
//								.withOutputTags(CassandraInsertRPCSingleRecord.responseSuccess,
//										TupleTagList.of(CassandraInsertRPCSingleRecord.deadLetterQueue)))
//				.get(CassandraInsertRPCSingleRecord.deadLetterQueue);

		
		ActivationInsight_CassandraNormalizationStream
		.get(CassandraNormalizationStreamFn.Cassandradata)
		.apply(String.format("To PubSubMessage - %s", Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL),
				ParDo.of(new PublishPubsubMessageFn(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE,
						Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL)))
		.apply(String.format("Message Write - %s", Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL),
				PubsubIO.writeMessages().to(options.getOutputPubsubTopic()));

		ShippigInsight_CassandraNormalizationStream
		.get(CassandraNormalizationStreamFn.Cassandradata)
		.apply(String.format("To PubSubMessage - %s", Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL),
				ParDo.of(new PublishPubsubMessageFn(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE,
						Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL)))
		.apply(String.format("Message Write - %s", Constants.PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL),
				PubsubIO.writeMessages().to(options.getOutputPubsubTopic()));


		PCollection<String> lookupDeadLetterSourceCCRAFeed = InsightsData.get(SourceCCRAFeed.deadLetter);
		PCollection<String> lookupDeadLetterActivationInsight_CassandraNormalizationStream = ActivationInsight_CassandraNormalizationStream
				.get(CassandraNormalizationStreamFn.deadLetter);
		PCollection<String> lookupDeadLetterShippigInsight_CassandraNormalizationStream = ShippigInsight_CassandraNormalizationStream
				.get(CassandraNormalizationStreamFn.deadLetter);

		PCollection<String> failureData = PCollectionList.of(lookupDeadLetterSourceCCRAFeed)
				.and(lookupDeadLetterActivationInsight_CassandraNormalizationStream)
				.and(lookupDeadLetterShippigInsight_CassandraNormalizationStream).apply(Flatten.pCollections())
				.apply("countDeadLetter", ParDo.of(new Counter()));

		IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(), failureData, options.getPubSubTopic(),
				options.getPath(), options.getFileName(), options.getNumShards());
		
		validData.apply("Publish RawData to Pub/Sub",
				PubsubIO.writeStrings().to(options.getPubSubTopic() + "-bqraw"));
		
		PCollection<String> ActivationInsightWithoutRedis =   InsightsData
				.get(SourceCCRAFeed.ActivationInsight).apply(
				ParDo.of(new PrintElementFromClassAsJsonFn()));
		
		PCollection<String> ShippigInsightWithoutRedis =   InsightsData
				.get(SourceCCRAFeed.ShippigInsight).apply(
				ParDo.of(new PrintElementFromClassAsJsonFn()));
		
		if (options.getPubsubParallelWrite()) {
			
			ActivationInsightWithoutRedis.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-actinsightwithoutredis-bqoutput"));
			ShippigInsightWithoutRedis.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-shipinsightwithoutredis-bqoutput"));
			ActivationInsight_CassandraNormalizationStream.get(CassandraNormalizationStreamFn.Cassandradata)
					.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-actinsight-bqoutput"));
			ShippigInsight_CassandraNormalizationStream.get(CassandraNormalizationStreamFn.Cassandradata)
					.apply(PubsubIO.writeStrings().to(options.getPubSubTopic() + "-shipinsight-bqoutput"));

		}

	}

}
