package com.verizon.dataindus.rtstreams.core.constants;


public class Constants {

	public static final String MEMSTORE_SECRET_ID_KEYSTORE_PASS ="memorystore-keystore-pass";
	public static final String MEMSTORE_SECRET_ID_JKS="memorystore-cert";
	public static final String MEMSTORE_SECRET_ID="memorystore-secrets";
	public static final String MEMSTORE_SECRET_ID_VERSION = "latest";
	
	public static final String MEMSTORE_HOST ="host";
	public static final String MEMSTORE_PORT="port";
	public static final String MEMSTORE_PASSWORD="password";
	public static final String MEMSTORE_JKS_FILEPATH = "/tmp/server-ca.jks";
	public static final String MEMSTORE_SSL_SOCKET_PROTOCOL= "TLSv1.3";
	public static final String MEMSTORE_KEYSTORE_INSTANCE_TYPE= "JKS";
	

	public static final String GCP_AUTH_CRED = "https://www.googleapis.com/auth/cloud-platform";
	
	
	public static final String REGEX_MTN = "^[0-9]+$";
	public static final String REGEX_PNO_SUCCESS = "(.*?)(200|Success)(.*?)";
	
	public static final String METRICS_COUNTER_VALID = "valid_count";
	public static final String METRICS_COUNTER_INVALID = "invalid_count";
	public static final String METRICS_COUNTER_SUCCESS = "successful_count";
	public static final String METRICS_COUNTER_FAILURE = "failure_count";
	public static final String METRICS_COUNTER_ERROR = "error_count";
	public static final String METRICS_COUNTER_FOUND = "found_count";
	public static final String METRICS_COUNTER_UNFOUND = "unfound_count";
	
	public static final String METRICS_JSON_PARSING = "JsonParsing";
	public static final String METRICS_PREPROCESSING = "Preprocessing";
	
	public static final String METRICS_CASSANDRA_INSERTION = "CassandraInsertion";
	public static final String METRICS_CASSANDRA_EVENTS = "EventsInsertionResponse";
	public static final String METRICS_CASSANDRA_API = "CassandraInsertionApi";

	public static final String REDIS_EDW_PREFIX = "EDW_";
	public static final String METRICS_MTN_EDWLOOKUP = "EDWResponse";
	
	public static final String HTTP_REQUEST_POST = "POST";
	
	public static final String HTTP_REQUEST_CONTENT_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String HTTP_REQUEST_CONTENT_JSON = "application/json";
	
	public static final String HTTP_REQUEST_CHARSET_UTF = "UTF-8";
	
	public static final String HTTP_REQUEST_PROP_CHARSET = "Charset";
	public static final String HTTP_REQUEST_PROP_CONTENT_TYPE = "Content-Type";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SERVICE = "ORIGINAL_SERVICE";
	public static final String HTTP_REQUEST_PROP_ORIGINAL_SUBSERVICE = "ORIGINAL_SUBSERVICE";
	public static final String HTTP_REQUEST_PROP_CORRELATION_ID = "CORRELATION_ID";
	public static final String HTTP_REQUEST_SERVICE_WW = "ww";
	
	public static final int HTTP_TIMEOUT = 600;
	
	public static final String CUST_ID = "custId";
    public static final String ACCT_NO = "acctNo";
    public static final String TTL = "ttl";
    public static final String SESSION_ID= "sessionId";
    public static final String MTN = "mtn";
    public static final String TUPLE_TIME_STAMP = "tupleTimestamp";
    public static final String LINKAGE_ID = "linkageId";
	
    public static final String PUBSUB = "PubSub";
	public static final String GCS = "GCS";
	public static final String CONFIG_KEYWORD_SOURCES = "sources";
	
	public static final String PUBSUB_KEYWORD_ATTRIBUTETYPE = "attributeType";
	public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS = "attr-cee-pubsub-cust-insights";// SOI_InsertCustomerInsights
	public static final String PUBSUB_ATTRIBUTE_CUST_INSIGHTS_TTL = "attr-cee-pubsub-cust-insights";// SOI_InsertCustomerInsights_ttl
	public static final String PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS = "attr-cee-pubsub-aggr-prod-insights";// SOI_InsertAggrProductInsights
	public static final String PUBSUB_ATTRIBUTE_CUST_MTN_INSIGHTS = "attr-cee-pubsub-cust-mtn-insights";// SOI_InsertCustomerMtnInsights_ttl
	public static final String PUBSUB_ATTRIBUTE_SESSION_INSIGHTS = "attr-cee-pubsub-session-insights";// SOI_InsertSessionInsights_ttl

	public static final String CONFIG_KEYWORD_REGIONS = "regions";

	public static final String CONFIG_KEYWORD_KAFKA_PROPERTIES = "kafka.properties";

	public static final String CONFIG_KEYWORD_BOOTSTRAP_SERVER = "bootstrap.servers";

	public static final String BQ_KAFKA_DATA_PUSH = "BQKafkaDatPush";

	public static final String REGION_EAST = "east";
	public static final String REGION_WEST = "west";

	public static final String CONFIG_KEYWORD_TOPICS = "topics";

}
