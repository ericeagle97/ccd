package com.verizon.dataindus.rtstreams.core.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import com.google.cloud.secretmanager.v1.SecretManagerServiceClient;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verizon.dataindus.rtstreams.core.constants.Constants;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.exceptions.JedisConnectionException;


class MemStoreJKS
{
	private static volatile MemStoreJKS singleton = null;
	public static SSLSocketFactory sslSocketFactory;
	public static byte [] jksBytes;
	public static String keystorePassword;
	private MemStoreJKS() throws IOException, KeyStoreException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException, KeyManagementException 
	{

		SecretManagerServiceClient secretManagerClient=SecretManagerServiceClient.create();
		//load the JKS certificate into a keystore
		KeyStore keystore = KeyStore.getInstance(Constants.MEMSTORE_KEYSTORE_INSTANCE_TYPE);
		keystore.load(new ByteArrayInputStream(jksBytes),keystorePassword.toCharArray());

		//Initialize keyManagerFactory with keystore
		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		keyManagerFactory.init(keystore, keystorePassword.toCharArray());

		//Initialize TrustManager with trusrstore (use the same keystore here if needed)
		TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		trustManagerFactory.init(keystore);

		//Create an SSL context
		SSLContext sslContext = SSLContext.getInstance(Constants.MEMSTORE_SSL_SOCKET_PROTOCOL);
		sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
		sslSocketFactory = sslContext.getSocketFactory();
		secretManagerClient.close();
	}

	public static  MemStoreJKS getInstance(byte [] jksBytes1, String keystorePassword1) throws IOException, UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException
	{
		jksBytes=jksBytes1;
		keystorePassword=keystorePassword1;
		if(singleton == null){
			synchronized (MemStoreJKS.class) {	
				if (singleton == null) {
					singleton = new MemStoreJKS(); 
				}
			}
		}
		return singleton;
	}
}


public class RedisConnector 
{
	private Jedis redisClientDoFnObject;
	private JedisPool jedisPool;
	public Jedis redisConnector(String secretPayload,byte[] jksBytes,String keystorePassword,boolean readFromReplica) throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		//Parse the secretPayload (assuming it's in JSON format)
		//Parse JSON and extract values
		JsonObject jsonObject = JsonParser.parseString(secretPayload).getAsJsonObject();
				
		String host = jsonObject.get(Constants.MEMSTORE_HOST).getAsString();
		int port = jsonObject.get(Constants.MEMSTORE_PORT).getAsInt();
		String password = jsonObject.get(Constants.MEMSTORE_PASSWORD).getAsString();
		if(readFromReplica) {
			//System.out.println("connecting client from replica");
			host =  jsonObject.get("ReplicaHost").getAsString();
		}
		Jedis redisClient=null;
		int retryCount=0;
		long initialDelay=10;//100ms
		long maxDelay=30000;//60 sec
		double backoffFactor=2.0;

		//File f = new File("/tmp/server-ca.jks"); //assuring the store file exists
		File f = new File(Constants.MEMSTORE_JKS_FILEPATH); //assuring the store file exists
		SSLSocketFactory sslSocketFactory = null;
		if (f.exists())
		{
			sslSocketFactory=MemStoreJKS.sslSocketFactory;
		}
		else
		{
			MemStoreJKS.getInstance(jksBytes,keystorePassword);
			sslSocketFactory=MemStoreJKS.sslSocketFactory;

		}				

		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		jedisPoolConfig.setMaxTotal(1);
		jedisPoolConfig.setMaxIdle(1);
		jedisPoolConfig.setMinIdle(10);
		jedisPoolConfig.setBlockWhenExhausted(true);
		jedisPoolConfig.setMaxWaitMillis(5000);

		JedisPool jedis = new JedisPool(jedisPoolConfig,host, port, 5000, password,0,true,sslSocketFactory,null,null);
		jedisPool = jedis;

		while(redisClient==null)
		{
			try {
				redisClient = jedisPool.getResource();
				redisClient.connect();
				redisClient.getClient().setTimeoutInfinite();
				//System.out.println("DoFn connection established");				
				redisClientDoFnObject = redisClient;
				return redisClientDoFnObject;
			}
			catch(JedisConnectionException e)
			{
				long retryDelay=(long)(initialDelay*Math.pow(backoffFactor, retryCount));
				if (retryDelay>maxDelay) {
					throw e;
				}
				try 
				{
					Thread.sleep(retryDelay);

				}
				catch(InterruptedException ex)
				{

				}
				retryCount++;
			}
		}
		return redisClientDoFnObject;

	}
	public void tearDown()
	{
		jedisPool.returnResource(redisClientDoFnObject);
		jedisPool.returnBrokenResource(redisClientDoFnObject);
		redisClientDoFnObject.close();
		jedisPool.close();
	}
}


