package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.lib.writers.KafkaWriter;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.bqtokafka.ProcessRows;
import org.apache.beam.sdk.transforms.GroupIntoBatches;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SerializableFunction;
import org.apache.beam.sdk.transforms.WithKeys;
import org.apache.beam.sdk.values.*;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.verizon.dataindus.rtstreams.core.common.CommonUtility.getKafkaIOReadConfigurations;
import static com.verizon.dataindus.rtstreams.pipeline.transforms.custom.bqtokafka.ProcessRows.validTag_east;
import static com.verizon.dataindus.rtstreams.pipeline.transforms.custom.bqtokafka.ProcessRows.validTag_west;

/*
 * This class is used to read the data from a GCS bucket, parse the json, extract the required data and push to Kafka topic
 */
public class SourceBQToKafkaTransform {
    public static void downstreamProcess(PCollection<String> validData, StreamsJobRunner.FileIOOptions options, List<Map<String, String>> inputFileList) {
        // create object mapper instance
        ObjectMapper om = new ObjectMapper();
        // configure ignore unknown properties
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        om.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        om.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);

        int keySize = options.getKeySize();//Size of the key to generate random key
        int batchSize = options.getBatchSize();//To group the data into batches
        /**
         * Fixed Window for Batching the Data
         */
        PCollection <KV<Integer,Iterable<String>>> groupedData = validData
                .apply("Assigning Random key", WithKeys.of(
                                (SerializableFunction<String,Integer>) ignored -> new Random()
                                        .nextInt(keySize))
                        .withKeyType(TypeDescriptors.integers()))
                .apply("Grouping into Batches",
                        GroupIntoBatches.ofSize(batchSize));

        /*
         * Process each row to generate the actual data to downstream and to partition the data to distribute the load equally to both  regions of Kafka
         */
        PCollectionTuple KafkaInsertBQData = groupedData.
                apply("ProcessRowsWithKafkaInsert", ParDo.of(new ProcessRows()).withOutputTags(validTag_east,
                        TupleTagList.of(validTag_west)));

        /*
         * Get the required details of Kafka configurations to push the data to Kafka using KafkaWirter
         */

        ExceptionsUtils objCustomExceptions = new ExceptionsUtils();

        Map<String, JSONObject> kafkaIOReadTopicWiseConfigMap = getKafkaIOReadConfigurations(
                options.getProjectId(),
                options.getKafkaIOReadConfigBucket(),
                options.getKafkaIOReadConfigFile(),
                options.getKafkaIOReadSource(),
                objCustomExceptions);

        PCollection<String> kafkaEastInsertBQData = KafkaInsertBQData.get(validTag_east);
        PCollection<String> kafkaWestInsertBQData = KafkaInsertBQData.get(validTag_west);


        for (String kafkaTopic : kafkaIOReadTopicWiseConfigMap.keySet()) {
            new KafkaWriter()
                    .writeData(kafkaEastInsertBQData, kafkaWestInsertBQData, kafkaTopic,
                            kafkaIOReadTopicWiseConfigMap);
        }

    }
}
