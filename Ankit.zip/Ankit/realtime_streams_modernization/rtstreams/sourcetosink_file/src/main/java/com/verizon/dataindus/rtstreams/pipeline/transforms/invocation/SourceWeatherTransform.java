package com.verizon.dataindus.rtstreams.pipeline.transforms.invocation;

import com.verizon.dataindus.rtstreams.core.common.PrintElementFromClassAsJsonFn;
import com.verizon.dataindus.rtstreams.core.common.PublishPubsubMessageFn;
import com.verizon.dataindus.rtstreams.core.constants.Constants;
import com.verizon.dataindus.rtstreams.core.constants.WeatherConstants;
import com.verizon.dataindus.rtstreams.core.utils.CassandraInsertRPCSingleRecord;
import com.verizon.dataindus.rtstreams.core.utils.IOUtility;
import com.verizon.dataindus.rtstreams.core.utils.WriteToGcs;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.SourceWeather.SourceWeather;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.ccrafeed.CassandraNormalizationStreamFn;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;

import java.util.List;
import java.util.Map;

public class SourceWeatherTransform {

    public static void downstreamProcess(PCollection<String> validData, StreamsJobRunner.FileIOOptions options, List<Map<String, String>> inputFileList)
    {
        /**
         * Source-weather data read and transformation
         */
        PCollectionTuple validInvalidData = validData.apply("Read data from Yahoo API", ParDo.of(new SourceWeather(
                inputFileList.get(0).get(WeatherConstants.YAHOO_SERVER_ENDPOINT),inputFileList.get(0).get(WeatherConstants.TOKEN)))
                .withOutputTags(SourceWeather.dailyForecastData, TupleTagList.of(SourceWeather.currentObervationData).and(SourceWeather.deadLetter).and(SourceWeather.rawTag)));

        /**
         * Collect current observation data and write to cassandra
         */
//        PCollection<String> currentObservationFailures = validInvalidData.get(SourceWeather.currentObervationData).apply("Insert data to cassandra",
//                ParDo.of(new CassandraInsertRPCSingleRecord(inputFileList.get(0).get(WeatherConstants.CASSANDRA_ENDPOINT),
//                        WeatherConstants.CASSANDRA_REQUEST_TYPE)).withOutputTags(CassandraInsertRPCSingleRecord.responseSuccess,
//                        TupleTagList.of(CassandraInsertRPCSingleRecord.deadLetterQueue)))
//                .get(CassandraInsertRPCSingleRecord.deadLetterQueue);

		
		IOUtility.deadLetterOptionalSink(Constants.PUBSUB,
				validInvalidData.get(SourceWeather.rawTag),
				options.getPubSubTopic() + "-bqraw",
				"",
				"",
				0);
		
        validInvalidData.get(SourceWeather.currentObervationData)
		.apply(String.format("To PubSubMessage - %s", Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS),
				ParDo.of(new PublishPubsubMessageFn(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE,
						Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS)))
		.apply(String.format("Message Write - %s", Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS),
				PubsubIO.writeMessages().to(options.getOutputPubsubTopic()));
        
		PCollection<String> currentObervationDataBq = validInvalidData.get(SourceWeather.currentObervationData).apply(
				ParDo.of(new PrintElementFromClassAsJsonFn()));
		IOUtility.deadLetterOptionalSink(Constants.PUBSUB,
				currentObervationDataBq,
				options.getPubSubTopic() + "-currentObervation-bqoutput",
				"",
				"",
				0);

        /**
         * Collect daily forecast data and write to cassandra
         */
//        PCollection<String> dailyForecastFailures = validInvalidData.get(SourceWeather.dailyForecastData).apply("Insert data to cassandra",
//                ParDo.of(new CassandraInsertRPCSingleRecord(inputFileList.get(0).get(WeatherConstants.CASSANDRA_ENDPOINT),WeatherConstants.CASSANDRA_REQUEST_TYPE))
//                        .withOutputTags(CassandraInsertRPCSingleRecord.responseSuccess, TupleTagList.of(CassandraInsertRPCSingleRecord.deadLetterQueue)))
//                .get(CassandraInsertRPCSingleRecord.deadLetterQueue);

		 validInvalidData.get(SourceWeather.dailyForecastData).apply(String.format("To PubSubMessage - %s", Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS),
					ParDo.of(new PublishPubsubMessageFn(Constants.PUBSUB_KEYWORD_ATTRIBUTETYPE,
							Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS)))
			.apply(String.format("Message Write - %s", Constants.PUBSUB_ATTRIBUTE_AGGR_PROD_INSIGHTS),
					PubsubIO.writeMessages().to(options.getOutputPubsubTopic()));
		 
			PCollection<String> dailyForecastDataBq = validInvalidData.get(SourceWeather.dailyForecastData).apply(
					ParDo.of(new PrintElementFromClassAsJsonFn()));
			IOUtility.deadLetterOptionalSink(Constants.PUBSUB,
					dailyForecastDataBq,
					options.getPubSubTopic() + "-dailyForecast-bqoutput",
					"",
					"",
					0);
        

        PCollection<String> deadLetter = validInvalidData.get(SourceWeather.deadLetter);

        /**
         * Collect all the invalid data
         */
		IOUtility.deadLetterOptionalSink(options.getDeadLetterSink(), deadLetter,
				options.getPubSubTopic() +"-error",
				options.getPath()+"/deadletter/",options.getFileName(), options.getNumShards());

    }
}
