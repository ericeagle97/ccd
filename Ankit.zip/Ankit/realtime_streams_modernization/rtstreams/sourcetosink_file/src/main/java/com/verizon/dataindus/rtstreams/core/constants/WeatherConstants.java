package com.verizon.dataindus.rtstreams.core.constants;

public class WeatherConstants {

    public static final String CURRENT_OBSERVATIONS = "current_observations";
    public static final String DAILY_FORECASTS = "daily_forecasts";
    public static final String FORECAST_TIME = "forecast_time";
    public static final String PROVIDER_LAST_UPDATE_TIME = "provider_last_update_time";
    public static final String RESULT = "result";
    public static final String DATE_PATTERN = "EEE, dd MMM yyy hh:mm:ss 'GMT'";

    public static final String CONDITION_CODE = "condition_code";
    public static final String CONDITION_DESCRIPTION = "condition_description";
    public static final String TEMPERATURE = "temperature";
    public static final String INSIGHT_VALUES = "insight_values";
    public static final String ZIP_CODE = "zipCode";
    public static final String HOURLY_FORECASTS = "hourly_forecasts";
    public static final String X_APIKEY = "X-Apikey";
    public static final String CASSANDRA_ENDPOINT = "cassandraEndPoint";
    public static final String REQUESTED_BY = "requestedBy";
    public static final String UPDATE_BY     = "updateBy";
    public static final String AGGR_CATEGORY = "aggrCategory";
    public static final String PROD_ID = "aggrProdId";
    public static final String AGGR_NAME = "aggrName";
    public static final String STREAMS = "streams";
    public static final String WEATHER = "WEATHER";
    public static final String WEATHERFORECAST = "WEATHERFORECAST";
    public static final String RT = "RT";
    public static final String UPDATE_TS = "updateTs";
    public static final String AGGR_VALUES = "aggrValues";
    public static final String CASSANDRA_REQUEST_TYPE = "SOI_InsertAggrProductInsights";
    public static final String YAHOO_SERVER_ENDPOINT = "yahooServerEndpoint";

    public static final String TOKEN = "token";







}
