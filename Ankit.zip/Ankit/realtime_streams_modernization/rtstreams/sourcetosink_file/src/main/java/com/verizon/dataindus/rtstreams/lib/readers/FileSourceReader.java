package com.verizon.dataindus.rtstreams.lib.readers;

import java.util.Collections;
import java.util.Map;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.Compression;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.vendor.grpc.v1p36p0.com.google.common.collect.ImmutableMap;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.checkerframework.checker.initialization.qual.Initialized;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.checker.nullness.qual.UnknownKeyFor;

import com.verizon.dataindus.rtstreams.core.common.ExceptionsUtils;
import com.verizon.dataindus.rtstreams.jobDriver.StreamsJobRunner.FileIOOptions;


/*
 * Connection to Kafka Server using parameters assigined in pipeline and returning PCollection
 */
public class FileSourceReader
{
	public PCollection<String> readSource(Pipeline pipeline, String sourceType, String inputPath, String channel, FileIOOptions options)
	{
		/* Creating object for custom exception class*/
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();
		try {
			if (inputPath.contains("gz")) {
				PCollection<String> data=pipeline.apply("Reading "+channel, 
						TextIO.read().from(inputPath).withCompression(Compression.GZIP)); //"gs://vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow/DataflowSources/batched_pipeline/input_folder/input.txt"
				return data;
			}
			else {
				 
				PCollection<String> data=pipeline.apply("Reading "+channel, 
						TextIO.read().from(inputPath));
				return data;
			}
		}
		catch(Exception e)
		{
			objCustomExceptions.errorPipeline("FileSourceReader",e);
			return null;
		}
	}
	
	
	public PCollection<String> readCsvSource(Pipeline pipeline, String sourceType, String inputPath, String channel, FileIOOptions options)
	{
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();
		PCollection<String> data = null;
		for(String fileinputPath:inputPath.split(",")){
			try {
				if (fileinputPath.contains("csv") || fileinputPath.contains("CSV")) {
					data=pipeline.apply("Reading "+channel, 
							TextIO.read().from(fileinputPath)); //"gs://vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow/DataflowSources/batched_pipeline/input_folder/input.txt"	
				}
			}
			catch(Exception e)
			{
				objCustomExceptions.errorPipeline("FileSourceReader",e);
				return null;
			}
			
		}
		return data;

	}
	
	public PCollection<String> readDatSource(Pipeline pipeline, String sourceType, String inputPath, String channel, FileIOOptions options)
	{
		
		ExceptionsUtils objCustomExceptions=new ExceptionsUtils();
		PCollection<String> data = null;
		for(String fileinputPath:inputPath.split(",")){
			try {
				if (fileinputPath.contains("dat") || fileinputPath.contains("DAT")) {
					data=pipeline.apply("Reading "+channel, 
							TextIO.read().from(fileinputPath)); //"gs://vz-it-np-gh2v-dev-rtstdo-0-devlopment_dataflow/DataflowSources/batched_pipeline/input_folder/input.txt"		
				}
			}
			catch(Exception e)
			{
				objCustomExceptions.errorPipeline("FileSourceReader",e);
				return null;
			}
			
		}
		return data;
	
	}
}