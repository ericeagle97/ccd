package com.verizon.dataindus.restreams.pipeline.sourceweather.util;

public class SourceWeatherTestConstants {

    public static final String API_YAHOO = "https://api-qa.ebiz.verizon.com/ann/yahoo/weather?query=";
    public static final String TOKEN = "WNAdR4Js3TkXQTUoQlBLtPHhrAzUkXFU" ;
    public static final String ZIP_CODE = "00601";
}
