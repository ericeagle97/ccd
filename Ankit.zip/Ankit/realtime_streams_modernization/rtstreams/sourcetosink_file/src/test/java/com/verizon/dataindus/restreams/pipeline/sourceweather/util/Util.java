package com.verizon.dataindus.restreams.pipeline.sourceweather.util;

import org.apache.beam.sdk.transforms.DoFn;
import org.json.JSONObject;

import java.io.Serializable;
import java.text.ParseException;

public class Util extends DoFn<String, String> implements Serializable {

    @ProcessElement
    public void processElement(ProcessContext c) throws ParseException {
        JSONObject json = new JSONObject(c.element());
        c.output(json.getString("aggrCategory"));
    }
}
