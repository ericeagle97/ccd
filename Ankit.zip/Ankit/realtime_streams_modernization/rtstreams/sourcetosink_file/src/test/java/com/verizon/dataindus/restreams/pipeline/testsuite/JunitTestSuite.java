package com.verizon.dataindus.restreams.pipeline.testsuite;

import com.verizon.dataindus.restreams.pipeline.sourceweather.SourceWeatherTest;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Categories.class)

@Suite.SuiteClasses({
        SourceWeatherTest.class,
})
@Categories.IncludeCategory(TestCategories.Sourceweather.class)
public class JunitTestSuite {
}