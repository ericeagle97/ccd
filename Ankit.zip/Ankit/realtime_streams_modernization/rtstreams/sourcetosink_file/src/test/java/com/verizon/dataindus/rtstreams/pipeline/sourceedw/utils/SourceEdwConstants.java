package com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils;


public class SourceEdwConstants {

	public static final String SOURCE_EDW_EXPECTED_OUTPUT =
			"C:\\Users\\shavi2f\\FeatureVinish\\dataengineering\\rtstreams\\filesources\\src\\test\\resources\\Sourc_EDW\\expected_output\\edwoutput.txt";

	public static final String SOURCE_EDW_INPUT = 
			"C:\\Users\\shavi2f\\FeatureVinish\\dataengineering\\rtstreams\\filesources\\src\\test\\resources\\Sourc_EDW\\expected_input\\edwinput.txt";

	public static final String PROJECT_ID = "vz-it-np-gh2v-dev-rtstdo-0";

}
