package com.verizon.dataindus.rtstreams.pipeline.sourceedw;

import java.util.Objects;

import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.junit.Test;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils.Common;
import com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils.RemoveTimeDetails;
import com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils.SourceEdwConstants;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.sourceedw.SourceEDW;

public class SourceedwTransform {
	public final transient TestPipeline testPipeline = TestPipeline.create().enableAbandonedNodeEnforcement(false);
	ValueProvider.StaticValueProvider<Boolean> errorLog = ValueProvider.StaticValueProvider.of(true);

	@Test
	public void sourceFraudRemarkSuccessRun() {
//
//		// Read the lookup data
//		PCollection<String> fileLookUpData = testPipeline
//				.apply(Create.of(Common.readFileContentAsString(SourceEdwConstants.SOURCE_EDW_INPUT)));
//
//		// Create the input data
//		// Run the
//		PCollectionTuple output = fileLookUpData.apply("EDW Transform",
//				ParDo.of(new SourceEDW())
//						.withOutputTags(SourceEDW.validTag, TupleTagList.of(SourceEDW.deadLetter)));
//
//		// Get data for each generated output
//		PCollection<String> generatedData = output.get(SourceEDW.validTag).apply(ParDo.of(new RemoveTimeDetails()));
//				
//
//		JsonObject expectedOutputJsonObject = JsonParser
//				.parseString(Objects.requireNonNull(
//						Common.readFileContentAsString(SourceEdwConstants.SOURCE_EDW_EXPECTED_OUTPUT)))
//				.getAsJsonObject();
//System.out.println(expectedOutputJsonObject);
//		PAssert.that(generatedData).containsInAnyOrder(expectedOutputJsonObject.toString());
//		// Run the test pipeline
//		testPipeline.run();
	}
}
