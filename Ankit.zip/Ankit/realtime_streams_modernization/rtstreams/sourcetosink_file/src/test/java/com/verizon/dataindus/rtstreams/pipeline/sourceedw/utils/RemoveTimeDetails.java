package com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils;

import org.apache.beam.sdk.transforms.DoFn;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/*
 * Remove time Deatils
*/
public class RemoveTimeDetails extends DoFn<String, String> {

	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext c)
			throws CloneNotSupportedException, JsonMappingException, JsonProcessingException {

		String inputData = c.element();
		ObjectMapper om = new ObjectMapper();
		JsonNode jsonNode = om.readTree(inputData);
		if (jsonNode instanceof ObjectNode) {
			ObjectNode objectNode = (ObjectNode) jsonNode;
			objectNode.remove("updateTs");
		}
		String updated = om.writeValueAsString(jsonNode);
		c.output(updated);
	}
}
