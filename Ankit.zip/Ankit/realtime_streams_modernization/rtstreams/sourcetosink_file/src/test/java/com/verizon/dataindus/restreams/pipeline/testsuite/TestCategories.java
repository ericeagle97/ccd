package com.verizon.dataindus.restreams.pipeline.testsuite;

public class TestCategories {
    public interface PipelineRun {}
    public interface Sourceweather {}
}
