package com.verizon.dataindus.rtstreams.pipeline.sourceedw.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

public class Common {

	public static HashMap<String, String> convertStringToHashMapOfStrings(String input) {
		HashMap<String, String> outputHashMap = new HashMap<>();
		String[] keyValuePairs = input.split(",");
		for (String pair : keyValuePairs) {
			String[] keyValue = pair.split("=");
			if (keyValue.length == 2) {
				String key = keyValue[0];
				String value = keyValue[1];
				outputHashMap.put(key, value);
			}
		}
		return outputHashMap;
	}

	public static String readFileContentAsString(String filePath) {
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			String fileContent = sb.toString();
			return fileContent;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static HashMap<String, Object> convertStringToHashMapOfStringAndObject(String input) {
		Gson gson = new Gson();
		Type type = new TypeToken<HashMap<String, Object>>() {

			private static final long serialVersionUID = 1L;
		}.getType();
		HashMap<String, Object> output = new HashMap<>();

		return gson.fromJson(input, type);
	}
}
