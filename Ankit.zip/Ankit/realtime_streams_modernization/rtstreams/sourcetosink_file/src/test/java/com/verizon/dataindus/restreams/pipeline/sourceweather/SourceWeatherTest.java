package com.verizon.dataindus.restreams.pipeline.sourceweather;

import com.verizon.dataindus.restreams.pipeline.sourceweather.util.SourceWeatherTestConstants;
import com.verizon.dataindus.restreams.pipeline.sourceweather.util.Util;
import com.verizon.dataindus.restreams.pipeline.testsuite.TestCategories;
import com.verizon.dataindus.rtstreams.pipeline.transforms.custom.SourceWeather.SourceWeather;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.*;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTagList;
import org.junit.Test;
import org.junit.experimental.categories.Category;

@Category(TestCategories.Sourceweather.class)
public class SourceWeatherTest {

    @Test
    public void test() {
        TestPipeline testPipeline = TestPipeline.create().enableAbandonedNodeEnforcement(false);

        PCollection<String> validData = testPipeline.apply(Create.of(SourceWeatherTestConstants.ZIP_CODE));
        PCollectionTuple validInvalidData = validData.apply("Read data from Yahoo API", ParDo.of(new SourceWeather(
                        SourceWeatherTestConstants.API_YAHOO,SourceWeatherTestConstants.TOKEN))
                .withOutputTags(SourceWeather.dailyForecastData, TupleTagList.of(SourceWeather.currentObervationData).and(SourceWeather.deadLetter)));
        PCollection<String> currentObservation = validInvalidData.get(SourceWeather.currentObervationData);
        PCollection<String> dailyObservation = validInvalidData.get(SourceWeather.dailyForecastData);

        PAssert.that(currentObservation.apply("test current observation", ParDo.of(new Util())))
                .containsInAnyOrder("WEATHER");
        PAssert.that(dailyObservation.apply(ParDo.of(new Util())))
                .containsInAnyOrder("WEATHERFORECAST");
        testPipeline.run();
    }
}
