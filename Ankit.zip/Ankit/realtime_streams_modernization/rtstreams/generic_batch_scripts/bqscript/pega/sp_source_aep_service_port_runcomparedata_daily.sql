CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_source_aep_service_port_runcomparedata_daily`(PROCESS_DT_V STRING)
Begin
DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V TIMESTAMP;
DECLARE PROCESS_END_TS_V TIMESTAMP;
DECLARE CUR_EST_TS TIMESTAMP;
DECLARE STR_V STRING;
SET PROCESS_START_TS_V = CAST(CONCAT(PROCESS_DT_V,' 00:00:00') AS TIMESTAMP);
SET PROCESS_END_TS_V = CAST(CONCAT(PROCESS_DT_V,' 23:59:59') AS TIMESTAMP);
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'source_aep_service_port';
SET STR_V = concat('%""""updateTs"""":""""', PROCESS_DT_V ,'%');

--df data
truncate table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_raw_stg`;

insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_raw_stg`
select  data,created_ts FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_raw`  B where date(B.CREATED_TS) = CURR_DATE_V;

delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` where date(created_ts) = date(PROCESS_DT_V);
--multiple record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event`
with t1 as (
  select data,created_ts from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_raw_stg`)
select
JSON_VALUE(data, '$.ttl') as  ttl,
JSON_VALUE(data, '$.mtn') as  mtn,
JSON_VALUE(data, '$.updateBy') as  updateBy,
JSON_VALUE(data, '$.insightName') as  insightName,
JSON_VALUE(data, '$.insightCategory') as  insightCategory,
JSON_VALUE(data, '$.currentvalues') as  currentvalues,
SAFE_CAST(JSON_VALUE(data, '$.updateTs') AS timestamp) updateTs,
JSON_VALUE(data, '$.createdBy') as  createdBy,
JSON_VALUE(JSON_EXTRACT_SCALAR(data, '$.insightValues'), '$.status') as  status,
JSON_VALUE(JSON_EXTRACT_SCALAR(data, '$.insightValues'), '$.name') as  name,
JSON_VALUE(JSON_EXTRACT_SCALAR(data, '$.insightValues'), '$.lastQualificationTime') as  lastQualificationTime,
CURR_HR_V,
CURR_DATE_V,
created_ts,
from t1;
/*
Load IBM Pipeline data - start
*/
--INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pega_fraudremarks_ibm_raw_stg`
--SELECT srcdata FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pega_fraudremarks_ibm_raw` B where date(JSON_VALUE(B.srcdata, '$.updateTs')) = CURR_DATE_V;
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` where  date(created_ts) = date(PROCESS_DT_V);
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event`


with t5 as(
with t4 as(
with t3 as(
with t2 as (with t1 as(
select split(split(REPLACE(srcdata,'\\',''),'}}{')[safe_offset(1)],'{"requestType":')[safe_offset(1)] as  reqtype,created_ts
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_raw`  where date(created_ts)=date(PROCESS_DT_V)
)
select concat('{"requestType":', reqtype) as rdata1,created_ts from t1
)
select case when REGEXP_CONTAINS(rdata1,',"{"results":{}') then rtrim(split(rdata1,',"{"results":{}')[0],'","') else rtrim(rdata1,'","') end as rdata2,created_ts from t2
)
select replace(replace(rdata2,'"insightValues":"{','"insightValues":{'),'}","insightName"','},"insightName"') as rdata2,created_ts from t3)
select rdata2,JSON_EXTRACT(rdata2, '$.keyAttributes') as eventdata,created_ts from t4)
select


JSON_VALUE(eventdata, '$.ttl') as  ttl,
JSON_VALUE(eventdata, '$.mtn') as  mtn,
JSON_VALUE(eventdata, '$.updateBy') as  updateBy,
JSON_VALUE(eventdata, '$.insightName') as  insightName,
JSON_VALUE(eventdata, '$.insightCategory') as  insightCategory,
JSON_VALUE(rdata2, '$.currentvalues') as  currentvalues,
SAFE_CAST(JSON_VALUE(eventdata, '$.updateTs')  AS timestamp) as  updateTs,
JSON_VALUE(eventdata, '$.createdBy') as  createdBy,
JSON_VALUE(eventdata, '$.insightValues.status') as  status,
JSON_VALUE(eventdata, '$.insightValues.name') as  name,
JSON_VALUE(eventdata, '$.insightValues.lastQualificationTime') as  lastQualificationTime,
CURR_HR_V,
CURR_DATE_V,
created_ts,
from t5;

/*
Compare table data process
*/
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_event_cmp` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_event_cmp`
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
CURR_HR_V as PROCESS_HR,
CURR_DATE_V as PROCESS_DT
from
(select
t1.ttl as ibm_ttl,
t1.mtn as ibm_mtn,
t1.updateBy as ibm_updateBy,
t1.insightName as ibm_insightName,
t1.insightCategory as ibm_insightCategory,
t1.currentvalues as ibm_currentvalues,
t1.updateTs as ibm_updateTs,
t1.createdBy as ibm_createdBy,
t1.status as ibm_status,
t1.name as ibm_name,
t1.lastQualificationTime as ibm_lastQualificationTime,
t2.ttl as df_ttl,
t2.mtn as df_mtn,
t2.updateBy as df_updateBy,
t2.insightName as df_insightName,
t2.insightCategory as df_insightCategory,
t2.currentvalues as df_currentvalues,
t2.updateTs as df_updateTs,
t2.createdBy as df_createdBy,
t2.status as df_status,
t2.name as df_name,
t2.lastQualificationTime as df_lastQualificationTime,

case
  when trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
  then 1 else 0 end key_match,
case
  when
trim(t1.updateBy) = trim(t2.updateBy)
and trim(t1.insightName) =trim(t2.insightName)
and trim(t1.insightCategory) = trim(t2.insightCategory) 
and trim(t1.currentvalues) = trim(t2.currentvalues)
and trim(t1.createdBy) =trim(t2.createdBy)
and trim(t1.status) =trim(t2.status)
and trim(t1.name)=trim(t2.name)
and trim(t1.lastQualificationTime) =trim(t2.lastQualificationTime)

  then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t1
full outer join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t2
on  trim(t1.mtn) = trim(t2.mtn)
) A;
/*
Compare table count process
*/
-- matched key count
SET MATCH_CNT_V = (select COUNT(*) from (select distinct mtn from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct mtn from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
);
-- unmatched records count
SET UNMATCH_CNT_V =(select count(*) from (select  case
  when 
  trim(t1.updateBy) = trim(t2.updateBy)
and trim(t1.insightName) =trim(t2.insightName)
and trim(t1.insightCategory) = trim(t2.insightCategory) 
and trim(t1.currentvalues) = trim(t2.currentvalues)
and trim(t1.createdBy) =trim(t2.createdBy)
and trim(t1.status) =trim(t2.status)
and trim(t1.name)=trim(t2.name)
and trim(t1.mtn)=trim(t2.mtn)
and trim(t1.lastQualificationTime) =trim(t2.lastQualificationTime)
  then 1 else 0 end as field_match,* from (select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
   ) where field_match=0);

-- unmatched keys count in ibm table
SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct mtn from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
   select * from ( select distinct mtn
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` t2
    where
   t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)t2 where trim(t1.mtn) = trim(t2.mtn)
)));


-- unmatched keys count in df table
SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct mtn from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
   select * from ( select distinct mtn
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` t2
    where
   t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)t2 where trim(t1.mtn) = trim(t2.mtn)
)));
SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct mtn
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));
SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct mtn
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_aepsrcport_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));

--Delete and load into the event metrics table for the specific day
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = STRING(PROCESS_START_TS_V) AND PROCESS_END_TS = STRING(PROCESS_END_TS_V) AND jobname = JOBNAME_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',STRING(PROCESS_START_TS_V),STRING(PROCESS_END_TS_V),current_timestamp);
End;