CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_source_ivrcall_mtninsight_runcomparedata_daily`(PROCESS_DT_V STRING)
Begin
DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V TIMESTAMP;
DECLARE PROCESS_END_TS_V TIMESTAMP;
DECLARE CUR_EST_TS TIMESTAMP;
DECLARE STR_V STRING;
SET PROCESS_START_TS_V = CAST(CONCAT(PROCESS_DT_V,' 00:00:00') AS TIMESTAMP);
SET PROCESS_END_TS_V = CAST(CONCAT(PROCESS_DT_V,' 23:59:59') AS TIMESTAMP);
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'source_ivrcall_mtninsight';
SET STR_V = concat('%""""updateTs"""":""""', PROCESS_DT_V ,'%');

-- REMOVE DATA FROM DF STG TABLE
truncate  table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_raw_stg`;

-- INSERT DATA to DF STG TABLE FROM RAW TABLE
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_raw_stg`
select  data,created_ts FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_raw` B where date(B.CREATED_TS) = CURR_DATE_V  ;

-- DELETE CURRENT DATE DATA FROM EVENT TABLE
delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` where date(created_ts) = date(PROCESS_DT_V);


--multiple record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event`

with t2 as(
with t1 as (
  select data,create_ts,
   JSON_EXTRACT(REPLACE(REPLACE(REPLACE(data,'"{','{'),'}"','}'),'\\',''),'$.insightValues.context')
    as rdata2 from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_raw
   
)
select rdata2,created_ts, data from t1 
)
select

JSON_VALUE(data, '$.mtn') as  mtn,
JSON_VALUE(data, '$.insightName') as  insightName,
JSON_VALUE(data, '$.updateBy') as  updateBy,
JSON_VALUE(data, '$.insightCategory') as  insightCategory,
SAFE_CAST(JSON_VALUE(data, '$.updateTs') AS timestamp) updateTs,

JSON_VALUE(rdata2, '$.contextInfo.athenaSessionID') as  athenaSessionID,
JSON_VALUE(rdata2, '$.contextInfo.processStep') as  processStep,
JSON_VALUE(rdata2, '$.contextInfo.callReason') as  callReason,
JSON_VALUE(rdata2, '$.responseList.response.dispositionOptionID') as  dispositionOptionID,
JSON_VALUE(rdata2, '$.responseList.response.dispositionDesc') as  dispositionDesc,
JSON_VALUE(rdata2, '$.responseList.response.rank') as  rank,
JSON_VALUE(rdata2, '$.responseList.response.propositionID') as  propositionID,
JSON_VALUE(rdata2, '$.responseList.response.externalID') as  externalID,

JSON_VALUE(rdata2, '$.dnsInfo.dnsNumber') as  dnsNumber,

CURR_HR_V,
CURR_DATE_V,
created_ts,
from t2 ;



/*
Load IBM Pipeline data - start
*/


--INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_ibm_raw_stg`
--SELECT srcdata FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_ibm_raw` B where date(JSON_VALUE(B.srcdata, '$.updateTs')) = CURR_DATE_V;


DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` where  date(created_ts) = CURR_DATE_V;

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event`

with t2 as(
with t1 as (
  select data,create_ts,
   JSON_EXTRACT(REPLACE(REPLACE(REPLACE(data,'"{','{'),'}"','}'),'\\',''),'$.insight_values')
    as rdata2 from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_raw
    
)

select rdata2,JSON_EXTRACT(rdata2, '$.context') as eventdata, created_ts from t1
)
select

JSON_VALUE(data, '$.mtn') as  mtn,
JSON_VALUE(data, '$.insightName') as  insightName,
JSON_VALUE(data, '$.updateBy') as  updateBy,
JSON_VALUE(data, '$.insightCategory') as  insightCategory,
SAFE_CAST(JSON_VALUE(data, '$.updateTs') AS timestamp) updateTs,

JSON_VALUE(eventdata, '$.contextInfo.athenaSessionID') as  athenaSessionID,
JSON_VALUE(eventdata, '$.contextInfo.processStep') as  processStep,
JSON_VALUE(eventdata, '$.contextInfo.callReason') as  callReason,
JSON_VALUE(eventdata, '$.responseList.response.dispositionOptionID') as  dispositionOptionID,
JSON_VALUE(eventdata, '$.responseList.response.dispositionDesc') as  dispositionDesc,
JSON_VALUE(eventdata, '$.responseList.response.rank') as  rank1,
JSON_VALUE(eventdata, '$.responseList.response.propositionID') as  propositionID,
JSON_VALUE(eventdata, '$.responseList.response.externalID') as  externalID,

JSON_VALUE(eventdata, '$.dnsInfo.dnsNumber') as  dnsNumber,

CURR_HR_V,
CURR_DATE_V,
created_ts,
from t2 ;



/*
Compare table data process
*/
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_cmp` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/


INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_cmp`
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
CURR_HR_V as PROCESS_HR,
CURR_DATE_V as PROCESS_DT
from
(select
t1.mtn as ibm_mtn,
t1.insightName as ibm_insightName,
t1.updateBy as ibm_updateBy,
t1.insightCategory as ibm_insightCategory,
t1.updateTs as ibm_updateTs,
t1.athenaSessionID as ibm_athenaSessionID,
t1.processStep as ibm_processStep,
t1.callReason as ibm_callReason,
t1.dispositionOptionID as ibm_dispositionOptionID,
t1.dispositionDesc as ibm_dispositionDesc,
t1.rank1 as ibm_rank1,
t1.propositionID as ibm_propositionID,
t1.externalID as ibm_externalID,
t1.dnsNumber as ibm_dnsNumber,
t2.mtn as df_mtn,
t2.insightName as df_insightName,
t2.updateBy as df_updateBy,
t2.insightCategory as df_insightCategory,
t2.updateTs as df_updateTs,
t2.athenaSessionID as df_athenaSessionID,
t2.processStep as df_processStep,
t2.callReason as df_callReason,
t2.dispositionOptionID as df_dispositionOptionID,
t2.dispositionDesc as df_dispositionDesc,
t2.rank1 as df_rank1,
t2.propositionID as df_propositionID,
t2.externalID as df_externalID,
t2.dnsNumber as df_dnsNumber,



case
  when trim(t1.mtn) = trim(t2.mtn)
  then 1 else 0 end key_match,
case
  when trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
   and trim(t1.athenaSessionID) = trim(t2.athenaSessionID)
   and trim(t1.processStep) = trim(t2.processStep)
   and trim(t1.callReason) = trim(t2.callReason)
   and trim(t1.dispositionOptionID) = trim(t2.dispositionOptionID)
   and trim(t1.dispositionDesc) = trim(t2.dispositionDesc)
   and trim(t1.rank1) = trim(t2.rank1)
   and trim(t1.propositionID) = trim(t2.propositionID)
   and trim(t1.externalID) = trim(t2.externalID)
   and trim(t1.dnsNumber) = trim(t2.dnsNumber)

  then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t1
full outer join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
 
) A;



/*
Compare table count process
*/
-- matched key count
SET MATCH_CNT_V = (select COUNT(*) from (select distinct custId,insightName,insightCategory from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct custId,insightName,insightCategory from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
   and trim(t1.athenaSessionID) = trim(t2.athenaSessionID)
   and trim(t1.processStep) = trim(t2.processStep)
   and trim(t1.callReason) = trim(t2.callReason)
   and trim(t1.dispositionOptionID) = trim(t2.dispositionOptionID)
   and trim(t1.dispositionDesc) = trim(t2.dispositionDesc)
   and trim(t1.rank1) = trim(t2.rank1)
   and trim(t1.propositionID) = trim(t2.propositionID)
   and trim(t1.externalID) = trim(t2.externalID)
   and trim(t1.dnsNumber) = trim(t2.dnsNumber)
);


-- unmatched records count
SET UNMATCH_CNT_V = (select COUNT(*) FROM
(select case
  when trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
  then 1 else 0 end as field_match from (select distinct * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
   and trim(t1.athenaSessionID) = trim(t2.athenaSessionID)
   and trim(t1.processStep) = trim(t2.processStep)
   and trim(t1.callReason) = trim(t2.callReason)
   and trim(t1.dispositionOptionID) = trim(t2.dispositionOptionID)
   and trim(t1.dispositionDesc) = trim(t2.dispositionDesc)
   and trim(t1.rank1) = trim(t2.rank1)
   and trim(t1.propositionID) = trim(t2.propositionID)
   and trim(t1.externalID) = trim(t2.externalID)
   and trim(t1.dnsNumber) = trim(t2.dnsNumber)
) A where field_match=0);



-- unmatched keys count in ibm table
SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn,insightName from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
    select distinct custId,acctNo,mtn,insightName
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` t2
    where trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
   and trim(t1.athenaSessionID) = trim(t2.athenaSessionID)
   and trim(t1.processStep) = trim(t2.processStep)
   and trim(t1.callReason) = trim(t2.callReason)
   and trim(t1.dispositionOptionID) = trim(t2.dispositionOptionID)
   and trim(t1.dispositionDesc) = trim(t2.dispositionDesc)
   and trim(t1.rank1) = trim(t2.rank1)
   and trim(t1.propositionID) = trim(t2.propositionID)
   and trim(t1.externalID) = trim(t2.externalID)
   and trim(t1.dnsNumber) = trim(t2.dnsNumber)
   and t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)));



-- unmatched keys count in df table
SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` t1
where  created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V and not exists (
    select distinct custId,acctNo,mtn,insightName
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` t2
    where trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.updateBy) = trim(t2.updateBy)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and trim(t1.updateTs) = trim(t2.updateTs)
   and trim(t1.athenaSessionID) = trim(t2.athenaSessionID)
   and trim(t1.processStep) = trim(t2.processStep)
   and trim(t1.callReason) = trim(t2.callReason)
   and trim(t1.dispositionOptionID) = trim(t2.dispositionOptionID)
   and trim(t1.dispositionDesc) = trim(t2.dispositionDesc)
   and trim(t1.rank1) = trim(t2.rank1)
   and trim(t1.propositionID) = trim(t2.propositionID)
   and trim(t1.externalID) = trim(t2.externalID)
   and trim(t1.dnsNumber) = trim(t2.dnsNumber)
   and t1.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)));


SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn 
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));

SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_ivrcall_mtninsight_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));



--Delete and load into the event metrics table for the specific day
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = STRING(PROCESS_START_TS_V) AND PROCESS_END_TS = STRING(PROCESS_END_TS_V) AND jobname = JOBNAME_V;

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',STRING(PROCESS_START_TS_V),STRING(PROCESS_END_TS_V),current_timestamp);
End;