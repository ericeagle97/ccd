CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_src_digitalsecure_securityscore_raw_runcomparedata_daily`(PROCESS_DT_V STRING)
Begin
DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V TIMESTAMP;
DECLARE PROCESS_END_TS_V TIMESTAMP;
DECLARE CUR_EST_TS TIMESTAMP;
DECLARE STR_V STRING;
SET PROCESS_START_TS_V = CAST(CONCAT(PROCESS_DT_V,' 00:00:00') AS TIMESTAMP);
SET PROCESS_END_TS_V = CAST(CONCAT(PROCESS_DT_V,' 23:59:59') AS TIMESTAMP);
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'src_digitalsecure_securityscore_raw';
SET STR_V = concat('%""""updateTs"""":""""', PROCESS_DT_V ,'%');

-- REMOVE DATA FROM DF STG TABLE
truncate table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_df_raw_stg`;

-- INSERT DATA to DF STG TABLE FROM RAW TABLE
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_df_raw_stg`
select  data,created_ts FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_df_raw` B where date(B.CREATED_TS) = CURR_DATE_V ;

-- DELETE CURRENT DATE DATA FROM EVENT TABLE
delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` where date(created_ts) = date(PROCESS_DT_V);


--multiple record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_df_event`


with t1 as (
  select data,create_ts,
   JSON_EXTRACT(REPLACE(REPLACE(REPLACE(data,'"{','{'),'}"','}'),'\\',''),'$.insightValues')
    as rdata2 from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_df_raw
     where JSON_VALUE(data, '$.insightName') = "securityscore_raw"
)

select
JSON_VALUE(data, '$.custId') as  custId,
JSON_VALUE(data, '$.acctNo') as  acctNo,
JSON_VALUE(data, '$.mtn') as  mtn,
JSON_VALUE(data, '$.insightName') as  insightName,
JSON_VALUE(data, '$.updateBy') as  updateBy,
JSON_VALUE(data, '$.insightCategory') as  insightCategory,
JSON_VALUE(data, '$.ttl') as  ttl,
SAFE_CAST(JSON_VALUE(data, '$.updateTs') AS timestamp) updateTs,
JSON_VALUE(rdata2, '$.isScheduledScanEnabled') as  isScheduledScanEnabled,
JSON_VALUE(rdata2, '$.isDigitalSecureActivated') as  isDigitalSecureActivated,
JSON_VALUE(rdata2, '$.isDigitalSecureAppInstalled') as  isDigitalSecureAppInstalled,
JSON_VALUE(rdata2, '$.signatureVersion') as  signatureVersion,
JSON_VALUE(rdata2, '$.privacyAlertCount') as  privacyAlertCount,
JSON_VALUE(rdata2, '$.isRunning') as  isRunning,
JSON_VALUE(rdata2, '$.isUserEnrolledToCSID') as  isUserEnrolledToCSID,
JSON_VALUE(rdata2, '$.isWifiSecurityEnabled') as  isWifiSecurityEnabled,
JSON_VALUE(rdata2, '$.mmsVersionCode') as  mmsVersionCode,
JSON_VALUE(rdata2, '$.subscriptionType') as  subscriptionType,
JSON_VALUE(rdata2, '$.mmsVersion') as  mmsVersion,
JSON_VALUE(rdata2, '$.isVPNAutoConnectEnabled') as  isVPNAutoConnectEnabled,
JSON_VALUE(rdata2, '$.isVPNConnected') as  isVPNConnected,
JSON_VALUE(rdata2, '$.isMdnCaptured') as  isMdnCaptured,
JSON_VALUE(rdata2, '$.isRealTimeScanEnabled') as  isRealTimeScanEnabled,
JSON_VALUE(rdata2, '$.isWebSecurityEnabled') as  isWebSecurityEnabled,
JSON_VALUE(rdata2, '$.deviceOS') as  deviceOS,
JSON_VALUE(rdata2, '$.lastUpdateTime') as  lastUpdateTime,
JSON_VALUE(rdata2, '$.lastSignatureCheckTime') as  lastSignatureCheckTime,
JSON_VALUE(rdata2, '$.lastScanTime') as  lastScanTime,
JSON_VALUE(rdata2, '$.nextScanTime') as  nextScanTime,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.timeZone') as  timeZone,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.sdk_int') as  sdkInt,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.make') as  make,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.model') as  model1,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.buildTime') as  buildTime,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.osFirmware') as  osFirmware,
JSON_VALUE(JSON_EXTRACT_SCALAR(rdata2, '$.metaData'), '$.mvmVersion') as  mvmVersion,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.threats')) AS threats,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.scannedThreatLogs')) AS scannedThreatLogs,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.appsWithHighDataExposure')) AS appsWithHighDataExposure,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.wifiAlertsByDay')) AS wifiAlertsByDay,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.threatHistoryLogs')) AS threatHistoryLogs,
TO_JSON_STRING(JSON_EXTRACT(rdata2, '$.ignoredWifiAlertsByDay')) AS ignoredWifiAlertsByDay,

CURR_HR_V,
CURR_DATE_V,
created_ts,
from t1 ;



/*
Load IBM Pipeline data - start
*/


--INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_ibm_raw_stg`
--SELECT srcdata FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_ibm_raw` B where date(JSON_VALUE(B.srcdata, '$.updateTs')) = CURR_DATE_V;

DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` where  date(created_ts) = CURR_DATE_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event`


with t6 as(
with t5 as(
with t4 as(
with t3 as(
with t2 as (with t1 as(
select split(split(REPLACE(srcdata,'\\',''),'}}{')[safe_offset(1)],'{"requestType":')[safe_offset(1)] as  reqtype,created_ts
from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_ibm_raw
where date(created_ts)=date(PROCESS_DT_V)
)
select concat('{"requestType":', reqtype) as rdata1,created_ts from t1
)
select case when REGEXP_CONTAINS(rdata1,',"{"results":{}') then rtrim(split(rdata1,',"{"results":{}')[0],'","') else rtrim(rdata1,'","') end as rdata2,created_ts from t2
)
select replace(replace(replace(rdata2,'\\',''),'"{','{'),'}"','}') as rdata2,created_ts from t3)
select rdata2,JSON_EXTRACT(rdata2, '$.keyAttributes') as keyattdata,created_ts from t4
where JSON_VALUE(JSON_EXTRACT(rdata2, '$.keyAttributes'), '$.insightName') = "securityscore_raw"
)
select rdata2,keyattdata,created_ts,JSON_EXTRACT(keyattrdata, '$.insightValues') as eventdata from t5)
select
JSON_VALUE(keyattdata, '$.custId') as  custId,
JSON_VALUE(keyattdata, '$.acctNo') as  acctNo,
JSON_VALUE(keyattdata, '$.mtn') as  mtn,
JSON_VALUE(keyattdata, '$.insightName') as  insightName,
JSON_VALUE(keyattdata, '$.updateBy') as  updateBy,
JSON_VALUE(keyattdata, '$.insightCategory') as  insightCategory,
JSON_VALUE(keyattdata, '$.ttl') as  ttl,
SAFE_CAST(JSON_VALUE(keyattdata, '$.updateTs') AS timestamp) updateTs,
JSON_VALUE(eventdata, '$.isScheduledScanEnabled') as  isScheduledScanEnabled,
JSON_VALUE(eventdata, '$.isDigitalSecureActivated') as  isDigitalSecureActivated,
JSON_VALUE(eventdata, '$.isDigitalSecureAppInstalled') as  isDigitalSecureAppInstalled,
JSON_VALUE(eventdata, '$.signatureVersion') as  signatureVersion,
JSON_VALUE(eventdata, '$.privacyAlertCount') as  privacyAlertCount,
JSON_VALUE(eventdata, '$.isRunning') as  isRunning,
JSON_VALUE(eventdata, '$.isUserEnrolledToCSID') as  isUserEnrolledToCSID,
JSON_VALUE(eventdata, '$.isWifiSecurityEnabled') as  isWifiSecurityEnabled,
JSON_VALUE(eventdata, '$.mmsVersionCode') as  mmsVersionCode,
JSON_VALUE(eventdata, '$.subscriptionType') as  subscriptionType,
JSON_VALUE(eventdata, '$.mmsVersion') as  mmsVersion,
JSON_VALUE(eventdata, '$.isVPNAutoConnectEnabled') as  isVPNAutoConnectEnabled,
JSON_VALUE(eventdata, '$.isVPNConnected') as  isVPNConnected,
JSON_VALUE(eventdata, '$.isMdnCaptured') as  isMdnCaptured,
JSON_VALUE(eventdata, '$.isRealTimeScanEnabled') as  isRealTimeScanEnabled,
JSON_VALUE(eventdata, '$.isWebSecurityEnabled') as  isWebSecurityEnabled,
JSON_VALUE(eventdata, '$.deviceOS') as  deviceOS,
JSON_VALUE(eventdata, '$.lastUpdateTime') as  lastUpdateTime,
JSON_VALUE(eventdata, '$.lastSignatureCheckTime') as  lastSignatureCheckTime,
JSON_VALUE(eventdata, '$.lastScanTime') as  lastScanTime,
JSON_VALUE(eventdata, '$.nextScanTime') as  nextScanTime,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.timeZone') as  timeZone,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.sdk_int') as  sdkInt,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.make') as  make,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.model') as  model1,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.buildTime') as  buildTime,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.osFirmware') as  osFirmware,
JSON_VALUE(JSON_EXTRACT_SCALAR(eventdata, '$.metaData'), '$.mvmVersion') as  mvmVersion,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.threats')) AS threats,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.scannedThreatLogs')) AS scannedThreatLogs,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.appsWithHighDataExposure')) AS appsWithHighDataExposure,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.wifiAlertsByDay')) AS wifiAlertsByDay,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.threatHistoryLogs')) AS threatHistoryLogs,
TO_JSON_STRING(JSON_EXTRACT(eventdata, '$.ignoredWifiAlertsByDay')) AS ignoredWifiAlertsByDay,


CURR_HR_V,
CURR_DATE_V,
created_ts,
from t6;




/*
Compare table data process
*/
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_event_cmp2` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_event_cmp2`
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
CURR_HR_V as PROCESS_HR,
CURR_DATE_V as PROCESS_DT
from
(select
t1.custId as ibm_custId,
t1.acctNo as ibm_acctNo,
t1.mtn as ibm_mtn,
t1.insightName as ibm_insightName,
t1.updateBy as ibm_updateBy,
t1.insightCategory as ibm_insightCategory,
t1.ttl as ibm_ttl,
t1.updateTs as ibm_updateTs,

t1.isScheduledScanEnabled as ibm_isScheduledScanEnabled,
t1.isDigitalSecureActivated as ibm_isDigitalSecureActivated,
t1.isDigitalSecureAppInstalled as ibm_isDigitalSecureAppInstalled,
t1.signatureVersion as ibm_signatureVersion,
t1.privacyAlertCount as ibm_privacyAlertCount,
t1.insightCategory as ibm_insightCategory,
t1.isRunning as ibm_isRunning,
t1.isUserEnrolledToCSID as ibm_isUserEnrolledToCSID,
t1.isWifiSecurityEnabled as ibm_isWifiSecurityEnabled,
t1.mmsVersionCode as ibm_mmsVersionCode,
t1.subscriptionType as ibm_subscriptionType,
t1.mmsVersion as ibm_mmsVersion,
t1.lastSignatureCheckTime as ibm_lastSignatureCheckTime,
t1.insightCategory as ibm_insightCategory,
t1.isVPNConnected as ibm_isVPNConnected,
t1.isMdnCaptured as ibm_isMdnCaptured,
t1.isRealTimeScanEnabled as ibm_isRealTimeScanEnabled,
t1.isWebSecurityEnabled as ibm_isWebSecurityEnabled,
t1.deviceOS as ibm_deviceOS,
t1.lastUpdateTime as ibm_lastUpdateTime,
t1.lastScanTime as ibm_lastScanTime,
t1.nextScanTime as ibm_nextScanTime,

t1.timeZone as ibm_timeZone,
t1.sdkInt as ibm_sdkInt,
t1.make as ibm_make,
t1.model1 as ibm_model1,
t1.buildTime as ibm_buildTime,
t1.osFirmware as ibm_osFirmware,
t1.mvmVersion as ibm_mvmVersion,


t2.custId as df_custId,
t2.acctNo as df_acctNo,
t2.mtn as df_mtn,
t2.insightName as df_insightName,
t2.updateBy as df_updateBy,
t2.insightCategory as df_insightCategory,
t2.ttl as df_ttl,
t2.updateTs as df_updateTs,
t2.isScheduledScanEnabled as df_isScheduledScanEnabled,
t2.isDigitalSecureActivated as df_isDigitalSecureActivated,
t2.isDigitalSecureAppInstalled as df_isDigitalSecureAppInstalled,
t2.signatureVersion as df_signatureVersion,
t2.privacyAlertCount as df_privacyAlertCount,
t2.insightCategory as df_insightCategory,
t2.isRunning as df_isRunning,
t2.isUserEnrolledToCSID as df_isUserEnrolledToCSID,
t2.isWifiSecurityEnabled as df_isWifiSecurityEnabled,
t2.mmsVersionCode as df_mmsVersionCode,
t2.subscriptionType as df_subscriptionType,
t2.mmsVersion as df_mmsVersion,
t2.lastSignatureCheckTime as df_lastSignatureCheckTime,
t2.insightCategory as df_insightCategory,
t2.isVPNConnected as df_isVPNConnected,
t2.isMdnCaptured as df_isMdnCaptured,
t2.isRealTimeScanEnabled as df_isRealTimeScanEnabled,
t2.isWebSecurityEnabled as df_isWebSecurityEnabled,
t2.deviceOS as df_deviceOS,
t2.lastUpdateTime as df_lastUpdateTime,
t2.lastScanTime as df_lastScanTime,
t2.nextScanTime as df_nextScanTime,

t2.timeZone as df_timeZone,
t2.sdkInt as df_sdkInt,
t2.make as df_make,
t2.model1 as df_model1,
t2.buildTime as df_buildTime,
t2.osFirmware as df_osFirmware,
t2.mvmVersion as df_mvmVersion,

case
  when trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
  then 1 else 0 end key_match,
case
  when trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
  then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` where updateTs > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t1
full outer join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
) A;


/*
Compare table count process
*/


-- matched key count
SET MATCH_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct custId,acctNo,mtn from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
);


-- unmatched records count
SET UNMATCH_CNT_V = (select COUNT(*) FROM
(select case
  when t1.insightName = t2.insightName
   and t1.insightCategory = t2.insightCategory
  then 1 else 0 end as field_match from (select distinct * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
) A where field_match=0);


-- unmatched keys count in ibm table
SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
    select distinct custId,acctNo,mtn
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` t2
    where trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)));

-- unmatched keys count in df table
SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` t1
where  created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V and not exists (
    select distinct custId,acctNo,mtn
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` t2
    where trim(t1.custId) = trim(t2.custId)
   and trim(t1.acctNo) = trim(t2.acctNo)
   and trim(t1.mtn) = trim(t2.mtn)
   and trim(t1.insightName) = trim(t2.insightName)
   and trim(t1.insightCategory) = trim(t2.insightCategory)
   and t1.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)));


SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn 
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));

SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct custId,acctNo,mtn
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_digisecure_securityscore_raw_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));



--Delete and load into the event metrics table for the specific day
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = STRING(PROCESS_START_TS_V) AND PROCESS_END_TS = STRING(PROCESS_END_TS_V) AND jobname = JOBNAME_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',STRING(PROCESS_START_TS_V),STRING(PROCESS_END_TS_V),current_timestamp);
End;