CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_source_weather_api_runcomparedata_daily`(PROCESS_DT_V STRING)
Begin
DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V TIMESTAMP;
DECLARE PROCESS_END_TS_V TIMESTAMP;
DECLARE CUR_EST_TS TIMESTAMP;
DECLARE STR_V STRING;
SET PROCESS_START_TS_V = CAST(CONCAT(PROCESS_DT_V,' 00:00:00') AS TIMESTAMP);
SET PROCESS_END_TS_V = CAST(CONCAT(PROCESS_DT_V,' 23:59:59') AS TIMESTAMP);
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'source_weather_api';
SET STR_V = concat('%""""updateTs"""":""""', PROCESS_DT_V ,'%');

--df data
truncate table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_raw_stg`;

insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_raw_stg`
select  data,created_ts FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_raw`  B where date(B.CREATED_TS) = CURR_DATE_V;

delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` where  date(created_ts) = CURR_DATE_V;

--multiple record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event`


with t2 as(
with t1 as (
  select data,create_ts,
   REPLACE(REPLACE(REPLACE(data,'"{','{'),'}"','}'),'\\','')
    as rdata2 from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_raw_stg
    
)
select rdata2,JSON_EXTRACT(rdata2, '$.aggrValues') as eventdata, created_ts from t1
)
select
JSON_VALUE(rdata2, '$.updateBy') as  updateBy,
JSON_VALUE(rdata2, '$.requestedBy') as  requestedBy,
JSON_VALUE(rdata2, '$.aggrName') as  aggrName,
JSON_VALUE(rdata2, '$.aggrCategory') as  aggrCategory,
JSON_VALUE(rdata2, '$.aggrProdId') as  aggrProdId,
JSON_VALUE(rdata2, '$.updateTs') as  updateTs,
JSON_VALUE(eventdata, '$.temperature') as  temperature,
JSON_VALUE(eventdata, '$.condition_description') as  conditiondescription,
JSON_VALUE(eventdata, '$.condition_code') as  conditioncode,
JSON_VALUE(eventdata, '$.provider_last_update_time') as  providerlastupdatetime,

CURR_HR_V,
CURR_DATE_V,
created_ts,
from t2;

/*
Load IBM Pipeline data - start
*/
--INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pega_fraudremarks_ibm_raw_stg`
--SELECT srcdata FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pega_fraudremarks_ibm_raw` B where date(JSON_VALUE(B.srcdata, '$.updateTs')) = CURR_DATE_V;
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event`   where  date(created_ts) = CURR_DATE_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event`

-- with t6 as(
-- with t5 as(
-- with t4 as(
-- with t3 as(
-- with t2 as (with t1 as(
-- select split(split(REPLACE(srcdata,'\\',''),'}}{')[safe_offset(1)],'{"requestType":')[safe_offset(1)] as  reqtype,created_ts
-- from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_raw`  where safe.parse_date('%m/%d/%Y',LEFT(regexp_extract(srcdata,r'\\\"updateTs\\\":\\\"(.*?)\\\"'),10))=date(PROCESS_DT_V)
-- )
-- select concat('{"requestType":', reqtype) as rdata1,created_ts from t1
-- )
-- select case when REGEXP_CONTAINS(rdata1,',"{"results":{}') then rtrim(split(rdata1,',"{"results":{}')[0],'","') else rtrim(rdata1,'","') end as rdata2, created_ts from t2
-- )

-- select replace(replace(replace(rdata2,'\\',''),'"{','{'),'}"','}') as rdata2,created_ts from t3)
-- select rdata2,JSON_EXTRACT(rdata2, '$.keyAttributes') as keyattrdata, created_ts from t4)
-- select rdata2,created_ts,JSON_VALUE(keyattrdata, '$.aggrValues') as eventdata from t5)

-- select

-- JSON_VALUE(keyattrdata, '$.updateBy') as  updateBy,
-- JSON_VALUE(keyattrdata, '$.requestedBy') as  requestedBy,
-- JSON_VALUE(keyattrdata, '$.aggrName') as  aggrName,
-- JSON_VALUE(keyattrdata, '$.aggrCategory') as  aggrCategory,
-- JSON_VALUE(keyattrdata, '$.aggrProdId') as  aggrProdId,
-- JSON_VALUE(keyattrdata, '$.updateTs') as  updateTs,
-- JSON_VALUE(eventdata, '$.temperature') as  temperature,
-- JSON_VALUE(eventdata, '$.condition_description') as  conditiondescription,
-- JSON_VALUE(eventdata, '$.condition_code') as  conditioncode,
-- JSON_VALUE(eventdata, '$.provider_last_update_time') as  providerlastupdatetime,

-- CURR_HR_V,
-- CURR_DATE_V,
-- created_ts,
-- from t6;



with t2 as(
with t1 as (
  select data,create_ts,
   JSON_EXTRACT(REPLACE(REPLACE(REPLACE(data,'"{','{'),'}"','}'),'\\',''),'$.keyAttributes')
    as rdata2 from vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_raw
    
)

select rdata2,JSON_EXTRACT(rdata2, '$.aggrValues') as eventdata, created_ts from t1
)

select
JSON_VALUE(rdata2, '$.updateBy') as  updateBy,
JSON_VALUE(rdata2, '$.requestedBy') as  requestedBy,
JSON_VALUE(rdata2, '$.aggrName') as  aggrName,
JSON_VALUE(rdata2, '$.aggrCategory') as  aggrCategory,
JSON_VALUE(rdata2, '$.aggrProdId') as  aggrProdId,
JSON_VALUE(rdata2, '$.updateTs') as  updateTs,
JSON_VALUE(eventdata, '$.temperature') as  temperature,
JSON_VALUE(eventdata, '$.condition_description') as  conditiondescription,
JSON_VALUE(eventdata, '$.condition_code') as  conditioncode,
JSON_VALUE(eventdata, '$.provider_last_update_time') as  providerlastupdatetime,

CURR_HR_V,
CURR_DATE_V,
created_ts,
from t2;

/*
Compare table data process
*/
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_event_cmp` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_event_cmp`
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
CURR_HR_V as PROCESS_HR,
CURR_DATE_V as PROCESS_DT
from
(select

t1.updateBy as ibm_updateBy,
t1.requestedBy as ibm_requestedBy,
t1.aggrName as ibm_aggrName,
t1.aggrCategory as ibm_aggrCategory,
t1.aggrProdId as ibm_aggrProdId,
t1.updateTs as ibm_updateTs,
t1.temperature as ibm_temperature,
t1.conditiondescription as ibm_conditiondescription,
t1.conditioncode as ibm_conditioncode,
t1.providerlastupdatetime as ibm_providerlastupdatetime,
t2.updateBy as df_updateBy,
t2.requestedBy as df_requestedBy,
t2.aggrName as df_aggrName,
t2.aggrCategory as df_aggrCategory,
t2.aggrProdId as df_aggrProdId,
t2.updateTs as df_updateTs,
t2.temperature as df_temperature,
t2.conditiondescription as df_conditiondescription,
t2.conditioncode as df_conditioncode,
t2.providerlastupdatetime as df_providerlastupdatetime,

case
  when trim(t1.aggrName) = trim(t2.aggrName)
and trim(t1.aggrProdId) = trim(t2.aggrProdId)
and trim(t1.aggrCategory) = trim(t2.aggrCategory)
  then 1 else 0 end key_match,
case
  when
trim(t1.updateBy) = trim(t2.updateBy)
and trim(t1.updateTs) =trim(t2.updateTs)
and trim(t1.requestedBy) =trim(t2.requestedBy)
and trim(t1.temperature) = trim(t2.temperature)
and trim(t1.conditiondescription) = trim(t2.conditiondescription)
and trim(t1.conditioncode) = trim(t2.conditioncode)
and trim(t1.providerlastupdatetime) =trim(t2.providerlastupdatetime)

  then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t1
full outer join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` where created_ts > PROCESS_START_TS_V  and created_ts <= PROCESS_END_TS_V) t2
on  trim(t1.aggrProdId) = trim(t2.aggrProdId)
) A;



/*
Compare table count process
*/


-- matched key count
SET MATCH_CNT_V = (select COUNT(*) from (select distinct aggrName,aggrCategory,aggrProdId from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select distinct aggrName,aggrCategory,aggrProdId from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.aggrName) = trim(t2.aggrName)
   and trim(t1.aggrProdId) = trim(t2.aggrProdId)
   and trim(t1.aggrCategory) = trim(t2.aggrCategory)
   and trim(t1.temperature) = trim(t2.temperature)
   and trim(t1.conditiondescription) = trim(t2.conditiondescription)
   and trim(t1.conditioncode) = trim(t2.conditioncode)
   and trim(t1.providerlastupdatetime) =trim(t2.providerlastupdatetime)
);



-- unmatched records count
SET UNMATCH_CNT_V =(select count(*) from (select  case
  when 
  trim(t1.aggrName) = trim(t2.aggrName)
   and trim(t1.aggrProdId) = trim(t2.aggrProdId)
   and trim(t1.aggrCategory) = trim(t2.aggrCategory)
   and trim(t1.temperature) = trim(t2.temperature)
   and trim(t1.conditiondescription) = trim(t2.conditiondescription)
   and trim(t1.conditioncode) = trim(t2.conditioncode)
   and trim(t1.providerlastupdatetime) =trim(t2.providerlastupdatetime)
   
  then 1 else 0 end as field_match,* from (select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t1
inner join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V) t2
on trim(t1.mtn) = trim(t2.mtn)
   ) where field_match=0);
   
   

-- unmatched keys count in ibm table
SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct aggrName,aggrCategory,aggrProdId from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
   select * from ( select distinct aggrName,aggrCategory,aggrProdId
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` t2
    where
   t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)t2 where trim(t1.aggrName) = trim(t2.aggrName)
   and trim(t1.aggrProdId) = trim(t2.aggrProdId)
   and trim(t1.aggrCategory) = trim(t2.aggrCategory)
   and trim(t1.temperature) = trim(t2.temperature)
   and trim(t1.conditiondescription) = trim(t2.conditiondescription)
   and trim(t1.conditioncode) = trim(t2.conditioncode)
   and trim(t1.providerlastupdatetime) =trim(t2.providerlastupdatetime)
   and t1.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)));



-- unmatched keys count in df table
SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct aggrName,aggrCategory,aggrProdId from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` t1
where  t1.created_ts >= PROCESS_START_TS_V and t1.created_ts <= PROCESS_END_TS_V and not exists (
   select * from ( select distinct aggrName,aggrCategory,aggrProdId 
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` t2
    where
   t2.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V
)t2 where  trim(t1.aggrName) = trim(t2.aggrName)
   and trim(t1.aggrProdId) = trim(t2.aggrProdId)
   and trim(t1.aggrCategory) = trim(t2.aggrCategory)
   and trim(t1.temperature) = trim(t2.temperature)
   and trim(t1.conditiondescription) = trim(t2.conditiondescription)
   and trim(t1.conditioncode) = trim(t2.conditioncode)
   and trim(t1.providerlastupdatetime) =trim(t2.providerlastupdatetime)
   and t1.created_ts >= PROCESS_START_TS_V and t2.created_ts <= PROCESS_END_TS_V

)));


SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct aggrName,aggrCategory,aggrProdId
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_ibm_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));

SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct aggrName,aggrCategory,aggrProdId
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rtins_sourceweather_df_event` where created_ts >= PROCESS_START_TS_V and created_ts <= PROCESS_END_TS_V));

--Delete and load into the event metrics table for the specific day
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = STRING(PROCESS_START_TS_V) AND PROCESS_END_TS = STRING(PROCESS_END_TS_V) AND jobname = JOBNAME_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',STRING(PROCESS_START_TS_V),STRING(PROCESS_END_TS_V),current_timestamp);
End;