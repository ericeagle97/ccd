CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_runcomparedata_daily`(PROCESS_DT_V STRING)
Begin

DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V STRING;
DECLARE PROCESS_END_TS_V STRING;
DECLARE CUR_EST_TS TIMESTAMP;
DECLARE STR_V STRING;


SET PROCESS_START_TS_V = CONCAT(PROCESS_DT_V,' 00:00:00');
SET PROCESS_END_TS_V = CONCAT(PROCESS_DT_V,' 23:59:59');
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'PZAI';

SET STR_V = concat('%"eventTimestamp":"', PROCESS_DT_V ,'%');

-- Added on 12/Jan
--IBM

create or replace table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_drop` as
select * from (select REPLACE(srcdata,'\\','') as srcdata from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw`)  
where srcdata like STR_V and trim(srcdata) != '' and srcdata = '{"requestType":';

create or replace table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_tmp_dump` as 
with t5 as (
with t4 as (
with t3 as (
with t2 as (
with t1 as(
select split(split(REPLACE(srcdata,'\\',''),']}|')[1],'{"requestType":')[1] as reqtype 
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_drop`
) 
select concat('{"requestType":', reqtype) as rdata1 from t1 where reqtype != '') 
select case when REGEXP_CONTAINS(rdata1,'{"status":{"code":"200"') then rtrim(split(rdata1,'{"status":{"code":"200"')[0],'","') else rtrim(rdata1,'","') end as rdata2 from t2)
select regexp_replace(regexp_replace(rdata2,'"eventValue":"','"eventValue":'),'","mtn"', ',"mtn"') as requesttype from t3)

select JSON_VALUE(requesttype, '$.requestType') as requestType,eventdata from t4,UNNEST(JSON_EXTRACT_ARRAY(requesttype,"$.listKeyAttributes")) eventdata)
select JSON_VALUE(eventdata, '$.keyName') as  keyName, JSON_VALUE(eventdata, '$.keyValue') as  keyValue,
JSON_VALUE(eventdata, '$.eventTimestamp') as  eventTimestamp,
JSON_VALUE(eventdata, '$.eventName') as  eventName,
JSON_VALUE(eventdata, '$.eventCat') as  eventCat,
JSON_QUERY(eventdata, '$.eventValue') as  eventValue,
0 as cmp_status,
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.current')) as productCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.product.search.term'),'') as searchTerm,  
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.eventType'),'') as eventType,
coalesce(JSON_VALUE(eventdata,'$.eventValue.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(eventdata,'$.eventValue.target'),'') as target,
0 as CURR_HR_V,
date(PROCESS_DT_V) as CURR_DATE_V,
current_timestamp() as created_ts from t5;

delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where date(eventTimestamp) = PROCESS_DT_V;

insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` 
select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_tmp_dump`;

--df data
delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where date(eventTimestamp) = PROCESS_DT_V;

insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event`
SELECT 
JSON_VALUE(srcdata, '$.keyName') keyName,
JSON_VALUE(srcdata, '$.keyValue') keyValue,
replace(JSON_VALUE(srcdata, '$.eventTimestamp'),'T',' ') as  eventTimestamp,
JSON_VALUE(srcdata, '$.eventName') eventName,
JSON_VALUE(srcdata, '$.eventCat') eventCat,
eventValue,
0,
array_length(JSON_EXTRACT_ARRAY(eventValue,'$.product.current')) as productCnt,
coalesce(JSON_VALUE(eventValue,'$.product.search.term'),'') as searchTerm,
array_length(JSON_EXTRACT_ARRAY(eventValue,'$.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(eventValue,'$.eventType'),'') as eventType,
coalesce(JSON_VALUE(eventValue,'$.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(eventValue,'$.target'),'') as target,
0 as process_hr,
date(PROCESS_DT_V) as process_dt,
current_timestamp() as CREATED_TS
from 
(select * from (select data as srcdata, JSON_VALUE(data,'$.eventValue') as eventValue from
`vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw`) where srcdata like STR_V) A;


-- End - Added on 12/Jan


SET MATCH_CNT_V = (select COUNT(*) from (select distinct keyName,eventtimestamp,keyvalue,eventcat,eventname from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t1
inner join 
(select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t2
on trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
);



SET UNMATCH_CNT_V = (select COUNT(*) FROM (select case 
  when 
  t1.productCnt = t2.productCnt AND
   trim(t1.searchTerm) = trim(t2.searchTerm)
   and t1.ownsCnt = t2.ownsCnt
   -- and t1.eventType = t2.eventType
   and trim(t1.rptMth) = trim(t2.rptMth)
   and trim(t1.target) = trim(t2.target)
  then 1 else 0 end as field_match from (select distinct keyName,eventtimestamp,keyvalue,eventcat,eventname,productCnt,searchTerm,ownsCnt,eventType,rptMth,`target` from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t1
inner join 
(select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname,productCnt,searchTerm,ownsCnt,eventType,rptMth,`target` from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t2
on trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
) A where field_match=0);


SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` t1
where  t1.eventTimestamp >= PROCESS_START_TS_V and t1.eventTimestamp <= PROCESS_END_TS_V and not exists (
    select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` t2
    where trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
   and t2.eventTimestamp >= PROCESS_START_TS_V and t2.eventTimestamp <= PROCESS_END_TS_V
)));

SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
from  `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` t1
where  t1.eventTimestamp >= PROCESS_START_TS_V and t1.eventTimestamp <= PROCESS_END_TS_V and not exists (
    select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
    from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` t2
    where trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
   and t2.eventTimestamp >= PROCESS_START_TS_V and t2.eventTimestamp <= PROCESS_END_TS_V
)));

SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V));

SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct keyName,eventtimestamp,keyvalue,eventcat, eventname
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where eventTimestamp >= PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V));
--Delete and load into the event metrics table for the specific day
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = PROCESS_START_TS_V AND PROCESS_END_TS = PROCESS_END_TS_V AND jobname = JOBNAME_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` 
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',PROCESS_START_TS_V,PROCESS_END_TS_V,current_timestamp);


END;