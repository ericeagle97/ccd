
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_tbls6`
(
  srcdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_job_meta_query`
(
  jobname STRING,
  strquery STRING,
  metrictype STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg_tmp`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  CURR_HR_V INT64,
  CURR_DATE_V DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.tbltest_b`
(
  id INT64,
  name STRING,
  process_hr STRING,
  process_dt STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_tbls`
(
  requestType STRING,
  listKeyAttributes ARRAY<STRUCT<keyName STRING, keyValue INT64, eventTimestamp DATE, eventCat STRING, eventName STRING, eventValue STRUCT<event_name STRING, event_ts DATE, rpt_mth DATE, device_info STRING, target STRING, webref_url STRING, prevPageName STRING, cmp STRING, eventType STRING, user STRUCT<zip FLOAT64, tenure FLOAT64, authStatus STRING, accountType STRING, customerRole FLOAT64, customerType FLOAT64, geo_country STRING, geo_state STRING, geo_city STRING, geo_postalcode INT64, geo_Dma INT64, target_offer_id FLOAT64>, search STRUCT<term FLOAT64, type FLOAT64>, page STRUCT<channel_session STRING, name STRING, detail FLOAT64, link FLOAT64, flow STRING, subFlow FLOAT64>, product STRUCT<`current` ARRAY<STRUCT<category STRING, discount FLOAT64, qty INT64, mcat FLOAT64, id STRING, sku STRING, name STRING, offer FLOAT64, line FLOAT64, recurringPrice FLOAT64, nonRecurringPrice FLOAT64>>, owns ARRAY<STRING>>, prod_name FLOAT64, url STRING, webinteraction_url FLOAT64, product_list ARRAY<STRUCT<item_meta STRING, item_sku FLOAT64, product_id STRING>>>, mtn INT64, createdBy STRING, createdTmstamp DATE, ttl INT64>>
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw`
(
  srcdata STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_eventdata_tbl`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventCat STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  process_hr INT64,
  process_dt DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_sessionai_ibm_raw_stg`
(
  srcdata STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_comparsion_dtl`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP,
  ismatched STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.t1`
(
  c1 STRING,
  c2 STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw`
(
  data STRING,
  created_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_eventdata_df_tbl`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp`
(
  ibm_keyName STRING,
  ibm_keyValue STRING,
  ibm_eventTimestamp STRING,
  ibm_eventName STRING,
  ibm_eventCat STRING,
  ibm_eventValue STRING,
  ibm_productCnt INT64,
  ibm_searchTerm STRING,
  ibm_ownsCnt INT64,
  ibm_eventType STRING,
  ibm_rptMth STRING,
  ibm_target STRING,
  df_keyName STRING,
  df_keyValue STRING,
  df_eventTimestamp STRING,
  df_eventName STRING,
  df_eventCat STRING,
  df_eventValue STRING,
  df_productCnt INT64,
  df_searchTerm STRING,
  df_ownsCnt INT64,
  df_eventType STRING,
  df_rptMth STRING,
  df_target STRING,
  key_match INT64,
  field_match INT64,
  cmp_status INT64,
  PROCESS_HR INT64,
  PROCESS_DT DATE
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_tbl`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_incrload_status`
(
  jobname STRING,
  last_load_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_tbl`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_tbls1`
(
  eventName STRING,
  eventTimestamp TIMESTAMP,
  keyValue FLOAT64,
  eventCat STRING,
  keyName STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_df_raw`
(
  data STRING,
  current_ts TIMESTAMP DEFAULT current_timestamp()
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  process_hr INT64,
  process_dt DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE VIEW `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_vz`
AS select 
ibm_keyName,
ibm_keyValue,
ibm_eventTimestamp,
ibm_eventName,
ibm_eventCat,
STRUCT(

    JSON_VALUE(ibm_eventValue, ""$.event_name"") AS event_name,
    JSON_VALUE(ibm_eventValue, ""$.event_ts"") AS event_ts,
    JSON_VALUE(ibm_eventValue, ""$.rpt_mth"") AS rpt_mth,
    JSON_VALUE(ibm_eventValue, ""$.device_info"") AS device_info,
    JSON_VALUE(ibm_eventValue, ""$.target"") AS target,
    JSON_VALUE(ibm_eventValue, ""$.webref_url"") AS webref_url,
    JSON_VALUE(ibm_eventValue, ""$.prevPageName"") AS prevPageName,
    JSON_VALUE(ibm_eventValue, ""$.cmp"") AS cmp,
    JSON_VALUE(ibm_eventValue, ""$.eventType"") AS eventType,
    STRUCT(
      JSON_VALUE(ibm_eventValue, ""$.user.zip"") AS  zip,
      JSON_VALUE(ibm_eventValue, ""$.user.tenure"") AS  tenure,
      JSON_VALUE(ibm_eventValue, ""$.user.authStatus"") AS  authStatus,
      JSON_VALUE(ibm_eventValue, ""$.user.accountType"") AS  accountType,
      JSON_VALUE(ibm_eventValue, ""$.user.customerRole"") AS  customerRole,
      JSON_VALUE(ibm_eventValue, ""$.user.customerType"") AS  customerType,
      JSON_VALUE(ibm_eventValue, ""$.user.geo_country"") AS  geo_country,
      JSON_VALUE(ibm_eventValue, ""$.user.geo_state"") AS  geo_state,
      JSON_VALUE(ibm_eventValue, ""$.user.geo_city"") AS  geo_city,
      JSON_VALUE(ibm_eventValue, ""$.user.geo_postalcode"") AS  geo_postalcode,
      JSON_VALUE(ibm_eventValue, ""$.user.geo_Dma"") AS  geo_Dma,
      JSON_VALUE(ibm_eventValue, ""$.user.target_offer_id"") AS  target_offer_id
) AS user,
STRUCT(
  JSON_VALUE(ibm_eventValue, ""$.search.term"") AS  term,
  JSON_VALUE(ibm_eventValue, ""$.search.type"") AS  type
) AS `search`,
STRUCT(
  JSON_VALUE(ibm_eventValue, ""$.page.channel_session"") AS  channel_session,
  JSON_VALUE(ibm_eventValue, ""$.page.name"") AS  name,
  JSON_VALUE(ibm_eventValue, ""$.page.detail"") AS  detail,
  JSON_VALUE(ibm_eventValue, ""$.page.link"") AS  link,
  JSON_VALUE(ibm_eventValue, ""$.page.flow"") AS  flow,
  JSON_VALUE(ibm_eventValue, ""$.page.subFlow"") AS  subFlow
) AS page,
STRUCT(
        ARRAY( SELECT STRUCT(JSON_VALUE(cur_data,'$.category') AS category,
          JSON_VALUE(cur_data,'$.discount') AS discount,
          JSON_VALUE(cur_data,'$.qty') AS qty,
          JSON_VALUE(cur_data,'$.mcat') AS mcat,
          JSON_VALUE(cur_data,'$.id') AS id,
          JSON_VALUE(cur_data,'$.sku') AS sku,
          JSON_VALUE(cur_data,'$.name') AS name,
          JSON_VALUE(cur_data,'$.offer') AS offer,
          JSON_VALUE(cur_data,'$.line') AS line,
          JSON_VALUE(cur_data,'$.recurringPrice') AS recurringPrice,
          JSON_VALUE(cur_data,'$.nonRecurringPrice') AS nonRecurringPrice) 
         FROM UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, ""$.product.current"")) cur_data) as `current`
) as product,
JSON_VALUE(ibm_eventValue, ""$.prod_name"") AS  prod_name,
JSON_VALUE(ibm_eventValue, ""$.url"") AS  url,
JSON_VALUE(ibm_eventValue, ""$.webinteraction_url"") AS  webinteraction_url,
    ARRAY(SELECT STRUCT(JSON_VALUE(prd_list,'$.item_meta') AS item_meta,
    JSON_VALUE(prd_list,'$.item_sku') AS item_sku,
    JSON_VALUE(prd_list,'$.product_id') AS product_id
    ) FROM UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, ""$.product_list"")) prd_list) as product_list,

ARRAY(SELECT STRUCT(JSON_VALUE(own,'$.category') AS category,
JSON_VALUE(own,'$.mcat') AS mcat,
JSON_VALUE(own,'$.id') AS id,
JSON_VALUE(own,'$.sku') AS sku,
JSON_VALUE(own,'$.name') AS name,
JSON_VALUE(own,'$.offer') AS offer) FROM 
UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, ""$.owns"")) as own 
) as owns
) ibm_eventValue,
--df column list
df_keyName,
df_keyValue,
df_eventTimestamp,
df_eventName,
df_eventCat,
STRUCT(
    JSON_VALUE(df_eventValue, ""$.event_name"") AS event_name,
    JSON_VALUE(df_eventValue, ""$.event_ts"") AS event_ts,
    JSON_VALUE(df_eventValue, ""$.rpt_mth"") AS rpt_mth,
    JSON_VALUE(df_eventValue, ""$.device_info"") AS device_info,
    JSON_VALUE(df_eventValue, ""$.target"") AS target,
    JSON_VALUE(df_eventValue, ""$.webref_url"") AS webref_url,
    JSON_VALUE(df_eventValue, ""$.prevPageName"") AS prevPageName,
    JSON_VALUE(df_eventValue, ""$.cmp"") AS cmp,
    JSON_VALUE(df_eventValue, ""$.eventType"") AS eventType,
    STRUCT(
      JSON_VALUE(df_eventValue, ""$.user.zip"") AS  zip,
      JSON_VALUE(df_eventValue, ""$.user.tenure"") AS  tenure,
      JSON_VALUE(df_eventValue, ""$.user.authStatus"") AS  authStatus,
      JSON_VALUE(df_eventValue, ""$.user.accountType"") AS  accountType,
      JSON_VALUE(df_eventValue, ""$.user.customerRole"") AS  customerRole,
      JSON_VALUE(df_eventValue, ""$.user.customerType"") AS  customerType,
      JSON_VALUE(df_eventValue, ""$.user.geo_country"") AS  geo_country,
      JSON_VALUE(df_eventValue, ""$.user.geo_state"") AS  geo_state,
      JSON_VALUE(df_eventValue, ""$.user.geo_city"") AS  geo_city,
      JSON_VALUE(df_eventValue, ""$.user.geo_postalcode"") AS  geo_postalcode,
      JSON_VALUE(df_eventValue, ""$.user.geo_Dma"") AS  geo_Dma,
      JSON_VALUE(df_eventValue, ""$.user.target_offer_id"") AS  target_offer_id
) AS user,
STRUCT(
  JSON_VALUE(df_eventValue, ""$.search.term"") AS  term,
  JSON_VALUE(df_eventValue, ""$.search.type"") AS  type
) AS `search`,
STRUCT(
  JSON_VALUE(df_eventValue, ""$.page.channel_session"") AS  channel_session,
  JSON_VALUE(df_eventValue, ""$.page.name"") AS  name,
  JSON_VALUE(df_eventValue, ""$.page.detail"") AS  detail,
  JSON_VALUE(df_eventValue, ""$.page.link"") AS  link,
  JSON_VALUE(df_eventValue, ""$.page.flow"") AS  flow,
  JSON_VALUE(df_eventValue, ""$.page.subFlow"") AS  subFlow
) AS page,
STRUCT(
        ARRAY( SELECT STRUCT(JSON_VALUE(cur_data,'$.category') AS category,
          JSON_VALUE(cur_data,'$.discount') AS discount,
          JSON_VALUE(cur_data,'$.qty') AS qty,
          JSON_VALUE(cur_data,'$.mcat') AS mcat,
          JSON_VALUE(cur_data,'$.id') AS id,
          JSON_VALUE(cur_data,'$.sku') AS sku,
          JSON_VALUE(cur_data,'$.name') AS name,
          JSON_VALUE(cur_data,'$.offer') AS offer,
          JSON_VALUE(cur_data,'$.line') AS line,
          JSON_VALUE(cur_data,'$.recurringPrice') AS recurringPrice,
          JSON_VALUE(cur_data,'$.nonRecurringPrice') AS nonRecurringPrice) 
         FROM UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, ""$.product.current"")) cur_data) as `current`
) as product,
JSON_VALUE(df_eventValue, ""$.prod_name"") AS  prod_name,
JSON_VALUE(df_eventValue, ""$.url"") AS  url,
JSON_VALUE(df_eventValue, ""$.webinteraction_url"") AS  webinteraction_url,
    ARRAY(SELECT STRUCT(JSON_VALUE(prd_list,'$.item_meta') AS item_meta,
    JSON_VALUE(prd_list,'$.item_sku') AS item_sku,
    JSON_VALUE(prd_list,'$.product_id') AS product_id
    ) FROM UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, ""$.product_list"")) prd_list) as product_list,

ARRAY(SELECT STRUCT(JSON_VALUE(own,'$.category') AS category,
JSON_VALUE(own,'$.mcat') AS mcat,
JSON_VALUE(own,'$.id') AS id,
JSON_VALUE(own,'$.sku') AS sku,
JSON_VALUE(own,'$.name') AS name,
JSON_VALUE(own,'$.offer') AS offer) FROM 
UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, ""$.owns"")) as own 
) as owns
) df_eventValue,
key_match,
field_match,
cmp_status,
process_hr,
process_dt
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_monthly`;"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_parsed`
(
  requestType STRING,
  eventdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg`
(
  srcdata STRING,
  Created_TS TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  process_hr INT64,
  process_dt DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_ibm_event_tmp`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.t2`
(
  c1 STRING,
  c2 STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_tbls2`
(
  eventName STRING,
  keyName STRING,
  eventTimestamp TIMESTAMP,
  listKeyAttributes ARRAY<STRUCT<ttl INT64, createdTmstamp TIMESTAMP, createdBy STRING, eventValue STRUCT<product STRUCT<owns ARRAY<STRING>, `current` ARRAY<STRUCT<nonRecurringPrice FLOAT64, offer STRING, line STRING, name STRING, sku STRING, recurringPrice FLOAT64, discount STRING, mcat STRING, qty INT64, id STRING, category STRING>>>, page STRUCT<flow STRING, subFlow STRING, link STRING, name STRING, detail STRING, channel_session STRING>, cmp STRING, prevPageName STRING, user STRUCT<geo_postalcode INT64, geo_state STRING, zip INT64, geo_country STRING, customerType STRING, geo_city STRING, target_offer_id STRING, customerRole STRING, accountType STRING, geo_Dma INT64, authStatus STRING, tenure STRING>, target STRING, product_list ARRAY<STRUCT<product_id STRING, item_sku STRING, item_meta STRING>>, eventType STRING, rpt_mth DATE, webinteraction_url STRING, search STRUCT<type STRING, term STRING>, event_ts TIMESTAMP, prod_name STRING, webref_url STRING, url STRING, device_info STRING, event_name STRING>, eventName STRING, keyName STRING, eventTimestamp TIMESTAMP, keyValue FLOAT64, mtn FLOAT64, eventCat STRING>>,
  keyValue FLOAT64,
  eventCat STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp`
(
  ibm_keyName STRING,
  ibm_keyValue STRING,
  ibm_eventTimestamp STRING,
  ibm_eventName STRING,
  ibm_eventCat STRING,
  ibm_eventValue STRING,
  ibm_productCnt INT64,
  ibm_searchTerm STRING,
  ibm_ownsCnt INT64,
  ibm_eventType STRING,
  ibm_rptMth STRING,
  ibm_target STRING,
  df_keyName STRING,
  df_keyValue STRING,
  df_eventTimestamp STRING,
  df_eventName STRING,
  df_eventCat STRING,
  df_eventValue STRING,
  df_productCnt INT64,
  df_searchTerm STRING,
  df_ownsCnt INT64,
  df_eventType STRING,
  df_rptMth STRING,
  df_target STRING,
  key_match INT64,
  field_match INT64,
  cmp_status INT64,
  PROCESS_HR INT64,
  PROCESS_DT DATE
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_monthly_tmp`
(
  ibm_keyName STRING,
  ibm_keyValue STRING,
  ibm_eventTimestamp STRING,
  ibm_eventName STRING,
  ibm_eventCat STRING,
  ibm_eventValue STRING,
  ibm_productCnt INT64,
  ibm_searchTerm STRING,
  ibm_ownsCnt INT64,
  ibm_eventType STRING,
  ibm_rptMth STRING,
  ibm_target STRING,
  df_keyName STRING,
  df_keyValue STRING,
  df_eventTimestamp STRING,
  df_eventName STRING,
  df_eventCat STRING,
  df_eventValue STRING,
  df_productCnt INT64,
  df_searchTerm STRING,
  df_ownsCnt INT64,
  df_eventType STRING,
  df_rptMth STRING,
  df_target STRING,
  key_match INT64,
  field_match INT64,
  cmp_status INT64,
  PROCESS_HR INT64,
  PROCESS_DT DATE
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_monthly`
(
  ibm_keyName STRING,
  ibm_keyValue STRING,
  ibm_eventTimestamp STRING,
  ibm_eventName STRING,
  ibm_eventCat STRING,
  ibm_eventValue STRING,
  ibm_productCnt INT64,
  ibm_searchTerm STRING,
  ibm_ownsCnt INT64,
  ibm_eventType STRING,
  ibm_rptMth STRING,
  ibm_target STRING,
  df_keyName STRING,
  df_keyValue STRING,
  df_eventTimestamp STRING,
  df_eventName STRING,
  df_eventCat STRING,
  df_eventValue STRING,
  df_productCnt INT64,
  df_searchTerm STRING,
  df_ownsCnt INT64,
  df_eventType STRING,
  df_rptMth STRING,
  df_target STRING,
  key_match INT64,
  field_match INT64,
  cmp_status INT64,
  PROCESS_HR INT64,
  PROCESS_DT DATE
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_ibm_srcdata`
(
  srcdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.pzai_reqtype_raw`
(
  srcdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_sessionai_df_raw_stg`
(
  srcdata STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_tmp_dump`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  CURR_HR_V INT64,
  CURR_DATE_V DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
(
  jobname STRING,
  ibm_unmatch_cnt INT64,
  df_notmatch_cnt INT64,
  ibm_total_cnt INT64,
  df_total_cnt INT64,
  match_cnt INT64,
  notmatch_cnt INT64,
  frequency STRING,
  process_start_ts STRING,
  process_end_ts STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_eventled_gk1v`
(
  data STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.test_todrop`
(
  id INT64,
  current_ts TIMESTAMP DEFAULT current_timestamp()
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_notmatch`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_sessionai_df_raw`
(
  data STRING,
  created_ts TIMESTAMP DEFAULT current_timestamp()
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.tbltest_a`
(
  id INT64,
  name STRING,
  process_hr STRING,
  process_dt STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw_g`
(
  srcdata STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw_stg`
(
  srcdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventCat STRING,
  eventValue STRING,
  cmp_status INT64,
  productCnt INT64,
  searchTerm STRING,
  ownsCnt INT64,
  eventType STRING,
  rptMth STRING,
  target STRING,
  process_hr INT64,
  process_dt DATE,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_tbls5`
(
  srcdata STRING
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_notmatch`
(
  keyName STRING,
  keyValue STRING,
  eventTimestamp STRING,
  eventName STRING,
  eventValue STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_job_meta`
(
  jobname STRING,
  ibm_tbl STRING,
  df_tbl STRING,
  condtioncols STRING,
  nextrunhour INT64,
  isacitive STRING,
  jobstart_dt DATE,
  jobend_dt DATE,
  created_on TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"
"CREATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_sessionai_ibm_raw`
(
  srcdata STRING,
  created_ts TIMESTAMP
)
OPTIONS(
  kms_key_name=""projects/vz-it-np-d0sv-vsadkms-0/locations/us/keyRings/vz-it-np-kr-aid/cryptoKeys/vz-it-np-kms-gh2v/cryptoKeyVersions/3""
);"