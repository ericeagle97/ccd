select 
ibm_keyName,
ibm_keyValue,
ibm_eventTimestamp,
ibm_eventName,
ibm_eventCat,
STRUCT(

    JSON_VALUE(ibm_eventValue, "$.event_name") AS event_name,
    JSON_VALUE(ibm_eventValue, "$.event_ts") AS event_ts,
    JSON_VALUE(ibm_eventValue, "$.rpt_mth") AS rpt_mth,
    JSON_VALUE(ibm_eventValue, "$.device_info") AS device_info,
    JSON_VALUE(ibm_eventValue, "$.target") AS target,
    JSON_VALUE(ibm_eventValue, "$.webref_url") AS webref_url,
    JSON_VALUE(ibm_eventValue, "$.prevPageName") AS prevPageName,
    JSON_VALUE(ibm_eventValue, "$.cmp") AS cmp,
    JSON_VALUE(ibm_eventValue, "$.eventType") AS eventType,
    STRUCT(
      JSON_VALUE(ibm_eventValue, "$.user.zip") AS  zip,
      JSON_VALUE(ibm_eventValue, "$.user.tenure") AS  tenure,
      JSON_VALUE(ibm_eventValue, "$.user.authStatus") AS  authStatus,
      JSON_VALUE(ibm_eventValue, "$.user.accountType") AS  accountType,
      JSON_VALUE(ibm_eventValue, "$.user.customerRole") AS  customerRole,
      JSON_VALUE(ibm_eventValue, "$.user.customerType") AS  customerType,
      JSON_VALUE(ibm_eventValue, "$.user.geo_country") AS  geo_country,
      JSON_VALUE(ibm_eventValue, "$.user.geo_state") AS  geo_state,
      JSON_VALUE(ibm_eventValue, "$.user.geo_city") AS  geo_city,
      JSON_VALUE(ibm_eventValue, "$.user.geo_postalcode") AS  geo_postalcode,
      JSON_VALUE(ibm_eventValue, "$.user.geo_Dma") AS  geo_Dma,
      JSON_VALUE(ibm_eventValue, "$.user.target_offer_id") AS  target_offer_id
) AS user,
STRUCT(
  JSON_VALUE(ibm_eventValue, "$.search.term") AS  term,
  JSON_VALUE(ibm_eventValue, "$.search.type") AS  type
) AS `search`,
STRUCT(
  JSON_VALUE(ibm_eventValue, "$.page.channel_session") AS  channel_session,
  JSON_VALUE(ibm_eventValue, "$.page.name") AS  name,
  JSON_VALUE(ibm_eventValue, "$.page.detail") AS  detail,
  JSON_VALUE(ibm_eventValue, "$.page.link") AS  link,
  JSON_VALUE(ibm_eventValue, "$.page.flow") AS  flow,
  JSON_VALUE(ibm_eventValue, "$.page.subFlow") AS  subFlow
) AS page,
STRUCT(
        ARRAY( SELECT STRUCT(JSON_VALUE(cur_data,'$.category') AS category,
          JSON_VALUE(cur_data,'$.discount') AS discount,
          JSON_VALUE(cur_data,'$.qty') AS qty,
          JSON_VALUE(cur_data,'$.mcat') AS mcat,
          JSON_VALUE(cur_data,'$.id') AS id,
          JSON_VALUE(cur_data,'$.sku') AS sku,
          JSON_VALUE(cur_data,'$.name') AS name,
          JSON_VALUE(cur_data,'$.offer') AS offer,
          JSON_VALUE(cur_data,'$.line') AS line,
          JSON_VALUE(cur_data,'$.recurringPrice') AS recurringPrice,
          JSON_VALUE(cur_data,'$.nonRecurringPrice') AS nonRecurringPrice) 
         FROM UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, "$.product.current")) cur_data) as `current`
) as product,
JSON_VALUE(ibm_eventValue, "$.prod_name") AS  prod_name,
JSON_VALUE(ibm_eventValue, "$.url") AS  url,
JSON_VALUE(ibm_eventValue, "$.webinteraction_url") AS  webinteraction_url,
    ARRAY(SELECT STRUCT(JSON_VALUE(prd_list,'$.item_meta') AS item_meta,
    JSON_VALUE(prd_list,'$.item_sku') AS item_sku,
    JSON_VALUE(prd_list,'$.product_id') AS product_id
    ) FROM UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, "$.product_list")) prd_list) as product_list,

ARRAY(SELECT STRUCT(JSON_VALUE(own,'$.category') AS category,
JSON_VALUE(own,'$.mcat') AS mcat,
JSON_VALUE(own,'$.id') AS id,
JSON_VALUE(own,'$.sku') AS sku,
JSON_VALUE(own,'$.name') AS name,
JSON_VALUE(own,'$.offer') AS offer) FROM 
UNNEST(JSON_EXTRACT_ARRAY(ibm_eventValue, "$.owns")) as own 
) as owns
) ibm_eventValue,
--df column list
df_keyName,
df_keyValue,
df_eventTimestamp,
df_eventName,
df_eventCat,
STRUCT(
    JSON_VALUE(df_eventValue, "$.event_name") AS event_name,
    JSON_VALUE(df_eventValue, "$.event_ts") AS event_ts,
    JSON_VALUE(df_eventValue, "$.rpt_mth") AS rpt_mth,
    JSON_VALUE(df_eventValue, "$.device_info") AS device_info,
    JSON_VALUE(df_eventValue, "$.target") AS target,
    JSON_VALUE(df_eventValue, "$.webref_url") AS webref_url,
    JSON_VALUE(df_eventValue, "$.prevPageName") AS prevPageName,
    JSON_VALUE(df_eventValue, "$.cmp") AS cmp,
    JSON_VALUE(df_eventValue, "$.eventType") AS eventType,
    STRUCT(
      JSON_VALUE(df_eventValue, "$.user.zip") AS  zip,
      JSON_VALUE(df_eventValue, "$.user.tenure") AS  tenure,
      JSON_VALUE(df_eventValue, "$.user.authStatus") AS  authStatus,
      JSON_VALUE(df_eventValue, "$.user.accountType") AS  accountType,
      JSON_VALUE(df_eventValue, "$.user.customerRole") AS  customerRole,
      JSON_VALUE(df_eventValue, "$.user.customerType") AS  customerType,
      JSON_VALUE(df_eventValue, "$.user.geo_country") AS  geo_country,
      JSON_VALUE(df_eventValue, "$.user.geo_state") AS  geo_state,
      JSON_VALUE(df_eventValue, "$.user.geo_city") AS  geo_city,
      JSON_VALUE(df_eventValue, "$.user.geo_postalcode") AS  geo_postalcode,
      JSON_VALUE(df_eventValue, "$.user.geo_Dma") AS  geo_Dma,
      JSON_VALUE(df_eventValue, "$.user.target_offer_id") AS  target_offer_id
) AS user,
STRUCT(
  JSON_VALUE(df_eventValue, "$.search.term") AS  term,
  JSON_VALUE(df_eventValue, "$.search.type") AS  type
) AS `search`,
STRUCT(
  JSON_VALUE(df_eventValue, "$.page.channel_session") AS  channel_session,
  JSON_VALUE(df_eventValue, "$.page.name") AS  name,
  JSON_VALUE(df_eventValue, "$.page.detail") AS  detail,
  JSON_VALUE(df_eventValue, "$.page.link") AS  link,
  JSON_VALUE(df_eventValue, "$.page.flow") AS  flow,
  JSON_VALUE(df_eventValue, "$.page.subFlow") AS  subFlow
) AS page,
STRUCT(
        ARRAY( SELECT STRUCT(JSON_VALUE(cur_data,'$.category') AS category,
          JSON_VALUE(cur_data,'$.discount') AS discount,
          JSON_VALUE(cur_data,'$.qty') AS qty,
          JSON_VALUE(cur_data,'$.mcat') AS mcat,
          JSON_VALUE(cur_data,'$.id') AS id,
          JSON_VALUE(cur_data,'$.sku') AS sku,
          JSON_VALUE(cur_data,'$.name') AS name,
          JSON_VALUE(cur_data,'$.offer') AS offer,
          JSON_VALUE(cur_data,'$.line') AS line,
          JSON_VALUE(cur_data,'$.recurringPrice') AS recurringPrice,
          JSON_VALUE(cur_data,'$.nonRecurringPrice') AS nonRecurringPrice) 
         FROM UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, "$.product.current")) cur_data) as `current`
) as product,
JSON_VALUE(df_eventValue, "$.prod_name") AS  prod_name,
JSON_VALUE(df_eventValue, "$.url") AS  url,
JSON_VALUE(df_eventValue, "$.webinteraction_url") AS  webinteraction_url,
    ARRAY(SELECT STRUCT(JSON_VALUE(prd_list,'$.item_meta') AS item_meta,
    JSON_VALUE(prd_list,'$.item_sku') AS item_sku,
    JSON_VALUE(prd_list,'$.product_id') AS product_id
    ) FROM UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, "$.product_list")) prd_list) as product_list,

ARRAY(SELECT STRUCT(JSON_VALUE(own,'$.category') AS category,
JSON_VALUE(own,'$.mcat') AS mcat,
JSON_VALUE(own,'$.id') AS id,
JSON_VALUE(own,'$.sku') AS sku,
JSON_VALUE(own,'$.name') AS name,
JSON_VALUE(own,'$.offer') AS offer) FROM 
UNNEST(JSON_EXTRACT_ARRAY(df_eventValue, "$.owns")) as own 
) as owns
) df_eventValue,
key_match,
field_match,
cmp_status,
process_hr,
process_dt
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_monthly`