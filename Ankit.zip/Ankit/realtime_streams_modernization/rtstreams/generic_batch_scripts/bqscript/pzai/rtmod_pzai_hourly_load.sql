CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_pzai_runcomparedata`()
Begin

DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V STRING;
DECLARE PROCESS_END_TS_V STRING;
DECLARE CUR_EST_TS TIMESTAMP;


SET CUR_EST_TS = CAST(DATETIME(CURRENT_TIMESTAMP(),'America/New_York') AS TIMESTAMP);
SET JOBNAME_V = 'PZAI';
SET CURR_DATE_V = DATE(CUR_EST_TS);
SET CURR_HR_V = EXTRACT(HOUR FROM(CUR_EST_TS));

SET PROCESS_START_TS_V = concat(cast(EXTRACT(DATE FROM TIMESTAMP_SUB(CUR_EST_TS, INTERVAL 2 HOUR)) as string), ' ',lpad(cast(EXTRACT(HOUR FROM TIMESTAMP_SUB(CUR_EST_TS, INTERVAL 2 HOUR)) as string),2,'0'),':00:00');
SET PROCESS_END_TS_V = concat(cast(EXTRACT(DATE FROM TIMESTAMP_SUB(CUR_EST_TS, INTERVAL 2 HOUR)) as string), ' ',lpad(cast(EXTRACT(HOUR FROM TIMESTAMP_SUB(CUR_EST_TS, INTERVAL 2 HOUR)) as string),2,'0'),':59:59');
/*
Load Incremental DF data from pubsub raw table to raw table stg
*/

TRUNCATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg`;

SET MAX_TS = (SELECT MAX(last_load_ts) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_incrload_status`);

IF MAX_TS IS NULL THEN
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg` SELECT * FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw`;
ELSE
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg` SELECT * FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw` 
WHERE CREATED_TS > MAX_TS;
END IF;

DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_incrload_status` where jobname = JOBNAME_V;

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_incrload_status`(last_load_ts,jobname) 
SELECT MAX(CREATED_TS),JOBNAME_V FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg`;

TRUNCATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg`;

--single record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg` 
SELECT  
JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.keyName') keyName,
JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.keyValue') keyValue,
replace(JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.eventTimestamp'),'T',' ') as  eventTimestamp,
--JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.eventTimestamp') eventTimestamp,
JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.eventName') eventName,
JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.eventCat') eventCat,
JSON_VALUE(srcdata, '$.keyAttributes.Keyattributes.eventValue') eventValue,
0,
array_length(JSON_EXTRACT_ARRAY(srcdata,'$.keyAttributes.Keyattributes.eventValue.product.current')) as productCnt,
coalesce(JSON_VALUE(srcdata,'$.keyAttributes.Keyattributes.eventValue.product.search.term'),'') as searchTerm,  
array_length(JSON_EXTRACT_ARRAY(srcdata,'$.keyAttributes.Keyattributes.eventValue.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(srcdata,'$.keyAttributes.Keyattributes.eventValue.eventType'),'') as eventType,
coalesce(JSON_VALUE(srcdata,'$.keyAttributes.Keyattributes.eventValue.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(srcdata,'$.keyAttributes.Keyattributes.eventValue.target'),'') as target,
CURR_HR_V,
CURR_DATE_V,
current_timestamp() as CREATED_TS 
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg` where srcdata like '%"KeyAttributes%';

--plain json format
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg` 
SELECT
JSON_VALUE(srcdata, '$.keyName') keyName,
JSON_VALUE(srcdata, '$.keyValue') keyValue,
replace(JSON_VALUE(srcdata, '$.eventTimestamp'),'T',' ') as  eventTimestamp,
--JSON_VALUE(srcdata, '$.eventTimestamp') eventTimestamp,
JSON_VALUE(srcdata, '$.eventName') eventName,
JSON_VALUE(srcdata, '$.eventCat') eventCat,
eventValue,
0,
array_length(JSON_EXTRACT_ARRAY(eventValue,'$.product.current')) as productCnt,
coalesce(JSON_VALUE(eventValue,'$.product.search.term'),'') as searchTerm,
array_length(JSON_EXTRACT_ARRAY(eventValue,'$.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(eventValue,'$.eventType'),'') as eventType,
coalesce(JSON_VALUE(eventValue,'$.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(eventValue,'$.target'),'') as target,
CURR_HR_V,
CURR_DATE_V,
current_timestamp() as CREATED_TS
from 
(select srcdata,JSON_VALUE(srcdata,'$.eventValue') as eventValue from
`vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg` where NOT (srcdata LIKE '%KeyAttributes%' OR srcdata LIKE '%listKeyAttributes%')) A;



--multiple record
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg` 
with t2 as (
with t1 as (
  select regexp_replace(regexp_replace(srcdata,'"eventValue":"','"eventValue":'),'"}}"', '"}}') as srcdata from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_raw_stg` where srcdata like '%listKeyAttributes%')
select JSON_VALUE(srcdata, '$.requestType') as requestType,eventdata from t1,UNNEST(JSON_EXTRACT_ARRAY(srcdata,"$.listKeyAttributes")) eventdata)
select JSON_VALUE(eventdata, '$.keyName') as  keyName, JSON_VALUE(eventdata, '$.keyValue') as  keyValue,
replace(JSON_VALUE(eventdata, '$.eventTimestamp'),'T',' ') as  eventTimestamp,
JSON_VALUE(eventdata, '$.eventName') as  eventName,
JSON_VALUE(eventdata, '$.eventCat') as  eventCat,
JSON_QUERY(eventdata, '$.eventValue') as  eventValue,
0,
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.current')) as productCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.product.search.term'),'') as searchTerm,  
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.eventType'),'') as eventType,
coalesce(JSON_VALUE(eventdata,'$.eventValue.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(eventdata,'$.eventValue.target'),'') as target,
CURR_HR_V,
CURR_DATE_V,
current_timestamp() as created_ts from t2;


/*
Load IBM Pipeline data - start
*/
TRUNCATE TABLE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg`;

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg` 
with t5 as (
with t4 as (
with t3 as (
with t2 as (
with t1 as(
select split(split(REPLACE(srcdata,'\\',''),'|')[1],'{"requestType":') as reqtype 
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw_stg`
) 
select concat('{"requestType":', rdata) as rdata1 from t1, unnest(reqtype) rdata where rdata != '')
select case when REGEXP_CONTAINS(rdata1,'{"status":{"code":"200"') then rtrim(split(rdata1,'{"status":{"code":"200"')[0],'","') else rtrim(rdata1,'","') end as rdata2 from t2)
select regexp_replace(regexp_replace(rdata2,'"eventValue":"','"eventValue":'),'","mtn"', ',"mtn"') as requesttype from t3)
select JSON_VALUE(requesttype, '$.requestType') as requestType,eventdata from t4,UNNEST(JSON_EXTRACT_ARRAY(requesttype,"$.listKeyAttributes")) eventdata)
select JSON_VALUE(eventdata, '$.keyName') as  keyName, JSON_VALUE(eventdata, '$.keyValue') as  keyValue,
JSON_VALUE(eventdata, '$.eventTimestamp') as  eventTimestamp,
JSON_VALUE(eventdata, '$.eventName') as  eventName,
JSON_VALUE(eventdata, '$.eventCat') as  eventCat,
JSON_QUERY(eventdata, '$.eventValue') as  eventValue,
0,
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.current')) as productCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.product.search.term'),'') as searchTerm,  
array_length(JSON_EXTRACT_ARRAY(eventdata,'$.eventValue.product.owns')) as ownsCnt,
coalesce(JSON_VALUE(eventdata,'$.eventValue.eventType'),'') as eventType,
coalesce(JSON_VALUE(eventdata,'$.eventValue.rpt_mth'),'') as rptMth,
coalesce(JSON_VALUE(eventdata,'$.eventValue.target'),'') as target,
CURR_HR_V,
CURR_DATE_V,
current_timestamp() as created_ts from t5;

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw` (srcdata) 
SELECT srcdata FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_raw_stg`;


DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where process_hr = CURR_HR_V and process_dt = CURR_DATE_V;

--SET IBM_TOTAL_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg`);
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` 
select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event_stg`;


DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where process_hr = CURR_HR_V and process_dt = CURR_DATE_V;

--SET DF_TOTAL_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg`);
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` 
select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event_stg`;


/*
Compare table data process
*/


DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/

INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp`  
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
CURR_HR_V as PROCESS_HR,
CURR_DATE_V as PROCESS_DT 
from 
(select 
t1.keyName as ibm_keyName,
t1.keyValue as ibm_keyValue,
t1.eventTimestamp as ibm_eventTimestamp,
t1.eventName as ibm_eventName,
t1.eventCat as ibm_eventCat,
t1.eventValue as ibm_eventValue,
t1.productCnt as ibm_productCnt,
t1.searchTerm as ibm_searchTerm,
t1.ownsCnt as ibm_ownsCnt,
t1.eventType as ibm_eventType,
t1.rptMth as ibm_rptMth,
t1.target as ibm_target,

t2.keyName as df_keyName,
t2.keyValue as df_keyValue,
t2.eventTimestamp as df_eventTimestamp,
t2.eventName as df_eventName,
t2.eventCat as df_eventCat,
t2.eventValue as df_eventValue,
t2.productCnt as df_productCnt,
t2.searchTerm as df_searchTerm,
t2.ownsCnt as df_ownsCnt,
t2.eventType as df_eventType,
t2.rptMth as df_rptMth,
t2.target as df_target,

case 
  when trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
  then 1 else 0 end key_match,
case 
  when t1.productCnt = t2.productCnt
   and trim(t1.searchTerm) = trim(t2.searchTerm)
   and t1.ownsCnt = t2.ownsCnt
   and t1.eventType = t2.eventType
   and trim(t1.rptMth) = trim(t2.rptMth)
   and trim(t1.target) = trim(t2.target)
  then 1 else 0 end as field_match
from 
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where eventTimestamp > PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t1 
full outer join 
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where eventTimestamp > PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V) t2
on trim(t1.keyName) = trim(t2.keyName) 
   and trim(t1.keyValue) = trim(t2.keyValue) 
   and trim(t1.eventTimestamp) = trim(t2.eventTimestamp)
   and trim(t1.eventName) = trim(t2.eventName)
   and trim(t1.eventCat) = trim(t2.eventCat)
) A;


SET IBM_TOTAL_CNT_V = (select COUNT(*) from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_ibm_event` where eventTimestamp > PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V);

SET DF_TOTAL_CNT_V = (select COUNT(*) from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_df_event` where eventTimestamp > PROCESS_START_TS_V and eventTimestamp <= PROCESS_END_TS_V);

SET MATCH_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp` WHERE cmp_status = 2);

SET UNMATCH_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp` WHERE cmp_status = 1);

SET IBM_UNMATCH_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp` WHERE cmp_status = 0 AND (ibm_keyName IS NOT NULL 
AND ibm_keyValue IS NOT NULL AND ibm_eventTimestamp IS NOT NULL AND ibm_eventName IS NOT NULL AND ibm_eventCat IS NOT NULL));

SET DF_UNMATCH_CNT_V = (SELECT COUNT(*) FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp` WHERE cmp_status = 0 AND (df_keyName IS NOT NULL 
AND df_keyValue IS NOT NULL AND df_eventTimestamp IS NOT NULL AND df_eventName IS NOT NULL AND df_eventCat IS NOT NULL));

--Delete and load into the event metrics table for the specific hour
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = PROCESS_START_TS_V AND PROCESS_END_TS = PROCESS_END_TS_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` 
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'HOURLY',PROCESS_START_TS_V,PROCESS_END_TS_V,CAST(DATETIME(CURRENT_TIMESTAMP(),'America/New_York') AS TIMESTAMP));


--Delete and load into the event detail table for the specific hour
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp` where PROCESS_HR = CURR_HR_V and PROCESS_DT = CURR_DATE_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp` 
SELECT * FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_pzai_event_cmp_tmp`;

End;