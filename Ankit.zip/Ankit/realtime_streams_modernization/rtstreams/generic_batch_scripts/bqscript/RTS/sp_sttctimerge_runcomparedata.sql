CREATE OR REPLACE PROCEDURE `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.sp_sttctimerge_runcomparedata`(PROCESS_DT_V STRING)
Begin
DECLARE MATCH_CNT_V INT64;
DECLARE UNMATCH_CNT_V INT64;
DECLARE IBM_UNMATCH_CNT_V INT64;
DECLARE DF_UNMATCH_CNT_V INT64;
DECLARE IBM_TOTAL_CNT_V INT64;
DECLARE DF_TOTAL_CNT_V INT64;
DECLARE CURR_DATE_V DATE;
DECLARE CURR_HR_V INT64;
DECLARE MAX_TS TIMESTAMP;
DECLARE JOBNAME_V STRING;
DECLARE PROCESS_START_TS_V TIMESTAMP;
DECLARE PROCESS_END_TS_V TIMESTAMP;
DECLARE CUR_EST_TS TIMESTAMP;
SET PROCESS_START_TS_V = SAFE_CAST(CONCAT(PROCESS_DT_V,' 00:00:00') AS TIMESTAMP);
SET PROCESS_END_TS_V = SAFE_CAST(CONCAT(PROCESS_DT_V,' 23:59:59') AS TIMESTAMP);
SET CURR_DATE_V = DATE(PROCESS_DT_V);
SET CURR_HR_V = -1;
SET JOBNAME_V = 'STT_CTIMERGE';


--df data
truncate table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_raw_stg`;
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_raw_stg`
select * from (SELECT data, current_timestamp() as CREATED_TS FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_raw`) B where date(timestamp_seconds(SAFE_CAST(JSON_VALUE(data, '$.callEstablishedTime') as integer))) = CURR_DATE_V;
delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` where date(timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER))) = CURR_DATE_V;
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event`
SELECT
JSON_VALUE(srcdata, '$.DACCCD') DACCCD,
JSON_VALUE(srcdata, '$.ServiceRegionID') ServiceRegionID,
JSON_VALUE(srcdata, '$.SACC') SACC,
JSON_VALUE(srcdata, '$.acssValidationCode') acssValidationCode,
JSON_VALUE(srcdata, '$.OldAccountNo') OldAccountNo,
JSON_VALUE(srcdata, '$.obxBtn') obxBtn,
JSON_VALUE(srcdata, '$.AccountContactNumber') AccountContactNumber,
SAFE_CAST(JSON_VALUE(srcdata, '$.captureSeconds') AS INTEGER) captureSeconds,
JSON_VALUE(srcdata, '$.TotalMtnCount') TotalMtnCount,
JSON_VALUE(srcdata, '$.LanguageInd') LanguageInd,
SAFE_CAST(JSON_VALUE(srcdata, '$.timezoneOffset') AS INTEGER) timezoneOffset,
JSON_VALUE(srcdata, '$.VZBTN') VZBTN,
JSON_VALUE(srcdata, '$.rcHotline') rcHotline,
JSON_VALUE(srcdata, '$.utterance') utterance,
JSON_VALUE(srcdata, '$.failedDialCountInter') failedDialCountInter,
JSON_VALUE(srcdata, '$.agentid') agentid,
JSON_VALUE(srcdata, '$.CtiPopSeqNum') CtiPopSeqNum,
JSON_VALUE(srcdata, '$.Make') Make,
JSON_VALUE(srcdata, '$.CustomerId') CustomerId,
JSON_VALUE(srcdata, '$.CustomerType') CustomerType,
JSON_VALUE(srcdata, '$.failedDialCountIVR') failedDialCountIVR,
JSON_VALUE(srcdata, '$.ObxData') ObxData,
JSON_VALUE(srcdata, '$.GroupIDTiecode') GroupIDTiecode,
JSON_VALUE(srcdata, '$.BillAccountContactNumber') BillAccountContactNumber,
JSON_VALUE(srcdata, '$.ctiCallStartTime') ctiCallStartTime,
JSON_VALUE(srcdata, '$.ECPDID') ECPDID,
JSON_VALUE(srcdata, '$.AccountName') AccountName,
JSON_VALUE(srcdata, '$.role') role,
JSON_VALUE(srcdata, '$.AgentExtension') AgentExtension,
JSON_VALUE(srcdata, '$.OwningRegionId') OwningRegionId,
SAFE_CAST(JSON_VALUE(srcdata, '$.droppedPackets') AS INTEGER) droppedPackets,
JSON_VALUE(srcdata, '$.CustomerClassCode') CustomerClassCode,
JSON_VALUE(srcdata, '$.ivrAni') ivrAni,
JSON_VALUE(srcdata, '$.MDNCount') MDNCount,
JSON_VALUE(srcdata, '$.IvrCallMdn') IvrCallMdn,
JSON_VALUE(srcdata, '$.obxCode') obxCode,
JSON_VALUE(srcdata, '$.CallDataSrcCallID') CallDataSrcCallID,
JSON_VALUE(srcdata, '$.ACSSID') ACSSID,
JSON_VALUE(srcdata, '$.IMSIVF') IMSIVF,
JSON_VALUE(srcdata, '$.callId') callId,
JSON_VALUE(srcdata, '$.EUIMID') EUIMID,
JSON_VALUE(srcdata, '$.CallDataCallEndTimeStamp') CallDataCallEndTimeStamp,
JSON_VALUE(srcdata, '$.BillAcctStatus') BillAcctStatus,
JSON_VALUE(srcdata, '$.outboundtype') outboundtype,
JSON_VALUE(srcdata, '$.CustStatus') CustStatus,
JSON_VALUE(srcdata, '$.utteranceConfidence') utteranceConfidence,
JSON_VALUE(srcdata, '$.CallDataACDCallID') CallDataACDCallID,
JSON_VALUE(srcdata, '$.transferReasonCode') transferReasonCode,
JSON_VALUE(srcdata, '$.destDeptCode') destDeptCode,
JSON_VALUE(srcdata, '$.BillCycleNumber') BillCycleNumber,
JSON_VALUE(srcdata, '$.CustomerStatus') CustomerStatus,
JSON_VALUE(srcdata, '$.dialCountIVR') dialCountIVR,
JSON_VALUE(srcdata, '$.Model') Model,
JSON_VALUE(srcdata, '$.BillTypeCode') BillTypeCode,
JSON_VALUE(srcdata, '$.BillAccountName') BillAccountName,
TO_JSON_STRING(JSON_EXTRACT(srcdata, '$.utteranceTokenConfidences')) AS utteranceTokenConfidences,
JSON_VALUE(srcdata, '$.BillingSystem') BillingSystem,
JSON_VALUE(srcdata, '$.MDNName') MDNName,
JSON_VALUE(srcdata, '$.ctiCall_Event_Type') ctiCall_Event_Type,
JSON_VALUE(srcdata, '$.CustomerContactNumber') CustomerContactNumber,
JSON_VALUE(srcdata, '$.callDispositionInd') callDispositionInd,
JSON_VALUE(srcdata, '$.ctiCallDisconnectTime') ctiCallDisconnectTime,
JSON_VALUE(srcdata, '$.Mtn') Mtn,
JSON_VALUE(srcdata, '$.NumOfAccts') NumOfAccts,
JSON_VALUE(srcdata, '$.InsertFlag') InsertFlag,
JSON_VALUE(srcdata, '$.CustOrigSetupDate') CustOrigSetupDate,
JSON_VALUE(srcdata, '$.OldBillingSystem') OldBillingSystem,
JSON_VALUE(srcdata, '$.CallDataContactName') CallDataContactName,
JSON_VALUE(srcdata, '$.dialCountInter') dialCountInter,
JSON_VALUE(srcdata, '$.ivrValidation') ivrValidation,
JSON_VALUE(srcdata, '$.ivrLanguage') ivrLanguage,
JSON_VALUE(srcdata, '$.Mdn') Mdn,
JSON_VALUE(srcdata, '$.failedDialCountIntra') failedDialCountIntra,
JSON_VALUE(srcdata, '$.MDNContactNumber') MDNContactNumber,
JSON_VALUE(srcdata, '$.xferTFN') xferTFN,
JSON_VALUE(srcdata, '$.ivrAniNumber') ivrAniNumber,
JSON_VALUE(srcdata, '$.inboundOutboundCallType') inboundOutboundCallType,
JSON_VALUE(srcdata, '$.transferReasonDesc') transferReasonDesc,
JSON_VALUE(srcdata, '$.confCount') confCount,
JSON_VALUE(srcdata, '$.CTICallDataCallType') CTICallDataCallType,
JSON_VALUE(srcdata, '$.ServiceName') ServiceName,
JSON_VALUE(srcdata, '$.SIM') SIM,
JSON_VALUE(srcdata, '$.ivrcallid') ivrcallid,
JSON_VALUE(srcdata, '$.CallID') callID_1,
SAFE_CAST(JSON_VALUE(srcdata, '$.speakerId') AS NUMERIC) speakerId,
JSON_VALUE(srcdata, '$.callControlId') callControlId,
JSON_VALUE(srcdata, '$.acss_id') acss_id,
JSON_VALUE(srcdata, '$.sourceappid') sourceappid,
JSON_VALUE(srcdata, '$.MDNStatus') MDNStatus,
JSON_VALUE(srcdata, '$.DepartmentID') DepartmentID,
JSON_VALUE(srcdata, '$.CustomerName') CustomerName,
JSON_VALUE(srcdata, '$.ani') ani,
JSON_VALUE(srcdata, '$.callCenter') callCenter,
SAFE_CAST(JSON_VALUE(srcdata, '$.transcriptionCompleted') AS BOOLEAN) transcriptionCompleted,
JSON_VALUE(srcdata, '$.VZEXTN') VZEXTN,
JSON_VALUE(srcdata, '$.CallDataCallType') CallDataCallType,
JSON_VALUE(srcdata, '$.DeviceID') DeviceID,
JSON_VALUE(srcdata, '$.ZipCode') ZipCode,
JSON_VALUE(srcdata, '$.PriceplanId') PriceplanId,
JSON_VALUE(srcdata, '$.CallDataTimeStamp') CallDataTimeStamp,
JSON_VALUE(srcdata, '$.IMEI') IMEI,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceNumber') AS INTEGER) utteranceNumber,
SAFE_CAST(JSON_VALUE(srcdata, '$.lowQualityChannel') AS INTEGER) lowQualityChannel,
JSON_VALUE(srcdata, '$.acdCallId') acdCallId,
JSON_VALUE(srcdata, '$.BillAccountNumber') BillAccountNumber,
Floor(SAFE_CAST(JSON_VALUE(srcdata, '$.callEstablishedTime') AS FLOAT64)) CallEstablishedTime,
JSON_VALUE(srcdata, '$.OBPPEnrollCode') OBPPEnrollCode,
JSON_VALUE(srcdata, '$.CallDataContactType') CallDataContactType,
JSON_VALUE(srcdata, '$.transferReasonCodes') transferReasonCodes,
JSON_VALUE(srcdata, '$.SKU') SKU,
JSON_VALUE(srcdata, '$.dialCount') dialCount,
JSON_VALUE(srcdata, '$.acssCallIdOnXfer') acssCallIdOnXfer,
JSON_VALUE(srcdata, '$.EffectiveDate') EffectiveDate,
JSON_VALUE(srcdata, '$.CallDataContactValidation') CallDataContactValidation,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceStartTime') AS FLOAT64) as utteranceStartTime,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceEndTime') AS FLOAT64) as utteranceEndTime,
"0" as process_hr,
PROCESS_DT_V as process_dt,
current_timestamp() as CREATED_TS
from
(select data as srcdata from
`vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_raw_stg`) A;

--End df data

--IBM data parse

--truncate table `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_raw_stg`;
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_raw`
select * from (SELECT srcdata, current_timestamp() as created_ts FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_raw_stg`) B;
delete from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` where date(timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER))) = CURR_DATE_V;
insert into `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event`
SELECT
JSON_VALUE(srcdata, '$.dacccd') DACCCD,
JSON_VALUE(srcdata, '$.serviceRegionID') ServiceRegionID,
JSON_VALUE(srcdata, '$.sacc') SACC,
JSON_VALUE(srcdata, '$.acssValidationCode') acssValidationCode,
JSON_VALUE(srcdata, '$.oldAccountNo') OldAccountNo,
JSON_VALUE(srcdata, '$.obxBtn') obxBtn,
JSON_VALUE(srcdata, '$.accountContactNumber') AccountContactNumber,
SAFE_CAST(JSON_VALUE(srcdata, '$.captureSeconds') AS INTEGER) captureSeconds,
JSON_VALUE(srcdata, '$.totalMtnCount') TotalMtnCount,
JSON_VALUE(srcdata, '$.languageInd') LanguageInd,
SAFE_CAST(JSON_VALUE(srcdata, '$.timezoneOffset') AS INTEGER) timezoneOffset,
JSON_VALUE(srcdata, '$.vzbtn') VZBTN,
JSON_VALUE(srcdata, '$.rcHotline') rcHotline,
JSON_VALUE(srcdata, '$.utterance') utterance,
JSON_VALUE(srcdata, '$.failedDialCountInter') failedDialCountInter,
JSON_VALUE(srcdata, '$.agentid') agentid,
JSON_VALUE(srcdata, '$.ctiPopSeqNum') CtiPopSeqNum,
JSON_VALUE(srcdata, '$.make') Make,
JSON_VALUE(srcdata, '$.customerId') CustomerId,
JSON_VALUE(srcdata, '$.customerType') CustomerType,
JSON_VALUE(srcdata, '$.failedDialCountIVR') failedDialCountIVR,
JSON_VALUE(srcdata, '$.obxData') ObxData,
JSON_VALUE(srcdata, '$.groupIDTiecode') GroupIDTiecode,
JSON_VALUE(srcdata, '$.billAccountContactNumber') BillAccountContactNumber,
JSON_VALUE(srcdata, '$.ctiCallStartTime') ctiCallStartTime,
JSON_VALUE(srcdata, '$.ecpdid') ECPDID,
JSON_VALUE(srcdata, '$.accountName') AccountName,
JSON_VALUE(srcdata, '$.role') role,
JSON_VALUE(srcdata, '$.agentExtension') AgentExtension,
JSON_VALUE(srcdata, '$.owningRegionId') OwningRegionId,
SAFE_CAST(JSON_VALUE(srcdata, '$.droppedPackets') AS INTEGER) droppedPackets,
JSON_VALUE(srcdata, '$.customerClassCode') CustomerClassCode,
JSON_VALUE(srcdata, '$.ivrAni') ivrAni,
JSON_VALUE(srcdata, '$.mdnCount') MDNCount,
JSON_VALUE(srcdata, '$.ivrCallMdn') IvrCallMdn,
JSON_VALUE(srcdata, '$.obxCode') obxCode,
JSON_VALUE(srcdata, '$.callDataSrcCallID') CallDataSrcCallID,
JSON_VALUE(srcdata, '$.acssid') ACSSID,
JSON_VALUE(srcdata, '$.imsivf') IMSIVF,
JSON_VALUE(srcdata, '$.callId') callId,
JSON_VALUE(srcdata, '$.euimid') EUIMID,
JSON_VALUE(srcdata, '$.callDataCallEndTimeStamp') CallDataCallEndTimeStamp,
JSON_VALUE(srcdata, '$.billAcctStatus') BillAcctStatus,
JSON_VALUE(srcdata, '$.outboundtype') outboundtype,
JSON_VALUE(srcdata, '$.custStatus') CustStatus,
JSON_VALUE(srcdata, '$.utteranceConfidence') utteranceConfidence,
JSON_VALUE(srcdata, '$.callDataACDCallID') CallDataACDCallID,
JSON_VALUE(srcdata, '$.transferReasonCode') transferReasonCode,
JSON_VALUE(srcdata, '$.destDeptCode') destDeptCode,
JSON_VALUE(srcdata, '$.billCycleNumber') BillCycleNumber,
JSON_VALUE(srcdata, '$.customerStatus') CustomerStatus,
JSON_VALUE(srcdata, '$.dialCountIVR') dialCountIVR,
JSON_VALUE(srcdata, '$.model') Model,
JSON_VALUE(srcdata, '$.billTypeCode') BillTypeCode,
JSON_VALUE(srcdata, '$.billAccountName') BillAccountName,
REPLACE(TO_JSON_STRING(JSON_EXTRACT(srcdata, '$.utteranceTokenConfidences')), '"', '') AS utteranceTokenConfidences,
JSON_VALUE(srcdata, '$.billingSystem') BillingSystem,
JSON_VALUE(srcdata, '$.mdnname') MDNName,
JSON_VALUE(srcdata, '$.ctiCall_Event_Type') ctiCall_Event_Type,
JSON_VALUE(srcdata, '$.customerContactNumber') CustomerContactNumber,
JSON_VALUE(srcdata, '$.callDispositionInd') callDispositionInd,
JSON_VALUE(srcdata, '$.ctiCallDisconnectTime') ctiCallDisconnectTime,
JSON_VALUE(srcdata, '$.mtn') Mtn,
JSON_VALUE(srcdata, '$.numOfAccts') NumOfAccts,
JSON_VALUE(srcdata, '$.insertFlag') InsertFlag,
JSON_VALUE(srcdata, '$.custOrigSetupDate') CustOrigSetupDate,
JSON_VALUE(srcdata, '$.oldBillingSystem') OldBillingSystem,
JSON_VALUE(srcdata, '$.callDataContactName') CallDataContactName,
JSON_VALUE(srcdata, '$.dialCountInter') dialCountInter,
JSON_VALUE(srcdata, '$.ivrValidation') ivrValidation,
JSON_VALUE(srcdata, '$.ivrLanguage') ivrLanguage,
JSON_VALUE(srcdata, '$.mdn') Mdn,
JSON_VALUE(srcdata, '$.failedDialCountIntra') failedDialCountIntra,
JSON_VALUE(srcdata, '$.MDNContactNumber') MDNContactNumber,
JSON_VALUE(srcdata, '$.xferTFN') xferTFN,
JSON_VALUE(srcdata, '$.ivrAniNumber') ivrAniNumber,
JSON_VALUE(srcdata, '$.inboundOutboundCallType') inboundOutboundCallType,
JSON_VALUE(srcdata, '$.transferReasonDesc') transferReasonDesc,
JSON_VALUE(srcdata, '$.confCount') confCount,
JSON_VALUE(srcdata, '$.cticallDataCallType') CTICallDataCallType,
JSON_VALUE(srcdata, '$.serviceName') ServiceName,
JSON_VALUE(srcdata, '$.sim') SIM,
JSON_VALUE(srcdata, '$.ivrcallid') ivrcallid,
JSON_VALUE(srcdata, '$.callID') callID_1,
SAFE_CAST(JSON_VALUE(srcdata, '$.speakerId') AS NUMERIC) speakerId,
JSON_VALUE(srcdata, '$.callControlId') callControlId,
JSON_VALUE(srcdata, '$.acss_id') acss_id,
JSON_VALUE(srcdata, '$.sourceappid') sourceappid,
JSON_VALUE(srcdata, '$.mdnstatus') MDNStatus,
JSON_VALUE(srcdata, '$.departmentID') DepartmentID,
JSON_VALUE(srcdata, '$.customerName') CustomerName,
JSON_VALUE(srcdata, '$.ani') ani,
JSON_VALUE(srcdata, '$.callCenter') callCenter,
SAFE_CAST(JSON_VALUE(srcdata, '$.transcriptionCompleted') AS BOOLEAN) transcriptionCompleted,
JSON_VALUE(srcdata, '$.vzextn') VZEXTN,
JSON_VALUE(srcdata, '$.callDataCallType') CallDataCallType,
JSON_VALUE(srcdata, '$.deviceID') DeviceID,
JSON_VALUE(srcdata, '$.zipCode') ZipCode,
JSON_VALUE(srcdata, '$.priceplanId') PriceplanId,
JSON_VALUE(srcdata, '$.callDataTimeStamp') CallDataTimeStamp,
JSON_VALUE(srcdata, '$.imei') IMEI,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceNumber') AS INTEGER) utteranceNumber,
SAFE_CAST(JSON_VALUE(srcdata, '$.lowQualityChannel') AS INTEGER) lowQualityChannel,
JSON_VALUE(srcdata, '$.acdCallId') acdCallId,
JSON_VALUE(srcdata, '$.billAccountNumber') BillAccountNumber,
Floor(SAFE_CAST(JSON_VALUE(srcdata, '$.CallEstablishedTime') AS FLOAT64)) CallEstablishedTime,
JSON_VALUE(srcdata, '$.obppenrollCode') OBPPEnrollCode,
JSON_VALUE(srcdata, '$.callDataContactType') CallDataContactType,
JSON_VALUE(srcdata, '$.transferReasonCodes') transferReasonCodes,
JSON_VALUE(srcdata, '$.sku') SKU,
JSON_VALUE(srcdata, '$.dialCount') dialCount,
JSON_VALUE(srcdata, '$.acssCallIdOnXfer') acssCallIdOnXfer,
JSON_VALUE(srcdata, '$.effectiveDate') EffectiveDate,
JSON_VALUE(srcdata, '$.callDataContactValidation') CallDataContactValidation,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceStartTime') AS FLOAT64) as utteranceStartTime,
SAFE_CAST(JSON_VALUE(srcdata, '$.utteranceEndTime') AS FLOAT64) as utteranceEndTime,
"0" as process_hr,
PROCESS_DT_V as process_dt,
current_timestamp() as CREATED_TS
from
(select REPLACE(REPLACE(REPLACE(srcdata,'\\',''),'"{', '{'),'}"','}') as srcdata from
`vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_raw`) A where date(timestamp_seconds(SAFE_CAST(FLOOR(SAFE_CAST(JSON_VALUE(srcdata, '$.CallEstablishedTime') AS FLOAT64)) AS INTEGER))) = DATE(PROCESS_DT_V) ;
--end IBM data

/*
Compare table data process
*/
DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_event_cmp` where 1=1;
--CHANGE TO INSERT STATEMENT
/*
cmp_status = 0 - key not matched
cmp_status = 1 - key matched but fields values not matched
cmp_status = 2 - key and fields matched
*/
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_event_cmp`
select *,case when key_match = 0 then 0
when key_match = 1 and field_match = 0 then 1
when key_match = 1 and field_match = 1 then 2 end as cmp_status,
SAFE_CAST(CURR_HR_V as string) as PROCESS_HR,
PROCESS_DT_V as PROCESS_DT
from
(select
t1.DACCCD as ibm_DACCCD,
t1.ServiceRegionID as ibm_ServiceRegionID,
t1.SACC as ibm_SACC,
t1.acssValidationCode as ibm_acssValidationCode,
t1.OldAccountNo as ibm_OldAccountNo,
t1.obxBtn as ibm_obxBtn,
t1.AccountContactNumber as ibm_AccountContactNumber,
t1.captureSeconds as ibm_captureSeconds,
t1.TotalMtnCount as ibm_TotalMtnCount,
t1.LanguageInd as ibm_LanguageInd,
t1.timezoneOffset as ibm_timezoneOffset,
t1.VZBTN as ibm_VZBTN,
t1.rcHotline as ibm_rcHotline,
t1.utterance as ibm_utterance,
t1.failedDialCountInter as ibm_failedDialCountInter,
t1.utteranceStartTime as ibm_utteranceStartTime,
t1.agentid as ibm_agentid,
t1.CtiPopSeqNum as ibm_CtiPopSeqNum,
t1.Make as ibm_Make,
t1.CustomerId as ibm_CustomerId,
t1.CustomerType as ibm_CustomerType,
t1.failedDialCountIVR as ibm_failedDialCountIVR,
t1.ObxData as ibm_ObxData,
t1.GroupIDTiecode as ibm_GroupIDTiecode,
t1.BillAccountContactNumber as ibm_BillAccountContactNumber,
t1.ctiCallStartTime as ibm_ctiCallStartTime,
t1.ECPDID as ibm_ECPDID,
t1.AccountName as ibm_AccountName,
t1.role as ibm_role,
t1.AgentExtension as ibm_AgentExtension,
t1.OwningRegionId as ibm_OwningRegionId,
t1.droppedPackets as ibm_droppedPackets,
t1.CustomerClassCode as ibm_CustomerClassCode,
t1.ivrAni as ibm_ivrAni,
t1.MDNCount as ibm_MDNCount,
t1.IvrCallMdn as ibm_IvrCallMdn,
t1.obxCode as ibm_obxCode,
t1.CallDataSrcCallID as ibm_CallDataSrcCallID,
t1.ACSSID as ibm_ACSSID,
t1.callId as ibm_callId,
t1.CallDataCallEndTimeStamp as ibm_CallDataCallEndTimeStamp,
t1.BillAcctStatus as ibm_BillAcctStatus,
t1.outboundtype as ibm_outboundtype,
t1.CustStatus as ibm_CustStatus,
t1.utteranceConfidence as ibm_utteranceConfidence,
t1.CallDataACDCallID as ibm_CallDataACDCallID,
t1.transferReasonCode as ibm_transferReasonCode,
t1.destDeptCode as ibm_destDeptCode,
t1.BillCycleNumber as ibm_BillCycleNumber,
t1.CustomerStatus as ibm_CustomerStatus,
t1.dialCountIVR as ibm_dialCountIVR,
t1.Model as ibm_Model,
t1.BillTypeCode as ibm_BillTypeCode,
t1.BillAccountName as ibm_BillAccountName,
t1.utteranceTokenConfidences as ibm_utteranceTokenConfidences,
t1.BillingSystem as ibm_BillingSystem,
t1.MDNName as ibm_MDNName,
t1.ctiCall_Event_Type as ibm_ctiCall_Event_Type,
t1.IMSIVF as ibm_IMSIVF,
t1.EUIMID as ibm_EUIMID,
t1.CustomerContactNumber as ibm_CustomerContactNumber,
t1.callDispositionInd as ibm_callDispositionInd,
t1.ctiCallDisconnectTime as ibm_ctiCallDisconnectTime,
t1.Mtn as ibm_Mtn,
t1.NumOfAccts as ibm_NumOfAccts,
t1.InsertFlag as ibm_InsertFlag,
t1.CustOrigSetupDate as ibm_CustOrigSetupDate,
t1.OldBillingSystem as ibm_OldBillingSystem,
t1.CallDataContactName as ibm_CallDataContactName,
t1.dialCountInter as ibm_dialCountInter,
t1.ivrValidation as ibm_ivrValidation,
t1.ivrLanguage as ibm_ivrLanguage,
t1.Mdn as ibm_Mdn,
t1.failedDialCountIntra as ibm_failedDialCountIntra,
t1.MDNContactNumber as ibm_MDNContactNumber,
t1.xferTFN as ibm_xferTFN,
t1.ivrAniNumber as ibm_ivrAniNumber,
t1.inboundOutboundCallType as ibm_inboundOutboundCallType,
t1.transferReasonDesc as ibm_transferReasonDesc,
t1.confCount as ibm_confCount,
t1.CTICallDataCallType as ibm_CTICallDataCallType,
t1.ServiceName as ibm_ServiceName,
t1.SIM as ibm_SIM,
t1.ivrcallid as ibm_ivrcallid,
t1.utteranceEndTime as ibm_utteranceEndTime,
t1.callID_1 as ibm_callID_1,
t1.speakerId as ibm_speakerId,
t1.callControlId as ibm_callControlId,
t1.acss_id as ibm_acss_id,
t1.sourceappid as ibm_sourceappid,
t1.MDNStatus as ibm_MDNStatus,
t1.DepartmentID as ibm_DepartmentID,
t1.CustomerName as ibm_CustomerName,
t1.ani as ibm_ani,
t1.callCenter as ibm_callCenter,
t1.transcriptionCompleted as ibm_transcriptionCompleted,
t1.VZEXTN as ibm_VZEXTN,
t1.CallDataCallType as ibm_CallDataCallType,
t1.DeviceID as ibm_DeviceID,
t1.ZipCode as ibm_ZipCode,
t1.PriceplanId as ibm_PriceplanId,
t1.CallDataTimeStamp as ibm_CallDataTimeStamp,
t1.IMEI as ibm_IMEI,
t1.utteranceNumber as ibm_utteranceNumber,
t1.lowQualityChannel as ibm_lowQualityChannel,
t1.acdCallId as ibm_acdCallId,
t1.BillAccountNumber as ibm_BillAccountNumber,
t1.CallEstablishedTime as ibm_CallEstablishedTime,
t1.OBPPEnrollCode as ibm_OBPPEnrollCode,
t1.CallDataContactType as ibm_CallDataContactType,
t1.transferReasonCodes as ibm_transferReasonCodes,
t1.SKU as ibm_SKU,
t1.dialCount as ibm_dialCount,
t1.acssCallIdOnXfer as ibm_acssCallIdOnXfer,
t1.EffectiveDate as ibm_EffectiveDate,
t1.CallDataContactValidation as ibm_CallDataContactValidation,
t2.DACCCD as df_DACCCD,
t2.ServiceRegionID as df_ServiceRegionID,
t2.SACC as df_SACC,
t2.acssValidationCode as df_acssValidationCode,
t2.OldAccountNo as df_OldAccountNo,
t2.obxBtn as df_obxBtn,
t2.AccountContactNumber as df_AccountContactNumber,
t2.captureSeconds as df_captureSeconds,
t2.TotalMtnCount as df_TotalMtnCount,
t2.LanguageInd as df_LanguageInd,
t2.timezoneOffset as df_timezoneOffset,
t2.VZBTN as df_VZBTN,
t2.rcHotline as df_rcHotline,
t2.utterance as df_utterance,
t2.failedDialCountInter as df_failedDialCountInter,
t2.utteranceStartTime as df_utteranceStartTime,
t2.agentid as df_agentid,
t2.CtiPopSeqNum as df_CtiPopSeqNum,
t2.Make as df_Make,
t2.CustomerId as df_CustomerId,
t2.CustomerType as df_CustomerType,
t2.failedDialCountIVR as df_failedDialCountIVR,
t2.ObxData as df_ObxData,
t2.GroupIDTiecode as df_GroupIDTiecode,
t2.BillAccountContactNumber as df_BillAccountContactNumber,
t2.ctiCallStartTime as df_ctiCallStartTime,
t2.ECPDID as df_ECPDID,
t2.AccountName as df_AccountName,
t2.role as df_role,
t2.AgentExtension as df_AgentExtension,
t2.OwningRegionId as df_OwningRegionId,
t2.droppedPackets as df_droppedPackets,
t2.CustomerClassCode as df_CustomerClassCode,
t2.ivrAni as df_ivrAni,
t2.MDNCount as df_MDNCount,
t2.IvrCallMdn as df_IvrCallMdn,
t2.obxCode as df_obxCode,
t2.CallDataSrcCallID as df_CallDataSrcCallID,
t2.ACSSID as df_ACSSID,
t2.IMSIVF as df_IMSIVF,
t2.callId as df_callId,
t2.EUIMID as df_EUIMID,
t2.CallDataCallEndTimeStamp as df_CallDataCallEndTimeStamp,
t2.BillAcctStatus as df_BillAcctStatus,
t2.outboundtype as df_outboundtype,
t2.CustStatus as df_CustStatus,
t2.utteranceConfidence as df_utteranceConfidence,
t2.CallDataACDCallID as df_CallDataACDCallID,
t2.transferReasonCode as df_transferReasonCode,
t2.destDeptCode as df_destDeptCode,
t2.BillCycleNumber as df_BillCycleNumber,
t2.CustomerStatus as df_CustomerStatus,
t2.dialCountIVR as df_dialCountIVR,
t2.Model as df_Model,
t2.BillTypeCode as df_BillTypeCode,
t2.BillAccountName as df_BillAccountName,
t2.utteranceTokenConfidences as df_utteranceTokenConfidences,
t2.BillingSystem as df_BillingSystem,
t2.MDNName as df_MDNName,
t2.ctiCall_Event_Type as df_ctiCall_Event_Type,
t2.callID_1 as df_callID_1,
t2.CustomerContactNumber as df_CustomerContactNumber,
t2.callDispositionInd as df_callDispositionInd,
t2.ctiCallDisconnectTime as df_ctiCallDisconnectTime,
t2.Mtn as df_Mtn,
t2.NumOfAccts as df_NumOfAccts,
t2.InsertFlag as df_InsertFlag,
t2.CustOrigSetupDate as df_CustOrigSetupDate,
t2.OldBillingSystem as df_OldBillingSystem,
t2.CallDataContactName as df_CallDataContactName,
t2.dialCountInter as df_dialCountInter,
t2.ivrValidation as df_ivrValidation,
t2.ivrLanguage as df_ivrLanguage,
t2.Mdn as df_Mdn,
t2.failedDialCountIntra as df_failedDialCountIntra,
t2.MDNContactNumber as df_MDNContactNumber,
t2.xferTFN as df_xferTFN,
t2.ivrAniNumber as df_ivrAniNumber,
t2.inboundOutboundCallType as df_inboundOutboundCallType,
t2.transferReasonDesc as df_transferReasonDesc,
t2.confCount as df_confCount,
t2.CTICallDataCallType as df_CTICallDataCallType,
t2.ServiceName as df_ServiceName,
t2.SIM as df_SIM,
t2.ivrcallid as df_ivrcallid,
t2.utteranceEndTime as df_utteranceEndTime,
t2.speakerId as df_speakerId,
t2.callControlId as df_callControlId,
t2.acss_id as df_acss_id,
t2.sourceappid as df_sourceappid,
t2.MDNStatus as df_MDNStatus,
t2.DepartmentID as df_DepartmentID,
t2.CustomerName as df_CustomerName,
t2.ani as df_ani,
t2.callCenter as df_callCenter,
t2.transcriptionCompleted as df_transcriptionCompleted,
t2.VZEXTN as df_VZEXTN,
t2.CallDataCallType as df_CallDataCallType,
t2.DeviceID as df_DeviceID,
t2.ZipCode as df_ZipCode,
t2.PriceplanId as df_PriceplanId,
t2.CallDataTimeStamp as df_CallDataTimeStamp,
t2.IMEI as df_IMEI,
t2.utteranceNumber as df_utteranceNumber,
t2.lowQualityChannel as df_lowQualityChannel,
t2.acdCallId as df_acdCallId,
t2.BillAccountNumber as df_BillAccountNumber,
t2.CallEstablishedTime as df_CallEstablishedTime,
t2.OBPPEnrollCode as df_OBPPEnrollCode,
t2.CallDataContactType as df_CallDataContactType,
t2.transferReasonCodes as df_transferReasonCodes,
t2.SKU as df_SKU,
t2.dialCount as df_dialCount,
t2.acssCallIdOnXfer as df_acssCallIdOnXfer,
t2.EffectiveDate as df_EffectiveDate,
t2.CallDataContactValidation as df_CallDataContactValidation,
case
when trim(t1.ivrcallid) = trim(t2.ivrcallid)
and t1.utteranceNumber = t2.utteranceNumber
then 1 else 0 end as key_match,
case
when trim(t1.DACCCD) = trim(t2.DACCCD) AND
trim(t1.ServiceRegionID) = trim(t2.ServiceRegionID) AND
trim(t1.SACC) = trim(t2.SACC) AND
trim(t1.acssValidationCode) = trim(t2.acssValidationCode) AND
trim(t1.OldAccountNo) = trim(t2.OldAccountNo) AND
trim(t1.obxBtn) = trim(t2.obxBtn) AND
trim(t1.AccountContactNumber) = trim(t2.AccountContactNumber) AND
t1.captureSeconds = t2.captureSeconds AND
trim(t1.TotalMtnCount) = trim(t2.TotalMtnCount) AND
trim(t1.LanguageInd) = trim(t2.LanguageInd) AND
--t1.timezoneOffset = t2.timezoneOffset AND
trim(t1.VZBTN) = trim(t2.VZBTN) AND
trim(t1.rcHotline) = trim(t2.rcHotline) AND
trim(t1.utterance) = trim(t2.utterance) AND
trim(t1.failedDialCountInter) = trim(t2.failedDialCountInter) AND
t1.utteranceStartTime = t2.utteranceStartTime AND
trim(t1.agentid) = trim(t2.agentid) AND
trim(t1.CtiPopSeqNum) = trim(t2.CtiPopSeqNum) AND
trim(t1.Make) = trim(t2.Make) AND
trim(t1.CustomerId) = trim(t2.CustomerId) AND
trim(t1.CustomerType) = trim(t2.CustomerType) AND
trim(t1.failedDialCountIVR) = trim(t2.failedDialCountIVR) AND
trim(t1.ObxData) = trim(t2.ObxData) AND
trim(t1.GroupIDTiecode) = trim(t2.GroupIDTiecode) AND
trim(t1.BillAccountContactNumber) = trim(t2.BillAccountContactNumber) AND
trim(t1.ctiCallStartTime) = trim(t2.ctiCallStartTime) AND
trim(t1.ECPDID) = trim(t2.ECPDID) AND
trim(t1.AccountName) = trim(t2.AccountName) AND
trim(t1.role) = trim(t2.role) AND
trim(t1.AgentExtension) = trim(t2.AgentExtension) AND
trim(t1.OwningRegionId) = trim(t2.OwningRegionId) AND
t1.droppedPackets = t2.droppedPackets AND
trim(t1.CustomerClassCode) = trim(t2.CustomerClassCode) AND
trim(t1.ivrAni) = trim(t2.ivrAni) AND
trim(t1.MDNCount) = trim(t2.MDNCount) AND
trim(t1.IvrCallMdn) = trim(t2.IvrCallMdn) AND
trim(t1.obxCode) = trim(t2.obxCode) AND
trim(t1.CallDataSrcCallID) = trim(t2.CallDataSrcCallID) AND
trim(t1.ACSSID) = trim(t2.ACSSID) AND
trim(t1.IMSIVF) = trim(t2.IMSIVF) AND
trim(t1.callId) = trim(t2.callId) AND
trim(t1.EUIMID) = trim(t2.EUIMID) AND
trim(t1.CallDataCallEndTimeStamp) = trim(t2.CallDataCallEndTimeStamp) AND
trim(t1.BillAcctStatus) = trim(t2.BillAcctStatus) AND
trim(t1.outboundtype) = trim(t2.outboundtype) AND
trim(t1.CustStatus) = trim(t2.CustStatus) AND
t1.utteranceConfidence = t2.utteranceConfidence AND
trim(t1.CallDataACDCallID) = trim(t2.CallDataACDCallID) AND
trim(t1.transferReasonCode) = trim(t2.transferReasonCode) AND
trim(t1.destDeptCode) = trim(t2.destDeptCode) AND
trim(t1.BillCycleNumber) = trim(t2.BillCycleNumber) AND
trim(t1.CustomerStatus) = trim(t2.CustomerStatus) AND
trim(t1.dialCountIVR) = trim(t2.dialCountIVR) AND
trim(t1.Model) = trim(t2.Model) AND
trim(t1.BillTypeCode) = trim(t2.BillTypeCode) AND
trim(t1.BillAccountName) = trim(t2.BillAccountName) AND
trim(t1.BillingSystem) = trim(t2.BillingSystem) AND
trim(t1.MDNName) = trim(t2.MDNName) AND
trim(t1.ctiCall_Event_Type) = trim(t2.ctiCall_Event_Type) AND
trim(t1.CallDataSrcCallID) = trim(t2.CallDataSrcCallID) AND
trim(t1.ACSSID) = trim(t2.ACSSID) AND
trim(t1.IMSIVF) = trim(t2.IMSIVF) AND
trim(t1.callID_1) = trim(t2.callID_1) AND
trim(t1.EUIMID) = trim(t2.EUIMID) AND
trim(t1.CallDataCallEndTimeStamp) = trim(t2.CallDataCallEndTimeStamp) AND
trim(t1.BillAcctStatus) = trim(t2.BillAcctStatus) AND
trim(t1.outboundtype) = trim(t2.outboundtype) AND
trim(t1.CustStatus) = trim(t2.CustStatus) AND
t1.utteranceConfidence = t2.utteranceConfidence AND
trim(t1.CallDataACDCallID) = trim(t2.CallDataACDCallID) AND
trim(t1.transferReasonCode) = trim(t2.transferReasonCode) AND
trim(t1.destDeptCode) = trim(t2.destDeptCode) AND
trim(t1.BillCycleNumber) = trim(t2.BillCycleNumber) AND
trim(t1.CustomerStatus) = trim(t2.CustomerStatus) AND
trim(t1.dialCountIVR) = trim(t2.dialCountIVR) AND
trim(t1.Model) = trim(t2.Model) AND
trim(t1.BillTypeCode) = trim(t2.BillTypeCode) AND
trim(t1.BillAccountName) = trim(t2.BillAccountName) AND
--trim(t1.utteranceTokenConfidences) = trim(t2.utteranceTokenConfidences) AND
trim(t1.BillingSystem) = trim(t2.BillingSystem) AND
trim(t1.MDNName) = trim(t2.MDNName) AND
trim(t1.ctiCall_Event_Type) = trim(t2.ctiCall_Event_Type) AND
trim(t1.CustomerContactNumber) = trim(t2.CustomerContactNumber) AND
trim(t1.callDispositionInd) = trim(t2.callDispositionInd) AND
trim(t1.ctiCallDisconnectTime) = trim(t2.ctiCallDisconnectTime) AND
trim(t1.Mtn) = trim(t2.Mtn) AND
trim(t1.NumOfAccts) = trim(t2.NumOfAccts) AND
trim(t1.InsertFlag) = trim(t2.InsertFlag) AND
trim(t1.CustOrigSetupDate) = trim(t2.CustOrigSetupDate) AND
trim(t1.OldBillingSystem) = trim(t2.OldBillingSystem) AND
trim(t1.CallDataContactName) = trim(t2.CallDataContactName) AND
trim(t1.dialCountInter) = trim(t2.dialCountInter) AND
trim(t1.ivrValidation) = trim(t2.ivrValidation) AND
trim(t1.ivrLanguage) = trim(t2.ivrLanguage) AND
trim(t1.Mdn) = trim(t2.Mdn) AND
trim(t1.failedDialCountIntra) = trim(t2.failedDialCountIntra) AND
trim(t1.MDNContactNumber) = trim(t2.MDNContactNumber) AND
trim(t1.xferTFN) = trim(t2.xferTFN) AND
trim(t1.ivrAniNumber) = trim(t2.ivrAniNumber) AND
trim(t1.inboundOutboundCallType) = trim(t2.inboundOutboundCallType) AND
trim(t1.transferReasonDesc) = trim(t2.transferReasonDesc) AND
trim(t1.confCount) = trim(t2.confCount) AND
trim(t1.CTICallDataCallType) = trim(t2.CTICallDataCallType) AND
trim(t1.ServiceName) = trim(t2.ServiceName) AND
trim(t1.SIM) = trim(t2.SIM) AND
t1.utteranceEndTime = (t2.utteranceEndTime) AND
t1.speakerId = t2.speakerId AND
trim(t1.callControlId) = trim(t2.callControlId) AND
trim(t1.acss_id) = trim(t2.acss_id) AND
trim(t1.sourceappid) = trim(t2.sourceappid) AND
trim(t1.MDNStatus) = trim(t2.MDNStatus) AND
trim(t1.DepartmentID) = trim(t2.DepartmentID) AND
trim(t1.CustomerName) = trim(t2.CustomerName) AND
trim(t1.ani) = trim(t2.ani) AND
trim(t1.callCenter) = trim(t2.callCenter) AND
(t1.transcriptionCompleted) = (t2.transcriptionCompleted) AND
trim(t1.VZEXTN) = trim(t2.VZEXTN) AND
trim(t1.CallDataCallType) = trim(t2.CallDataCallType) AND
trim(t1.DeviceID) = trim(t2.DeviceID) AND
trim(t1.ZipCode) = trim(t2.ZipCode) AND
trim(t1.PriceplanId) = trim(t2.PriceplanId) AND
trim(t1.CallDataTimeStamp) = trim(t2.CallDataTimeStamp) AND
trim(t1.IMEI) = trim(t2.IMEI) AND
t1.lowQualityChannel = t2.lowQualityChannel AND
trim(t1.acdCallId) = trim(t2.acdCallId) AND
trim(t1.BillAccountNumber) = trim(t2.BillAccountNumber) AND
Floor(t1.CallEstablishedTime) = Floor(t2.CallEstablishedTime) AND
trim(t1.OBPPEnrollCode) = trim(t2.OBPPEnrollCode) AND
trim(t1.CallDataContactType) = trim(t2.CallDataContactType) AND
trim(t1.transferReasonCodes) = trim(t2.transferReasonCodes) AND
trim(t1.SKU) = trim(t2.SKU) AND
trim(t1.dialCount) = trim(t2.dialCount) AND
trim(t1.acssCallIdOnXfer) = trim(t2.acssCallIdOnXfer) AND
trim(t1.EffectiveDate) = trim(t2.EffectiveDate) AND
trim(t1.CallDataContactValidation) = trim(t2.CallDataContactValidation)
then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t1
full outer join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t2
on trim(t1.ivrcallid) = trim(t2.ivrcallid) and t1.utteranceNumber = t2.utteranceNumber
) A;


/*
Compare table count process
*/
-- matched key count
SET MATCH_CNT_V = (select COUNT(*) from (select distinct ivrcallid, utteranceNumber from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t1
inner join
(select distinct ivrcallid, utteranceNumber from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t2
on trim(t1.ivrcallid) = trim(t2.ivrcallid) and t1.utteranceNumber = t2.utteranceNumber
);


-- unmatched records count
SET UNMATCH_CNT_V = (select COUNT(*) FROM (select t1.DACCCD as ibm_DACCCD,
t1.ServiceRegionID as ibm_ServiceRegionID,
t1.SACC as ibm_SACC,
t1.acssValidationCode as ibm_acssValidationCode,
t1.OldAccountNo as ibm_OldAccountNo,
t1.obxBtn as ibm_obxBtn,
t1.AccountContactNumber as ibm_AccountContactNumber,
t1.captureSeconds as ibm_captureSeconds,
t1.TotalMtnCount as ibm_TotalMtnCount,
t1.LanguageInd as ibm_LanguageInd,
t1.timezoneOffset as ibm_timezoneOffset,
t1.VZBTN as ibm_VZBTN,
t1.rcHotline as ibm_rcHotline,
t1.utterance as ibm_utterance,
t1.failedDialCountInter as ibm_failedDialCountInter,
t1.utteranceStartTime as ibm_utteranceStartTime,
t1.agentid as ibm_agentid,
t1.CtiPopSeqNum as ibm_CtiPopSeqNum,
t1.Make as ibm_Make,
t1.CustomerId as ibm_CustomerId,
t1.CustomerType as ibm_CustomerType,
t1.failedDialCountIVR as ibm_failedDialCountIVR,
t1.ObxData as ibm_ObxData,
t1.GroupIDTiecode as ibm_GroupIDTiecode,
t1.BillAccountContactNumber as ibm_BillAccountContactNumber,
t1.ctiCallStartTime as ibm_ctiCallStartTime,
t1.ECPDID as ibm_ECPDID,
t1.AccountName as ibm_AccountName,
t1.role as ibm_role,
t1.AgentExtension as ibm_AgentExtension,
t1.OwningRegionId as ibm_OwningRegionId,
t1.droppedPackets as ibm_droppedPackets,
t1.CustomerClassCode as ibm_CustomerClassCode,
t1.ivrAni as ibm_ivrAni,
t1.MDNCount as ibm_MDNCount,
t1.IvrCallMdn as ibm_IvrCallMdn,
t1.obxCode as ibm_obxCode,
t1.CallDataSrcCallID as ibm_CallDataSrcCallID,
t1.ACSSID as ibm_ACSSID,
t1.callId as ibm_callId,
t1.CallDataCallEndTimeStamp as ibm_CallDataCallEndTimeStamp,
t1.BillAcctStatus as ibm_BillAcctStatus,
t1.outboundtype as ibm_outboundtype,
t1.CustStatus as ibm_CustStatus,
t1.utteranceConfidence as ibm_utteranceConfidence,
t1.CallDataACDCallID as ibm_CallDataACDCallID,
t1.transferReasonCode as ibm_transferReasonCode,
t1.destDeptCode as ibm_destDeptCode,
t1.BillCycleNumber as ibm_BillCycleNumber,
t1.CustomerStatus as ibm_CustomerStatus,
t1.dialCountIVR as ibm_dialCountIVR,
t1.Model as ibm_Model,
t1.BillTypeCode as ibm_BillTypeCode,
t1.BillAccountName as ibm_BillAccountName,
t1.utteranceTokenConfidences as ibm_utteranceTokenConfidences,
t1.BillingSystem as ibm_BillingSystem,
t1.MDNName as ibm_MDNName,
t1.ctiCall_Event_Type as ibm_ctiCall_Event_Type,
t1.IMSIVF as ibm_IMSIVF,
t1.EUIMID as ibm_EUIMID,
t1.CustomerContactNumber as ibm_CustomerContactNumber,
t1.callDispositionInd as ibm_callDispositionInd,
t1.ctiCallDisconnectTime as ibm_ctiCallDisconnectTime,
t1.Mtn as ibm_Mtn,
t1.NumOfAccts as ibm_NumOfAccts,
t1.InsertFlag as ibm_InsertFlag,
t1.CustOrigSetupDate as ibm_CustOrigSetupDate,
t1.OldBillingSystem as ibm_OldBillingSystem,
t1.CallDataContactName as ibm_CallDataContactName,
t1.dialCountInter as ibm_dialCountInter,
t1.ivrValidation as ibm_ivrValidation,
t1.ivrLanguage as ibm_ivrLanguage,
t1.Mdn as ibm_Mdn,
t1.failedDialCountIntra as ibm_failedDialCountIntra,
t1.MDNContactNumber as ibm_MDNContactNumber,
t1.xferTFN as ibm_xferTFN,
t1.ivrAniNumber as ibm_ivrAniNumber,
t1.inboundOutboundCallType as ibm_inboundOutboundCallType,
t1.transferReasonDesc as ibm_transferReasonDesc,
t1.confCount as ibm_confCount,
t1.CTICallDataCallType as ibm_CTICallDataCallType,
t1.ServiceName as ibm_ServiceName,
t1.SIM as ibm_SIM,
t1.ivrcallid as ibm_ivrcallid,
t1.utteranceEndTime as ibm_utteranceEndTime,
t1.callID_1 as ibm_callID_1,
t1.speakerId as ibm_speakerId,
t1.callControlId as ibm_callControlId,
t1.acss_id as ibm_acss_id,
t1.sourceappid as ibm_sourceappid,
t1.MDNStatus as ibm_MDNStatus,
t1.DepartmentID as ibm_DepartmentID,
t1.CustomerName as ibm_CustomerName,
t1.ani as ibm_ani,
t1.callCenter as ibm_callCenter,
t1.transcriptionCompleted as ibm_transcriptionCompleted,
t1.VZEXTN as ibm_VZEXTN,
t1.CallDataCallType as ibm_CallDataCallType,
t1.DeviceID as ibm_DeviceID,
t1.ZipCode as ibm_ZipCode,
t1.PriceplanId as ibm_PriceplanId,
t1.CallDataTimeStamp as ibm_CallDataTimeStamp,
t1.IMEI as ibm_IMEI,
t1.utteranceNumber as ibm_utteranceNumber,
t1.lowQualityChannel as ibm_lowQualityChannel,
t1.acdCallId as ibm_acdCallId,
t1.BillAccountNumber as ibm_BillAccountNumber,
t1.CallEstablishedTime as ibm_CallEstablishedTime,
t1.OBPPEnrollCode as ibm_OBPPEnrollCode,
t1.CallDataContactType as ibm_CallDataContactType,
t1.transferReasonCodes as ibm_transferReasonCodes,
t1.SKU as ibm_SKU,
t1.dialCount as ibm_dialCount,
t1.acssCallIdOnXfer as ibm_acssCallIdOnXfer,
t1.EffectiveDate as ibm_EffectiveDate,
t1.CallDataContactValidation as ibm_CallDataContactValidation,
t2.DACCCD as df_DACCCD,
t2.ServiceRegionID as df_ServiceRegionID,
t2.SACC as df_SACC,
t2.acssValidationCode as df_acssValidationCode,
t2.OldAccountNo as df_OldAccountNo,
t2.obxBtn as df_obxBtn,
t2.AccountContactNumber as df_AccountContactNumber,
t2.captureSeconds as df_captureSeconds,
t2.TotalMtnCount as df_TotalMtnCount,
t2.LanguageInd as df_LanguageInd,
t2.timezoneOffset as df_timezoneOffset,
t2.VZBTN as df_VZBTN,
t2.rcHotline as df_rcHotline,
t2.utterance as df_utterance,
t2.failedDialCountInter as df_failedDialCountInter,
t2.utteranceStartTime as df_utteranceStartTime,
t2.agentid as df_agentid,
t2.CtiPopSeqNum as df_CtiPopSeqNum,
t2.Make as df_Make,
t2.CustomerId as df_CustomerId,
t2.CustomerType as df_CustomerType,
t2.failedDialCountIVR as df_failedDialCountIVR,
t2.ObxData as df_ObxData,
t2.GroupIDTiecode as df_GroupIDTiecode,
t2.BillAccountContactNumber as df_BillAccountContactNumber,
t2.ctiCallStartTime as df_ctiCallStartTime,
t2.ECPDID as df_ECPDID,
t2.AccountName as df_AccountName,
t2.role as df_role,
t2.AgentExtension as df_AgentExtension,
t2.OwningRegionId as df_OwningRegionId,
t2.droppedPackets as df_droppedPackets,
t2.CustomerClassCode as df_CustomerClassCode,
t2.ivrAni as df_ivrAni,
t2.MDNCount as df_MDNCount,
t2.IvrCallMdn as df_IvrCallMdn,
t2.obxCode as df_obxCode,
t2.CallDataSrcCallID as df_CallDataSrcCallID,
t2.ACSSID as df_ACSSID,
t2.IMSIVF as df_IMSIVF,
t2.callId as df_callId,
t2.EUIMID as df_EUIMID,
t2.CallDataCallEndTimeStamp as df_CallDataCallEndTimeStamp,
t2.BillAcctStatus as df_BillAcctStatus,
t2.outboundtype as df_outboundtype,
t2.CustStatus as df_CustStatus,
t2.utteranceConfidence as df_utteranceConfidence,
t2.CallDataACDCallID as df_CallDataACDCallID,
t2.transferReasonCode as df_transferReasonCode,
t2.destDeptCode as df_destDeptCode,
t2.BillCycleNumber as df_BillCycleNumber,
t2.CustomerStatus as df_CustomerStatus,
t2.dialCountIVR as df_dialCountIVR,
t2.Model as df_Model,
t2.BillTypeCode as df_BillTypeCode,
t2.BillAccountName as df_BillAccountName,
t2.utteranceTokenConfidences as df_utteranceTokenConfidences,
t2.BillingSystem as df_BillingSystem,
t2.MDNName as df_MDNName,
t2.ctiCall_Event_Type as df_ctiCall_Event_Type,
t2.callID_1 as df_callID_1,
t2.CustomerContactNumber as df_CustomerContactNumber,
t2.callDispositionInd as df_callDispositionInd,
t2.ctiCallDisconnectTime as df_ctiCallDisconnectTime,
t2.Mtn as df_Mtn,
t2.NumOfAccts as df_NumOfAccts,
t2.InsertFlag as df_InsertFlag,
t2.CustOrigSetupDate as df_CustOrigSetupDate,
t2.OldBillingSystem as df_OldBillingSystem,
t2.CallDataContactName as df_CallDataContactName,
t2.dialCountInter as df_dialCountInter,
t2.ivrValidation as df_ivrValidation,
t2.ivrLanguage as df_ivrLanguage,
t2.Mdn as df_Mdn,
t2.failedDialCountIntra as df_failedDialCountIntra,
t2.MDNContactNumber as df_MDNContactNumber,
t2.xferTFN as df_xferTFN,
t2.ivrAniNumber as df_ivrAniNumber,
t2.inboundOutboundCallType as df_inboundOutboundCallType,
t2.transferReasonDesc as df_transferReasonDesc,
t2.confCount as df_confCount,
t2.CTICallDataCallType as df_CTICallDataCallType,
t2.ServiceName as df_ServiceName,
t2.SIM as df_SIM,
t2.ivrcallid as df_ivrcallid,
t2.utteranceEndTime as df_utteranceEndTime,
t2.speakerId as df_speakerId,
t2.callControlId as df_callControlId,
t2.acss_id as df_acss_id,
t2.sourceappid as df_sourceappid,
t2.MDNStatus as df_MDNStatus,
t2.DepartmentID as df_DepartmentID,
t2.CustomerName as df_CustomerName,
t2.ani as df_ani,
t2.callCenter as df_callCenter,
t2.transcriptionCompleted as df_transcriptionCompleted,
t2.VZEXTN as df_VZEXTN,
t2.CallDataCallType as df_CallDataCallType,
t2.DeviceID as df_DeviceID,
t2.ZipCode as df_ZipCode,
t2.PriceplanId as df_PriceplanId,
t2.CallDataTimeStamp as df_CallDataTimeStamp,
t2.IMEI as df_IMEI,
t2.utteranceNumber as df_utteranceNumber,
t2.lowQualityChannel as df_lowQualityChannel,
t2.acdCallId as df_acdCallId,
t2.BillAccountNumber as df_BillAccountNumber,
t2.CallEstablishedTime as df_CallEstablishedTime,
t2.OBPPEnrollCode as df_OBPPEnrollCode,
t2.CallDataContactType as df_CallDataContactType,
t2.transferReasonCodes as df_transferReasonCodes,
t2.SKU as df_SKU,
t2.dialCount as df_dialCount,
t2.acssCallIdOnXfer as df_acssCallIdOnXfer,
t2.EffectiveDate as df_EffectiveDate,
t2.CallDataContactValidation as df_CallDataContactValidation,
case
when trim(t1.ivrcallid) = trim(t2.ivrcallid)
and t1.utteranceNumber = t2.utteranceNumber
then 1 else 0 end as key_match,
case
when trim(t1.DACCCD) = trim(t2.DACCCD) AND
trim(t1.ServiceRegionID) = trim(t2.ServiceRegionID) AND
trim(t1.SACC) = trim(t2.SACC) AND
trim(t1.acssValidationCode) = trim(t2.acssValidationCode) AND
trim(t1.OldAccountNo) = trim(t2.OldAccountNo) AND
trim(t1.obxBtn) = trim(t2.obxBtn) AND
trim(t1.AccountContactNumber) = trim(t2.AccountContactNumber) AND
t1.captureSeconds = t2.captureSeconds AND
trim(t1.TotalMtnCount) = trim(t2.TotalMtnCount) AND
trim(t1.LanguageInd) = trim(t2.LanguageInd) AND
--t1.timezoneOffset = t2.timezoneOffset AND
trim(t1.VZBTN) = trim(t2.VZBTN) AND
trim(t1.rcHotline) = trim(t2.rcHotline) AND
trim(t1.utterance) = trim(t2.utterance) AND
trim(t1.failedDialCountInter) = trim(t2.failedDialCountInter) AND
t1.utteranceStartTime = t2.utteranceStartTime AND
trim(t1.agentid) = trim(t2.agentid) AND
trim(t1.CtiPopSeqNum) = trim(t2.CtiPopSeqNum) AND
trim(t1.Make) = trim(t2.Make) AND
trim(t1.CustomerId) = trim(t2.CustomerId) AND
trim(t1.CustomerType) = trim(t2.CustomerType) AND
trim(t1.failedDialCountIVR) = trim(t2.failedDialCountIVR) AND
trim(t1.ObxData) = trim(t2.ObxData) AND
trim(t1.GroupIDTiecode) = trim(t2.GroupIDTiecode) AND
trim(t1.BillAccountContactNumber) = trim(t2.BillAccountContactNumber) AND
trim(t1.ctiCallStartTime) = trim(t2.ctiCallStartTime) AND
trim(t1.ECPDID) = trim(t2.ECPDID) AND
trim(t1.AccountName) = trim(t2.AccountName) AND
trim(t1.role) = trim(t2.role) AND
trim(t1.AgentExtension) = trim(t2.AgentExtension) AND
trim(t1.OwningRegionId) = trim(t2.OwningRegionId) AND
t1.droppedPackets = t2.droppedPackets AND
trim(t1.CustomerClassCode) = trim(t2.CustomerClassCode) AND
trim(t1.ivrAni) = trim(t2.ivrAni) AND
trim(t1.MDNCount) = trim(t2.MDNCount) AND
trim(t1.IvrCallMdn) = trim(t2.IvrCallMdn) AND
trim(t1.obxCode) = trim(t2.obxCode) AND
trim(t1.CallDataSrcCallID) = trim(t2.CallDataSrcCallID) AND
trim(t1.ACSSID) = trim(t2.ACSSID) AND
trim(t1.IMSIVF) = trim(t2.IMSIVF) AND
trim(t1.callId) = trim(t2.callId) AND
trim(t1.EUIMID) = trim(t2.EUIMID) AND
trim(t1.CallDataCallEndTimeStamp) = trim(t2.CallDataCallEndTimeStamp) AND
trim(t1.BillAcctStatus) = trim(t2.BillAcctStatus) AND
trim(t1.outboundtype) = trim(t2.outboundtype) AND
trim(t1.CustStatus) = trim(t2.CustStatus) AND
t1.utteranceConfidence = t2.utteranceConfidence AND
trim(t1.CallDataACDCallID) = trim(t2.CallDataACDCallID) AND
trim(t1.transferReasonCode) = trim(t2.transferReasonCode) AND
trim(t1.destDeptCode) = trim(t2.destDeptCode) AND
trim(t1.BillCycleNumber) = trim(t2.BillCycleNumber) AND
trim(t1.CustomerStatus) = trim(t2.CustomerStatus) AND
trim(t1.dialCountIVR) = trim(t2.dialCountIVR) AND
trim(t1.Model) = trim(t2.Model) AND
trim(t1.BillTypeCode) = trim(t2.BillTypeCode) AND
trim(t1.BillAccountName) = trim(t2.BillAccountName) AND
--trim(t1.utteranceTokenConfidences) = trim(t2.utteranceTokenConfidences) AND
trim(t1.BillingSystem) = trim(t2.BillingSystem) AND
trim(t1.MDNName) = trim(t2.MDNName) AND
trim(t1.ctiCall_Event_Type) = trim(t2.ctiCall_Event_Type) AND
trim(t1.CallDataSrcCallID) = trim(t2.CallDataSrcCallID) AND
trim(t1.ACSSID) = trim(t2.ACSSID) AND
trim(t1.IMSIVF) = trim(t2.IMSIVF) AND
trim(t1.callID_1) = trim(t2.callID_1) AND
trim(t1.EUIMID) = trim(t2.EUIMID) AND
trim(t1.CallDataCallEndTimeStamp) = trim(t2.CallDataCallEndTimeStamp) AND
trim(t1.BillAcctStatus) = trim(t2.BillAcctStatus) AND
trim(t1.outboundtype) = trim(t2.outboundtype) AND
trim(t1.CustStatus) = trim(t2.CustStatus) AND
t1.utteranceConfidence = t2.utteranceConfidence AND
trim(t1.CallDataACDCallID) = trim(t2.CallDataACDCallID) AND
trim(t1.transferReasonCode) = trim(t2.transferReasonCode) AND
trim(t1.destDeptCode) = trim(t2.destDeptCode) AND
trim(t1.BillCycleNumber) = trim(t2.BillCycleNumber) AND
trim(t1.CustomerStatus) = trim(t2.CustomerStatus) AND
trim(t1.dialCountIVR) = trim(t2.dialCountIVR) AND
trim(t1.Model) = trim(t2.Model) AND
trim(t1.BillTypeCode) = trim(t2.BillTypeCode) AND
trim(t1.BillAccountName) = trim(t2.BillAccountName) AND
trim(t1.BillingSystem) = trim(t2.BillingSystem) AND
trim(t1.MDNName) = trim(t2.MDNName) AND
trim(t1.ctiCall_Event_Type) = trim(t2.ctiCall_Event_Type) AND
trim(t1.CustomerContactNumber) = trim(t2.CustomerContactNumber) AND
trim(t1.callDispositionInd) = trim(t2.callDispositionInd) AND
trim(t1.ctiCallDisconnectTime) = trim(t2.ctiCallDisconnectTime) AND
trim(t1.Mtn) = trim(t2.Mtn) AND
trim(t1.NumOfAccts) = trim(t2.NumOfAccts) AND
trim(t1.InsertFlag) = trim(t2.InsertFlag) AND
trim(t1.CustOrigSetupDate) = trim(t2.CustOrigSetupDate) AND
trim(t1.OldBillingSystem) = trim(t2.OldBillingSystem) AND
trim(t1.CallDataContactName) = trim(t2.CallDataContactName) AND
trim(t1.dialCountInter) = trim(t2.dialCountInter) AND
trim(t1.ivrValidation) = trim(t2.ivrValidation) AND
trim(t1.ivrLanguage) = trim(t2.ivrLanguage) AND
trim(t1.Mdn) = trim(t2.Mdn) AND
trim(t1.failedDialCountIntra) = trim(t2.failedDialCountIntra) AND
trim(t1.MDNContactNumber) = trim(t2.MDNContactNumber) AND
trim(t1.xferTFN) = trim(t2.xferTFN) AND
trim(t1.ivrAniNumber) = trim(t2.ivrAniNumber) AND
trim(t1.inboundOutboundCallType) = trim(t2.inboundOutboundCallType) AND
trim(t1.transferReasonDesc) = trim(t2.transferReasonDesc) AND
trim(t1.confCount) = trim(t2.confCount) AND
trim(t1.CTICallDataCallType) = trim(t2.CTICallDataCallType) AND
trim(t1.ServiceName) = trim(t2.ServiceName) AND
trim(t1.SIM) = trim(t2.SIM) AND
t1.utteranceEndTime = (t2.utteranceEndTime) AND
t1.speakerId = t2.speakerId AND
trim(t1.callControlId) = trim(t2.callControlId) AND
trim(t1.acss_id) = trim(t2.acss_id) AND
trim(t1.sourceappid) = trim(t2.sourceappid) AND
trim(t1.MDNStatus) = trim(t2.MDNStatus) AND
trim(t1.DepartmentID) = trim(t2.DepartmentID) AND
trim(t1.CustomerName) = trim(t2.CustomerName) AND
trim(t1.ani) = trim(t2.ani) AND
trim(t1.callCenter) = trim(t2.callCenter) AND
(t1.transcriptionCompleted) = (t2.transcriptionCompleted) AND
trim(t1.VZEXTN) = trim(t2.VZEXTN) AND
trim(t1.CallDataCallType) = trim(t2.CallDataCallType) AND
trim(t1.DeviceID) = trim(t2.DeviceID) AND
trim(t1.ZipCode) = trim(t2.ZipCode) AND
trim(t1.PriceplanId) = trim(t2.PriceplanId) AND
trim(t1.CallDataTimeStamp) = trim(t2.CallDataTimeStamp) AND
trim(t1.IMEI) = trim(t2.IMEI) AND
t1.lowQualityChannel = t2.lowQualityChannel AND
trim(t1.acdCallId) = trim(t2.acdCallId) AND
trim(t1.BillAccountNumber) = trim(t2.BillAccountNumber) AND
Floor(t1.CallEstablishedTime) = Floor(t2.CallEstablishedTime) AND
trim(t1.OBPPEnrollCode) = trim(t2.OBPPEnrollCode) AND
trim(t1.CallDataContactType) = trim(t2.CallDataContactType) AND
trim(t1.transferReasonCodes) = trim(t2.transferReasonCodes) AND
trim(t1.SKU) = trim(t2.SKU) AND
trim(t1.dialCount) = trim(t2.dialCount) AND
trim(t1.acssCallIdOnXfer) = trim(t2.acssCallIdOnXfer) AND
trim(t1.EffectiveDate) = trim(t2.EffectiveDate) AND
trim(t1.CallDataContactValidation) = trim(t2.CallDataContactValidation)
then 1 else 0 end as field_match
from
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t1
inner join
(select * from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V) t2
on trim(t1.ivrcallid) = trim(t2.ivrcallid) and t1.utteranceNumber = t2.utteranceNumber
)A where field_match=0);

-- unmatched keys count in ibm table
SET IBM_UNMATCH_CNT_V = (select COUNT(*) from (select distinct ivrcallid, utteranceNumber from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` t1
where timestamp_seconds(SAFE_CAST(Floor(t1.CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(t1.CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V and not exists (
select distinct ivrcallid, utteranceNumber
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` t2
where trim(t1.ivrcallid) = trim(t2.ivrcallid) and t1.utteranceNumber = t2.utteranceNumber
and timestamp_seconds(SAFE_CAST(Floor(t2.CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(t2.CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V
)));


-- unmatched keys count in df table
SET DF_UNMATCH_CNT_V = (select COUNT(*) from (select distinct ivrcallid, utteranceNumber from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` t1
where timestamp_seconds(SAFE_CAST(Floor(t1.CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(t1.CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V and not exists (
select distinct ivrcallid, utteranceNumber
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` t2
where trim(t1.ivrcallid) = trim(t2.ivrcallid) and t1.utteranceNumber = t2.utteranceNumber
and timestamp_seconds(SAFE_CAST(Floor(t2.CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(t2.CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V
)));

-- TOTAL COUNT FOR IBM TABLE
SET IBM_TOTAL_CNT_V = (select COUNT(*) from (select distinct ivrcallid, utteranceNumber
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_ibm_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V));

-- TOTAL COUNT FOR DF TABLE
SET DF_TOTAL_CNT_V = (select COUNT(*) from (select distinct ivrcallid, utteranceNumber
from `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_rts_ctimerge_df_event` where timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) >= PROCESS_START_TS_V and timestamp_seconds(SAFE_CAST(Floor(CallEstablishedTime) as INTEGER)) <= PROCESS_END_TS_V));

--Delete and load into the event metrics table for the specific day

DELETE FROM `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics` WHERE PROCESS_START_TS = STRING(PROCESS_START_TS_V) AND PROCESS_END_TS = STRING(PROCESS_END_TS_V) AND jobname = JOBNAME_V;
INSERT INTO `vz-it-pr-gh2v-rtstdo-0.vzw_rtmod_prd_tbls_data.rtmod_parrun_cmp_metrics`
VALUES(JOBNAME_V,IBM_UNMATCH_CNT_V,DF_UNMATCH_CNT_V,IBM_TOTAL_CNT_V,DF_TOTAL_CNT_V,MATCH_CNT_V,UNMATCH_CNT_V,'DAILY',STRING(PROCESS_START_TS_V),STRING(PROCESS_END_TS_V),current_timestamp);

End;