#############################################################################
#the script is to create a DAG using the configuration                      #
#command to execute: python dataflow_dag.py                            		#
#############################################################################

import os
from datetime import datetime
from datetime import timedelta
from pathlib import Path

from airflow.models.dag import DAG

from airflow.providers.google.cloud.hooks.dataflow import DataflowHook
from airflow.exceptions import AirflowException
from airflow.providers.google.cloud.hooks.dataflow import DataflowJobStatus

from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator

import argparse
import json
#from airflow.models import Variable

#_variables = Variable.get("cee_dataflow_dag", deserialize_json=True)

# Command line arguments
""" parser = argparse.ArgumentParser(description='RT CEE Batch Flex DAG Creation')
parser.add_argument('--config',required=True, help='Specify DAG configuration to be used')
parser.add_argument('--email',required=True, help='Specify MailId to provide updates')
parser.add_argument('--hookConnId',required=True, help='Specify DAG Hook Connection Id to be used')
parser.add_argument('--taskId',required=True, help='Specify DAG TaskId to be used')

args = parser.parse_args()
 """

""" _json_file_name = args.config
_email_reciever = args.email
_hook_conn_id = args.hookConnId
_task_id = args.taskId """

_json_file_name = "/home/airflow/gcs/dags/vz-it-gh2v-rtstdo-0/config/CustEdwDagConfig.json"

print("JSON file : ",_json_file_name)

with open(_json_file_name) as json_file:
    _variables = json.load(json_file)

print("Project ID : ",_variables["cee_dataflow_dag"]["project_id"])
print("DAG ID : ",_variables["cee_dataflow_dag"]["dag_id"])
print("DAG Location : ",_variables["cee_dataflow_dag"]["job_location"])     

PROJECT_ID = _variables["cee_dataflow_dag"]["project_id"]
DAG_ID = _variables["cee_dataflow_dag"]["dag_id"]
JOB_CONFIG = _variables["cee_dataflow_dag"]["job_config"]
JOB_LOCATION = _variables["cee_dataflow_dag"]["job_location"]

_email_reciever = _variables["cee_dataflow_dag"]["email_reciever"]
_hook_conn_id = _variables["cee_dataflow_dag"]["hook_conn_id"]
_task_id = _variables["cee_dataflow_dag"]["task_id"]

_email_on_retry = _variables["cee_dataflow_dag"]["email_on_retry"]
_email_on_failure = _variables["cee_dataflow_dag"]["email_on_failure"]
_max_retry_delay_min = _variables["cee_dataflow_dag"]["max_retry_delay_min"]

_schedule_interval = _variables["cee_dataflow_dag"]["schedule_interval"]

_source_bucket = _variables["cee_dataflow_dag"]["source_bucket"]
_source_objects = _variables["cee_dataflow_dag"]["source_objects"]
_destination_bucket = _variables["cee_dataflow_dag"]["destination_bucket"]
_destination_object = _variables["cee_dataflow_dag"]["destination_object"]



def submit_dataflow_job():
    # declare the variables
    # "sa-vz-it-gh2v-rtstdo-0-app"
    dataflow_hook = DataflowHook(gcp_conn_id=_hook_conn_id)

    start_template_dataflow_output = dataflow_hook.start_flex_template(
        project_id=PROJECT_ID,
        body=JOB_CONFIG,
        location=JOB_LOCATION)

dag_default_args = {	
        "email": [_email_reciever],
        "email_on_failure": _email_on_failure,
        "email_on_retry": _email_on_retry,
        "retries": 1,
        "retry_delay": timedelta(minutes=_max_retry_delay_min),
        "start_date":datetime(2024,3,1)
    }

with DAG(
        DAG_ID,
        default_args=dag_default_args,
        #schedule="@daily",
        start_date=datetime(2024,3,1),
        tags=['version:1.0','rt-cee-df-batch'],
        #schedule_interval="0 0 * * *",
        schedule_interval=_schedule_interval,
        catchup=False,
)as dag:
    from airflow.operators.python_operator import PythonOperator
    Dataflow_batch_hook = PythonOperator(
        #task_id='rt-cee-dataflow-flex-batch-hook',
        task_id = _task_id,
        python_callable=submit_dataflow_job
    )
    
    from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
    Processed_file = GCSToGCSOperator(
    task_id = 'Processed_file',
    source_bucket = _source_bucket,
    source_objects=[_source_objects],
    destination_bucket=_destination_bucket,
    destination_object=_destination_object,
    #exact_match=True,
    #move_object=True,
    match_glob='**/*.csv',
    gcp_conn_id='sa-vz-it-gh2v-rtstdo-0-app'
    )
    
    
    from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
    source_file_deletion = GCSDeleteObjectsOperator(
    task_id = 'source_file_deletion',
    bucket_name = _source_bucket,  # Replace with your GCS bucket name
    #objects = [_source_objects+'test.csv'], 
    prefix = _source_objects,
    # List of object names to delete
    gcp_conn_id='sa-vz-it-gh2v-rtstdo-0-app'
    )
    Dataflow_batch_hook >> Processed_file >> source_file_deletion